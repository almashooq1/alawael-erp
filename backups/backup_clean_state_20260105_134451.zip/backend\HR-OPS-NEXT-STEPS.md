# HR / Operations Next Steps Roadmap

This document outlines the upcoming iterations to evolve the initial HR, Payroll, LMS, Quality, Compliance, and Analytics services into a production-grade, intelligent, event-driven platform.

## 1. Persistence Layer

- Adopt PostgreSQL for transactional data (employees, licenses, payroll runs, courses, incidents, policies).
- Suggested schema fragments:
  - employees(id PK, name, role, department, status, joined_at TIMESTAMPTZ)
  - licenses(id PK, employee_id FK, authority, issued_at, expires_at, status)
  - payroll_runs(id PK, employee_id FK, period, gross NUMERIC, deductions NUMERIC, net NUMERIC, at TIMESTAMPTZ)
  - courses(id PK, title, mandatory BOOLEAN, duration_hours INT)
  - enrollments(id PK, employee_id FK, course_id FK, status, progress INT, updated_at TIMESTAMPTZ)
  - incidents(id PK, employee_id FK NULL, severity, type, description, status, reported_at TIMESTAMPTZ)
  - policies(id PK, title, version, status, published_at TIMESTAMPTZ)
- Introduce Knex / Prisma (evaluate) with migration strategy and idempotent seeds.

## 2. Event Envelope Standardization

Use common envelope across domains:

```json
{
  "id": "uuid",
  "type": "EVENT_TYPE",
  "occurredAt": "2025-11-12T12:34:56.000Z",
  "source": "hr-service",
  "traceId": "...",
  "payload": {
    /* domain fields */
  }
}
```

Add versioning header (`eventVersion`) and optional `schemaRef` for validation.

## 3. Streaming Infrastructure

- Promote Kafka/NATS from optional to required; define topics per bounded context or single `domain.events` with key = employeeId (for partition locality).
- Implement consumers:
  - Analytics service: subscribe & update aggregates (replaces HTTP ingestion).
  - Notification service (future): license expiry, incident escalation.
- Add DLQ (dead-letter queue) topic for failed consumer processing.

## 4. Outbox Hardening

- Persist outbox in each service DB with states: pending, published, failed.
- Background publisher with exponential backoff + circuit breaker.
- Metrics: publish retry counts, age histogram of pending rows.
- Add cleanup job (transition success > retention window to archived table).

## 5. Analytics Evolution

- Move aggregates to relational store or specialized OLAP (ClickHouse) for time-series & rollups.
- Add materialized views: payroll_monthly_totals, training_completion_rate.
- Support time-window queries (last 7d, MTD, QTD) with precomputed snapshots.

## 6. Alerting & SLOs

- Define SLOs (license expiry notice lead time, incident acknowledgment time, payroll completion window).
- Emit alert events when thresholds breached; integrate with Prometheus Alertmanager.
- Grafana dashboard enhancements: per-service error budget, license expiry forecast.

## 7. Tracing Enhancements

- Add semantic attributes: `employee.id`, `incident.severity`, `policy.version` on spans.
- Use span links for cross-service workflows (e.g., payroll run referencing attendance retrieval spans).

## 8. Security & Compliance

- Introduce JWT + RBAC middleware (roles: HR_ADMIN, PAYROLL_OFFICER, QUALITY_ANALYST, COMPLIANCE_MANAGER).
- Field-level encryption (salary figures) using shared crypto module.
- Audit log signatures (hash chain) for tamper evidence.

## 9. Intelligence Layer

- Feature store of derived signals: attendance reliability score, compliance risk score.
- Train simple classification model for incident severity prediction & license renewal prioritization.
- Use background batch job to enrich events with predictive fields.

## 10. API Gateway & Aggregation

- Unified GraphQL or BFF service to compose cross-domain data (employee profile with payroll summary & compliance status).
- Implement caching (Redis) for high-frequency queries.

## 11. Testing & Quality

- Per-service Jest config (ESM stable) & contract tests using Pact for event payloads.
- Load testing (k6 / Artillery) for peak payroll batch runs.

## 12. Deployment & DevOps

- Containerize each service; use Helm charts for Kubernetes.
- GitHub Actions workflow: lint, test, build image, publish, deploy with canary strategy.
- Observability auto-provision (dashboards packaged as ConfigMaps).

## 13. Data Governance

- Schema registry for event payloads (Avro/JSON Schema) with compatibility checks.
- PII classification & masking in analytics export.

## 14. Backfill & Replay

- Replay utility: read historical events from archive or outbox published table to rebuild analytics or fix missed consumer states.
- Idempotency keys ensure safe reprocessing.

## 15. Internationalization

- Support multi-language course titles & policy documents (store translation table).

## Immediate Next Sprint Candidates

1. Persistence introduction (employees, licenses, payroll_runs).
2. Standard event envelope & schema validation.
3. Kafka consumer for analytics (replace HTTP ingestion).
4. Outbox persistence & retry metrics.

---

This roadmap will evolve; treat items as backlog epics. Prioritize by operational risk reduction & value delivery.
