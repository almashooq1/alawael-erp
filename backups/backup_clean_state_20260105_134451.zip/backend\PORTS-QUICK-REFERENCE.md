# Local service ports (quick reference)

Use this table to quickly find which service should be listening on a given local port when running directly (outside the readiness contract runner which uses ephemeral ports).

- analytics-service: 3061
  - Start: from `backend/analytics-service` run `npm run start` (wrapper) or `npm run local`
  - Health: http://127.0.0.1:3061/health
- denial-management-service: 3076
  - Start: from `backend/denial-management-service` run `npm start`
  - Health: http://127.0.0.1:3076/health
- stamps-service: 3076 (same default as denial-management-service)
  - Note: Don’t run both on the same machine without setting different `PORT` (e.g., `PORT=3077`)
- documents-service: 3072
  - Start: from `backend/documents-service` run `npm start`
  - Health: http://127.0.0.1:3072/health
- homecare-transport-service: 3080
  - Start: from `backend/homecare-transport-service` run `npm start`
  - Health: http://127.0.0.1:3080/health
- admin-comms-service: 3081
  - Start: from `backend/admin-comms-service` run `npm start`
  - Health: http://127.0.0.1:3081/health
- attendance-service: 3001
  - Start: from `backend/attendance-service` run `npm start`
  - Health: http://127.0.0.1:3001/health
- scheduling-service: 3002
  - Start: from `backend/scheduling-service` run `npm start`
  - Health: http://127.0.0.1:3002/health

Notes

- The readiness contract test does NOT use the above ports. It starts each service on a temporary port (41000 + index) via a runner, to avoid conflicts.
- If a port probe like `http://127.0.0.1:3061/health` fails, ensure the corresponding service is running locally, or adjust the port via `PORT` env.
- On Windows PowerShell, set a one-time port when starting a service like:
  - $env:PORT='3077'; npm start

Optional: quick health probes for Windows

- Analytics: Invoke-WebRequest -UseBasicParsing http://127.0.0.1:3061/health
- Denials: Invoke-WebRequest -UseBasicParsing http://127.0.0.1:3076/health
- Admin Comms: Invoke-WebRequest -UseBasicParsing http://127.0.0.1:3081/health

Helper script (Windows)

- Start analytics (3061), denials (3076), documents (3072), and transport (3080), then check health automatically:
  - backend/scripts/windows/dev-start-and-check.ps1
  - From repo root, you can now run: npm run dev:up
  - Examples:
    - Start all with defaults: .\scripts\windows\dev-start-and-check.ps1
    - Start only analytics and transport: .\scripts\windows\dev-start-and-check.ps1 -SkipDenials -SkipDocuments
    - Override denials port: .\scripts\windows\dev-start-and-check.ps1 -DenialsPort 3077
    - Override transport port: .\scripts\windows\dev-start-and-check.ps1 -TransportPort 3081
