# Backend

Node.js + Express/Fastify services for the ERP system.

## Quick Start

- Install dependencies: `npm install`
- Start: `npm start`

## Environment & Observability

- In development, services auto-load `.env` via `backend/shared/env.js`.
- Observability is initialized at startup via `backend/shared/observability.js` (Sentry + Application Insights). Set `SENTRY_DSN` and `APPINSIGHTS_INSTRUMENTATIONKEY` in your environment or `.env`.
- Optional messaging broker: set `EVENT_BUS_IMPL=nats` and `NATS_SERVERS` to enable NATS in the shared `EventBus`.

## Tests

- Smoke validation: `node backend/shared/event-schemas/validate-all-smoke.mjs ; node backend/shared/event-schemas/check-sync.mjs`
- Trace propagation: `npm test -- backend/shared/event-bus/__tests__/trace-context.test.js`

## NATS E2E Trace Test

- Enable NATS: set `EVENT_BUS_IMPL=nats` and `NATS_SERVERS` (e.g., `NATS_SERVERS=nats://localhost:4222`).
- Run: `npm test -- integration-tests/nats.trace.e2e.spec.js`
- Asserts that `traceparent` and `correlationId` are preserved end-to-end via NATS.

## CI Quick Reference

- Smoke CI runs on PRs: schema validation + contracts/idempotency/traceprop.
- Opt-in DB suites: trigger `CI Opt-in DB Suites` via Actions "Run workflow" or add PR label `run-db-tests`.
- Opt-in NATS E2E: trigger `CI NATS E2E (Opt-in)` via Actions or add PR label `run-nats-e2e`.
- Local smoke commands (PowerShell):
  - `node backend/shared/event-schemas/validate-all-smoke.mjs`
  - `node backend/shared/event-schemas/check-sync.mjs`
  - `npm test -- integration-tests/events.contracts.spec.js`
  - `npm test -- integration-tests/events.idempotency.spec.js`
  - `npm test -- integration-tests/events.traceprop.spec.js`
