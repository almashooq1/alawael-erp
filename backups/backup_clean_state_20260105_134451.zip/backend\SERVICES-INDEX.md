# 📋 فهرس جميع الخدمات - Services Index

**التاريخ:** 2025-01-10  
**آخر تحديث:** 2025-01-10

---

## 🎯 الأنظمة الجديدة (9 أنظمة)

### 1. 🏆 Gamification Service

- **المنفذ:** 3032
- **المسار:** `backend/gamification-service/`
- **Health:** http://localhost:3032/health
- **الوصف:** نظام الجوائز والتحفيز

### 2. 💰 Budget Service

- **المنفذ:** 3033
- **المسار:** `backend/budget-service/`
- **Health:** http://localhost:3033/health
- **الوصف:** نظام إدارة الميزانية

### 3. 📚 Training Service

- **المنفذ:** 3034
- **المسار:** `backend/training-service/`
- **Health:** http://localhost:3034/health
- **الوصف:** نظام إدارة التدريب

### 4. ⭐ Quality Service

- **المنفذ:** 3035
- **المسار:** `backend/quality-service/`
- **Health:** http://localhost:3035/health
- **الوصف:** نظام إدارة الجودة

### 5. 💬 Social Service

- **المنفذ:** 3036
- **المسار:** `backend/social-service/`
- **Health:** http://localhost:3036/health
- **الوصف:** نظام التواصل الاجتماعي

### 6. 🤝 Volunteer Service

- **المنفذ:** 3037
- **المسار:** `backend/volunteer-service/`
- **Health:** http://localhost:3037/health
- **الوصف:** نظام إدارة التطوع

### 7. 🤝 Partnership Service

- **المنفذ:** 3038
- **المسار:** `backend/partnership-service/`
- **Health:** http://localhost:3038/health
- **الوصف:** نظام إدارة الشراكات

### 8. 💡 Innovation Service

- **المنفذ:** 3039
- **المسار:** `backend/innovation-service/`
- **Health:** http://localhost:3039/health
- **الوصف:** نظام إدارة الابتكار

### 9. 🌐 Community Partnership Service

- **المنفذ:** 3040
- **المسار:** `backend/community-partnership-service/`
- **Health:** http://localhost:3040/health
- **الوصف:** نظام إدارة الشراكات المجتمعية

---

## 📚 الأنظمة الموجودة

### 10. 📚 LMS Service

- **المنفذ:** 3031
- **المسار:** `backend/lms-service/`
- **Health:** http://localhost:3031/health
- **الوصف:** نظام إدارة المحتوى التعليمي

---

## 🌐 Services Gateway

### API Gateway

- **المنفذ:** 3050
- **المسار:** `backend/services-gateway/`
- **Health:** http://localhost:3050/health
- **الوصف:** API Gateway موحد لجميع الخدمات

---

## 🚀 التشغيل السريع

### تشغيل جميع الخدمات:

```bash
# استخدام Script
./scripts/start-all-new-services.sh

# أو PowerShell
.\scripts\start-all-new-services.ps1

# أو Docker Compose
cd backend
docker-compose -f docker-compose.all-services.yml up -d
```

### تشغيل API Gateway:

```bash
cd backend/services-gateway
npm install
npm start
```

---

## 📊 الإحصائيات

- **إجمالي الخدمات:** 11 خدمة (10 خدمات + 1 Gateway)
- **المنافذ المستخدمة:** 3031-3040, 3050
- **إجمالي API Endpoints:** 100+ endpoint

---

**آخر تحديث:** 2025-01-10
