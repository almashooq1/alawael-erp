# Services Quick Health / Troubleshooting

Use these quick checks to diagnose why a service health endpoint may be failing locally.

- Check port listener
  - PowerShell: `Get-NetTCPConnection -State Listen -LocalPort <port>`
- Try a simple health request
  - PowerShell: `try { (Invoke-WebRequest -UseBasicParsing http://127.0.0.1:<port>/health).StatusCode } catch { $_.Exception.Message }`
- Start a service with the test runner (if present)
  - Example: `node backend/hr-service/test/helpers/svc-runner.mjs backend/attendance-service/src/server.js 41000`
  - If it exits immediately (code 1), check:
    - .env or config files required
    - Port already in use
    - Missing npm install in that service folder
- Kill stuck svc-runner processes
  - PowerShell: `Get-CimInstance Win32_Process | Where-Object { $_.Name -like 'node*' -and $_.CommandLine -match 'svc-runner\.mjs' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }`
- Logs
  - Run the service directly (not via runner) to see console errors.

Tip: Keep health endpoints minimal (no external deps) so they start returning 200 as soon as the process boots.
