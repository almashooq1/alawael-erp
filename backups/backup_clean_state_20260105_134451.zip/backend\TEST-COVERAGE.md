# Test Coverage Overview (Scheduling & Analytics)

_Last updated: 2025-11-13_

## Scheduling (Gateway ↔ Scheduling-Service E2E via Fastify.inject)

| Scenario                                            | File                                                    | Key Assertions                                                 |
| --------------------------------------------------- | ------------------------------------------------------- | -------------------------------------------------------------- |
| Proxy core flow (health, create/list shift)         | `backend/gateway-service/test/scheduling.proxy.test.js` | 200 health; 201 shift creation; list contains shift            |
| Overlapping assignment blocked (same assignee)      | `scheduling.proxy.test.js`                              | 409 conflict on second assignment                              |
| Shift overlap by location blocked (policy flag)     | `scheduling.proxy.test.js`                              | 409 when `SHIFT_NO_OVERLAP_BY_LOCATION=true`                   |
| Daily hour cap enforced                             | `scheduling.proxy.test.js`                              | 422 when daily hours exceeded (`SHIFT_CAP_HOURS_PER_DAY`)      |
| Weekly hour cap enforced                            | `scheduling.caps.test.js`                               | 422 when weekly hours exceeded (`SHIFT_CAP_HOURS_PER_WEEK`)    |
| Availability create & list                          | `scheduling.availability.test.js`                       | 201 create; GET lists availability for user                    |
| Swap lifecycle (create, approve, list)              | `scheduling.swap.test.js`                               | 201 create; 200 approve; list status reflects change           |
| Swap invalid approval (role check)                  | `scheduling.swap.invalid.test.js`                       | 403 when non-manager approves                                  |
| Midnight-spanning shift handling & overlap blocking | `scheduling.midnight.test.js`                           | 201 spanning shift; overlapping assignment returns 409         |
| Metrics proxy exposes counter                       | `scheduling.metrics.test.js`                            | /api/scheduling/metrics contains `service_http_requests_total` |
| Metrics labels present (method, route, status)      | `scheduling.metrics.labels.test.js`                     | Exposition text contains POST /shifts, GET /health entries     |

### Metrics Label Expectations

Counter format includes labels: `service_http_requests_total{service="scheduling-service",method="GET",route="/health",status="200"}` (exact route may differ if Fastify normalizes). Tests use substring/regex to avoid brittleness.

## Analytics-Service (Direct Fastify.inject Tests)

| Scenario                                       | File                                                              | Key Assertions                                                              |
| ---------------------------------------------- | ----------------------------------------------------------------- | --------------------------------------------------------------------------- |
| Health endpoint basic                          | `backend/analytics-service/test/analytics.health.test.js`         | 200 status; body has `status: ok` & `streaming` field                       |
| Metrics counter after traffic                  | `backend/analytics-service/test/analytics.metrics.test.js`        | `/metrics` contains `service_http_requests_total` & `route="/health"` label |
| Ingestion accepts valid event                  | `backend/analytics-service/test/analytics.ingest.test.js`         | 202 response; state aggregation updated (if asserted)                       |
| Ingestion rejects invalid event                | `backend/analytics-service/test/analytics.ingest.invalid.test.js` | 400 for missing `type`                                                      |
| Overview returns global snapshot               | `backend/analytics-service/test/analytics.overview.test.js`       | 200; body keys match expected global counters                               |
| Consumer derived metrics & multi-type handling | `backend/analytics-service/test/consumer.multi-types.test.js`     | Multiple ingested types reflected in gauges                                 |
| Metrics aggregation with histograms            | `backend/analytics-service/test/consumer.histogram.test.js`       | Histogram buckets exist (exposition match)                                  |
| Deduplication logic                            | `backend/analytics-service/test/consumer.dedup.test.js`           | Duplicate events not double-counted                                         |
| Handler error resilience                       | `backend/analytics-service/test/consumer.handlerError.test.js`    | Error logged; process continues                                             |
| Invalid consumer payloads                      | `backend/analytics-service/test/consumer.invalid.test.js`         | Proper rejection / safe handling                                            |
| Consume & state integration                    | `backend/analytics-service/test/analytics.consume.test.js`        | State.meta / counters reflect consumed events                               |

### Derived Metrics

`analytics_derived_no_show_rate` gauge updated just-in-time during `/metrics` scrape. Test coverage indirectly assures presence via metrics tests.

## Gaps & Next Opportunities

- Add explicit test for `/analytics/extended` derived fields (payrollAvgNet, appointmentNoShowRate).
- Add test for debug endpoints guarded by `ANALYTICS_DEBUG_STATE` env (non-production safety).
- Add scheduling negative validation tests (invalid shift times, missing required fields).
- Add cross-service integration test ensuring gateway metric proxy isolation when gateway metrics enabled simultaneously.

## CI Integration

Workflow `scheduling-proxy-tests.yml` runs:

- Scheduling E2E suites (`test:scheduling:all`)
- Analytics smoke tests (`analytics.health.test.js`, `analytics.metrics.test.js`)

For expanded analytics coverage, create a dedicated workflow (e.g., `analytics-tests.yml`) targeting all analytics test files or add a matrix strategy.

## Maintenance

Update this document when adding/removing test files or changing scenario names. Keep assertions column focused on business rule invariants (status codes, critical fields) over implementation details.
