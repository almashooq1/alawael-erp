# Admin Communications Service

A lightweight administrative correspondence system with AI-assisted classification and summarization.

## Features

- Register incoming/outgoing correspondence with subject/body, priority, due date, and linked documents
- AI enrich: classify and summarize via knowledge-service if available, else local fallback
- Route/assign to teams or users; close with full audit trail
- Health `/health`, readiness `/ready`, and Prometheus `/metrics`

## Run

PowerShell (Windows):

```powershell
# From repo root
$env:PORT='3081'; npm --prefix backend/admin-comms-service start

# Health check
Invoke-WebRequest -UseBasicParsing http://127.0.0.1:3081/health
```

Optional: integrate with knowledge-service

```powershell
$env:KNOWLEDGE_URL='http://127.0.0.1:3078'
$env:PORT='3081'; npm --prefix backend/admin-comms-service start
```

Optional: integrate outbound notifications via comms-service

```powershell
$env:COMMS_URL='http://127.0.0.1:3071' # comms-service base URL
$env:PORT='3081'; npm --prefix backend/admin-comms-service start
```

Self-check (no external services required)

```powershell
# From repo root
node backend/admin-comms-service/test/self-check.mjs
```

## API (brief)

- POST /correspondence { direction, subject, body, priority, dueDate, docs }
- GET /correspondence/:id
- GET /correspondence?q=&status=
- POST /correspondence/:id/route { assignees[], priority?, dueDate? }
- POST /correspondence/:id/close
- POST /correspondence/:id/reply-draft

Authorization headers are enforced via shared `requireAuth()`; enable strict RBAC with `ENABLE_STRICT_RBAC=true`.
