/**
 * @file Admin Communications Service Server
 * Main entry for the administrative communications microservice using Fastify.
 * -------------------------------------------------------------
 * Handles registration, routing, and management of administrative correspondences.
 * Integrates AI-based classification and summarization, RBAC, metrics, and event bus.
 * All endpoints are documented inline. Strict mode and security best practices enforced.
 *
 * @example
 * // Start the server (from CLI)
 * $ node backend/admin-comms-service/src/server.js
 *
 * @example
 * // Import and use in another module
 * import { createServer } from './server.js';
 * const fastify = createServer();
 * fastify.listen({ port: 3081 });
 *
 * @see {@link https://www.fastify.io/docs/latest/ Fastify Documentation}
 * @see {@link https://github.com/almashooq1/66666 Project Repository}
 *
 * @section Main Variables
 * @property {EventBus} bus - Event bus for publishing and subscribing to events.
 * @property {Map} registry - In-memory registry for correspondence items.
 *
 * @section Service Endpoints
 * - /correspondence: Register new correspondence (POST), list/filter (GET).
 * - /correspondence/:id: Get correspondence by ID (GET).
 * - /correspondence/:id/route: Route/assign correspondence (POST).
 * - /correspondence/:id/close: Close correspondence (POST).
 * - /correspondence/:id/reply-draft: Generate reply draft (POST).
 * - /metrics: Expose Prometheus metrics.
 * - /health, /ready: Service health and readiness checks.
 *
 * @section Security
 * - Role-based access enforced via requireAuth and RBAC middleware.
 * - Security headers and rate limiting applied to sensitive endpoints.
 *
 * @section Notes
 * - All endpoints are documented inline with JSDoc.
 * - AI helpers for classification and summarization are integrated.
 * - For more details, see inline documentation for each function and endpoint.
 */
import Fastify from 'fastify';
import { createRequire } from 'module';
import { randomUUID } from 'crypto';
import { applySecurityHeaders, makeRouteRateLimiter } from '../../shared/http/security.js';
import { attachErrorHandler, notFound } from '../../shared/http/errors.js';
import { buildReadyHandler } from '../../shared/http/ready.js';
import {
  sanitizeInputs,
  trackRequest,
  errorHandler,
} from '../../shared/middleware/security-middleware-fastify-es6.js';
import { EventBus } from '../../shared/event-bus/index.js';
import { AdminCommsEvents, DocumentEvents } from '../../shared/event-schemas/types.js';
import { requireAuth, rbac } from '../../shared/http/auth.js';

const bus = new EventBus(
  process.env.EVENT_BUS_IMPL === 'mock'
    ? { transport: 'mock', mockChannel: (globalThis.__EVENTBUS_MOCK_CHANNEL ||= {}) }
    : {}
);

// In-memory registry of administrative correspondences
// Each item: { id, direction, subject, body, sender, recipient, priority, dueDate, status, ai, docs, audit, assignees }
const registry = new Map();

function registerMetrics(fastify) {
  try {
    const requireCJS = createRequire(import.meta.url);

    const prom = (globalThis.__promClient ||= requireCJS('prom-client'));
    if (process.env.METRICS_DEFAULTS === 'true' && !globalThis.__metricsDefaultsRegistered) {
      try {
        prom.collectDefaultMetrics({ prefix: process.env.METRICS_PREFIX || '' });
        globalThis.__metricsDefaultsRegistered = true;
      } catch {
        // Intentionally empty - metrics defaults registration failed
      }
    }
    const httpReqCounter = new prom.Counter({
      name: 'service_http_requests_total',
      help: 'Total HTTP requests',
      labelNames: ['service', 'method', 'route', 'status'],
    });
    const itemsGauge = new prom.Gauge({
      name: 'admin_comms_items_total',
      help: 'Total correspondence items',
    });
    setInterval(() => itemsGauge.set(registry.size), 5000).unref?.();
    fastify.addHook('onResponse', (req, reply, done) => {
      try {
        const route = (req.routeOptions && req.routeOptions.url) || req.url || 'unknown';
        httpReqCounter.inc({
          service: 'admin-comms-service',
          method: req.method,
          route,
          status: String(reply.statusCode),
        });
      } catch {
        // Intentionally empty - metrics counter increment failed
      }
      done();
    });
    fastify.get('/metrics', async (_req, reply) => {
      reply.header('Content-Type', prom.register.contentType);
      reply.send(await prom.register.metrics());
    });
  } catch {
    // Intentionally empty - metrics registration failed
  }
}

// Optional: small RBAC gate when strict mode is on
function requireRoles(roles) {
  if (process.env.ENABLE_STRICT_RBAC === 'true') {
    return rbac(roles);
  }
  return async () => {};
}

// Lightweight AI helpers with optional knowledge-service integration
async function aiClassify(text) {
  const raw = String(text || '');
  const url =
    process.env.KNOWLEDGE_URL && `${process.env.KNOWLEDGE_URL.replace(/\/$/, '')}/kb/classify`;
  if (url) {
    try {
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: 'Bearer test' },
        body: JSON.stringify({ text: raw }),
      });
      if (res.ok) {
        return await res.json();
      }
    } catch {
      // Intentionally empty - knowledge service classify request failed
    }
  }
  // local stub (aligned with knowledge-service)
  const lower = raw.toLowerCase();
  const hasAny = arr => arr.some(k => lower.includes(k));
  const labels = new Set();
  if (hasAny(['invoice', 'payment', 'credit', 'amount', 'account', 'balance'])) {
    labels.add('finance');
  }
  if (hasAny(['contract', 'agreement', 'law', 'regulation', 'compliance'])) {
    labels.add('legal');
  }
  if (hasAny(['patient', 'diagnosis', 'therapy', 'treatment', 'clinic', 'doctor'])) {
    labels.add('medical');
  }
  if (hasAny(['employee', 'leave', 'payroll', 'attendance', 'benefits'])) {
    labels.add('hr');
  }
  const emailRe = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi;
  const ccRe = /\b(?:\d[ -]*?){13,16}\b/g;
  const ssnRe = /\b\d{3}-\d{2}-\d{4}\b/g;
  const matches = {
    email: lower.match(emailRe) || [],
    credit_card: lower.match(ccRe) || [],
    ssn: lower.match(ssnRe) || [],
  };
  const flags = Object.entries(matches)
    .filter(([, v]) => v && v.length)
    .map(([k]) => k);
  if (flags.length) {
    labels.add('sensitive');
  }
  return {
    labels: Array.from(labels),
    confidence: Math.min(1, (labels.size || 0) / 5),
    sensitive: flags.length > 0,
    dlp: { flags, matches },
  };
}

async function aiSummarize(text) {
  const raw = String(text || '');
  const url =
    process.env.KNOWLEDGE_URL && `${process.env.KNOWLEDGE_URL.replace(/\/$/, '')}/kb/summarize`;
  if (url) {
    try {
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: 'Bearer test' },
        body: JSON.stringify({ text: raw, sentences: 3 }),
      });
      if (res.ok) {
        return await res.json();
      }
    } catch {
      // Intentionally empty - knowledge service summarize request failed
    }
  }
  // local frequency-based stub
  const STOP = new Set([
    'the',
    'a',
    'an',
    'and',
    'or',
    'but',
    'if',
    'then',
    'else',
    'for',
    'of',
    'to',
    'in',
    'on',
    'at',
    'by',
    'with',
    'from',
    'as',
    'is',
    'are',
    'was',
    'were',
    'be',
    'been',
    'being',
    'it',
    'this',
    'that',
    'these',
    'those',
    'over',
    'under',
    'into',
    'out',
    'up',
    'down',
    'no',
    'not',
    'so',
  ]);
  const tokenize = s =>
    s
      .toLowerCase()
      .split(/[^a-z0-9]+/i)
      .filter(t => t && !STOP.has(t));
  const sents = raw
    .split(/(?<=[.!?])\s+/)
    .map(s => s.trim())
    .filter(Boolean);
  const freq = new Map();
  for (const s of sents) {
    for (const t of tokenize(s)) {
      freq.set(t, (freq.get(t) || 0) + 1);
    }
  }
  const scored = sents.map((s, idx) => {
    let score = 0;
    for (const t of tokenize(s)) {
      score += freq.get(t) || 0;
    }
    return { idx, s, score };
  });
  scored.sort((a, b) => b.score - a.score);
  const top = scored.slice(0, Math.min(3, scored.length)).sort((a, b) => a.idx - b.idx);
  const summary = top.map(x => x.s).join(' ');
  const ratio = raw.length ? Number((summary.length / raw.length).toFixed(3)) : 0;
  return { sentences: top.length, ratio, summary };
}

// Optional outbound notification via comms-service
async function notifyViaComms(payloads = []) {
  const base = (process.env.COMMS_URL || '').replace(/\/$/, '');
  if (!base) {
    return;
  }
  const url = `${base}/comms/send`;
  for (const p of payloads) {
    try {
      await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: 'Bearer test' },
        body: JSON.stringify(p),
      });
    } catch {
      // best-effort only
    }
  }
}

export function createServer() {
  const fastify = Fastify({ logger: true, ignoreTrailingSlash: true });

  // Security Middleware
  fastify.addHook('onRequest', sanitizeInputs);
  fastify.addHook('onRequest', trackRequest);
  fastify.setErrorHandler(errorHandler);

  if (process.env.METRICS_ENABLED === 'true') {
    registerMetrics(fastify);
  }
  applySecurityHeaders(fastify);
  attachErrorHandler(fastify);
  const rateLimit = makeRouteRateLimiter({ windowMs: 60000, max: 100 });
  const auth = requireAuth();

  // Health & Readiness
  fastify.get('/health', async () => ({
    status: 'ok',
    features: ['registry', 'ai', 'routing', 'audit'],
  }));
  fastify.get(
    '/ready',
    buildReadyHandler({
      serviceName: 'admin-comms-service',
      checks: [
        { name: 'env', check: async () => ({ ok: true, details: { node: process.version } }) },
        {
          name: 'registry',
          check: async () => ({ ok: registry.size >= 0, details: { count: registry.size } }),
        },
        {
          name: 'forcedFail',
          check: async () => ({ ok: process.env.ADMIN_COMMS_FORCE_FAIL === 'true' ? false : true }),
        },
      ],
    })
  );

  // Register a correspondence (incoming/outgoing)
  fastify.post(
    '/correspondence',
    { preHandler: [auth, rateLimit, requireRoles(['user', 'admin'])] },
    async (req, reply) => {
      const body = req.body || {};
      const id = randomUUID();
      const now = new Date().toISOString();
      const direction = String(body.direction || 'IN').toUpperCase();
      const meta = {
        id,
        direction: direction === 'OUT' ? 'OUT' : 'IN',
        subject: body.subject || '',
        body: body.body || '',
        sender: body.sender || null,
        recipient: body.recipient || null,
        priority: body.priority || 'normal',
        dueDate: body.dueDate || null,
        status: 'OPEN',
        docs: Array.isArray(body.docs) ? body.docs.filter(Boolean) : [],
        assignees: [],
        ai: {},
        audit: [{ at: now, action: 'CREATED', actor: (req.user && req.user.sub) || 'system' }],
      };
      // AI enrich
      try {
        const [clf, sum] = await Promise.all([
          aiClassify(meta.subject + ' ' + meta.body),
          aiSummarize(meta.body || meta.subject || ''),
        ]);
        meta.ai = { classify: clf, summary: sum };
      } catch {
        // Intentionally empty - AI enrichment failed
      }
      registry.set(id, meta);
      await bus.publish({
        topic: 'admin-comms',
        event: {
          type: AdminCommsEvents.CORRESPONDENCE_REGISTERED,
          id,
          direction: meta.direction,
          priority: meta.priority,
        },
      });
      reply.code(201).send({ id, status: meta.status, ai: meta.ai });
    }
  );

  // Get one
  fastify.get('/correspondence/:id', { preHandler: [auth, rateLimit] }, async (req, reply) => {
    const cur = registry.get(req.params.id);
    if (!cur) {
      return notFound(reply, 'Correspondence not found');
    }
    return cur;
  });

  // List (lightweight filtering)
  fastify.get('/correspondence', { preHandler: [auth, rateLimit] }, async req => {
    const q = String(req.query.q || '').toLowerCase();
    const status = String(req.query.status || '').toUpperCase();
    const items = Array.from(registry.values()).filter(x => {
      const matchQ =
        !q || x.subject?.toLowerCase().includes(q) || x.body?.toLowerCase().includes(q);
      const matchS = !status || x.status === status;
      return matchQ && matchS;
    });
    return { count: items.length, items };
  });

  // Route/assign
  fastify.post(
    '/correspondence/:id/route',
    { preHandler: [auth, rateLimit, requireRoles(['supervisor', 'admin'])] },
    async (req, reply) => {
      const cur = registry.get(req.params.id);
      if (!cur) {
        return notFound(reply, 'Correspondence not found');
      }
      const body = req.body || {};
      const assignees = Array.isArray(body.assignees) ? body.assignees.filter(Boolean) : [];
      const dueDate = body.dueDate || cur.dueDate || null;
      const priority = body.priority || cur.priority;
      cur.assignees = assignees;
      cur.dueDate = dueDate;
      cur.priority = priority;
      cur.status = 'IN_REVIEW';
      (cur.audit ||= []).push({
        at: new Date().toISOString(),
        action: 'ROUTED',
        actor: (req.user && req.user.sub) || 'system',
        details: { assignees, dueDate, priority },
      });
      registry.set(req.params.id, cur);
      await bus.publish({
        topic: 'admin-comms',
        event: {
          type: AdminCommsEvents.CORRESPONDENCE_ROUTED,
          id: req.params.id,
          assignees,
          dueDate,
          priority,
        },
      });
      // Fire-and-forget notifications to assignees if COMMS_URL set
      try {
        const payloads = (assignees || []).slice(0, 10).map(to => ({
          channel: 'push',
          to,
          data: {
            event: 'ADMIN_COMMS_ROUTED',
            id: req.params.id,
            subject: cur.subject,
            priority,
            dueDate,
          },
        }));
        notifyViaComms(payloads);
      } catch {
        // Intentionally empty - notification failed
      }
      return { id: req.params.id, status: cur.status };
    }
  );

  // Close/complete
  fastify.post(
    '/correspondence/:id/close',
    { preHandler: [auth, rateLimit, requireRoles(['supervisor', 'admin'])] },
    async (req, reply) => {
      const cur = registry.get(req.params.id);
      if (!cur) {
        return notFound(reply, 'Correspondence not found');
      }
      cur.status = 'CLOSED';
      (cur.audit ||= []).push({
        at: new Date().toISOString(),
        action: 'CLOSED',
        actor: (req.user && req.user.sub) || 'system',
      });
      registry.set(req.params.id, cur);
      await bus.publish({
        topic: 'admin-comms',
        event: { type: AdminCommsEvents.CORRESPONDENCE_CLOSED, id: req.params.id },
      });
      // Notify originator/assignees about closure if COMMS_URL set
      try {
        const targets = new Set([...(cur.assignees || [])]);
        if (cur.sender) {
          targets.add(cur.sender);
        }
        const payloads = Array.from(targets)
          .slice(0, 10)
          .map(to => ({
            channel: 'push',
            to,
            data: {
              event: 'ADMIN_COMMS_CLOSED',
              id: req.params.id,
              subject: cur.subject,
              closedAt: new Date().toISOString(),
            },
          }));
        notifyViaComms(payloads);
      } catch {
        // Intentionally empty - close notification failed
      }
      return { id: req.params.id, status: cur.status };
    }
  );

  // Draft a reply (template-like)
  fastify.post(
    '/correspondence/:id/reply-draft',
    { preHandler: [auth, rateLimit] },
    async (req, reply) => {
      const cur = registry.get(req.params.id);
      if (!cur) {
        return notFound(reply, 'Correspondence not found');
      }
      const name = (req.user && req.user.name) || 'Team';
      const summary = cur?.ai?.summary?.summary || cur.subject || '';
      const greeting = cur.direction === 'IN' ? 'السيد/السيدة المحترم/ة' : 'فريقنا المحترم';
      const body = `
${greeting},

بالإشارة إلى موضوع: "${cur.subject}".

ملخص موجز: ${summary || '-'}

نؤكد استلامكم/استلامنا ونقترح الخطوات التالية:
- مراجعة من القسم المختص.
- الرد خلال (${cur.dueDate || '3 أيام عمل'}) حسب الأولوية (${cur.priority}).

مع خالص التحية،
${name}
`;
      return { id: req.params.id, draft: body.trim() };
    }
  );

  // Subscribe to document OCR to auto-augment items when IDs match
  try {
    bus
      .subscribe({
        topics: 'documents',
        handler: async ({ event }) => {
          if (event?.type === DocumentEvents.OCR_EXTRACTED && event?.id) {
            // Find items referencing this document id and attach OCR fields into AI context
            for (const [, meta] of registry) {
              if ((meta.docs || []).includes(event.id)) {
                meta.ai = meta.ai || {};
                meta.ai.ocr = event.fields;
                (meta.audit ||= []).push({
                  at: new Date().toISOString(),
                  action: 'OCR_ATTACHED',
                  actor: 'system',
                  details: { docId: event.id },
                });
              }
            }
          }
        },
      })
      .catch(() => {});
  } catch {
    // Intentionally empty - event bus subscription failed
  }

  return fastify;
}

if (process.argv[1] && process.argv[1].endsWith('server.js')) {
  const port = Number(process.env.PORT || 3081);
  createServer().listen({ port, host: '0.0.0.0' }, (err, address) => {
    if (err) {
      console.error('admin-comms-service failed to start', err);
      return;
    }
    console.log('admin-comms-service listening at', address);
  });
}

// Error Handling
const { errorHandler, notFoundHandler } = require('../../shared/middleware/error-handler');

// 404 handler (must be after all routes)

// API Documentation
const { swaggerSetup } = require('../../shared/docs/swagger-config');
swaggerSetup(app);

app.use(notFoundHandler);

// Error handler (must be last)
app.use(errorHandler);
