// Simple in-process self-check for admin-comms-service
// Runs a minimal happy-path: health -> register -> route -> reply-draft -> close
import http from 'http';
import { createServer } from '../src/server.js';

function httpRequest(method, url, body) {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const data = body ? Buffer.from(JSON.stringify(body)) : null;
    const headers = { Authorization: 'Bearer test' };
    if (data) {
      headers['Content-Type'] = 'application/json';
      headers['Content-Length'] = Buffer.byteLength(data);
    }
    const req = http.request(
      {
        method,
        hostname: u.hostname,
        port: u.port,
        path: u.pathname + (u.search || ''),
        headers,
      },
      res => {
        let chunks = '';
        res.on('data', c => (chunks += c));
        res.on('end', () => {
          try {
            const text = chunks || '';
            const json = text ? JSON.parse(text) : undefined;
            resolve({ statusCode: res.statusCode, body: json, text });
          } catch (e) {
            resolve({ statusCode: res.statusCode, body: undefined, text: chunks });
          }
        });
      }
    );
    req.on('error', reject);
    if (data) {
      req.write(data);
    }
    req.end();
  });
}

async function main() {
  const app = createServer();
  const port = 0; // ephemeral
  let address;
  try {
    await app.listen({ port, host: '127.0.0.1' });
    address = app.server.address();
  } catch (e) {
    console.error('[self-check] Failed to start server:', e?.stack || e?.message || e);
    process.exit(2);
  }
  const base = `http://127.0.0.1:${address.port}`;

  try {
    // Health
    const h = await httpRequest('GET', `${base}/health`);
    if (h.statusCode !== 200 || h.body?.status !== 'ok') {
      throw new Error('health failed');
    }

    // Register a correspondence
    const reg = await httpRequest('POST', `${base}/correspondence`, {
      direction: 'IN',
      subject: 'Test subject',
      body: 'Body for test item.',
      priority: 'high',
      docs: [],
    });
    if (reg.statusCode !== 201 || !reg.body?.id) {
      throw new Error('register failed');
    }
    const id = reg.body.id;

    // Route
    const route = await httpRequest('POST', `${base}/correspondence/${id}/route`, {
      assignees: ['user:demo'],
      dueDate: new Date(Date.now() + 86400000).toISOString(),
      priority: 'high',
    });
    if (route.statusCode !== 200 || route.body?.status !== 'IN_REVIEW') {
      throw new Error('route failed');
    }

    // Reply draft
    const draft = await httpRequest('POST', `${base}/correspondence/${id}/reply-draft`);
    if (draft.statusCode !== 200 || !draft.body?.draft) {
      throw new Error('draft failed');
    }

    // Close
    const close = await httpRequest('POST', `${base}/correspondence/${id}/close`);
    if (close.statusCode !== 200 || close.body?.status !== 'CLOSED') {
      throw new Error('close failed');
    }

    console.log('[self-check] PASS');
    process.exit(0);
  } catch (e) {
    console.error('[self-check] FAIL:', e?.message || e);
    process.exit(1);
  } finally {
    try {
      await app.close();
    } catch {
      // ignore
    }
  }
}

main();
