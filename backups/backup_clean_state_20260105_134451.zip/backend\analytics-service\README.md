# Analytics Service

Aggregates cross-domain operational events (payroll, LMS, quality, compliance, HR licensing) into per-employee and global counters. Currently uses an HTTP ingestion endpoint as a temporary bridge until real event streaming consumers are added.

## Endpoints

| Method | Path                      | Purpose                                       |
| ------ | ------------------------- | --------------------------------------------- |
| GET    | `/health`                 | Liveness check                                |
| POST   | `/ingest-event`           | Temporary event ingestion `{ type, payload }` |
| GET    | `/analytics/employee/:id` | Aggregated counters for one employee          |
| GET    | `/analytics/overview`     | Global aggregate counters                     |
| GET    | `/metrics`                | Prometheus metrics (when enabled)             |

## Event Types Handled

| Type                    | Effect                                                          |
| ----------------------- | --------------------------------------------------------------- |
| `PAYROLL_RUN_COMPLETED` | Increments payroll run count & sums net value                   |
| `ENROLLMENT_CREATED`    | Increments trainingCompleted or trainingPending based on status |
| `INCIDENT_REPORTED`     | Increments incident count                                       |
| `AUDIT_LOGGED`          | Increments audits count                                         |
| `KPI_UPDATED`           | Increments KPI count                                            |
| `LICENSE_EXPIRING`      | Increments expiring licenses counters                           |

All other events are ignored gracefully.

## Data Model (In-Memory)

```ts
employees[id] = {
  payrollRuns, totalPayrollNet,
  trainingCompleted, trainingPending,
  incidents, audits, kpis, expiringLicenses
}
global = same shape (aggregated)
```

## Tracing & Metrics

`initTracing({ serviceName: 'analytics-service' })` activates OpenTelemetry. Configure exporter via env:
| Var | Example |
|-----|---------|
| `OTEL_EXPORTER_OTLP_ENDPOINT` | http://otel-collector:4318 |
| `OTEL_SERVICE_NAME` | analytics-service |

Enable metrics: `METRICS_ENABLED=true` (optional `METRICS_DEFAULTS=true`).

Self-check: the service performs a periodic internal probe of `/health` using `fastify.inject` and logs warnings if the route becomes unavailable. Enable debug snapshot of the last probe with `ANALYTICS_DEBUG_STATE=true` at `GET /__self-check` (dev only).

Observability: Prometheus is configured (in `observability/prometheus/prometheus.yml`) to scrape this service on `host.docker.internal:3061/metrics`. Ensure the service is listening on port `3061` (or adjust the scrape target accordingly) when validating Grafana dashboards.

## Networking tips (host vs containers)

- From the host: use `http://localhost:3061` (or `127.0.0.1`).
- From inside the analytics container: use `http://localhost:3061` to reach itself, or service DNS names to reach peers, e.g. `http://supply-service:3051`.
- From another container to analytics: use `http://analytics-service:3061`.
- On Windows Docker Desktop, `host.docker.internal` points to the host; use it only if you intend to reach the host‑published port mapping from a container.
- Route matching tolerates trailing slashes (Fastify `ignoreTrailingSlash: true`), so `/analytics/extended` and `/analytics/extended/` both work.

Scripts

- `scripts/load-live-events.js` auto-detects container context via `IN_CONTAINER=true` and prefers service DNS names. Override with `SUPPLY_BASE_URL`, `ASSETS_BASE_URL`, `FACILITIES_BASE_URL`, `ANALYTICS_BASE_URL` if needed.
- `scripts/smoke-endpoints.js` is a quick health validator for `/health`, `/analytics/extended`, and `/metrics`.

### Quick Metrics Reference

Core streaming metrics exposed when the consumer is enabled (`ANALYTICS_STREAM_ENABLED=true`):

| Metric                                         | Type      | Labels           | Description                                             |
| ---------------------------------------------- | --------- | ---------------- | ------------------------------------------------------- |
| `analytics_events_processed_total`             | counter   | `type`, `source` | Events successfully applied to aggregates               |
| `analytics_events_invalid_total`               | counter   | `reason`         | Events rejected due to parse/handler errors             |
| `analytics_events_deduplicated_total`          | counter   | -                | Events skipped because their `id` was already processed |
| `analytics_events_processing_duration_seconds` | histogram | `type`           | Per-event handler duration in seconds                   |

### Environment Flags (Streaming)

| Var                        | Purpose                                                      | Default    |
| -------------------------- | ------------------------------------------------------------ | ---------- |
| `ANALYTICS_STREAM_ENABLED` | Toggle NATS subscription consumer                            | `false`    |
| `ANALYTICS_NATS_SUBJECTS`  | Subject pattern subscribed (wildcards supported)             | `*.events` |
| `ANALYTICS_DEDUP_WINDOW`   | Approximate max unique ids tracked in memory for idempotency | `50000`    |
| `ANALYTICS_DEDUP_ENABLED`  | Enable/disable dedup layer                                   | `true`     |

### Smoke Test (Two Options)

#### 1) Integrated local smoke (recommended)

Runs server + consumer in-process on a random free port, publishes sample events, prints aggregates, then exits.

```powershell
cd backend/analytics-service
npm run smoke:local
```

#### 2) Manual two‑shell workflow

```powershell
cd backend/analytics-service
$env:NATS_SERVERS='nats://127.0.0.1:4222'
$env:ANALYTICS_STREAM_ENABLED='true'
$env:METRICS_ENABLED='true'
npm run dev   # start service (consumer auto-starts)
```

Second shell:

```powershell
cd backend/analytics-service
npm run smoke
```

Inspect:

```powershell
curl http://localhost:3061/analytics/employee/emp-smoke
curl http://localhost:3061/analytics/overview
curl http://localhost:3061/metrics | Select-String analytics_events_processed_total
```

### Streaming Quick Start (End-to-End)

For a one-command local validation that starts analytics-service and hr-service, emits a sample event via NATS, and verifies metrics/aggregates, see `STREAMING-QUICK-START.md` in this folder. This flow is Windows/PowerShell friendly and aligns with our Prometheus/Grafana setup.

### Dev Utilities

- `npm run diagnose` — run an in-process server creation and `/health` probe to pinpoint import/startup issues without binding a port.
- `npm run load:events` — publish configurable sample events to NATS to increase `analytics_events_processed_total` for local testing or CI threshold checks.

### Troubleshooting startup

- If the process exited immediately with code 1 before this change, it was likely due to passing a custom logger object to Fastify. The service now uses Fastify's built-in logger (pino) for request logs. Ensure you're on this version and try again.
- If port 3061 is in use, either stop the existing instance or set a different `PORT` before starting.
- On Windows PowerShell, set env vars with `$env:VAR='value'` (for current session) or `setx VAR "value"` (to persist) rather than Bash-style `VAR=value`.

### Deprecation Notice

Legacy `createEvent` emitters have been migrated to the unified envelope via `createEnvelope()` + `withMeta()`. Benefits:

1. Consistent id field for dedup/idempotency.
2. Uniform trace correlation (`traceId`).
3. Simplified downstream parsing & validation.
4. Future transport portability (Kafka, JetStream) without schema divergence.

CloudEvents dual emission in RCM remains intentionally for backward compatibility and will be removed in a subsequent cleanup phase once downstream consumers switch fully to envelopes.

## Dev Run

```bash
npm run dev --workspace backend/analytics-service
```

## Manual Test

```bash
curl -X POST http://localhost:3061/ingest-event \
  -H 'Content-Type: application/json' \
  -d '{"type":"PAYROLL_RUN_COMPLETED","payload":{"employeeId":"emp-1","net":5000}}'
curl http://localhost:3061/analytics/employee/emp-1
```

## Roadmap

- Replace HTTP ingestion with true Kafka/NATS consumer (stream partition by employeeId)
- Stateful store (PostgreSQL or ClickHouse for analytical queries)
- Derived KPIs (average net pay, training completion %, incident rate per 100 employees)
- Time-window aggregations & downsampling
- Expose PromQL-ready custom metrics from aggregates
- Add GraphQL / aggregated projection API for dashboards

## Streaming Design (Planned Implementation)

This section details the upcoming migration from the temporary HTTP ingestion endpoint to a real streaming consumer leveraging the existing pluggable `EventBus` (NATS now, Kafka optional later).

### Goals

1. Low-latency ingestion (<50ms processing overhead per event in-memory).
2. Exactly-once semantic effect on aggregates (idempotent via event `id`).
3. Horizontal scalability (consumer group partitioning / queue subscription).
4. Observability: per-event processing duration, lag, error count, last processed timestamp.
5. Resilience: backpressure handling, DLQ for poison / repeatedly failing events.

### Transport Selection

Initial target: NATS (already present in repo tooling). Design keeps an abstraction so Kafka can be enabled by setting `EVENT_BUS_PREFERENCE=kafka` (producer side already supports). For consumption:

- NATS: Use a JetStream-enabled subject pattern `domain.events.*` (or simple core NATS + queue groups if JetStream not yet enabled). Subject suggestion per service: `<service>.events` (already used for publishing). Consumer will subscribe to multiple subjects via wildcard: `>.events` OR explicit list.
- Kafka (future): Single topic `domain.events` with key = `employeeId || type` for even distribution; partitions scaled based on throughput.

### Subscription Strategy

Option A (NATS core): Queue group `analytics-workers` on wildcard subscription so only one instance processes each message; scale by running multiple replicas.
Option B (JetStream): Durable consumer with Ack + Redelivery; provides at-least-once with replay. Recommended once durability required.

### Event Envelope Handling

All events follow standardized envelope `{ id, type, source, occurredAt, traceId?, payload }`.
Processing steps:

1. Parse JSON -> validate required fields (id, type, payload object).
2. Deduplicate using an in-memory LRU set of recent `id`s (size ~50k) until persistent store arrives. (Future: store high-water mark / processed ids table).
3. Dispatch on `type` to aggregate mutators (same logic currently inside `/ingest-event`).
4. Record metrics & tracing span.

### Idempotency & Ordering

Ordering per employee not strictly required for current additive counters (all operations are commutative). If future non-commutative events emerge (e.g., set/replace), we will key-partition (Kafka) or shard subscription (multiple NATS subjects by hash bucket). Idempotency uses event `id` set membership; persistent strategy later: `processed_events (id primary key, processed_at, type)`.

### Failure & DLQ

Failure categories:
| Category | Handling |
|----------|----------|
| Transient parse / transport | Log + metric increment; message auto-redeliver (JetStream) or dropped (core NATS) with counter. |
| Validation failure (malformed) | Increment `analytics_events_invalid_total`; publish to `analytics.dlq` with reason once persistent channel exists. |
| Handler exception | Retry (JetStream redelivery). After N attempts (configurable), publish to DLQ. |

DLQ (future): For NATS JetStream, configure a separate stream / subject `analytics.dlq`. For Kafka, use dead-letter topic `domain.events.dlq`.

### Backpressure & Flow Control

- NATS core: Fast consumer; rely on in-memory queue. If processing time increases, scale replicas.
- JetStream / Kafka: Use pull / flow control and process in bounded concurrency (e.g., p=4) with async queue.

### Metrics (Prometheus)

| Metric                                         | Type      | Labels       | Description                          |
| ---------------------------------------------- | --------- | ------------ | ------------------------------------ |
| `analytics_events_processed_total`             | counter   | type, source | Accepted & applied events            |
| `analytics_events_invalid_total`               | counter   | reason       | Dropped malformed events             |
| `analytics_events_processing_duration_seconds` | histogram | type         | Handler time per event               |
| `analytics_events_deduplicated_total`          | counter   | -            | Events skipped due to duplicate id   |
| `analytics_consumer_lag_seconds`               | gauge     | transport    | Approximate lag (JetStream/Kafka)    |
| `analytics_last_event_timestamp`               | gauge     | -            | Unix seconds of last processed event |

### Tracing

Wrap each event in span `analytics.consume` with attributes: `event.type`, `event.source`, `event.id`, `transport`. Propagate upstream traceId if present.

### Environment Variables

| Var                         | Default    | Purpose                         |
| --------------------------- | ---------- | ------------------------------- |
| `ANALYTICS_STREAM_ENABLED`  | `false`    | Toggle consumer on start        |
| `ANALYTICS_NATS_SUBJECTS`   | `*.events` | Subjects pattern to subscribe   |
| `ANALYTICS_DEDUP_WINDOW`    | `50000`    | LRU size for processed ids      |
| `ANALYTICS_MAX_CONCURRENCY` | `4`        | Parallel handler limit (future) |
| `ANALYTICS_DLQ_ENABLED`     | `false`    | Enable DLQ publishing when set  |

### Minimal Implementation Outline

1. File `src/consumer.js` exports `start()` (already implemented) which connects to NATS and subscribes.
2. Server auto-starts consumer when `ANALYTICS_STREAM_ENABLED=true` (sidecar optional); standalone run via `npm run consume`.
3. Consumer connects to NATS (re-using lightweight `nats` lib directly to avoid coupling to publisher-only abstraction) and subscribes.
4. For each message: decode -> validate -> dedup -> apply -> metrics -> ack (if JetStream) / implicit (core).
5. Expose health probe field `streaming: { enabled: true, lastEventAt, processedTotal }` at `/health`.

### Future Evolution

- Switch to persistent store (e.g., Postgres/Timescale or ClickHouse) and implement upsert logic.
- Replace LRU dedup with durable processed id store partitioned by day.
- Add reprocessing endpoint to replay from a retention window.
- Add windowed metrics (sliding 1m/5m counters) for real-time dashboards.

---

Implementation tasks tracked separately; this document section defines acceptance criteria for the upcoming PR.

## Quick Start (Streaming Mode)

```powershell
# Ensure a NATS server running locally (example using docker)
docker run -d --name nats -p 4222:4222 nats:2.10-alpine

# Start analytics service with streaming enabled
setx NATS_URL "nats://localhost:4222"
setx ANALYTICS_STREAM_ENABLED "true"
setx METRICS_ENABLED "true"
cd backend/analytics-service
npm run dev

# Produce a test event (PAYROLL_RUN_COMPLETED) via NATS publish helper script or any publisher
# Example using node REPL (simplified):
node -e "(async()=>{const {connect,StringCodec}=await import('nats');const c=await connect({servers:'nats://127.0.0.1:4222'});const sc=StringCodec();c.publish('hr.events',sc.encode(JSON.stringify({id:'evt-1',type:'PAYROLL_RUN_COMPLETED',source:'hr-service',occurredAt:new Date().toISOString(),payload:{employeeId:'emp-42',net:1500}})));await c.drain();})();"

# Verify aggregation
curl http://localhost:3061/analytics/employee/emp-42
```

Note (Windows PowerShell): some npm scripts in other services may use Bash-style inline env vars. Prefer setting environment variables via `$env:VAR='value'` (current session) or `setx VAR "value"` (persist) before running `npm run`.

## Integration Plan (Streaming)

1. Deploy Kafka topic per domain (or a unified `domain.events` with type headers).
2. Analytics consumer group subscribes; decodes envelope `{ id, type, occurredAt, payload }`.
3. Upsert counters inside a transactional store.
4. Emit secondary analytics events for downstream BI or ML features.

## Cleanup & Resets

In-memory only; restart wipes state. For local dev, that's intentional. Persistence layer will introduce migrations and idempotent processing.

---

Future enhancements tracked in central roadmap file; this README stays implementation-focused.
