# Streaming Quick Start (Local)

This guide validates the end-to-end streaming path (hr-service -> NATS -> analytics-service) and Prometheus/Grafana metrics.

## Prerequisites

- Docker available (for NATS, Prometheus, Grafana stack)
- Node.js 18+

## 1) Start Observability Stack

```powershell
cd observability
docker compose up -d
```

## 2) Start NATS

```powershell
docker run -d --name nats-broker -p 4222:4222 nats:2.10-alpine
```

## 3) Run automated streaming smoke (with integrated warm-up)

From `backend/analytics-service`:

```powershell
npm run e2e:stream
```

The script now:

- Starts analytics-service (port 3061, falls back to 3062 if busy) with streaming + metrics.
- Starts hr-service (port 3011, falls back to 3012 if busy).
- Optional warm-up: publishes a configurable batch of sample events via NATS before the main assertion (controlled by `E2E_WARMUP_BATCH`).
- Waits a configurable number of seconds for Prometheus to scrape (`E2E_SCRAPE_WAIT`).
- Emits a LICENSE_EXPIRING event for the main check.
- Performs PromQL baseline/delta attribution and strict target checks (if enabled).
- Prints aggregates, a metrics sample, and shuts both services down.

### Prometheus Delta Assertion

The e2e script now performs a PromQL baseline + after comparison:

`sum by (instance) (analytics_events_processed_total)`

It captures a baseline before emitting the event and asserts that at least one instance's value increases. If **no** increase is detected, the script fails with an error. This guards against silent ingestion failures.

Optional strict mode (single target must change):

```powershell
$env:E2E_ASSERT_SINGLE_TARGET='true'; npm run e2e:stream
```

Strict mode asserts exactly one Prometheus target changed and that it matches the analytics-service port chosen (e.g., `127.0.0.1:3061`). Use this to catch accidental multi-instance local runs or stale targets.

If Prometheus is unreachable, the script logs a notice but still validates local service state.

### Threshold Harness (Processed Growth)

For CI or sustained growth validation, use the threshold harness:

```powershell
node scripts\check-processed-threshold.js
```

Environment variables:

| Var                    | Default                        | Description                                                      |
| ---------------------- | ------------------------------ | ---------------------------------------------------------------- |
| `PROM_URL`             | `http://127.0.0.1:9090`        | Prometheus base URL                                              |
| `WINDOW`               | `1m`                           | Range for `increase()` (e.g. `30s`, `5m`)                        |
| `MIN_DELTA`            | `1` (CI default elevated to 3) | Required total increase to pass                                  |
| `PROM_JOB`             | (empty)                        | Optional job label selector                                      |
| `PROM_INSTANCE`        | (empty)                        | Optional instance label selector                                 |
| `PROM_LABELS`          | (empty)                        | Full label selector override (e.g. `{job="foo",instance="bar"}`) |
| `ASSERT_SINGLE_TARGET` | `false`                        | Require exactly one instance to increase                         |
| `EXPECT_INSTANCE`      | (empty)                        | Expected instance when single target asserted                    |

Example (expect exactly one instance with at least +2 events in last 2 minutes):

```powershell
$env:WINDOW='2m'; $env:MIN_DELTA='2'; $env:ASSERT_SINGLE_TARGET='true'; $env:EXPECT_INSTANCE='127.0.0.1:3061'; node scripts\check-processed-threshold.js
```

If you prefer manual control, see README for `smoke:local` and hr-service `/debug/emit-sample`.

## Helpful Utilities

- Diagnostics: `npm run diagnose` — verifies shared imports, constructs the server in-process, and probes `/health` without opening a port. Use this when `node src/server.js` exits with code 1.
- Load generator: `npm run load:events` — publishes a configurable batch of sample envelopes to NATS (defaults: 5 events per subject across payroll,lms,quality,hr). Useful to raise `analytics_events_processed_total` before running threshold checks.

### Warm-up Controls (integrated in e2e)

Environment variables consumed by the e2e script:

| Var                        | Default (CI) | Description                                                             |
| -------------------------- | ------------ | ----------------------------------------------------------------------- |
| `E2E_WARMUP_BATCH`         | `10`         | Number of events published before baseline capture. Set `0` to disable. |
| `E2E_SCRAPE_WAIT`          | `20`         | Seconds to wait after warm-up for Prometheus scrape.                    |
| `E2E_ASSERT_SINGLE_TARGET` | `true` (CI)  | Require exactly one Prometheus target to increase.                      |

Increasing `E2E_WARMUP_BATCH` allows a higher `MIN_DELTA` threshold reliably. Keep scrape wait >= 2 \* scrape_interval (default 10s) for consistent sampling.

Examples (PowerShell):

```powershell
# Diagnose server creation issues without binding a TCP port
cd backend/analytics-service
npm run diagnose

# Publish 20 events per subject to bump counters (manual)
$env:BATCH='20'; $env:EMPLOYEE_ID='emp-dev'; npm run load:events

# Threshold harness: require at least +5 within 1m, any instance
node scripts/check-processed-threshold.js --min-delta 5 --window 1m
```

## 4) Grafana Dashboard

- Open http://localhost:3001
- Load "Analytics Service Overview" dashboard
- Panels should show non-zero `analytics_events_processed_total` shortly after the smoke

## Notes

- Prometheus scrapes analytics-service on ports 3061 and 3062 by default (to tolerate local retries).
- If analytics-service binds to a different port (e.g., fallback 3063), adjust `observability/prometheus/prometheus.yml` or force PORT=3061/3062.
- When raising `MIN_DELTA` (e.g., 5), consider setting `E2E_WARMUP_BATCH=12` and `E2E_SCRAPE_WAIT=25` to absorb scrape timing variance.
