const { EventBus } = require('../../shared/event-bus/index.cjs');
const { createCloudEvent } = require('../../shared/events/index.js');
const { state } = require('../src/state.js');

// Guard execution: require both RUN_NATS_ANALYTICS_SMOKE and NATS_SERVERS
const shouldRun =
  !!process.env.RUN_NATS_ANALYTICS_SMOKE && !!(process.env.NATS_SERVERS || process.env.NATS_URL);
const maybe = shouldRun ? describe : describe.skip;

maybe('analytics-service NATS end-to-end (optional)', () => {
  it('consumer processes published CloudEvents and updates derived metrics', async () => {
    // Ensure streaming enabled before importing consumer start
    process.env.ANALYTICS_STREAM_ENABLED = 'true';
    // Import and start consumer
    const consumerMod = await import('../src/consumer.cjs');
    await consumerMod.start();

    // Initial snapshot
    const startAppointments = state.global.fhirAppointments;
    const startNoShows = state.global.appointmentNoShows;

    const bus = new EventBus({}); // NATS transport auto-selected by env
    const events = [
      createCloudEvent({
        id: 'nats-e2e-1',
        type: 'appointment.booked',
        source: 'e2e',
        data: { appointmentId: 'E2E-1' },
      }),
      createCloudEvent({
        id: 'nats-e2e-2',
        type: 'appointment.no_show',
        source: 'e2e',
        data: { appointmentId: 'E2E-1' },
      }),
    ];
    for (const evt of events) {
      await bus.publish('e2e.events', evt);
    }

    // Wait until state reflects both events or timeout
    const timeoutMs = 5000;
    const t0 = Date.now();
    while (Date.now() - t0 < timeoutMs) {
      const apptsDelta = state.global.fhirAppointments - startAppointments;
      const noShowsDelta = state.global.appointmentNoShows - startNoShows;
      if (apptsDelta >= 1 && noShowsDelta >= 1) {
        break;
      }
      await new Promise(r => setTimeout(r, 100));
    }
    expect(state.global.fhirAppointments).toBeGreaterThan(startAppointments);
    expect(state.global.appointmentNoShows).toBeGreaterThan(startNoShows);
    // Derived rate should be > 0 after no-show
    const rate =
      state.global.derived.appointmentNoShowRate ||
      state.global.appointmentNoShows / Math.max(1, state.global.fhirAppointments);
    expect(rate).toBeGreaterThan(0);
  }, 20000);
});
