const { createCloudEvent } = require('../../shared/events/index.js');
const { processRawMessage } = require('../src/consumer.js');
const { state } = require('../src/state.js');

describe('analytics consumer (mocked delivery)', () => {
  beforeEach(() => {
    // reset minimal state touched in test
    state.global.fhirAppointments = 0;
    state.global.appointmentNoShows = 0;
    state.global.derived.appointmentNoShowRate = 0;
    state.meta.processedTotal = 0;
    state.meta.invalidTotal = 0;
    state.meta.deduplicatedTotal = 0;
  });

  test('processes CloudEvent JSON and updates derived metrics', () => {
    const e1 = createCloudEvent({
      id: 'evt-1',
      type: 'appointment.booked',
      source: 'unit',
      data: { appointmentId: 'A-1' },
    });
    const e2 = createCloudEvent({
      id: 'evt-2',
      type: 'appointment.no_show',
      source: 'unit',
      data: { appointmentId: 'A-1' },
    });
    const r1 = processRawMessage(JSON.stringify(e1));
    const r2 = processRawMessage(JSON.stringify(e2));
    expect(r1.status).toBe('ok');
    expect(r2.status).toBe('ok');
    expect(state.global.fhirAppointments).toBeGreaterThanOrEqual(1);
    expect(state.global.appointmentNoShows).toBe(1);
    expect(state.global.derived.appointmentNoShowRate).toBeGreaterThan(0);
  });
});
