#!/usr/bin/env node
/**
 * Threshold harness: asserts that analytics_events_processed_total increased over a window.
 *
 * Env vars:
 * - PROM_URL (default: http://127.0.0.1:9090)
 * - WINDOW (default: 1m)  e.g., 30s, 1m, 5m
 * - PROM_JOB (optional)   adds job="..." to metric selector
 * - PROM_INSTANCE (optional) adds instance="..." to metric selector
 * - PROM_LABELS (optional) full label selector, e.g., {job="foo",instance="bar"}
 * - MIN_DELTA (default: 1) minimal total increase required to pass
 * - ASSERT_SINGLE_TARGET (optional: 'true'|'false')
 * - EXPECT_INSTANCE (optional) required instance when ASSERT_SINGLE_TARGET=true (e.g., 127.0.0.1:3061)
 */
import { fetchPromQuery } from './lib/prom-helpers.js';

function env(name, def) {
  const v = process.env[name];
  return v === undefined || v === '' ? def : v;
}

// Simple CLI arg parsing (overrides env): --prom-url, --window, --min-delta, --labels, --job, --instance, --single, --expect
const argv = process.argv.slice(2);
function arg(name) {
  const i = argv.findIndex(a => a === `--${name}`);
  if (i >= 0 && argv[i + 1] && !argv[i + 1].startsWith('--')) {
    return argv[i + 1];
  }
  const j = argv.findIndex(a => a.startsWith(`--${name}=`));
  if (j >= 0) {
    return argv[j].split('=')[1];
  }
  return undefined;
}

const PROM_URL = arg('prom-url') || env('PROM_URL', 'http://127.0.0.1:9090');
const WINDOW = arg('window') || env('WINDOW', '1m');
const MIN_DELTA = Number(arg('min-delta') || env('MIN_DELTA', '1'));
const ASSERT_SINGLE = ['true', '1', 'yes'].includes(
  String(arg('single') || env('ASSERT_SINGLE_TARGET', 'false')).toLowerCase()
);
const EXPECT_INSTANCE = arg('expect') || env('EXPECT_INSTANCE', '');
const PROM_LABELS = arg('labels') || env('PROM_LABELS', '');
const PROM_JOB = arg('job') || env('PROM_JOB', '');
const PROM_INSTANCE = arg('instance') || env('PROM_INSTANCE', '');
const JSON_OUTPUT = String(env('THRESHOLD_JSON', 'false')) === 'true';

function buildSelector() {
  if (PROM_LABELS && PROM_LABELS.trim().startsWith('{')) {
    return PROM_LABELS.trim();
  }
  const parts = [];
  if (PROM_JOB) {
    parts.push(`job="${PROM_JOB}"`);
  }
  if (PROM_INSTANCE) {
    parts.push(`instance="${PROM_INSTANCE}"`);
  }
  return parts.length ? `{${parts.join(',')}}` : '';
}

function toInstanceValues(data) {
  const map = new Map();
  if (data && Array.isArray(data.result)) {
    for (const r of data.result) {
      const inst = r.metric?.instance ?? 'unknown';
      const val = Number(r.value?.[1] || 0);
      map.set(inst, (map.get(inst) || 0) + val);
    }
  }
  return map;
}

(async () => {
  const selector = buildSelector();
  const q = `sum by (instance) (increase(analytics_events_processed_total${selector}[${WINDOW}]))`;
  const data = await fetchPromQuery(q, PROM_URL);
  if (!data) {
    console.error(`[threshold] failed to query Prometheus at ${PROM_URL}`);
    process.exit(2);
  }
  const instances = toInstanceValues(data);
  const entries = [...instances.entries()];
  console.log(
    '[threshold] increases by instance:',
    entries.map(([i, v]) => `${i}=+${v}`).join(', ') || 'none'
  );

  const total = entries.reduce((s, [, v]) => s + Number(v || 0), 0);
  if (total < MIN_DELTA) {
    const failMsg = `[threshold] FAIL: total increase ${total} < MIN_DELTA ${MIN_DELTA}`;
    if (JSON_OUTPUT) {
      console.log(
        JSON.stringify({
          ok: false,
          reason: 'min-delta',
          totalIncrease: total,
          minDelta: MIN_DELTA,
          instances: Object.fromEntries(entries),
          query: q,
          window: WINDOW,
        })
      );
    } else {
      console.error(failMsg);
    }
    process.exit(1);
  }

  if (ASSERT_SINGLE) {
    const changed = entries.filter(([, v]) => Number(v || 0) > 0);
    if (changed.length !== 1) {
      const failMsg = `[threshold] FAIL: expected exactly one instance to increase, got ${changed.length}`;
      if (JSON_OUTPUT) {
        console.log(
          JSON.stringify({
            ok: false,
            reason: 'single-target-count',
            changed: changed.map(([i, v]) => ({ instance: i, delta: v })),
            totalIncrease: total,
            instances: Object.fromEntries(entries),
            query: q,
            window: WINDOW,
          })
        );
      } else {
        console.error(failMsg);
      }
      process.exit(1);
    }
    if (EXPECT_INSTANCE && changed[0][0] !== EXPECT_INSTANCE) {
      const failMsg = `[threshold] FAIL: expected instance ${EXPECT_INSTANCE} to increase, got ${changed[0][0]}`;
      if (JSON_OUTPUT) {
        console.log(
          JSON.stringify({
            ok: false,
            reason: 'wrong-instance',
            expectedInstance: EXPECT_INSTANCE,
            observedInstance: changed[0][0],
            totalIncrease: total,
            instances: Object.fromEntries(entries),
            query: q,
            window: WINDOW,
          })
        );
      } else {
        console.error(failMsg);
      }
      process.exit(1);
    }
  }

  if (JSON_OUTPUT) {
    console.log(
      JSON.stringify({
        ok: true,
        totalIncrease: total,
        minDelta: MIN_DELTA,
        instances: Object.fromEntries(entries),
        query: q,
        window: WINDOW,
      })
    );
  } else {
    console.log('[threshold] PASS');
  }
  process.exit(0);
})().catch(err => {
  console.error('[threshold] error:', err);
  process.exit(2);
});
