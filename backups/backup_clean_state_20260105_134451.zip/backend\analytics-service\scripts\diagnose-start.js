#!/usr/bin/env node
/**
 * Diagnose analytics-service server startup on Windows.
 * - Verifies key shared module imports
 * - Attempts to create the Fastify instance via createServer()
 * - Runs an in-process /health probe using fastify.inject
 * - Prints a structured diagnostic report and exits with non-zero on failure
 */
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const root = path.resolve(__dirname, '..');

function exists(p) {
  try {
    return fs.existsSync(p);
  } catch {
    return false;
  }
}

async function tryImport(label, spec) {
  try {
    const mod = await import(spec);
    console.log(`[diagnose] import OK: ${label}`);
    return { ok: true, mod };
  } catch (err) {
    console.error(`[diagnose] import FAILED: ${label} -> ${err?.message || err}`);
    if (err?.stack) {
      console.error(err.stack);
    }
    return { ok: false, err };
  }
}

(async () => {
  console.log('[diagnose] cwd:', process.cwd());
  console.log('[diagnose] node:', process.version);
  console.log('[diagnose] env subset:', {
    PORT: process.env.PORT,
    ANALYTICS_STREAM_ENABLED: process.env.ANALYTICS_STREAM_ENABLED,
    METRICS_ENABLED: process.env.METRICS_ENABLED,
    METRICS_DEFAULTS: process.env.METRICS_DEFAULTS,
  });

  // Check for shared files existence
  const paths = [
    path.resolve(root, '../shared/logging/index.js'),
    path.resolve(root, '../shared/http/security.js'),
    path.resolve(root, '../shared/http/errors.js'),
    path.resolve(root, '../shared/otel/index.js'),
    path.resolve(root, '../analytics-service/src/state.js'),
  ];
  for (const p of paths) {
    console.log(`[diagnose] exists ${p}:`, exists(p));
  }

  // Try critical imports one by one
  const checks = [];
  checks.push(await tryImport('fastify', 'fastify'));
  checks.push(await tryImport('shared/logging', '../../shared/logging/index.js'));
  checks.push(await tryImport('shared/security', '../../shared/http/security.js'));
  checks.push(await tryImport('shared/errors', '../../shared/http/errors.js'));
  checks.push(await tryImport('shared/otel', '../../shared/otel/index.js'));
  checks.push(await tryImport('analytics/state', '../src/state.js'));

  const failed = checks.filter(c => !c.ok);
  if (failed.length) {
    console.error(`[diagnose] FAILED imports: ${failed.length}. See errors above.`);
    process.exit(1);
  }

  // Try to construct server and run an in-process /health probe
  let fastify;
  try {
    const { createServer } = await import('../src/server.js');
    fastify = createServer();
    console.log('[diagnose] createServer() OK');
  } catch (err) {
    console.error('[diagnose] createServer() FAILED:', err?.message || err);
    if (err?.stack) {
      console.error(err.stack);
    }
    process.exit(1);
  }

  try {
    const res = await fastify.inject({ method: 'GET', url: '/health' });
    console.log('[diagnose] fastify.inject /health status:', res.statusCode);
    console.log('[diagnose] /health body:', res.body);
    if (res.statusCode !== 200) {
      console.error('[diagnose] /health returned non-200 status');
      process.exit(1);
    }
  } catch (err) {
    console.error('[diagnose] fastify.inject FAILED:', err?.message || err);
    if (err?.stack) {
      console.error(err.stack);
    }
    process.exit(1);
  }

  console.log('[diagnose] SUCCESS: server can be created and /health responds in-process.');
  process.exit(0);
})();
