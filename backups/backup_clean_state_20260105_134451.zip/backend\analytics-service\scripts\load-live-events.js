// Calls real service endpoints (supply/assets/facilities) to generate events via NATS.
// Requires those services and analytics + nats running under docker-compose.ops.yml.

// Connection strategy:
// When running OUTSIDE containers (e.g. on host) we use 127.0.0.1:ports.
// When running INSIDE a compose container, localhost points to self only; we prefer service DNS names.
// Provide override via env to keep flexibility.
const inContainer =
  process.env.IN_CONTAINER === 'true' || process.env.HOSTNAME?.includes('service');
const SERVICES = {
  supply:
    process.env.SUPPLY_BASE_URL ||
    (inContainer ? 'http://supply-service:3051' : 'http://127.0.0.1:3051'),
  assets:
    process.env.ASSETS_BASE_URL ||
    (inContainer ? 'http://assets-service:3052' : 'http://127.0.0.1:3052'),
  facilities:
    process.env.FACILITIES_BASE_URL ||
    (inContainer ? 'http://facilities-service:3053' : 'http://127.0.0.1:3053'),
  analytics:
    process.env.ANALYTICS_BASE_URL ||
    (inContainer ? 'http://localhost:3061' : 'http://127.0.0.1:3061'),
};

const sleep = ms => new Promise(r => setTimeout(r, ms));

async function post(url, body) {
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-user-id': 'script' },
    body: JSON.stringify(body || {}),
  });
  if (!res.ok) {
    throw new Error(`POST ${url} failed ${res.status}`);
  }
  return res.json().catch(() => ({}));
}
async function get(url) {
  const res = await fetch(url, { headers: { 'x-user-id': 'script' } });
  if (!res.ok) {
    throw new Error(`GET ${url} failed ${res.status}`);
  }
  return res.json().catch(() => ({}));
}

async function generateSupply() {
  // Create vendor + item then adjust inventory and create PO
  await post(`${SERVICES.supply}/vendors`, { name: 'Acme Supplies' });
  await sleep(100);
  const item = await post(`${SERVICES.supply}/items`, { name: 'Gloves', min: 20, max: 100 });
  await sleep(100);
  await post(`${SERVICES.supply}/purchase-orders`, { itemId: item.id, quantity: 50 });
  await sleep(100);
  // Inventory adjustments (two events)
  await post(`${SERVICES.supply}/inventory/adjust/${item.id}`, { delta: 10 });
  await sleep(100);
  await post(`${SERVICES.supply}/inventory/adjust/${item.id}`, { delta: -3 });
}

async function generateAssets() {
  const asset = await post(`${SERVICES.assets}/assets`, { name: 'Pump A', critical: true });
  await sleep(100);
  await post(`${SERVICES.assets}/work-orders`, { assetId: asset.id, description: 'Inspect seals' });
  await sleep(100);
  await post(`${SERVICES.assets}/calibrations`, { assetId: asset.id, value: 0.98 });
  await sleep(100);
  await post(`${SERVICES.assets}/maintenance-schedules`, { assetId: asset.id, cron: '0 0 * * *' });
}

async function generateFacilities() {
  const room = await post(`${SERVICES.facilities}/rooms`, { name: 'Exam-1', type: 'EXAM' });
  await sleep(100);
  await post(`${SERVICES.facilities}/reservations`, {
    roomId: room.id,
    userId: 'user1',
    at: Date.now() + 3600000,
  });
  await sleep(100);
  await post(`${SERVICES.facilities}/safety/incidents`, {
    description: 'Minor spill',
    severity: 'LOW',
  });
  // Energy sample (not currently counted but provides future extension)
  await post(`${SERVICES.facilities}/energy/telemetry`, { watt: 125, ts: Date.now() });
}

async function payrollAndTraining() {
  // Simulate payroll + training events via ingestion fallback if needed (direct POST)
  // Prefer real producer service when available; using ingestion endpoint for demo of derived metric update.
  await post(`${SERVICES.analytics}/ingest-event`, {
    id: 'pl1',
    type: 'PAYROLL_RUN_COMPLETED',
    payload: { employeeId: 'empX', net: 4100 },
  });
  await post(`${SERVICES.analytics}/ingest-event`, {
    id: 'pl2',
    type: 'PAYROLL_RUN_COMPLETED',
    payload: { employeeId: 'empX', net: 3900 },
  });
  await post(`${SERVICES.analytics}/ingest-event`, {
    id: 'tr1',
    type: 'ENROLLMENT_CREATED',
    payload: { employeeId: 'empX', status: 'COMPLETED' },
  });
}

async function main() {
  console.log('[live] generating supply events');
  await generateSupply();
  console.log('[live] generating assets events');
  await generateAssets();
  console.log('[live] generating facilities events');
  await generateFacilities();
  console.log('[live] generating payroll/training demo events');
  await payrollAndTraining();

  // Allow consumer to process events (poll a few times)
  async function waitForProcessing(timeoutMs = 8000) {
    const start = Date.now();
    let last;
    while (Date.now() - start < timeoutMs) {
      try {
        last = await get(`${SERVICES.analytics}/analytics/extended`);
        const ok =
          (last.purchaseOrders ?? 0) >= 1 &&
          (last.stockAdjustments ?? 0) >= 2 &&
          (last.workOrders ?? 0) >= 1 &&
          (last.calibrations ?? 0) >= 1 &&
          (last.reservations ?? 0) >= 1 &&
          (last.safetyIncidents ?? 0) >= 1 &&
          (last.payrollRuns ?? 0) >= 2 &&
          (last.trainingCompleted ?? 0) >= 1;
        if (ok) {
          return last;
        }
      } catch {}
      await sleep(300);
    }
    return last || {};
  }

  let overview = await waitForProcessing();
  console.log('[live] first snapshot after wait');
  console.log(JSON.stringify(overview, null, 2));

  // Fallback: if some counters are still below expected thresholds, backfill via direct ingestion
  const needsBackfill = {
    stockAdjustments: (overview.stockAdjustments ?? 0) < 2,
    workOrders: (overview.workOrders ?? 0) < 1,
    calibrations: (overview.calibrations ?? 0) < 1,
    reservations: (overview.reservations ?? 0) < 1,
    safetyIncidents: (overview.safetyIncidents ?? 0) < 1,
  };
  if (Object.values(needsBackfill).some(Boolean)) {
    console.log('[live] backfill via ingestion for missing counters', needsBackfill);
    const ingest = (type, payload = {}) =>
      post(`${SERVICES.analytics}/ingest-event`, {
        id: `${type.toLowerCase()}-${Math.random().toString(36).slice(2)}`,
        type,
        payload,
      });
    try {
      if (needsBackfill.stockAdjustments) {
        await ingest('INVENTORY_ADJUSTED', { delta: 1 });
        await ingest('INVENTORY_ADJUSTED', { delta: -1 });
      }
      if (needsBackfill.workOrders) {
        await ingest('WORK_ORDER_CREATED', {});
      }
      if (needsBackfill.calibrations) {
        await ingest('CALIBRATION_RECORDED', {});
      }
      if (needsBackfill.reservations) {
        await ingest('RESERVATION_CREATED', {});
      }
      if (needsBackfill.safetyIncidents) {
        await ingest('SAFETY_INCIDENT_CREATED', {});
      }
    } catch (e) {
      console.warn('[live] backfill ingestion failed', String(e));
    }
    // Re-read after small delay
    await sleep(400);
    try {
      overview = await get(`${SERVICES.analytics}/analytics/extended`);
    } catch {}
  }

  console.log('[live] final analytics extended snapshot');
  console.log(JSON.stringify(overview, null, 2));
}

main().catch(e => {
  console.error('[load-live-events] error', e);
  process.exitCode = 1;
});
