// Posts a few sample events to the analytics ingestion endpoint, then prints /analytics/extended

const BASE = process.env.ANALYTICS_BASE_URL || 'http://127.0.0.1:3061';

async function postEvent(evt) {
  const res = await fetch(`${BASE}/ingest-event`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(evt),
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`ingest failed ${res.status}: ${text}`);
  }
}

async function main() {
  // Core sample events
  const events = [
    // Supply
    { id: 'e1', type: 'INVENTORY_ADJUSTED', payload: { id: 'inv1' } },
    { id: 'e2', type: 'PURCHASE_ORDER_CREATED', payload: { id: 'po1' } },
    // Assets
    { id: 'e3', type: 'WORK_ORDER_CREATED', payload: { id: 'wo1' } },
    { id: 'e4', type: 'CALIBRATION_RECORDED', payload: { id: 'cal1' } },
    // Facilities
    { id: 'e5', type: 'RESERVATION_CREATED', payload: { roomId: 'r1', userId: 'u1' } },
    { id: 'e6', type: 'SAFETY_INCIDENT_CREATED', payload: { id: 'si1', severity: 'LOW' } },
    // Payroll + training to exercise derived + training counters
    { id: 'e7', type: 'PAYROLL_RUN_COMPLETED', payload: { employeeId: 'emp1', net: 3200.55 } },
    { id: 'e8', type: 'PAYROLL_RUN_COMPLETED', payload: { employeeId: 'emp1', net: 2800.1 } },
    { id: 'e9', type: 'ENROLLMENT_CREATED', payload: { employeeId: 'emp1', status: 'COMPLETED' } },
    { id: 'e10', type: 'ENROLLMENT_CREATED', payload: { employeeId: 'emp2', status: 'PENDING' } },
  ];
  for (const e of events) {
    await postEvent(e);
  }
  const r = await fetch(`${BASE}/analytics/extended`);
  const json = await r.json();
  console.log(JSON.stringify(json, null, 2));
}

main().catch(e => {
  console.error('[load-sample-events] error', e);
  process.exitCode = 1;
});
