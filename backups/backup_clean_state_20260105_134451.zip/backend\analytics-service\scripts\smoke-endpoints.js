// Simple smoke test: ensures key analytics endpoints respond and basic counters update after sample events.
// Usage (host): node scripts/smoke-endpoints.js
// Optionally set ANALYTICS_BASE_URL; defaults to http://127.0.0.1:3061

const BASE = process.env.ANALYTICS_BASE_URL || 'http://127.0.0.1:3061';

async function get(path) {
  const url = `${BASE}${path}`;
  const res = await fetch(url);
  if (!res.ok) {
    throw new Error(`GET ${path} failed ${res.status}`);
  }
  const ct = res.headers.get('content-type') || '';
  if (ct.includes('application/json')) {
    return res.json();
  }
  return res.text();
}
async function post(path, body) {
  const url = `${BASE}${path}`;
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body || {}),
  });
  if (!res.ok) {
    throw new Error(`POST ${path} failed ${res.status}`);
  }
  return res.json().catch(() => ({}));
}

async function run() {
  console.log('[smoke] BASE', BASE);
  // 1. Health
  const health = await get('/health');
  console.log('[smoke] /health', health);
  // 2. Initial extended snapshot
  const before = await get('/analytics/extended/');
  console.log('[smoke] before /analytics/extended', before);
  // 3. Send sample events (payroll + training)
  await post('/ingest-event', {
    id: 'sm-payroll-1',
    type: 'PAYROLL_RUN_COMPLETED',
    payload: { employeeId: 'sm1', net: 1000 },
  });
  await post('/ingest-event', {
    id: 'sm-train-1',
    type: 'ENROLLMENT_CREATED',
    payload: { employeeId: 'sm1', status: 'COMPLETED' },
  });
  // 4. After snapshot
  const after = await get('/analytics/extended');
  console.log('[smoke] after /analytics/extended', after);
  // 5. Metrics scrape (first 20 lines)
  const metrics = await get('/metrics');
  const metricsLines = metrics.split('\n').slice(0, 20).join('\n');
  console.log('[smoke] metrics sample:\n' + metricsLines);

  // Basic assertions (no test runner, exit code only)
  let ok = true;
  if (after.payrollRuns < before.payrollRuns + 1) {
    console.error('Expected payrollRuns increment');
    ok = false;
  }
  if (after.trainingCompleted < before.trainingCompleted + 1) {
    console.error('Expected trainingCompleted increment');
    ok = false;
  }
  if (!('analytics_global_payrollRuns' /* string search later */)) {
    /* placeholder */
  }

  if (!ok) {
    console.error('[smoke] FAILED');
    process.exitCode = 1;
  } else {
    console.log('[smoke] PASSED');
  }
}

run().catch(e => {
  console.error('[smoke] error', e);
  process.exitCode = 1;
});
