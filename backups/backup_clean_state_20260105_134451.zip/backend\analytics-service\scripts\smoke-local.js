#!/usr/bin/env node
// Start analytics-service in-process, run smoke, then shutdown (Windows-friendly)
import { createServer } from '../src/server.js';
import { start as startConsumer, stop as stopConsumer } from '../src/consumer.js';
import http from 'http';
import { connect, StringCodec } from 'nats';

process.env.NATS_SERVERS = process.env.NATS_SERVERS || 'nats://127.0.0.1:4222';
process.env.ANALYTICS_STREAM_ENABLED = 'true';
process.env.METRICS_ENABLED = process.env.METRICS_ENABLED || 'true';
process.env.METRICS_DEFAULTS = process.env.METRICS_DEFAULTS || 'true';

function env(name, def) {
  return process.env[name] || def;
}
const sc = StringCodec();

function envelope({ type, source, payload }) {
  return { id: cryptoRandomId(), type, source, occurredAt: new Date().toISOString(), payload };
}
function cryptoRandomId() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

async function publishBatch(nc, subject, events) {
  for (const evt of events) {
    nc.publish(subject, sc.encode(JSON.stringify(evt)));
  }
}
function fetchJSON(url) {
  return new Promise((resolve, reject) => {
    http
      .get(url, res => {
        let data = '';
        res.on('data', c => (data += c));
        res.on('end', () => {
          try {
            resolve(JSON.parse(data));
          } catch (e) {
            reject(e);
          }
        });
      })
      .on('error', reject);
  });
}

(async () => {
  const app = createServer();
  const address = await new Promise((resolve, reject) => {
    app.listen({ port: 0, host: '127.0.0.1' }, (err, addr) => (err ? reject(err) : resolve(addr)));
  });
  const url = `http://${address.split('://')[1]}`; // addr like http://127.0.0.1:PORT
  console.log('[smoke-local] server started at', url);
  await startConsumer();

  let nc;
  try {
    nc = await connect({ servers: env('NATS_SERVERS', 'nats://127.0.0.1:4222') });
  } catch (e) {
    console.error('[smoke-local] NATS connect failed', e?.message || e);
    process.exit(2);
  }

  const employeeId = 'emp-smoke';
  const payrollEvents = [
    envelope({
      type: 'PAYROLL_RUN_COMPLETED',
      source: 'payroll-service',
      payload: { employeeId, net: 1200 },
    }),
    envelope({
      type: 'PAYROLL_RUN_COMPLETED',
      source: 'payroll-service',
      payload: { employeeId, net: 1300 },
    }),
  ];
  const lmsEvents = [
    envelope({
      type: 'ENROLLMENT_CREATED',
      source: 'lms-service',
      payload: { employeeId, status: 'COMPLETED' },
    }),
    envelope({
      type: 'ENROLLMENT_CREATED',
      source: 'lms-service',
      payload: { employeeId, status: 'PENDING' },
    }),
  ];
  const qualityEvents = [
    envelope({
      type: 'INCIDENT_REPORTED',
      source: 'quality-service',
      payload: { employeeId, severity: 'LOW' },
    }),
    envelope({
      type: 'AUDIT_LOGGED',
      source: 'quality-service',
      payload: { employeeId, scope: 'SAFETY' },
    }),
  ];
  const kpiEvents = [
    envelope({
      type: 'KPI_UPDATED',
      source: 'quality-service',
      payload: { employeeId, kpi: 'throughput', value: 0.87 },
    }),
  ];
  const licenseEvents = [
    envelope({
      type: 'LICENSE_EXPIRING',
      source: 'hr-service',
      payload: { employeeId, dueInDays: 28 },
    }),
  ];

  await publishBatch(nc, 'payroll.events', payrollEvents);
  await publishBatch(nc, 'lms.events', lmsEvents);
  await publishBatch(nc, 'quality.events', qualityEvents);
  await publishBatch(nc, 'quality.events', kpiEvents);
  await publishBatch(nc, 'hr.events', licenseEvents);
  // duplicate first payroll
  nc.publish('payroll.events', sc.encode(JSON.stringify(payrollEvents[0])));
  await nc.flush();
  await nc.drain();
  console.log('[smoke-local] events published, waiting 1.5s');
  await new Promise(r => setTimeout(r, 1500));

  const emp = await fetchJSON(`${url}/analytics/employee/${employeeId}`).catch(() => ({}));
  const overview = await fetchJSON(`${url}/analytics/overview`).catch(() => ({}));
  const health = await fetchJSON(`${url}/health`).catch(() => ({}));
  console.log('[smoke-local] health:', health);
  console.log('[smoke-local] employee:', emp);
  console.log('[smoke-local] overview:', overview);

  try {
    await stopConsumer();
  } catch {}
  try {
    await app.close();
  } catch {}
  console.log('[smoke-local] done');
  process.exit(0);
})().catch(e => {
  console.error('[smoke-local] fatal', e);
  process.exit(1);
});
