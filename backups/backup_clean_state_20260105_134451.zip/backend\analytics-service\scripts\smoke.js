#!/usr/bin/env node
/**
 * Smoke test for analytics-service streaming pipeline.
 * 1. Publishes a set of standardized envelope events to NATS subjects mimicking domain services.
 * 2. Waits briefly for consumer processing.
 * 3. Fetches employee + overview aggregates and prints summary.
 * 4. Optionally prints /metrics if METRICS_ENABLED.
 */
import { connect, StringCodec } from 'nats';
import http from 'http';

function env(name, def) {
  return process.env[name] || def;
}
const servers = env('NATS_SERVERS', env('NATS_URL', 'nats://127.0.0.1:4222'));
const employeeId = env('SMOKE_EMPLOYEE_ID', 'emp-smoke');
const sc = StringCodec();

function envelope({ type, source, payload }) {
  return {
    id: cryptoRandomId(),
    type,
    source,
    occurredAt: new Date().toISOString(),
    payload,
  };
}
function cryptoRandomId() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

async function publishBatch(nc, subject, events) {
  for (const evt of events) {
    nc.publish(subject, sc.encode(JSON.stringify(evt)));
  }
}

function fetchJSON(url) {
  return new Promise((resolve, reject) => {
    http
      .get(url, res => {
        let data = '';
        res.on('data', c => (data += c));
        res.on('end', () => {
          try {
            resolve(JSON.parse(data));
          } catch (e) {
            reject(e);
          }
        });
      })
      .on('error', reject);
  });
}

(async () => {
  console.log('[smoke] Connecting to NATS:', servers);
  let nc;
  try {
    nc = await connect({
      servers: servers
        .split(',')
        .map(s => s.trim())
        .filter(Boolean),
      timeout: 1500,
    });
  } catch (err) {
    console.error(
      '[smoke] Failed to connect to NATS. Ensure broker is running (e.g., docker run -d -p 4222:4222 nats:2.10-alpine).'
    );
    console.error('[smoke] Error:', err.code || err.message);
    process.exit(2);
  }
  console.log('[smoke] Connected');

  const payrollEvents = [
    envelope({
      type: 'PAYROLL_RUN_COMPLETED',
      source: 'payroll-service',
      payload: { employeeId, net: 1200 },
    }),
    envelope({
      type: 'PAYROLL_RUN_COMPLETED',
      source: 'payroll-service',
      payload: { employeeId, net: 1300 },
    }),
  ];
  const lmsEvents = [
    envelope({
      type: 'ENROLLMENT_CREATED',
      source: 'lms-service',
      payload: { employeeId, status: 'COMPLETED' },
    }),
    envelope({
      type: 'ENROLLMENT_CREATED',
      source: 'lms-service',
      payload: { employeeId, status: 'PENDING' },
    }),
  ];
  const qualityEvents = [
    envelope({
      type: 'INCIDENT_REPORTED',
      source: 'quality-service',
      payload: { employeeId, severity: 'LOW' },
    }),
    envelope({
      type: 'AUDIT_LOGGED',
      source: 'quality-service',
      payload: { employeeId, scope: 'SAFETY' },
    }),
  ];
  const kpiEvents = [
    envelope({
      type: 'KPI_UPDATED',
      source: 'quality-service',
      payload: { employeeId, kpi: 'throughput', value: 0.87 },
    }),
  ];
  const licenseEvents = [
    envelope({
      type: 'LICENSE_EXPIRING',
      source: 'hr-service',
      payload: { employeeId, dueInDays: 28 },
    }),
  ];

  console.log('[smoke] Publishing events');
  await publishBatch(nc, 'payroll.events', payrollEvents);
  await publishBatch(nc, 'lms.events', lmsEvents);
  await publishBatch(nc, 'quality.events', qualityEvents);
  await publishBatch(nc, 'quality.events', kpiEvents);
  await publishBatch(nc, 'hr.events', licenseEvents);

  // Duplicate one event to exercise dedup (same id reused)
  const dup = payrollEvents[0];
  nc.publish('payroll.events', sc.encode(JSON.stringify(dup)));
  console.log('[smoke] Published duplicate event to test dedup:', dup.id);

  await nc.flush();
  await nc.drain();
  console.log('[smoke] Events sent; waiting 1.5s for processing');
  await new Promise(r => setTimeout(r, 1500));

  const baseUrl = env('ANALYTICS_BASE_URL', 'http://127.0.0.1:3061');
  // Wait for analytics-service health if not immediately available (up to ~10s)
  for (let i = 0; i < 40; i++) {
    // extend polling to ~20s
    const ok = await canReach(`${baseUrl}/health`);
    if (ok) {
      console.log(`[smoke] /health reachable after ${i + 1} attempt(s)`);
      break;
    }
    await new Promise(r => setTimeout(r, 500));
    if (i % 5 === 4) {
      console.log(`[smoke] waiting for /health ... attempt ${i + 1}`);
    }
    if (i === 39) {
      console.warn('[smoke] analytics-service /health not reachable after 20s');
    }
  }
  try {
    const emp = await fetchJSON(`${baseUrl}/analytics/employee/${employeeId}`);
    console.log('[smoke] Employee aggregate:', emp);
  } catch (err) {
    console.warn('[smoke] Failed to fetch employee aggregate', err.message);
  }
  // Health snapshot
  try {
    const health = await fetchJSON(`${baseUrl}/health`);
    console.log('[smoke] Health:', health);
  } catch (err) {
    console.warn('[smoke] Failed to fetch health', err.message);
  }
  try {
    const overview = await fetchJSON(`${baseUrl}/analytics/overview`);
    console.log('[smoke] Global overview:', overview);
  } catch (err) {
    console.warn('[smoke] Failed to fetch overview', err.message);
  }
  if (process.env.METRICS_ENABLED === 'true') {
    try {
      const rawMetrics = await fetchRaw(`${baseUrl}/metrics`);
      console.log('[smoke] Metrics sample (first 20 lines):');
      console.log(rawMetrics.split('\n').slice(0, 20).join('\n'));
    } catch (err) {
      console.warn('[smoke] Failed to fetch metrics', err.message);
    }
  }
  console.log('[smoke] Complete');
})().catch(err => {
  console.error('[smoke] Fatal', err);
  process.exit(1);
});

function fetchRaw(url) {
  return new Promise((resolve, reject) => {
    http
      .get(url, res => {
        let data = '';
        res.on('data', c => (data += c));
        res.on('end', () => resolve(data));
      })
      .on('error', reject);
  });
}

function canReach(url) {
  return new Promise(resolve => {
    http
      .get(url, res => {
        res.resume();
        resolve(res.statusCode && res.statusCode < 500);
      })
      .on('error', () => resolve(false));
  });
}
