// Local dev starter: runs the analytics server and (optionally) the embedded consumer.
// Keeps the process alive and prints useful diagnostics on failure.

process.env.METRICS_ENABLED = process.env.METRICS_ENABLED ?? 'true';
process.env.METRICS_DEFAULTS = process.env.METRICS_DEFAULTS ?? 'true';
process.env.PORT = process.env.PORT ?? '3061';

(async () => {
  try {
    const { createServer } = await import('../src/server.js');
    const fastify = createServer();
    const port = Number(process.env.PORT || 3061);
    await new Promise(resolve =>
      fastify.listen({ port, host: '0.0.0.0' }, (err, address) => {
        if (err) {
          console.error('[analytics-local] server start failed', err);
          resolve();
          return;
        }
        console.log(`[analytics-local] server listening at ${address}`);
        resolve();
      })
    );

    if (process.env.ANALYTICS_STREAM_ENABLED !== 'false') {
      try {
        const consumer = await import('../src/consumer.js');
        await consumer.start?.();
        console.log('[analytics-local] consumer started');
      } catch (e) {
        console.error('[analytics-local] consumer failed to start', e);
      }
    }
  } catch (e) {
    console.error('[analytics-local] boot error', e);
  }

  // Keep alive for interactive diagnosis
  setInterval(() => console.log('[analytics-local] tick'), 30000);
})();
