#!/usr/bin/env node
/*
 End-to-end streaming smoke for Windows-friendly dev:
 - Starts analytics-service (port 3061) with streaming + metrics
 - Starts hr-service (port 3011)
 - Emits a sample LICENSE_EXPIRING event via hr-service endpoint
 - Verifies analytics aggregates and prints key metrics
 - Shuts both servers down gracefully
*/
import { spawn } from 'child_process';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import { fetchPromQuery } from './lib/prom-helpers.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const repoRoot = path.resolve(__dirname, '..', '..'); // backend/analytics-service -> backend

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}
function fetchJSON(url) {
  return new Promise((resolve, reject) => {
    http
      .get(url, res => {
        let data = '';
        res.on('data', c => (data += c));
        res.on('end', () => {
          try {
            resolve(JSON.parse(data));
          } catch (e) {
            reject(e);
          }
        });
      })
      .on('error', reject);
  });
}
function fetchRaw(url) {
  return new Promise((resolve, reject) => {
    http
      .get(url, res => {
        let data = '';
        res.on('data', c => (data += c));
        res.on('end', () => resolve(data));
      })
      .on('error', reject);
  });
}
function postJSON(url, body) {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const req = http.request(
      {
        hostname: u.hostname,
        port: u.port,
        path: u.pathname,
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      },
      res => {
        let data = '';
        res.on('data', c => (data += c));
        res.on('end', () => {
          try {
            resolve(JSON.parse(data || '{}'));
          } catch {
            resolve({});
          }
        });
      }
    );
    req.on('error', reject);
    req.end(JSON.stringify(body || {}));
  });
}

// fetchPromQuery now provided by lib/prom-helpers

async function tryGrafanaPromQuery(query, baseUrl, apiKey) {
  // Try to resolve the first Prometheus datasource and proxy the same query through Grafana
  // Requires: GRAFANA_URL and GRAFANA_API_KEY
  const headers = { Authorization: `Bearer ${apiKey}` };
  // List datasources
  const dsList = await new Promise((resolve, reject) => {
    const u = new URL(`${baseUrl.replace(/\/$/, '')}/api/datasources`);
    const req = http.request(
      { hostname: u.hostname, port: u.port || 80, path: u.pathname, method: 'GET', headers },
      res => {
        let data = '';
        res.on('data', c => (data += c));
        res.on('end', () => {
          try {
            resolve(JSON.parse(data));
          } catch (err) {
            reject(err);
          }
        });
      }
    );
    req.on('error', reject);
    req.end();
  }).catch(() => null);
  if (!Array.isArray(dsList)) {
    return null;
  }
  const prom = dsList.find(d => (d.type || '').includes('prometheus'));
  if (!prom) {
    return null;
  }
  const proxyPath = `/api/datasources/proxy/${prom.id}/api/v1/query?query=${encodeURIComponent(query)}`;
  const proxied = await new Promise((resolve, reject) => {
    const u = new URL(`${baseUrl.replace(/\/$/, '')}${proxyPath}`);
    const req = http.request(
      {
        hostname: u.hostname,
        port: u.port || 80,
        path: u.pathname + u.search,
        method: 'GET',
        headers,
      },
      res => {
        let data = '';
        res.on('data', c => (data += c));
        res.on('end', () => {
          try {
            resolve(JSON.parse(data));
          } catch (err) {
            reject(err);
          }
        });
      }
    );
    req.on('error', reject);
    req.end();
  }).catch(() => null);
  if (!proxied || proxied.status !== 'success') {
    return null;
  }
  return proxied.data;
}

function startNode(file, opts = {}) {
  const env = { ...process.env, ...(opts.env || {}) };
  const child = spawn(process.execPath, [file], {
    cwd: opts.cwd || process.cwd(),
    env,
    stdio: 'pipe',
  });
  child.stdout.on('data', d => process.stdout.write(d));
  child.stderr.on('data', d => process.stderr.write(d));
  return child;
}

function runOnce(cmd, args = [], opts = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(cmd, args, {
      cwd: opts.cwd || process.cwd(),
      env: { ...process.env, ...(opts.env || {}) },
      stdio: 'inherit',
      shell: false,
    });
    child.on('exit', code => {
      if (code === 0) {
        return resolve();
      }
      reject(new Error(`${cmd} ${args.join(' ')} exited with code ${code}`));
    });
    child.on('error', reject);
  });
}

(async () => {
  const analyticsDir = path.join(repoRoot, 'analytics-service');
  const hrDir = path.join(repoRoot, 'hr-service');
  // Resolve ports with fallback if already in use
  let analyticsPort = 3061;
  let hrPort = 3011;
  // Probe if default ports are already serving health
  const probe = async port => {
    try {
      const r = await fetchJSON(`http://127.0.0.1:${port}/health`);
      return r && r.status === 'ok';
    } catch {
      return false;
    }
  };
  const analyticsBusy = await probe(analyticsPort);
  if (analyticsBusy) {
    analyticsPort = 3062;
  } // we'll start our own instance on 3062
  const hrBusy = await probe(hrPort);
  if (hrBusy) {
    hrPort = 3012;
  } // start our own instance on 3012

  // Start analytics-service (streaming enabled)
  const analyticsEnv = {
    NATS_SERVERS: process.env.NATS_SERVERS || 'nats://127.0.0.1:4222',
    ANALYTICS_STREAM_ENABLED: 'true',
    METRICS_ENABLED: 'true',
    METRICS_DEFAULTS: 'true',
    PORT: String(analyticsPort),
    ANALYTICS_DEBUG_STATE: process.env.ANALYTICS_DEBUG_STATE || 'false',
  };
  const analyticsProc = startNode(path.join(analyticsDir, 'src', 'server.js'), {
    cwd: analyticsDir,
    env: analyticsEnv,
  });

  // Wait for analytics /health
  let ok = false;
  for (let i = 0; i < 50; i++) {
    try {
      const r = await fetchJSON(`http://127.0.0.1:${analyticsPort}/health`);
      if (r && r.status === 'ok') {
        ok = true;
        break;
      }
    } catch {}
    await sleep(400);
  }
  if (!ok) {
    throw new Error(`analytics-service /health not reachable on ${analyticsPort}`);
  }

  // Start hr-service
  const hrEnv = {
    NATS_SERVERS: process.env.NATS_SERVERS || 'nats://127.0.0.1:4222',
    METRICS_ENABLED: 'true',
    METRICS_DEFAULTS: 'true',
    PORT: String(hrPort),
  };
  const hrProc = startNode(path.join(hrDir, 'src', 'server.js'), { cwd: hrDir, env: hrEnv });

  // Wait for hr /health
  ok = false;
  for (let i = 0; i < 50; i++) {
    try {
      const r = await fetchJSON(`http://127.0.0.1:${hrPort}/health`);
      if (r && r.status === 'ok') {
        ok = true;
        break;
      }
    } catch {}
    await sleep(400);
  }
  if (!ok) {
    throw new Error(`hr-service /health not reachable on ${hrPort}`);
  }

  // Optional warm-up: publish a batch of events and wait for Prometheus scrape
  const warmBatch = Number(process.env.E2E_WARMUP_BATCH || 0);
  if (warmBatch > 0) {
    console.log(`[e2e] warm-up: publishing ${warmBatch} events before checks...`);
    const analyticsSvcDir = path.join(repoRoot, 'analytics-service');
    await runOnce(
      process.execPath,
      [path.join(analyticsSvcDir, 'scripts', 'load-sample-events.js')],
      {
        cwd: analyticsSvcDir,
        env: {
          BATCH: String(warmBatch),
          EMPLOYEE_ID: 'ci-warmup',
          NATS_SERVERS: process.env.NATS_SERVERS || 'nats://127.0.0.1:4222',
        },
      }
    );
    const scrapeWait = Number(process.env.E2E_SCRAPE_WAIT || 20);
    console.log(`[e2e] warm-up: waiting ${scrapeWait}s for Prometheus scrape...`);
    await sleep(scrapeWait * 1000);
  }

  // Capture Prometheus baseline by instance (if available) BEFORE the event
  const promBase = process.env.PROM_URL || 'http://127.0.0.1:9090';
  const promQl = 'sum by (instance) (analytics_events_processed_total)';
  const toMap = data => {
    const m = new Map();
    if (data && Array.isArray(data.result)) {
      for (const r of data.result) {
        const inst = r.metric?.instance;
        const val = Number(r.value?.[1] || 0);
        if (inst) {
          m.set(inst, val);
        }
      }
    }
    return m;
  };
  const promBefore = toMap(await fetchPromQuery(promQl, promBase));

  // Emit sample event to our hr-service instance
  const resp = await postJSON(`http://127.0.0.1:${hrPort}/debug/emit-sample`, {
    employeeId: 'emp-sample',
    dueInDays: 12,
  });
  console.log('[e2e] emit response:', resp);

  // Verify analytics aggregates and metrics
  await sleep(1000);
  const emp = await fetchJSON(
    `http://127.0.0.1:${analyticsPort}/analytics/employee/emp-sample`
  ).catch(() => ({}));
  console.log('[e2e] analytics employee:', emp);
  const metrics = await fetchRaw(`http://127.0.0.1:${analyticsPort}/metrics`).catch(() => '');
  const lines = metrics
    .split('\n')
    .filter(
      l =>
        l.includes('analytics_events_processed_total') ||
        l.includes('analytics_events_deduplicated_total')
    );
  console.log('[e2e] metrics sample:', lines.slice(0, 10).join('\n'));

  // Identify which Prometheus target (3061 vs 3062) recorded the increment via Prometheus API
  const promData = await fetchPromQuery(promQl, promBase);
  if (promData && Array.isArray(promData.result) && promData.result.length) {
    const afterMap = toMap(promData);
    const deltas = [];
    for (const [inst, val] of afterMap.entries()) {
      const before = promBefore.get(inst) || 0;
      const delta = val - before;
      if (delta > 0) {
        deltas.push({ inst, delta });
      }
    }
    if (deltas.length) {
      console.log(
        '[e2e] prometheus instances with processed_total delta > 0:',
        deltas.map(d => `${d.inst} (+${d.delta})`).join(', ')
      );
      // Always assert that at least one instance increased processed_total
      const totalDelta = deltas.reduce((s, d) => s + d.delta, 0);
      if (totalDelta <= 0) {
        throw new Error('expected processed_total to increase, but delta was 0');
      }
      if (String(process.env.E2E_ASSERT_SINGLE_TARGET) === 'true') {
        const expected = `127.0.0.1:${analyticsPort}`;
        const matched = deltas.filter(d => d.inst === expected);
        if (deltas.length !== 1 || matched.length !== 1) {
          throw new Error(
            `strict-single-target failed: expected exactly one target ${expected} to change; got ${deltas
              .map(d => d.inst)
              .join(', ')}`
          );
        }
      }
    } else {
      // Prometheus reachable but no increment observed: treat as failure for stricter e2e
      throw new Error('[e2e] prometheus reachable but no instance changed since baseline');
    }
  } else {
    console.log(
      `[e2e] prometheus not reachable at ${promBase}; service responded on port ${analyticsPort}`
    );
  }

  // Optional: If Grafana API is configured, validate via panel datasource proxy
  if (process.env.GRAFANA_URL && process.env.GRAFANA_API_KEY) {
    const gData = await tryGrafanaPromQuery(
      promQl,
      process.env.GRAFANA_URL,
      process.env.GRAFANA_API_KEY
    );
    if (gData && Array.isArray(gData.result)) {
      const instances = gData.result
        .filter(r => Number(r.value?.[1] || 0) > 0)
        .map(r => r.metric?.instance)
        .filter(Boolean);
      console.log(
        '[e2e] grafana proxy instances with >0 processed_total:',
        instances.join(', ') || 'none'
      );
    } else {
      console.log('[e2e] grafana API reachable but no data returned for query');
    }
  }

  // Done - terminate children
  analyticsProc.kill('SIGTERM');
  hrProc.kill('SIGTERM');
  console.log('[e2e] done');
})().catch(err => {
  console.error('[e2e] failed:', err);
  process.exit(1);
});
