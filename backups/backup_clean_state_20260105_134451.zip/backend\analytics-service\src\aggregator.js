// Aggregator entrypoint: starts all analytics background processors.
// Currently this starts the NATS consumer to aggregate events into in-memory state.

export async function startAll() {
  try {
    const consumer = await import('./consumer.js');
    await consumer.start?.();
    console.log('[aggregator] consumer started');
  } catch (err) {
    console.error('[aggregator] failed to start consumer', err);
    throw err;
  }
}

// If run directly: start all
if (import.meta.url === `file://${process.argv[1]}`) {
  startAll().catch(() => {
    // keep alive for inspection
    setInterval(() => console.log('[aggregator] waiting after error'), 30000);
  });
}
