// Streaming consumer for analytics-service (NATS core). Switchable via ANALYTICS_STREAM_ENABLED=true
const { createLogger } = require('../../shared/logging/index.js');
const { applyEnvelopeAggregation, state } = require('./state.js');
const { initTracing, withSpan } = require('../../shared/otel/index.js');
const { performance } = require('perf_hooks');

const logger = createLogger();
initTracing({ serviceName: 'analytics-consumer' });

function env(name, def) {
  return process.env[name] || def;
}

// Subscribe to all subjects ending with .events (e.g., payroll.events, lms.events)
const SUBJECTS = env('ANALYTICS_NATS_SUBJECTS', '*.events');
let natsConn = null;
let shuttingDown = false;
let prom = null;
// Provide a sane default NATS server for local development if none configured
if (!process.env.NATS_SERVERS && !process.env.NATS_URL) {
  process.env.NATS_SERVERS = 'nats://127.0.0.1:4222';
}

// Dedup window (LRU) for idempotency before persistent store
const MAX_DEDUP = Number(env('ANALYTICS_DEDUP_WINDOW', '50000'));
const ENABLE_DEDUP = env('ANALYTICS_DEDUP_ENABLED', 'true') === 'true';
const seenIds = new Map(); // id -> timestamp

function dedup(id) {
  if (!ENABLE_DEDUP || !id) {
    return false;
  } // not deduped
  if (seenIds.has(id)) {
    return true;
  } // already processed
  seenIds.set(id, Date.now());
  if (seenIds.size > MAX_DEDUP) {
    // Simple eviction: remove oldest ~10% to keep map bounded
    const entries = [...seenIds.entries()].sort((a, b) => a[1] - b[1]);
    const removeCount = Math.ceil(entries.length * 0.1);
    for (let i = 0; i < removeCount; i++) {
      seenIds.delete(entries[i][0]);
    }
  }
  return false;
}

function initMetricsIfEnabled() {
  if (process.env.METRICS_ENABLED !== 'true' || prom) {
    return;
  }
  try {
    prom = globalThis.__promClient ||= require('prom-client');
    if (process.env.METRICS_DEFAULTS === 'true' && !globalThis.__metricsDefaultsRegistered) {
      try {
        prom.collectDefaultMetrics({ prefix: process.env.METRICS_PREFIX || '' });
        globalThis.__metricsDefaultsRegistered = true;
      } catch (e) {
        logger.warn({ err: String(e) }, 'metrics-defaults-init-failed');
      }
    }
    metrics.eventsProcessed = new prom.Counter({
      name: 'analytics_events_processed_total',
      help: 'Events successfully applied',
      labelNames: ['type', 'source'],
    });
    metrics.eventsInvalid = new prom.Counter({
      name: 'analytics_events_invalid_total',
      help: 'Events failed validation or processing',
      labelNames: ['reason'],
    });
    metrics.eventsDeduped = new prom.Counter({
      name: 'analytics_events_deduplicated_total',
      help: 'Events skipped due to duplicate id',
    });
    metrics.procDuration = new prom.Histogram({
      name: 'analytics_events_processing_duration_seconds',
      help: 'Per-event processing duration',
      labelNames: ['type'],
      buckets: [0.001, 0.005, 0.01, 0.05, 0.1, 0.25, 0.5, 1, 2],
    });
    metrics.natsMessages = new prom.Counter({
      name: 'analytics_nats_messages_total',
      help: 'NATS messages received by analytics consumer',
      labelNames: ['subject'],
    });
  } catch (err) {
    logger.warn({ err: String(err) }, 'analytics-consumer.metrics-init-failed');
  }
}

const metrics = {
  eventsProcessed: { inc: () => {} },
  eventsInvalid: { inc: () => {} },
  eventsDeduped: { inc: () => {} },
  procDuration: { observe: () => {} },
};

async function initNats() {
  if (natsConn) {
    return natsConn;
  }
  const servers = process.env.NATS_SERVERS || process.env.NATS_URL;
  if (!servers) {
    logger.warn('No NATS servers configured (NATS_SERVERS/NATS_URL). Consumer disabled.');
    return null;
  }
  try {
    const { connect, StringCodec } = await import('nats');
    natsConn = await connect({
      servers: servers
        .split(',')
        .map(s => s.trim())
        .filter(Boolean),
    });
    logger.info({ servers }, 'analytics-consumer.nats.connected');
    const sc = StringCodec();
    // Subscribe wildcard subjects
    const sub = natsConn.subscribe(SUBJECTS, { queue: 'analytics-workers' });
    state.meta.enabled = true;
    (async () => {
      for await (const m of sub) {
        if (shuttingDown) {
          break;
        }
        const raw = sc.decode(m.data);
        withSpan('analytics.consume', () => {
          try {
            try {
              metrics.natsMessages?.inc?.({ subject: m?.subject || 'unknown' });
            } catch {}
            processRawMessage(raw, { subject: m?.subject });
          } catch (err) {
            // processRawMessage already accounts for invalidTotal and metrics; this is a last-resort guard
            logger.error({ err: String(err) }, 'analytics-consumer.process-raw-error');
          }
        });
      }
    })();
    return natsConn;
  } catch (err) {
    logger.error({ err: String(err) }, 'analytics-consumer.nats.connect-failed');
    return null;
  }
}

async function start() {
  if (process.env.ANALYTICS_STREAM_ENABLED !== 'true') {
    logger.info('Streaming disabled (set ANALYTICS_STREAM_ENABLED=true to enable).');
    return;
  }
  initMetricsIfEnabled();
  await initNats();
}

async function stop() {
  shuttingDown = true;
  try {
    await natsConn?.drain?.();
  } catch {}
  try {
    await natsConn?.close?.();
  } catch {}
}

// Expose raw-message processing for unit tests (and potential reuse)
function processRawMessage(raw, meta = {}) {
  let evt = null;
  const t0 = performance.now?.() || Date.now();
  try {
    try {
      evt = JSON.parse(raw);
    } catch (err) {
      state.meta.invalidTotal++;
      metrics.eventsInvalid.inc({ reason: 'parse' });
      logger.error({ err: String(err) }, 'analytics-consumer.parse-failed');
      return { status: 'parse-error' };
    }
    if (process.env.ANALYTICS_CONSUMER_DEBUG === 'true') {
      try {
        logger.info(
          { type: evt?.type, source: evt?.source, subject: meta?.subject },
          'analytics-consumer.event'
        );
      } catch {}
    }
    if (dedup(evt.id)) {
      metrics.eventsDeduped.inc();
      state.meta.deduplicatedTotal = (state.meta.deduplicatedTotal || 0) + 1;
      return { status: 'deduped' };
    }
    const ok = applyEnvelopeAggregation(evt, { logger });
    const dt = (performance.now?.() || Date.now()) - t0;
    try {
      metrics.procDuration.observe({ type: evt.type || 'unknown' }, dt / 1000);
    } catch {}
    if (!ok) {
      state.meta.invalidTotal++;
      metrics.eventsInvalid.inc({ reason: 'handler' });
      return { status: 'handler-error' };
    }
    state.meta.lastEventAt = Date.now();
    metrics.eventsProcessed.inc({ type: evt.type || 'unknown', source: evt.source || 'unknown' });
    return { status: 'ok' };
  } catch (err) {
    state.meta.invalidTotal++;
    metrics.eventsInvalid.inc({ reason: 'unexpected' });
    logger.error(
      { err: String(err), rawLength: raw?.length },
      'analytics-consumer.unexpected-error'
    );
    return { status: 'unexpected-error' };
  }
}

// Testing/diagnostics helper: ensure metrics are initialized without enabling full streaming.
// Safe to call multiple times; initializes only once.
function ensureMetrics() {
  const was = !!prom; // whether already initialized
  initMetricsIfEnabled();
  return { initialized: !!prom, wasInitialized: was, metrics };
}

module.exports = {
  start,
  stop,
  processRawMessage,
  ensureMetrics,
};
// If run directly: start consumer standalone
if (process.argv[1] && process.argv[1].endsWith('consumer.js')) {
  // Auto-enable streaming when running standalone if not explicitly disabled
  if (!process.env.ANALYTICS_STREAM_ENABLED) {
    process.env.ANALYTICS_STREAM_ENABLED = 'true';
  }
  start().catch(err => {
    logger.error(err, 'consumer start failed');
    process.exit(1);
  });
  process.on('SIGINT', async () => {
    logger.info('shutdown');
    await stop();
    process.exit(0);
  });
  process.on('SIGTERM', async () => {
    logger.info('shutdown');
    await stop();
    process.exit(0);
  });
}

module.exports = {
  processRawMessage,
  ensureMetrics,
  start,
  stop,
};
