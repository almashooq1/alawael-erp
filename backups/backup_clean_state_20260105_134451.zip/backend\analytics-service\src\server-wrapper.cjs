// CommonJS wrapper to start the analytics ESM server with strong error capture.
// This helps diagnose early import/boot issues that would otherwise cause exit code 1.

(async () => {
  const PORT = Number(process.env.PORT || 3061);
  try {
    const mod = await import('./server.js');
    if (!mod || typeof mod.createServer !== 'function') {
      console.error('[analytics] createServer export not found');
      // keep process alive for inspection
      setInterval(() => console.log('[analytics] waiting (no createServer export)'), 30000);
      return;
    }
    const fastify = mod.createServer();
    fastify.listen({ port: PORT, host: '0.0.0.0' }, (err, address) => {
      if (err) {
        console.error('[analytics] server failed to start', err);
        setInterval(() => console.log('[analytics] waiting after start error'), 30000);
        return;
      }
      console.log(`[analytics] server listening at ${address}`);
    });

    // Sidecar-less consumer start when enabled
    if (process.env.ANALYTICS_STREAM_ENABLED === 'true') {
      try {
        const consumer = await import('./consumer.js');
        await consumer.start?.();
        console.log('[analytics] embedded consumer started');
      } catch (err) {
        console.error('[analytics] consumer failed to start', err);
      }
    }
  } catch (err) {
    console.error('[analytics] wrapper import error', err);
    setInterval(() => console.log('[analytics] waiting after import error'), 30000);
  }
})();
