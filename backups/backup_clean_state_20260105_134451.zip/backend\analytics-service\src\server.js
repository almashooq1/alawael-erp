/**
 * @file Analytics Service Server
 * Main entry for the analytics microservice using Fastify.
 * --------------------------------------------------------
 * Handles event ingestion, aggregation, and exposes global metrics for analytics and reporting.
 * Integrates Prometheus metrics, tracing, and health checks. All endpoints are documented inline.
 *
 * @example
 * // Start the server (from CLI)
 * $ node backend/analytics-service/src/server.js
 *
 * @example
 * // Import and use in another module
 * import { createServer } from './server.js';
 * const fastify = createServer();
 * if (process.env.NODE_ENV !== 'test') {
  fastify.listen({ port: 3090 });
   *
   * @see {@link https://www.fastify.io/docs/latest/ Fastify Documentation}
   * @see {@link https://github.com/almashooq1/66666 Project Repository}
   *
   * @section Main Variables
   * @property {Logger} logger - Main logger instance for service logging.
   * @property {Object} state - In-memory analytics state and global counters.
   *
   * @section Service Endpoints
   * - /metrics: Expose Prometheus metrics for analytics and global counters.
   * - /health, /ready: Service health and readiness checks.
   * - /ingest: Ingest analytics events (POST).
   *
   * @section Notes
   * - All endpoints are documented inline with JSDoc.
   * - For more details, see inline documentation for each function and endpoint.
   */
}
const Fastify = require('fastify');
// Security Middleware
const helmetConfig = require('../../shared/middleware/security/helmet-config');
const corsConfig = require('../../shared/middleware/security/cors-config');
const { apiLimiter } = require('../../shared/middleware/security/rate-limiter');
const securityHeaders = require('../../shared/middleware/security/security-headers');


const { sanitizeInputs, trackRequest, errorHandler } = require('../../shared/middleware/security-middleware-fastify');
// const { fileURLToPath } = require('url');
const { createLogger } = require('../../shared/logging/index.js');
const { applySecurityHeaders, makeRouteRateLimiter } = require('../../shared/http/security.js');
const { attachErrorHandler } = require('../../shared/http/errors.js');
const { initTracing, withSpan } = require('../../shared/otel/index.js');
const { state, applyEnvelopeAggregation } = require('./state.js');
const { buildHealthHandler } = require('../../shared/http/health.js');
const { buildReadyHandler } = require('../../shared/http/ready.js');

const logger = createLogger();
initTracing({ serviceName: 'analytics-service' });

// Event consumption strategy: this service only publishes traces/logs; the EventBus fallback logs events.
// For real subscription we would integrate Kafka/NATS consumer later.
// Placeholder: expose ingestion HTTP endpoint that other services can POST events to.

export function createServer() {
  // Use Fastify's built-in logger (pino). Our shared logger is used for app-level logs.
  const fastify = Fastify({ logger: true, ignoreTrailingSlash: true });

  fastify.addHook('onRequest', async (req) => {
    req.requestId = req.headers['x-request-id'] || 'req-' + Math.random().toString(36).slice(2);
  });

  // Metrics
  if (process.env.METRICS_ENABLED === 'true') {
    try {
      const prom = (globalThis.__promClient ||= require('prom-client'));
      if (process.env.METRICS_DEFAULTS === 'true' && !globalThis.__metricsDefaultsRegistered) {
        try {
          prom.collectDefaultMetrics({ prefix: process.env.METRICS_PREFIX || '' });
          globalThis.__metricsDefaultsRegistered = true;
        } catch (e) {
          fastify.log.warn({ err: String(e) }, 'metrics-defaults-registration-failed');
        }
      }
      // Reuse existing counter if server hot-reloaded to avoid duplicate metric registration errors
      let existing = prom.register.getSingleMetric?.('service_http_requests_total');
      const httpReqCounter =
        existing ||
        new prom.Counter({
          name: 'service_http_requests_total',
          help: 'Total HTTP requests',
          labelNames: ['service', 'method', 'route', 'status']
        });
      // Gauges for aggregated global counters so Grafana can scrape directly
      const globalGaugeDefs = [
        'payrollRuns',
        'totalPayrollNet',
        'trainingCompleted',
        'trainingPending',
        'incidents',
        'audits',
        'kpis',
        'expiringLicenses',
        'stockAdjustments',
        'purchaseOrders',
        'workOrders',
        'calibrations',
        'reservations',
        'safetyIncidents',
        'maintenanceSchedules',
        // FHIR counters
        'fhirPatients',
        'fhirAppointments',
        'fhirObservations',
        'fhirEncounters',
        'fhirDocuments',
        'fhirBinaries',
        'appointmentNoShows'
      ];
      const globalGauges = {};
      for (const key of globalGaugeDefs) {
        const metricName = `analytics_global_${key}`;
        const existingGauge = prom.register.getSingleMetric?.(metricName);
        globalGauges[key] =
          existingGauge ||
          new prom.Gauge({
            name: metricName,
            help: `Analytics global counter ${key}`
          });
      }
      fastify.addHook('onResponse', (req, reply, done) => {
        try {
          const route = (req.routeOptions && req.routeOptions.url) || req.url || 'unknown';
          httpReqCounter.inc({
            service: 'analytics-service',
            method: req.method,
            route,
            status: String(reply.statusCode)
          });
        } catch {
          // Intentionally empty - metrics counter increment failed
        }
        done();
      });
      const noShowRateGauge =
        prom.register.getSingleMetric?.('analytics_derived_no_show_rate') ||
        new prom.Gauge({
          name: 'analytics_derived_no_show_rate',
          help: 'Derived metric: appointment no-show rate (no_shows / appointments)'
        });

      fastify.get('/metrics', async (_req, reply) => {
        try {
          // Update gauges just-in-time
          for (const k of globalGaugeDefs) {
            globalGauges[k].set(state.global[k] || 0);
          }
          // Update derived gauges
          const appts = state.global.fhirAppointments || 0;
          const rate = appts > 0 ? (state.global.appointmentNoShows || 0) / appts : 0;
          noShowRateGauge.set(rate);
          reply.header('Content-Type', prom.register.contentType);
          reply.send(await prom.register.metrics());
        } catch (err) {
          reply.code(500).send({ error: 'metrics_error', details: String(err) });
        }
      });
    } catch (err) {
      fastify.log.warn({ err: String(err) }, 'metrics-registration-failed');
    }
  }

  applySecurityHeaders(fastify);
  const rateLimit = makeRouteRateLimiter({ windowMs: 60000, max: 80 });
  attachErrorHandler(fastify);

  // Ingestion endpoint (temporary until real consumer integration or as fallback when streaming disabled)
  fastify.post('/ingest-event', { preHandler: rateLimit }, async (request, reply) =>
    withSpan('analytics.ingest', async () => {
      const evt = request.body || {};
      if (!evt || !evt.type) {
        return reply.code(400).send({ error: 'invalid_event' });
      }
      try {
        applyEnvelopeAggregation(evt, { logger });
      } catch (err) {
        logger.error({ err: String(err), type: evt.type }, 'analytics-ingest-error');
      }
      reply.code(202);
      return { accepted: true };
    })
  );

  // Per employee view
  fastify.get('/analytics/employee/:id', async (request, reply) => {
    const emp = state.employees[request.params.id];
    if (!emp) {
      return reply.code(404).send({ error: 'not_found' });
    }
    return { id: request.params.id, ...emp };
  });

  // Global overview
  fastify.get('/analytics/overview', async () => ({ ...state.global }));
  // Extended overview with derived metrics (basic)
  fastify.get('/analytics/extended', async () => {
    const g = state.global;
    const derived = {
      payrollAvgNet: g.payrollRuns ? g.totalPayrollNet / g.payrollRuns : 0,
      appointmentNoShowRate: g.fhirAppointments ? g.appointmentNoShows / g.fhirAppointments : 0
    };
    return { ...g, derived };
  });
  // Raw state snapshot (debug only, do NOT expose in production without auth)
  if (process.env.ANALYTICS_DEBUG_STATE === 'true') {
    fastify.get('/analytics/state', async () => ({ ...state }));
    // Debug: list routes
    fastify.get('/__routes', async () => ({ routes: fastify.printRoutes() }));
  }

  // Standardized health endpoint with enrichment for streaming snapshot
  fastify.get(
    '/health',
    buildHealthHandler({
      serviceName: 'analytics-service',
      enrich: async () => ({ streaming: state.meta || { enabled: false } })
    })
  );

  // Readiness endpoint: env + metrics + counters + derived rate + streaming meta + simulated backlog + forced fail
  fastify.get(
    '/ready',
    buildReadyHandler({
      serviceName: 'analytics-service',
      checks: [
        { name: 'env.NODE_ENV', check: () => !!process.env.NODE_ENV },
        { name: 'env.METRICS_ENABLED', check: () => process.env.METRICS_ENABLED === 'true' },
        {
          name: 'global.counters.present',
          check: () => {
            const keys = Object.keys(state.global || {}).length;
            return { ok: keys >= 0, details: { keys } };
          }
        },
        {
          name: 'derived.noShowRate',
          check: () => {
            const appts = state.global.fhirAppointments || 0;
            const rate = appts > 0 ? (state.global.appointmentNoShows || 0) / appts : 0;
            return { ok: rate >= 0 && rate <= 1, details: { rate } };
          }
        },
        {
          name: 'streaming.enabled',
          check: () => {
            const enabled = !!(state.meta && state.meta.enabled);
            return { ok: enabled, details: { enabled } };
          }
        },
        {
          name: 'ingestion.backlog.simulated',
          check: () => {
            const backlog = Number.parseInt(process.env.ANALYTICS_BACKLOG_SIZE || '0', 10);
            const ok = Number.isFinite(backlog) ? backlog < 100000 : true;
            return { ok, details: { backlog: Number.isFinite(backlog) ? backlog : 0 } };
          }
        },
        {
          name: 'forcedFail',
          check: () => {
            const flag = process.env.ANALYTICS_FORCE_FAIL === 'true';
            return { ok: flag ? false : true, details: { flag } };
          }
        }
      ]
    })
  );

  // Internal self-check: periodically exercise the /health route via fastify.inject
  // to detect unexpected shutdowns or route registration issues without relying on network stack.
  const selfProbe = { ok: false, lastAt: 0, statusCode: 0, error: null };
  const SELF_CHECK_INTERVAL_MS = Number(process.env.SELF_CHECK_INTERVAL_MS || 10000);
  try {
    const iv = setInterval(async () => {
      try {
        const res = await fastify.inject({ method: 'GET', url: '/health' });
        selfProbe.ok = res.statusCode === 200;
        selfProbe.statusCode = res.statusCode;
        selfProbe.lastAt = Date.now();
        selfProbe.error = null;
        if (!selfProbe.ok) {
          fastify.log.warn({ status: res.statusCode }, 'self.check.warn');
        }
      } catch (err) {
        selfProbe.ok = false;
        selfProbe.lastAt = Date.now();
        selfProbe.error = String(err);
        fastify.log.warn({ err: String(err) }, 'self.check.error');
      }
    }, SELF_CHECK_INTERVAL_MS);
    // keep a reference to avoid GC
    global.__analyticsSelfCheck = iv;
  } catch {
    // non-fatal
  }
  // Expose last self-check snapshot (debug-only; do not expose in production without auth)
  if (process.env.ANALYTICS_DEBUG_STATE === 'true') {
    fastify.get('/__self-check', async () => ({ ...selfProbe }));
  }

  // Optional: start streaming consumer inside server process if enabled (sidecar-less mode)
  if (process.env.ANALYTICS_STREAM_ENABLED === 'true') {
    import('./consumer.js')
      .then((m) => m.start())
      .catch((err) => logger.error({ err: String(err) }, 'analytics-consumer.start-failed'));
  }

  return fastify;
}

const isMain = process.argv[1] === __filename;
if (isMain) {
  // Early exit interception BEFORE anything else so we catch premature exit attempts
  const originalExit = process.exit;
  process.exit = function guardedEarlyExit(code) {
    if (code && code !== 0) {
      logger.error({ code }, 'process.exit.invoked.early');
      // swallow non-zero to allow diagnostics; return without exiting
      return;
    }
    return originalExit(code);
  };

  logger.info('boot.sequence.start');
  let fastify;
  try {
    fastify = createServer();
  } catch (err) {
    logger.error({ err: String(err), stack: err.stack }, 'fastify.instance.create.failed');
    // keep event loop alive for inspection
    setInterval(() => logger.debug('keep.alive.after.create.failure'), 30000);
    // Do not exit; return to allow manual inspection
    fastify = null;
  }
  if (fastify) {
    logger.info('fastify.instance.created');
    const port = Number(process.env.PORT || 3061);
    logger.info({ port, env: process.env.NODE_ENV }, 'fastify.listen.begin');
    fastify.listen({ port, host: '0.0.0.0' }, (err, address) => {
      if (err) {
        logger.error({ err: String(err), stack: err.stack }, 'server.failed.start');
        if (err.code === 'EADDRINUSE') {
          logger.error(`❌ Port ${port} is already in use`);
          logger.error('Please change the PORT in your .env file or stop the process using this port');
        }
        process.exit(1);
      }
      logger.info({ address }, 'fastify.listen.ok');
      logger.info(`analytics-service listening on ${port}`);
      logger.info({ routes: fastify.printRoutes() }, 'fastify.routes');
      // Harden exit interception AFTER listen success
      const realExit = process.exit;
      process.exit = function patchedExit(code) {
        logger.error({ code }, 'process.exit.invoked.intercepted');
        if (code === 0) {
          return realExit(code);
        }
        logger.error('Non-zero exit prevented to keep diagnostics running');
      };
    });
  }

  // Keep-alive interval to prevent early exit in some environments
  // Keep reference so linter does not complain unused; expose on global for debug
  const keepAlive = setInterval(() => {
    logger.debug('keep.alive.tick');
  }, 30_000); // shorter tick
  // intentionally NOT calling unref so interval keeps event loop alive for diagnostics
  global.__analyticsKeepAlive = keepAlive;

  process.on('exit', (code) => {
    try {
      // capture minimal callsites if available
      const stack = new Error('exit.stack.capture').stack;
      logger.error({ code, stack }, 'process.exit');
    } catch {
      logger.error({ code }, 'process.exit');
    }
  });
  process.on('beforeExit', (code) => {
    logger.warn({ code }, 'process.beforeExit');
    try {
      const handles = (process._getActiveHandles?.() || []).map((h) => h.constructor?.name);
      logger.warn({ handles }, 'active.handles.snapshot');
    } catch {
      // Intentionally empty - handles snapshot failed
    }
  });
  process.on('SIGINT', () => {
    logger.warn('sigint.received');
  });
  process.on('SIGTERM', () => {
    logger.warn('sigterm.received');
  });

  // Debug endpoint to inspect active handles
  try {
    fastify.get('/__debug-handles', async () => {
      const handles = (process._getActiveHandles?.() || []).map((h) => h.constructor?.name);
      return { handles };
    });
  } catch (err) {
    logger.error({ err: String(err) }, 'debug.handles.endpoint.error');
  }

  // Catch unhandled errors to log before exit
  process.on('uncaughtException', (err) => {
    logger.error({ err: String(err), stack: err.stack }, 'uncaughtException');
  });
  process.on('unhandledRejection', (reason) => {
    logger.error({ reason: String(reason) }, 'unhandledRejection');
  });
}

// Error Handling
const { errorHandler, notFoundHandler } = require('../../shared/middleware/error-handler');


// 404 handler (must be after all routes)

// API Documentation
const { swaggerSetup } = require('../../shared/docs/swagger-config');
swaggerSetup(app);

app.use(notFoundHandler);

// Error handler (must be last)
app.use(errorHandler);
