// Shared in-memory state and aggregation helpers for analytics-service
// Extracted to allow reuse by streaming consumer.

export const state = {
  employees: {},
  global: {
    payrollRuns: 0,
    totalPayrollNet: 0,
    trainingCompleted: 0,
    trainingPending: 0,
    incidents: 0,
    audits: 0,
    kpis: 0,
    expiringLicenses: 0,
    // New domains
    stockAdjustments: 0,
    purchaseOrders: 0,
    workOrders: 0,
    calibrations: 0,
    reservations: 0,
    safetyIncidents: 0,
    maintenanceSchedules: 0,
    // FHIR operational KPIs
    fhirPatients: 0,
    fhirAppointments: 0,
    fhirObservations: 0,
    fhirEncounters: 0,
    fhirDocuments: 0,
    fhirBinaries: 0,
    appointmentNoShows: 0,
    // Derived metrics snapshot (updated lazily): maintain ratio for quick exposure
    derived: {
      appointmentNoShowRate: 0,
    },
  },
  meta: {
    enabled: false,
    lastEventAt: null,
    processedTotal: 0,
    invalidTotal: 0,
    deduplicatedTotal: 0,
  },
};

export function ensureEmployee(id) {
  if (!state.employees[id]) {
    state.employees[id] = {
      payrollRuns: 0,
      totalPayrollNet: 0,
      trainingCompleted: 0,
      trainingPending: 0,
      incidents: 0,
      audits: 0,
      kpis: 0,
      expiringLicenses: 0,
    };
  }
  return state.employees[id];
}

// Apply an envelope following { id, type, payload }
export function applyEnvelopeAggregation(evt, { logger } = {}) {
  if (!evt || !evt.type) {
    return false;
  }
  const type = evt.type;
  try {
    switch (type) {
      case 'PAYROLL_RUN_COMPLETED': {
        const { employeeId, net } = evt.payload || {};
        if (employeeId) {
          const emp = ensureEmployee(employeeId);
          emp.payrollRuns++;
          emp.totalPayrollNet += Number(net || 0);
          state.global.payrollRuns++;
          state.global.totalPayrollNet += Number(net || 0);
        }
        break;
      }
      case 'ENROLLMENT_CREATED': {
        const { employeeId, status } = evt.payload || {};
        if (employeeId) {
          const emp = ensureEmployee(employeeId);
          if (status === 'COMPLETED') {
            emp.trainingCompleted++;
            state.global.trainingCompleted++;
          } else {
            emp.trainingPending++;
            state.global.trainingPending++;
          }
        }
        break;
      }
      case 'INCIDENT_REPORTED': {
        const { employeeId } = evt.payload || {};
        if (employeeId) {
          const emp = ensureEmployee(employeeId);
          emp.incidents++;
          state.global.incidents++;
        }
        break;
      }
      case 'AUDIT_LOGGED': {
        state.global.audits++;
        break;
      }
      case 'KPI_UPDATED': {
        state.global.kpis++;
        break;
      }
      case 'LICENSE_EXPIRING': {
        const { employeeId } = evt.payload || {};
        if (employeeId) {
          const emp = ensureEmployee(employeeId);
          emp.expiringLicenses++;
          state.global.expiringLicenses++;
        }
        break;
      }
      // Supply domain
      case 'INVENTORY_ADJUSTED': {
        state.global.stockAdjustments++;
        break;
      }
      case 'PURCHASE_ORDER_CREATED': {
        state.global.purchaseOrders++;
        break;
      }
      // Assets domain
      case 'WORK_ORDER_CREATED': {
        state.global.workOrders++;
        break;
      }
      case 'WORK_ORDER_STATUS_UPDATED': {
        // treat status update as activity signal
        state.global.workOrders++;
        break;
      }
      case 'CALIBRATION_RECORDED': {
        state.global.calibrations++;
        break;
      }
      case 'MAINTENANCE_SCHEDULE_CREATED': {
        state.global.maintenanceSchedules++;
        break;
      }
      // Facilities domain
      case 'RESERVATION_CREATED': {
        state.global.reservations++;
        break;
      }
      case 'RESERVATION_STATUS_UPDATED': {
        // count status transitions as utilization events
        state.global.reservations++;
        break;
      }
      case 'SAFETY_INCIDENT_CREATED': {
        state.global.safetyIncidents++;
        break;
      }
      case 'SAFETY_INCIDENT_STATUS_UPDATED': {
        state.global.safetyIncidents++;
        break;
      }
      // Healthcare FHIR domain
      case 'patient.created': {
        state.global.fhirPatients++;
        break;
      }
      case 'appointment.booked': {
        state.global.fhirAppointments++;
        break;
      }
      case 'appointment.cancelled': {
        // track as negative but we just count occurrences for now
        state.global.fhirAppointments++;
        break;
      }
      case 'appointment.no_show': {
        state.global.appointmentNoShows++;
        // Update derived no-show rate if we have appointment count
        const appts = state.global.fhirAppointments || 0;
        if (appts > 0) {
          state.global.derived.appointmentNoShowRate = state.global.appointmentNoShows / appts;
        }
        break;
      }
      case 'observation.recorded': {
        state.global.fhirObservations++;
        break;
      }
      case 'encounter.started': {
        state.global.fhirEncounters++;
        break;
      }
      case 'encounter.completed': {
        state.global.fhirEncounters++;
        break;
      }
      case 'document.uploaded': {
        state.global.fhirDocuments++;
        break;
      }
      case 'binary.stored': {
        state.global.fhirBinaries++;
        break;
      }
      // Tickets (facilities helpdesk) - optional future dashboard metric
      case 'TICKET_CREATED': {
        // We could add a tickets counter later; ignoring for now to avoid global bloat
        break;
      }
      case 'TICKET_STATUS_UPDATED': {
        break;
      }
      default: {
        // Ignore other event types
        break;
      }
    }
    state.meta.lastEventAt = Date.now();
    state.meta.processedTotal++;
    return true;
  } catch (err) {
    logger?.error?.({ err: String(err), type }, 'applyEnvelopeAggregation.error');
    return false;
  }
}
