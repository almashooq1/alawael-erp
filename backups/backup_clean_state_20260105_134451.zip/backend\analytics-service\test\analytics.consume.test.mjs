import { processRawMessage } from '../src/consumer.js';
import { state } from '../src/state.js';

describe('analytics consumer aggregation', () => {
  it('should process LICENSE_EXPIRING event and update state', () => {
    const before = state.global.expiringLicenses;
    const evt = {
      id: 'evt-test-1',
      type: 'LICENSE_EXPIRING',
      source: 'hr-service',
      payload: { employeeId: 'emp-123', dueInDays: 20 },
    };
    const res = processRawMessage(JSON.stringify(evt));
    expect(res.status).toBe('ok');
    expect(state.global.expiringLicenses).toBe(before + 1);
    expect(state.employees['emp-123'].expiringLicenses).toBe(1);
  });
});
