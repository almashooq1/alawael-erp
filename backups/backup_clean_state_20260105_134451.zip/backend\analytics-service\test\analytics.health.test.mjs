/**
 * Minimal health test to guard service startup regressions.
 * Uses Fastify.inject so no network port is required.
 */
import { createServer } from '../src/server.js';

describe('analytics-service /health', () => {
  it('returns status ok and meta shape', async () => {
    process.env.METRICS_ENABLED = 'false';
    // Slow down self-check to avoid firing during this short test
    process.env.SELF_CHECK_INTERVAL_MS = '60000';
    const app = createServer();
    // Register for automatic teardown via setupFilesAfterEnv
    if (global.registerApp) {
      global.registerApp(app);
    }
    const res = await app.inject({ method: 'GET', url: '/health' });
    expect(res.statusCode).toBe(200);
    const body = res.json();
    expect(body).toHaveProperty('status', 'ok');
    expect(body).toHaveProperty('streaming');
  });
});
