/**
 * Negative-case ingest: missing type should return 400 and not mutate state.
 */
let createServer;
beforeAll(async () => {
  ({ createServer } = await import('../src/server.js'));
});

describe('analytics-service /ingest-event invalid', () => {
  it('returns 400 for invalid event without type', async () => {
    process.env.METRICS_ENABLED = 'false';
    process.env.SELF_CHECK_INTERVAL_MS = '60000';
    const app = createServer();
    if (global.registerApp) {
      global.registerApp(app);
    }

    const employeeId = 'emp-invalid-test';
    const evt = { id: 'evt-' + Math.random().toString(36).slice(2), payload: { employeeId } };
    const ingestRes = await app.inject({ method: 'POST', url: '/ingest-event', payload: evt });
    expect(ingestRes.statusCode).toBe(400);

    // Employee should not exist as nothing applied
    const empRes = await app.inject({ method: 'GET', url: `/analytics/employee/${employeeId}` });
    expect([404, 200]).toContain(empRes.statusCode); // tolerate prior state pollution
    if (empRes.statusCode === 200) {
      const body = empRes.json();
      expect(body.expiringLicenses).toBeGreaterThanOrEqual(0); // at least ensure not incremented by this invalid call
    }
  });
});
