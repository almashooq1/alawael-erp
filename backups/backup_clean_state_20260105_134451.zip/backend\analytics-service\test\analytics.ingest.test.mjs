/**
 * Validate aggregation via /ingest-event for LICENSE_EXPIRING.
 */
import { createServer } from '../src/server.js';
import { state } from '../src/state.js';

describe('analytics-service /ingest-event aggregation', () => {
  it('increments employee expiringLicenses count for LICENSE_EXPIRING', async () => {
    process.env.METRICS_ENABLED = 'false'; // keep minimal
    process.env.SELF_CHECK_INTERVAL_MS = '60000';
    const app = createServer();
    if (global.registerApp) {
      global.registerApp(app);
    }

    const employeeId = 'emp-test-ingest';
    const evt = {
      id: 'evt-' + Math.random().toString(36).slice(2),
      type: 'LICENSE_EXPIRING',
      payload: { employeeId },
    };

    const ingestRes = await app.inject({
      method: 'POST',
      url: '/ingest-event',
      payload: evt,
    });
    expect(ingestRes.statusCode).toBe(202);

    // Query state via public endpoint
    const empRes = await app.inject({ method: 'GET', url: `/analytics/employee/${employeeId}` });
    expect(empRes.statusCode).toBe(200);
    const body = empRes.json();
    expect(body.expiringLicenses).toBeGreaterThanOrEqual(1);

    // Internal state consistency assertion (optional)
    expect(state.employees[employeeId].expiringLicenses).toBe(body.expiringLicenses);
  });
});
