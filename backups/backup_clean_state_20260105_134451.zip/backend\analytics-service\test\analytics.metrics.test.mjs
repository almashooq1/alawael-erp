/**
 * Verify that /metrics endpoint exposes HTTP request counter after a request.
 */
import { createServer } from '../src/server.js';

describe('analytics-service /metrics', () => {
  it('exposes service_http_requests_total after a /health request', async () => {
    // Enable metrics only for this test before creating server
    process.env.METRICS_ENABLED = 'true';
    process.env.METRICS_DEFAULTS = 'false'; // not needed for this test
    process.env.SELF_CHECK_INTERVAL_MS = '60000';
    const app = createServer();
    if (global.registerApp) {
      global.registerApp(app);
    }

    // Trigger one request to /health to increment counter
    const res = await app.inject({ method: 'GET', url: '/health' });
    expect(res.statusCode).toBe(200);

    const metrics = await app.inject({ method: 'GET', url: '/metrics' });
    expect(metrics.statusCode).toBe(200);
    const body = metrics.body || '';
    expect(body).toContain('service_http_requests_total');
    expect(body).toContain('route="/health"');
  });
});
