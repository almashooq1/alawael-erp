/**
 * Validate /analytics/overview reflects aggregated changes after ingesting an event.
 */
let createServer;
beforeAll(async () => {
  ({ createServer } = await import('../src/server.js'));
});

describe('analytics-service /analytics/overview', () => {
  it('expiringLicenses increases after LICENSE_EXPIRING event', async () => {
    process.env.METRICS_ENABLED = 'false';
    process.env.SELF_CHECK_INTERVAL_MS = '60000';
    const app = createServer();
    if (global.registerApp) {
      global.registerApp(app);
    }

    // Baseline
    const beforeRes = await app.inject({ method: 'GET', url: '/analytics/overview' });
    expect(beforeRes.statusCode).toBe(200);
    const before = beforeRes.json();
    const baseline = Number(before.expiringLicenses || 0);

    // Ingest one event
    const employeeId = 'emp-overview-test';
    const evt = {
      id: 'evt-' + Math.random().toString(36).slice(2),
      type: 'LICENSE_EXPIRING',
      payload: { employeeId },
    };
    const ingestRes = await app.inject({ method: 'POST', url: '/ingest-event', payload: evt });
    expect(ingestRes.statusCode).toBe(202);

    // Verify increase
    const afterRes = await app.inject({ method: 'GET', url: '/analytics/overview' });
    expect(afterRes.statusCode).toBe(200);
    const after = afterRes.json();
    expect(Number(after.expiringLicenses || 0)).toBeGreaterThanOrEqual(baseline + 1);
  });
});
