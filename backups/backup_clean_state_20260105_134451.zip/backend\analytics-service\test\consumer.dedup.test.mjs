/**
 * Validate consumer dedup path using processRawMessage without NATS.
 * First event with id should process; second with same id should be deduped.
 */
import { processRawMessage } from '../src/consumer.js';
import { state } from '../src/state.js';

describe('analytics-consumer dedup bookkeeping', () => {
  it('increments deduplicatedTotal and counter on duplicate id', () => {
    const id = `evt-dedup-${Date.now()}`;
    const beforeProcessed = Number(state.meta.processedTotal || 0);
    const beforeDeduped = Number(state.meta.deduplicatedTotal || 0);

    // First time: should be processed
    const res1 = processRawMessage(
      JSON.stringify({ id, type: 'LICENSE_EXPIRING', payload: { employeeId: 'emp-dedup' } })
    );
    expect(res1).toEqual({ status: 'ok' });

    // Second time with same id: should be deduped
    const res2 = processRawMessage(
      JSON.stringify({ id, type: 'LICENSE_EXPIRING', payload: { employeeId: 'emp-dedup' } })
    );
    expect(res2).toEqual({ status: 'deduped' });

    const afterProcessed = Number(state.meta.processedTotal || 0);
    const afterDeduped = Number(state.meta.deduplicatedTotal || 0);

    expect(afterProcessed).toBe(beforeProcessed + 1); // only first counts
    expect(afterDeduped).toBe(beforeDeduped + 1); // dedup counter increments once
  });
});
