/**
 * Validate consumer handler error path: unsupported type should increment invalidTotal
 * via handler branch (not parse) and return handler-error status.
 */
import { processRawMessage } from '../src/consumer.js';
import { state } from '../src/state.js';

describe('analytics-consumer handler error bookkeeping', () => {
  it('increments invalidTotal for unsupported event when aggregation returns false', () => {
    const beforeInvalid = Number(state.meta.invalidTotal || 0);
    // Use an event with missing type to force applyEnvelopeAggregation to return false
    const res = processRawMessage(JSON.stringify({ id: `evt-no-type-${Date.now()}`, payload: {} }));
    expect(res).toEqual({ status: 'handler-error' });
    const afterInvalid = Number(state.meta.invalidTotal || 0);
    expect(afterInvalid).toBe(beforeInvalid + 1);
  });
});
