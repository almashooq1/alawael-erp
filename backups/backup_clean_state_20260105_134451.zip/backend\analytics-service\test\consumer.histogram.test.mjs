/**
 * Sanity test: processing an event should record a non-zero observation
 * in analytics_events_processing_duration_seconds histogram.
 */
import { start, processRawMessage } from '../src/consumer.js';

describe('analytics-consumer processing duration histogram', () => {
  it('records at least one observation after processing', async () => {
    // Ensure metrics are enabled and prevent nats connect attempt by omitting servers
    process.env.METRICS_ENABLED = 'true';
    process.env.ANALYTICS_STREAM_ENABLED = 'true';
    delete process.env.NATS_SERVERS;
    delete process.env.NATS_URL;

    await start(); // initializes prom metrics without connecting to NATS

    // Process one event
    const id = `evt-hist-${Date.now()}`;
    processRawMessage(
      JSON.stringify({ id, type: 'LICENSE_EXPIRING', payload: { employeeId: 'emp-hist' } })
    );
    // Allow event metrics observation to settle in registry (defensive, though observe is sync)
    await new Promise(r => setTimeout(r, 10));

    // Read histogram from global prom-client registry
    const prom = globalThis.__promClient;
    expect(prom).toBeTruthy();
    const metric = prom.register.getSingleMetric('analytics_events_processing_duration_seconds');
    expect(metric).toBeTruthy();
    const data = await Promise.resolve(metric.get());
    // Find the aggregate count across labels (first metric entry typically aggregates)
    const count = (Array.isArray(data?.values) ? data.values : [])
      .filter(v => String(v.metricName).endsWith('_count'))
      .reduce((s, v) => s + Number(v.value || 0), 0);
    if (count === 0) {
      // Provide diagnostic output if failing

      console.warn('histogram-test-diagnostics', data);
    }
    expect(count).toBeGreaterThan(0);
  });
});
