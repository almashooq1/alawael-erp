/**
 * Validate consumer invalidTotal bookkeeping on parse error without NATS.
 */
import { processRawMessage } from '../src/consumer.js';
import { state } from '../src/state.js';

describe('analytics-consumer invalidTotal bookkeeping', () => {
  it('increments invalidTotal on parse error', () => {
    const before = Number(state.meta.invalidTotal || 0);
    const res = processRawMessage('this is not json');
    expect(res.status).toBe('parse-error');
    const after = Number(state.meta.invalidTotal || 0);
    expect(after).toBe(before + 1);
  });
});
