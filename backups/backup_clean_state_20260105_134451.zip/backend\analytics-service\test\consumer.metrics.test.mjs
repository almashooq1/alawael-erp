import { ensureMetrics, processRawMessage } from '../src/consumer.js';

function makeEvt(overrides = {}) {
  return {
    id: 'test-evt-1',
    type: 'PAYROLL_RUN_COMPLETED',
    source: 'payroll-service',
    payload: { employeeId: 'e1', net: 100 },
    ...overrides,
  };
}

function encode(evt) {
  return JSON.stringify(evt);
}

describe('analytics-consumer metrics (no broker required)', () => {
  it('initializes metrics and records processed + dedup + invalid', () => {
    process.env.METRICS_ENABLED = 'true';
    process.env.METRICS_DEFAULTS = 'false';
    const { initialized } = ensureMetrics();
    expect(initialized).toBe(true);

    // happy path
    const r1 = processRawMessage(encode(makeEvt({ id: 'A' })), { subject: 'payroll.events' });
    expect(r1.status).toBe('ok');

    // duplicate
    const r2 = processRawMessage(encode(makeEvt({ id: 'A' })), { subject: 'payroll.events' });
    expect(r2.status).toBe('deduped');

    // invalid json
    const r3 = processRawMessage('{not-json}', { subject: 'payroll.events' });
    expect(r3.status).toBe('parse-error');
  });
});
