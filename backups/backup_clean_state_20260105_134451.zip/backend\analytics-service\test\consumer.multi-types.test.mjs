import { ensureMetrics, processRawMessage } from '../src/consumer.js';

function evt(id, type) {
  return { id, type, source: 'quality-service', payload: { employeeId: 'e2' } };
}

describe('analytics-consumer multi-type metrics', () => {
  it('processes multiple event types and returns ok status', () => {
    process.env.METRICS_ENABLED = 'true';
    const { initialized } = ensureMetrics();
    expect(initialized).toBe(true);

    const types = ['INCIDENT_REPORTED', 'AUDIT_LOGGED', 'KPI_UPDATED'];
    for (let i = 0; i < types.length; i++) {
      const raw = JSON.stringify(evt('MT-' + i, types[i]));
      const res = processRawMessage(raw, { subject: 'quality.events' });
      expect(res.status).toBe('ok');
    }
  });
});
