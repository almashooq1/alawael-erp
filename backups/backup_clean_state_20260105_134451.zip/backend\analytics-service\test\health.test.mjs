/**
 * Health endpoint test for analytics-service.
 * Ensures standardized shape with service & uptimeSeconds and streaming enrichment.
 */
import { createServer } from '../src/server.js';

describe('analytics-service /health', () => {
  test('shape contains status, service, uptimeSeconds and streaming', async () => {
    const app = createServer();
    const res = await app.inject({ method: 'GET', url: '/health' });
    expect(res.statusCode).toBe(200);
    const body = res.json();
    expect(body.status).toBe('ok');
    expect(body.service).toBe('analytics-service');
    expect(typeof body.uptimeSeconds).toBe('number');
    expect(body.uptimeSeconds).toBeGreaterThanOrEqual(0);
    expect(body.streaming).toBeDefined();
    // streaming.enabled may be false initially; ensure key exists
    expect(typeof body.streaming).toBe('object');
  });
});
