/**
 * Unit test for PromQL fetch helper: mocks a tiny HTTP server and verifies
 * that fetchPromQuery returns data on success and null on failure.
 */
import http from 'http';
import { fetchPromQuery } from '../scripts/lib/prom-helpers.js';

function makeServer(handler) {
  const srv = http.createServer(handler);
  return new Promise(resolve => {
    srv.listen(0, '127.0.0.1', () => {
      const addr = srv.address();
      resolve({ srv, url: `http://127.0.0.1:${addr.port}` });
    });
  });
}

describe('prom-helpers.fetchPromQuery', () => {
  it('returns data for status=success and null otherwise', async () => {
    const { srv, url } = await makeServer((req, res) => {
      if (req.url.startsWith('/api/v1/query')) {
        const u = new URL(req.url, 'http://localhost');
        const q = u.searchParams.get('query');
        const payload =
          q === 'ok'
            ? { status: 'success', data: { resultType: 'vector', result: [{ value: [0, '1'] }] } }
            : { status: 'error', errorType: 'bad_data', error: 'bad query' };
        const body = JSON.stringify(payload);
        res.writeHead(200, { 'content-type': 'application/json' });
        res.end(body);
      } else {
        res.writeHead(404).end();
      }
    });
    try {
      const ok = await fetchPromQuery('ok', url);
      expect(ok).toBeTruthy();
      expect(ok.result?.length || 0).toBeGreaterThan(0);
      const bad = await fetchPromQuery('bad', url);
      expect(bad).toBeNull();
    } finally {
      srv.close();
    }
  });
});
