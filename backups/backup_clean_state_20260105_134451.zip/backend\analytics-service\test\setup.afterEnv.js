// Global Jest setup for analytics-service tests
// - Provides global.registerApp(app) for tests to register Fastify instances
// - Ensures automatic teardown after each/all tests to prevent post-test logging
// Note: Use dynamic import to stay compatible with Jest loading mode (CJS/ESM)

// Registry for fastify apps created during tests
if (!globalThis.__analyticsFastifyApps) {
  globalThis.__analyticsFastifyApps = new Set();
}

// Expose a helper to register instances from tests
// Usage in tests: global.registerApp(app)
if (!globalThis.registerApp) {
  globalThis.registerApp = function registerApp(app) {
    try {
      if (app) {
        globalThis.__analyticsFastifyApps.add(app);
      }
    } catch {}
  };
}

async function cleanupAll() {
  const apps = Array.from(globalThis.__analyticsFastifyApps || []);
  // Lazy import to avoid top-level ESM import in this setup file
  let teardown = async app => app?.close?.();
  try {
    ({ teardown } = await import('./utils/teardown.js'));
  } catch {}
  for (const app of apps) {
    try {
      // Close server and clear internal intervals
      // teardown handles missing globals safely

      await teardown(app);
    } catch {}
  }
  try {
    globalThis.__analyticsFastifyApps.clear();
  } catch {}
}

afterEach(async () => {
  await cleanupAll();
});

afterAll(async () => {
  await cleanupAll();
});

// Silence routine request logs to reduce test noise while preserving warnings/errors.
// We patch console.log to drop lines containing known verbose phrases.
const originalLog = console.log;
console.log = function patchedLog(...args) {
  try {
    const joined = args.map(a => (typeof a === 'string' ? a : JSON.stringify(a))).join(' ');
    if (joined.includes('incoming request') || joined.includes('request completed')) {
      return; // suppress
    }
  } catch {}
  return originalLog.apply(this, args);
};
