/**
 * Ensures Fastify instance is closed and internal intervals cleared
 * to prevent logging after Jest test completion.
 */
export async function teardown(app) {
  try {
    // Clear self-check interval if set
    if (global.__analyticsSelfCheck) {
      clearInterval(global.__analyticsSelfCheck);
      global.__analyticsSelfCheck = null;
    }
    if (global.__analyticsKeepAlive) {
      clearInterval(global.__analyticsKeepAlive);
      global.__analyticsKeepAlive = null;
    }
  } catch {}
  try {
    await app.close();
  } catch {}
}
