# 🌐 API Gateway Service

Central API Gateway for all microservices.

## Features

- Service Routing
- API Versioning
- Rate Limiting
- API Analytics
- Security (Helmet, CORS)
- Swagger Documentation

## Usage

```bash
npm install
npm start
```

## Environment Variables

- `PORT` - Gateway port (default: 3000)
- `SOCIAL_SERVICE_URL` - Social service URL
- `VOLUNTEER_SERVICE_URL` - Volunteer service URL
- `PARTNERSHIP_SERVICE_URL` - Partnership service URL
- `INNOVATION_SERVICE_URL` - Innovation service URL
- `COMMUNITY_PARTNERSHIP_SERVICE_URL` - Community partnership service URL
- `GAMIFICATION_SERVICE_URL` - Gamification service URL
- `BUDGET_SERVICE_URL` - Budget service URL
- `TRAINING_SERVICE_URL` - Training service URL
- `QUALITY_SERVICE_URL` - Quality service URL
- `EVENT_BUS_URL` - Event bus service URL
- `ALLOWED_ORIGINS` - Allowed CORS origins (comma-separated)
