/**
 * 📊 API Analytics
 * Tracks API usage and performance
 */

class APIAnalytics {
  constructor() {
    this.metrics = {
      requests: [],
      services: {},
      errors: [],
      responseTimes: [],
    };
  }

  trackRequest(service, path, method, statusCode, responseTime) {
    const request = {
      service,
      path,
      method,
      statusCode,
      responseTime,
      timestamp: new Date(),
    };

    this.metrics.requests.push(request);

    // Keep only last 1000 requests
    if (this.metrics.requests.length > 1000) {
      this.metrics.requests.shift();
    }

    // Track by service
    if (!this.metrics.services[service]) {
      this.metrics.services[service] = {
        total: 0,
        success: 0,
        errors: 0,
        avgResponseTime: 0,
        responseTimes: [],
      };
    }

    const serviceMetrics = this.metrics.services[service];
    serviceMetrics.total++;
    serviceMetrics.responseTimes.push(responseTime);

    if (statusCode >= 200 && statusCode < 300) {
      serviceMetrics.success++;
    } else {
      serviceMetrics.errors++;
    }

    // Update average response time
    serviceMetrics.avgResponseTime =
      serviceMetrics.responseTimes.reduce((a, b) => a + b, 0) / serviceMetrics.responseTimes.length;

    // Keep only last 100 response times per service
    if (serviceMetrics.responseTimes.length > 100) {
      serviceMetrics.responseTimes.shift();
    }
  }

  getStats() {
    return {
      totalRequests: this.metrics.requests.length,
      services: this.metrics.services,
      recentErrors: this.metrics.errors.slice(-10),
      requestsPerMinute: this.metrics.requests.filter(
        r => Date.now() - r.timestamp.getTime() < 60000
      ).length,
      avgResponseTime:
        this.metrics.requests.length > 0
          ? this.metrics.requests.reduce((sum, r) => sum + r.responseTime, 0) /
            this.metrics.requests.length
          : 0,
    };
  }

  getServiceStats(service) {
    return this.metrics.services[service] || null;
  }
}

module.exports = APIAnalytics;
