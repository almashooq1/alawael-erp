#!/usr/bin/env node
/**
 * 🌐 API Gateway Service
 * Central API gateway for all services
 */

const express = require('express');
const { createProxyMiddleware } = require('http-proxy-middleware');
const rateLimit = require('express-rate-limit');
const helmet = require('helmet');
const cors = require('cors');
const swaggerUi = require('swagger-ui-express');
const swaggerJsdoc = require('swagger-jsdoc');

const app = express();
const PORT = process.env.PORT || 3000;

// Security middleware
app.use(helmet());

// CORS middleware (centralized)
const { corsMiddleware } = require('../../../shared/middleware/cors');
app.use(corsMiddleware);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Rate limiting
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: 'Too many requests from this IP, please try again later.',
});

app.use('/api/', apiLimiter);

// Service registry
const services = {
  'social-service': {
    url: process.env.SOCIAL_SERVICE_URL || 'http://localhost:3036',
    version: 'v1',
  },
  'volunteer-service': {
    url: process.env.VOLUNTEER_SERVICE_URL || 'http://localhost:3037',
    version: 'v1',
  },
  'partnership-service': {
    url: process.env.PARTNERSHIP_SERVICE_URL || 'http://localhost:3038',
    version: 'v1',
  },
  'innovation-service': {
    url: process.env.INNOVATION_SERVICE_URL || 'http://localhost:3039',
    version: 'v1',
  },
  'community-partnership-service': {
    url: process.env.COMMUNITY_PARTNERSHIP_SERVICE_URL || 'http://localhost:3040',
    version: 'v1',
  },
  'gamification-service': {
    url: process.env.GAMIFICATION_SERVICE_URL || 'http://localhost:3041',
    version: 'v1',
  },
  'budget-service': {
    url: process.env.BUDGET_SERVICE_URL || 'http://localhost:3042',
    version: 'v1',
  },
  'training-service': {
    url: process.env.TRAINING_SERVICE_URL || 'http://localhost:3043',
    version: 'v1',
  },
  'quality-service': {
    url: process.env.QUALITY_SERVICE_URL || 'http://localhost:3044',
    version: 'v1',
  },
  'event-bus': {
    url: process.env.EVENT_BUS_URL || 'http://localhost:3100',
    version: 'v1',
  },
};

// API Analytics
const analytics = {
  requests: [],
  services: {},
  errors: [],
};

function trackRequest(service, path, method, statusCode, responseTime) {
  const request = {
    service,
    path,
    method,
    statusCode,
    responseTime,
    timestamp: new Date(),
  };
  analytics.requests.push(request);

  // Keep only last 1000 requests
  if (analytics.requests.length > 1000) {
    analytics.requests.shift();
  }

  // Track by service
  if (!analytics.services[service]) {
    analytics.services[service] = {
      total: 0,
      success: 0,
      errors: 0,
      avgResponseTime: 0,
    };
  }

  analytics.services[service].total++;
  if (statusCode >= 200 && statusCode < 300) {
    analytics.services[service].success++;
  } else {
    analytics.services[service].errors++;
  }

  // Update average response time
  const serviceStats = analytics.services[service];
  serviceStats.avgResponseTime =
    (serviceStats.avgResponseTime * (serviceStats.total - 1) + responseTime) / serviceStats.total;
}

// Create proxy middleware for each service
Object.keys(services).forEach(serviceName => {
  const service = services[serviceName];
  const basePath = `/api/${service.version}/${serviceName}`;

  app.use(basePath, (req, res, next) => {
    const startTime = Date.now();

    createProxyMiddleware({
      target: service.url,
      changeOrigin: true,
      pathRewrite: {
        [`^${basePath}`]: '',
      },
      onProxyRes: (proxyRes, req, res) => {
        const responseTime = Date.now() - startTime;
        trackRequest(serviceName, req.path, req.method, proxyRes.statusCode, responseTime);
      },
      onError: (err, req, res) => {
        const responseTime = Date.now() - startTime;
        trackRequest(serviceName, req.path, req.method, 500, responseTime);
        analytics.errors.push({
          service: serviceName,
          error: err.message,
          timestamp: new Date(),
        });
        res.status(500).json({ error: 'Service unavailable', service: serviceName });
      },
    })(req, res, next);
  });

  console.log(`✅ Registered service: ${serviceName} -> ${basePath}`);
});

// API Versioning
app.use('/api/v1', (req, res, next) => {
  req.apiVersion = 'v1';
  next();
});

app.use('/api/v2', (req, res, next) => {
  req.apiVersion = 'v2';
  next();
});

// Health check
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'api-gateway',
    timestamp: new Date(),
    services: Object.keys(services).length,
  });
});

// Analytics endpoint
app.get('/api/analytics', (req, res) => {
  const stats = {
    totalRequests: analytics.requests.length,
    services: analytics.services,
    recentErrors: analytics.errors.slice(-10),
    requestsPerMinute: analytics.requests.filter(r => Date.now() - r.timestamp.getTime() < 60000)
      .length,
  };
  res.json(stats);
});

// Swagger documentation
const swaggerOptions = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'API Gateway',
      version: '1.0.0',
      description: 'Central API Gateway for all services',
    },
    servers: [
      {
        url: `http://localhost:${PORT}`,
        description: 'Development server',
      },
    ],
  },
  apis: ['./src/*.js'],
};

const swaggerSpec = swaggerJsdoc(swaggerOptions);
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec));

// Root endpoint
app.get('/', (req, res) => {
  res.json({
    name: 'API Gateway',
    version: '1.0.0',
    description: 'Central API Gateway for all microservices',
    services: Object.keys(services),
    endpoints: {
      health: '/health',
      analytics: '/api/analytics',
      docs: '/api-docs',
    },
  });
});

app
  .listen(PORT, () => {
    console.log(`🌐 API Gateway running on port ${PORT}`);
    console.log(`📊 Analytics: http://localhost:${PORT}/api/analytics`);
    console.log(`📚 Docs: http://localhost:${PORT}/api-docs`);
    console.log(`💚 Health: http://localhost:${PORT}/health`);
  })
  .on('error', error => {
    if (error.code === 'EADDRINUSE') {
      console.error(`❌ Port ${PORT} is already in use`);
      console.error('Please change the PORT in your .env file or stop the process using this port');
      process.exit(1);
    } else {
      console.error('❌ Server error:', error);
      process.exit(1);
    }
  });
