/**
 * 📋 API Versioning
 * Manages API versions
 */

class APIVersioning {
  constructor() {
    this.versions = new Map();
  }

  register(version, config) {
    this.versions.set(version, {
      ...config,
      createdAt: new Date(),
    });
  }

  getVersion(version) {
    return this.versions.get(version);
  }

  getAllVersions() {
    return Array.from(this.versions.entries()).map(([version, config]) => ({
      version,
      ...config,
    }));
  }

  isVersionSupported(version) {
    return this.versions.has(version);
  }
}

module.exports = APIVersioning;
