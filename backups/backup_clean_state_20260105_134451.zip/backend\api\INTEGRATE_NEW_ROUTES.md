# 🔗 دليل التكامل - Integration Guide

## ✅ المسارات الجديدة المُضافة

### 1. Analytics Routes 📊

- ✅ `backend/api/routes/analytics.js`
- **Base Path**: `/api/analytics`

#### Endpoints:

- `GET /api/analytics/dashboard` - Get dashboard data
- `GET /api/analytics/users?period=month` - Get user analytics
- `GET /api/analytics/sessions?period=month` - Get session analytics
- `GET /api/analytics/performance` - Get performance metrics
- `GET /api/analytics/insights` - Get insights
- `POST /api/analytics/metrics` - Add metric

### 2. Notifications Routes 🔔

- ✅ `backend/api/routes/notifications.js`
- **Base Path**: `/api/notifications`

#### Endpoints:

- `GET /api/notifications` - Get notifications
- `POST /api/notifications` - Create notification
- `PUT /api/notifications/:id/read` - Mark as read
- `PUT /api/notifications/read-all` - Mark all as read
- `DELETE /api/notifications/:id` - Delete notification
- `GET /api/notifications/unread/count` - Get unread count
- `POST /api/notifications/subscribe` - Subscribe to notifications
- `PUT /api/notifications/channels` - Configure channels

### 3. Search Routes 🔍

- ✅ `backend/api/routes/search.js`
- **Base Path**: `/api/search`

#### Endpoints:

- `GET /api/search?q=query&limit=10` - Search
- `GET /api/search/fuzzy?q=query&threshold=0.7` - Fuzzy search
- `POST /api/search/index` - Index document
- `GET /api/search/stats` - Get index stats
- `DELETE /api/search/index` - Clear index

## 🔧 كيفية التكامل

### في `backend/api/app.js`:

```javascript
// Add after existing route imports
const analyticsRoutes = require('./routes/analytics');
const searchRoutes = require('./routes/search');
// Note: notifications.js already exists, update if needed

// Add routes (after line ~772)
app.use('/api/analytics', analyticsRoutes);
app.use('/api/search', searchRoutes);
// app.use('/api/notifications', notificationsRoutes); // Already exists
```

## 📋 أمثلة الاستخدام

### Analytics:

```javascript
// Get dashboard data
fetch('/api/analytics/dashboard')
  .then(res => res.json())
  .then(data => console.log(data));

// Get user analytics
fetch('/api/analytics/users?period=month')
  .then(res => res.json())
  .then(data => console.log(data));
```

### Notifications:

```javascript
// Get notifications
fetch('/api/notifications?unreadOnly=true')
  .then(res => res.json())
  .then(data => console.log(data));

// Create notification
fetch('/api/notifications', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    type: 'info',
    title: 'عنوان',
    message: 'رسالة',
  }),
});
```

### Search:

```javascript
// Search
fetch('/api/search?q=بحث&limit=10')
  .then(res => res.json())
  .then(data => console.log(data));

// Index document
fetch('/api/search/index', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    id: 'doc1',
    content: 'محتوى الوثيقة',
    metadata: { type: 'report' },
  }),
});
```

## ✅ الخطوات التالية

1. ✅ إضافة المسارات في app.js
2. ✅ اختبار المسارات
3. ✅ إضافة Authentication Middleware
4. ✅ إضافة Rate Limiting
5. ✅ إضافة Error Handling

---

**تاريخ**: 2025-01-10
**الحالة**: ✅ المسارات جاهزة للتكامل
