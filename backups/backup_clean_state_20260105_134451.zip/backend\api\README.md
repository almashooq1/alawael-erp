# Backend API Demo Messaging

This API includes demo routes wired to a pluggable messaging transport (memory by default, NATS optional).

Environment variables:

- `MSG_TRANSPORT`: `memory` (default) or `nats`
- `NATS_URL`: NATS server URL (e.g. `nats://localhost:4222`)

Routes:

- `POST /demo/patient`: Publishes a CloudEvent `patient.created.v1` to subject `demo.patient.created`.
  - Body: `{ "id": "evt-001", ... }`
  - Returns: `202 { ok: true, id }`
- `POST /demo/fail`: Sends a simulated bad message to DLQ subject `dlq`.
  - Body: any JSON payload
  - Returns: `202 { ok: true, id }`

Run locally (PowerShell on Windows):

Memory transport:

```
$env:MSG_TRANSPORT = "memory"
node backend\api\server.js
```

NATS transport (requires Docker):

```
docker run --name nats -p 4222:4222 -p 8222:8222 -d nats:2.10-alpine
$env:MSG_TRANSPORT = "nats"
$env:NATS_URL = "nats://localhost:4222"
node backend\api\server.js
```

Publish demo event:

```
Invoke-RestMethod -Method POST -Uri http://localhost:3000/demo/patient -ContentType 'application/json' -Body (@{ id = "evt-001"; name = "Alice" } | ConvertTo-Json)
```

Simulate failure to DLQ:

```
Invoke-RestMethod -Method POST -Uri http://localhost:3000/demo/fail -ContentType 'application/json' -Body (@{ cause = "unit-test" } | ConvertTo-Json)
```
