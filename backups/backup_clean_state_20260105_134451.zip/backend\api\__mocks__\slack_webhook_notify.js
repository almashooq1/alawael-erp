module.exports = { notifySlack: () => {} };
