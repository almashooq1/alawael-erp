const request = require('supertest');
const app = require('../app');
const Branch = require('../models/Branch');

describe('Branches API', () => {
  beforeAll(async () => {
    await Branch.sync({ force: true });
  });

  let branchId;

  it('should create a branch', async () => {
    const res = await request(app)
      .post('/api/branches')
      .send({ name: 'Test Branch', address: 'Test Address' });
    if (res.statusCode !== 201) {
      require('fs').writeFileSync('branches-test-error.json', JSON.stringify(res.body, null, 2));
      console.error('Create branch error:', res.body);
    }
    expect(res.statusCode).toBe(201);
    expect(res.body.name).toBe('Test Branch');
    branchId = res.body.id;
  });

  it('should get all branches', async () => {
    const res = await request(app).get('/api/branches');
    if (res.statusCode !== 200) {
      require('fs').writeFileSync('branches-test-error.json', JSON.stringify(res.body, null, 2));
      console.error('Get branches error:', res.body);
    }
    expect(res.statusCode).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
    expect(res.body.length).toBeGreaterThan(0);
  });

  it('should update a branch', async () => {
    const res = await request(app)
      .put(`/api/branches/${branchId}`)
      .send({ name: 'Updated Branch', address: 'Updated Address' });
    if (res.statusCode !== 200) {
      require('fs').writeFileSync('branches-test-error.json', JSON.stringify(res.body, null, 2));
      console.error('Update branch error:', res.body);
    }
    expect(res.statusCode).toBe(200);
    expect(res.body.name).toBe('Updated Branch');
  });

  it('should delete a branch', async () => {
    const res = await request(app).delete(`/api/branches/${branchId}`);
    if (res.statusCode !== 200) {
      require('fs').writeFileSync('branches-test-error.json', JSON.stringify(res.body, null, 2));
      console.error('Delete branch error:', res.body);
    }
    expect(res.statusCode).toBe(200);
    expect(res.body.message).toMatch(/تم حذف الفرع/);
  });
});
