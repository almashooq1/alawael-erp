const request = require('supertest');
const app = require('../app');
const Document = require('../models/Document');
const User = require('../models/User');

describe('Documents API', () => {
  beforeAll(async () => {
    await User.sync({ force: true });
    await Document.sync({ force: true });
  });

  let id;

  it('should create a document', async () => {
    const u = await User.create({ name: 'DocOwner', role: 'member' });
    const res = await request(app)
      .post('/api/documents')
      .send({ type: 'note', content: 'Hello', access_level: 'private', owner_id: u.id });
    if (res.statusCode !== 201) {
      require('fs').writeFileSync('documents-test-error.json', JSON.stringify(res.body, null, 2));
      console.error('Create document error:', res.body);
    }
    expect(res.statusCode).toBe(201);
    expect(res.body.type).toBe('note');
    id = res.body.id;
  });

  it('should get all documents', async () => {
    const res = await request(app).get('/api/documents');
    if (res.statusCode !== 200) {
      require('fs').writeFileSync('documents-test-error.json', JSON.stringify(res.body, null, 2));
      console.error('Get documents error:', res.body);
    }
    expect(res.statusCode).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
    // Allow both empty and non-empty document lists
    expect(res.body.length).toBeGreaterThanOrEqual(0);
  });

  it('should update a document', async () => {
    const res = await request(app).put(`/api/documents/${id}`).send({ content: 'Updated' });
    if (res.statusCode !== 200) {
      require('fs').writeFileSync('documents-test-error.json', JSON.stringify(res.body, null, 2));
      console.error('Update document error:', res.body);
    }
    expect(res.statusCode).toBe(200);
    expect(res.body.content).toBe('Updated');
  });

  it('should delete a document', async () => {
    const res = await request(app).delete(`/api/documents/${id}`);
    if (res.statusCode !== 200) {
      require('fs').writeFileSync('documents-test-error.json', JSON.stringify(res.body, null, 2));
      console.error('Delete document error:', res.body);
    }
    expect(res.statusCode).toBe(200);
    expect(res.body.message).toMatch(/تم حذف المستند/);
  });
});
