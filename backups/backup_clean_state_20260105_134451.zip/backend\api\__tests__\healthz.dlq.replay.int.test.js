const request = require('supertest');
process.env.MSG_TRANSPORT = 'memory';
delete process.env.NATS_URL;
process.env.DLQ_SUBJECT = 'dlq-test';
// Stub external dependencies
jest.mock('../../../scripts/slack_webhook_notify.js', () => ({ notifySlack: () => {} }), {
  virtual: true,
});
jest.mock('../routes/analyticsReport.js', () => {
  const express = require('express');
  return express.Router();
});
jest.mock(
  '../../services/auditMiddleware.js',
  () => ({
    auditAllRequests: () => (req, res, next) => next(),
  }),
  { virtual: true }
);
const app = require('../app');

// Import DLQ to trigger a replay and update the global
const { createDlq } = require('../../shared/dlq');
const memoryTransport = require('../../shared/messaging/inmemory');

describe('/healthz dlq telemetry', () => {
  test('lastReplayAt is set after replay', async () => {
    const dlq = createDlq(memoryTransport, { subject: process.env.DLQ_SUBJECT });
    const bad = {
      id: 'ops-bad-' + Date.now(),
      originalSubject: 'probe',
      reason: 'ops-test',
      payload: { ok: false },
    };
    // Start replay subscription first (memory transport processes new messages only)
    await dlq.replay(async () => {});
    await dlq.send(bad);
    // Give a brief tick for lastReplayAt to be recorded
    await new Promise(r => setTimeout(r, 50));
    // After replay, /healthz should expose lastReplayAt
    const res = await request(app).get('/healthz');
    expect(res.status).toBe(200);
    expect(res.body.dlq).toEqual(
      expect.objectContaining({
        subject: 'dlq-test',
        lastReplayAt: expect.any(String),
      })
    );
  });
});
