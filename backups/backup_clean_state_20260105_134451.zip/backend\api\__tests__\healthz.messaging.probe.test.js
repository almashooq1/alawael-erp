// Lightweight messaging health probe using memory transport
process.env.MSG_TRANSPORT = 'memory';
delete process.env.NATS_URL;
const { createPublisher } = require('../../shared/messaging/publisher');
const { createSubscriber } = require('../../shared/messaging/subscriber');
const transport = require('../../shared/messaging/inmemory');

describe('messaging health probe (memory)', () => {
  test('publish-subscribe works within timeout', async () => {
    const publish = createPublisher(transport);
    const subscribe = createSubscriber(transport);

    const subject = 'probe.healthz.messaging';
    const observed = [];
    await subscribe(subject, async evt => {
      observed.push(evt.id);
      return true;
    });

    const evt = {
      specversion: '1.0',
      id: 'probe-' + Date.now(),
      type: 'probe.event.v1',
      source: 'ops-probe',
      time: new Date().toISOString(),
      datacontenttype: 'application/json',
      data: { ok: true },
    };
    await publish(subject, evt);

    await new Promise(resolve => setTimeout(resolve, 100));
    expect(observed).toContain(evt.id);
  }, 3000);
});
