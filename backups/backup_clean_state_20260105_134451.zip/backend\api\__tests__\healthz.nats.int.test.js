const request = require('supertest');

describe('/healthz with NATS transport (conditional)', () => {
  const originalEnv = { ...process.env };

  beforeAll(() => {
    // Only run if NATS_URL is provided; otherwise skip gracefully
    if (!process.env.NATS_URL) {
      // Mark for skip
      // eslint-disable-next-line jest/no-focused-tests
      test('NATS_URL not set; skipping NATS health probe', () => {});
      return;
    }
    process.env.MSG_TRANSPORT = 'nats';
  });

  afterAll(() => {
    process.env = originalEnv;
  });

  // Run conditionally
  const shouldRun = !!process.env.NATS_URL;

  (shouldRun ? test : test.skip)(
    'reports effectiveTransport=nats when NATS configured',
    async () => {
      const app = require('../app');
      const res = await request(app).get('/healthz');
      expect(res.status).toBe(200);
      expect(res.body).toEqual(
        expect.objectContaining({
          ok: true,
          transport: 'nats',
          effectiveTransport: expect.stringMatching(/nats|memory/),
        })
      );
    }
  );
});
