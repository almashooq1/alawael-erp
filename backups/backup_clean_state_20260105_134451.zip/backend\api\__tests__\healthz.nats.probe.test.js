/**
 * Conditional NATS health probe test.
 * Runs only when NATS_URL is present. Publishes a probe event and asserts it is consumed.
 */

const { createNatsTransport } = require('../../shared/messaging/nats');

const PROBE_SUBJECT = 'ops.health.nats.probe';

describe('healthz.nats.probe (conditional)', () => {
  const natsUrl = process.env.NATS_URL;

  if (!natsUrl) {
    test('skipped: NATS_URL not set', () => {});
    return;
  }

  let transport;
  let nc;

  beforeAll(async () => {
    transport = await createNatsTransport({ url: natsUrl });
    nc = transport.__nc || null; // for closing if exposed
  });

  afterAll(async () => {
    try {
      if (transport && transport.close) {
        await transport.close();
      } else if (nc) {
        await nc.drain();
      }
    } catch (_) {
      // ignore
    }
  });

  test('publishes and receives probe event via NATS', async () => {
    const received = new Promise((resolve, reject) => {
      const timeout = setTimeout(() => reject(new Error('Probe not received in time')), 5000);
      transport.subscribe(PROBE_SUBJECT, async msg => {
        try {
          clearTimeout(timeout);
          // Minimal CloudEvent check: id/type present
          expect(msg && msg.id).toBeTruthy();
          expect(msg && msg.type).toBe('ops.health.nats.probe.v1');
          resolve(true);
        } catch (err) {
          reject(err);
        }
      });
    });

    await transport.publish(PROBE_SUBJECT, {
      specversion: '1.0',
      id: `probe-${Date.now()}`,
      type: 'ops.health.nats.probe.v1',
      source: 'ops-health-tests',
      time: new Date().toISOString(),
      datacontenttype: 'application/json',
      data: { ok: true },
    });

    await expect(received).resolves.toBe(true);
  });
});
// Conditional NATS messaging health probe
const { createPublisher } = require('../../shared/messaging/publisher');
const { createSubscriber } = require('../../shared/messaging/subscriber');

const hasNats = !!process.env.NATS_URL;

(hasNats ? describe : describe.skip)('messaging health probe (nats)', () => {
  test('publish-subscribe works within timeout when NATS_URL is set', async () => {
    process.env.MSG_TRANSPORT = 'nats';
    const { createNatsTransport } = require('../../shared/messaging/nats.js');
    const transport = createNatsTransport({ url: process.env.NATS_URL });
    const publish = createPublisher(transport);
    const subscribe = createSubscriber(transport);

    const subject = 'probe.healthz.messaging.nats';
    const observed = [];
    await subscribe(subject, async evt => {
      observed.push(evt.id);
      return true;
    });

    const evt = {
      specversion: '1.0',
      id: 'probe-nats-' + Date.now(),
      type: 'probe.event.v1',
      source: 'ops-probe',
      time: new Date().toISOString(),
      datacontenttype: 'application/json',
      data: { ok: true },
    };
    await publish(subject, evt);

    await new Promise(resolve => setTimeout(resolve, 400));
    expect(observed).toContain(evt.id);
  }, 5000);
});
