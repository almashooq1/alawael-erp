const request = require('supertest');
// Ensure envs are set before app load
process.env.MSG_TRANSPORT = 'memory';
delete process.env.NATS_URL;
process.env.SENTRY_DSN = 'https://example@sentry.io/123';
process.env.APPINSIGHTS_INSTRUMENTATIONKEY = '0000-1111-2222-3333';
process.env.DLQ_SUBJECT = 'dlq-test';
// Stub external dependencies
jest.mock('../../../scripts/slack_webhook_notify.js', () => ({ notifySlack: () => {} }), {
  virtual: true,
});
jest.mock('../routes/analyticsReport.js', () => {
  const express = require('express');
  return express.Router();
});
jest.mock(
  '../../services/auditMiddleware.js',
  () => ({
    auditAllRequests: () => (req, res, next) => next(),
  }),
  { virtual: true }
);
const app = require('../app');

describe('/healthz/recheck ops visibility', () => {
  test('recomputes schemaStatus and returns health payload', async () => {
    const res = await request(app).post('/healthz/recheck');
    expect(res.status).toBe(200);
    expect(res.body).toEqual(
      expect.objectContaining({
        ok: true,
        transport: 'memory',
        effectiveTransport: expect.any(String),
        observability: expect.objectContaining({
          sentryEnabled: true,
          appInsightsEnabled: true,
        }),
        schemaStatus: expect.objectContaining({
          schemas: expect.any(Number),
          recheckedAt: expect.any(String),
        }),
        dlq: expect.objectContaining({ enabled: true, subject: 'dlq-test' }),
      })
    );
  });
});
