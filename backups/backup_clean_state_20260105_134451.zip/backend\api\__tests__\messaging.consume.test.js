const request = require('supertest');
const app = require('../app');
// Subscribe directly to the in-memory transport used by app
const transport = require('../../shared/messaging/inmemory');

describe('Messaging consumer observation (memory transport)', () => {
  beforeAll(() => {
    process.env.MSG_TRANSPORT = 'memory';
  });

  test('Subscriber receives published CloudEvent', async () => {
    const received = [];
    transport.subscribe('demo.patient.created', evt => {
      received.push(evt.id);
    });

    const id = 'obs-evt-1';
    const res = await request(app)
      .post('/demo/patient')
      .set('Content-Type', 'application/json')
      .send({ id, name: 'Observer' });

    expect(res.status).toBe(202);
    // Allow microtask queue to flush
    await new Promise(r => setTimeout(r, 10));
    expect(received).toContain(id);
  });
});
