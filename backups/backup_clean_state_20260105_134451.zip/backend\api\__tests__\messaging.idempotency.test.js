const request = require('supertest');
const app = require('../app');

describe('Messaging idempotency (memory transport)', () => {
  beforeAll(() => {
    process.env.MSG_TRANSPORT = 'memory';
  });

  test('Duplicate CloudEvent id publishes successfully twice (consumer should dedupe)', async () => {
    const body = { id: 'dup-evt-1', name: 'Alice' };
    const r1 = await request(app)
      .post('/demo/patient')
      .send(body)
      .set('Content-Type', 'application/json');
    const r2 = await request(app)
      .post('/demo/patient')
      .send(body)
      .set('Content-Type', 'application/json');

    // Both requests should be accepted
    expect([r1.status, r2.status]).toEqual([202, 202]);
    // Test passes if requests are accepted without errors
    expect([r1.status, r2.status].some(s => s === 202)).toBe(true);
  });
});
