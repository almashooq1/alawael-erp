const request = require('supertest');

// Import app directly to avoid starting an external server
const app = require('../app');

describe('Messaging integration (memory transport)', () => {
  beforeAll(() => {
    process.env.MSG_TRANSPORT = 'memory';
  });

  test('Publishes CloudEvent via /demo/patient', async () => {
    const res = await request(app)
      .post('/demo/patient')
      .send({ id: 't-evt-1', name: 'Bob' })
      .set('Content-Type', 'application/json');
    expect(res.status).toBe(202);
    expect(res.body).toEqual(expect.objectContaining({ ok: true, id: 't-evt-1' }));
  }, 20000);

  test('Sends to DLQ via /demo/fail', async () => {
    const res = await request(app)
      .post('/demo/fail')
      .send({ cause: 'unit-test' })
      .set('Content-Type', 'application/json');
    expect(res.status).toBe(202);
    expect(res.body).toEqual(expect.objectContaining({ ok: true }));
  }, 20000);
});
