const request = require('supertest');
const app = require('../app');
const Patient = require('../models/Patient');
const User = require('../models/User');

describe('Patients API', () => {
  beforeAll(async () => {
    await User.sync({ force: true });
    await Patient.sync({ force: true });
  });

  let id;

  it('should create a patient', async () => {
    const u = await User.create({ name: 'U1', role: 'member' });
    const res = await request(app)
      .post('/api/patients')
      .send({ medical_info: 'Test', sessions: 1, user_id: u.id });
    if (res.statusCode !== 201) {
      require('fs').writeFileSync('patients-test-error.json', JSON.stringify(res.body, null, 2));
      console.error('Create patient error:', res.body);
    }
    expect(res.statusCode).toBe(201);
    expect(res.body.medical_info).toBe('Test');
    id = res.body.id;
  });

  it('should get all patients', async () => {
    const res = await request(app).get('/api/patients');
    if (res.statusCode !== 200) {
      require('fs').writeFileSync('patients-test-error.json', JSON.stringify(res.body, null, 2));
      console.error('Get patients error:', res.body);
    }
    expect(res.statusCode).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
    expect(res.body.length).toBeGreaterThan(0);
  });

  it('should update a patient', async () => {
    const res = await request(app).put(`/api/patients/${id}`).send({ sessions: 2 });
    if (res.statusCode !== 200) {
      require('fs').writeFileSync('patients-test-error.json', JSON.stringify(res.body, null, 2));
      console.error('Update patient error:', res.body);
    }
    expect(res.statusCode).toBe(200);
    expect(res.body.sessions).toBe(2);
  });

  it('should delete a patient', async () => {
    const res = await request(app).delete(`/api/patients/${id}`);
    if (res.statusCode !== 200) {
      require('fs').writeFileSync('patients-test-error.json', JSON.stringify(res.body, null, 2));
      console.error('Delete patient error:', res.body);
    }
    expect(res.statusCode).toBe(200);
    expect(res.body.message).toMatch(/تم حذف المريض/);
  });
});
