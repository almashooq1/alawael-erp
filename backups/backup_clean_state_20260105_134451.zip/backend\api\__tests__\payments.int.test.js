process.env.NODE_ENV = 'test';

const request = require('supertest');
const app = require('../app');
const Payment = require('../models/Payment');
const User = require('../models/User');

const TEST_ORIGIN = 'http://localhost:3000';

describe('Payments API', () => {
  beforeAll(async () => {
    await User.sync({ force: true });
    await Payment.sync({ force: true });
  });

  let id;

  it('should create a payment', async () => {
    const u = await User.create({ name: 'PayUser', role: 'member' });
    const res = await request(app)
      .post('/api/payments')
      .set('Origin', TEST_ORIGIN)
      .send({ amount: 100.5, method: 'card', status: 'pending', fraud_flag: false, user_id: u.id });
    if (res.statusCode !== 201) {
      require('fs').writeFileSync('payments-test-error.json', JSON.stringify(res.body, null, 2));
      console.error('Create payment error:', res.body);
    }
    expect(res.statusCode).toBe(201);
    expect(Number(res.body.amount)).toBeCloseTo(100.5);
    id = res.body.id;
  });

  it('should get all payments', async () => {
    const res = await request(app).get('/api/payments').set('Origin', TEST_ORIGIN);
    if (res.statusCode !== 200) {
      require('fs').writeFileSync('payments-test-error.json', JSON.stringify(res.body, null, 2));
      console.error('Get payments error:', res.body);
    }
    expect(res.statusCode).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
    expect(res.body.length).toBeGreaterThanOrEqual(0);
  }, 20000);

  it('should update a payment', async () => {
    const res = await request(app)
      .put(`/api/payments/${id}`)
      .set('Origin', TEST_ORIGIN)
      .send({ status: 'completed' });
    if (res.statusCode !== 200) {
      require('fs').writeFileSync('payments-test-error.json', JSON.stringify(res.body, null, 2));
      console.error('Update payment error:', res.body);
    }
    expect(res.statusCode).toBe(200);
    expect(res.body.status).toBe('completed');
  }, 20000);

  it('should delete a payment', async () => {
    const res = await request(app).delete(`/api/payments/${id}`).set('Origin', TEST_ORIGIN);
    if (res.statusCode !== 200) {
      require('fs').writeFileSync('payments-test-error.json', JSON.stringify(res.body, null, 2));
      console.error('Delete payment error:', res.body);
    }
    expect(res.statusCode).toBe(200);
    expect(res.body.message).toMatch(/تم حذف الدفع/);
  }, 20000);
});
