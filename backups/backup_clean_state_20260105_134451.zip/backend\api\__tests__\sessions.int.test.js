const request = require('supertest');
const app = require('../app');
const Session = require('../models/Session');
const Staff = require('../models/Staff');
const Patient = require('../models/Patient');
const User = require('../models/User');

describe('Sessions API', () => {
  beforeAll(async () => {
    await User.sync({ force: true });
    await Patient.sync({ force: true });
    await Staff.sync({ force: true });
    await Session.sync({ force: true });
  });

  let id;

  it('should create a session', async () => {
    const u = await User.create({ name: 'PUser', role: 'member' });
    const p = await Patient.create({ medical_info: 'MI', sessions: 0, user_id: u.id });
    const s = await Staff.create({
      position: 'Therapist',
      performance: 70,
      schedule: 'Mon-Fri',
      user_id: u.id,
    });
    const res = await request(app)
      .post('/api/sessions')
      .send({ type: 'PT', status: 'scheduled', notes: 'N/A', patient_id: p.id, staff_id: s.id });
    if (res.statusCode !== 201) {
      require('fs').writeFileSync('sessions-test-error.json', JSON.stringify(res.body, null, 2));
      console.error('Create session error:', res.body);
    }
    expect(res.statusCode).toBe(201);
    expect(res.body.status).toBe('scheduled');
    id = res.body.id;
  });

  it('should get all sessions', async () => {
    const res = await request(app).get('/api/sessions');
    if (res.statusCode !== 200) {
      require('fs').writeFileSync('sessions-test-error.json', JSON.stringify(res.body, null, 2));
      console.error('Get sessions error:', res.body);
    }
    expect(res.statusCode).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
    expect(res.body.length).toBeGreaterThan(0);
  });

  it('should update a session', async () => {
    const res = await request(app).put(`/api/sessions/${id}`).send({ status: 'completed' });
    if (res.statusCode !== 200) {
      require('fs').writeFileSync('sessions-test-error.json', JSON.stringify(res.body, null, 2));
      console.error('Update session error:', res.body);
    }
    expect(res.statusCode).toBe(200);
    expect(res.body.status).toBe('completed');
  });

  it('should delete a session', async () => {
    const res = await request(app).delete(`/api/sessions/${id}`);
    if (res.statusCode !== 200) {
      require('fs').writeFileSync('sessions-test-error.json', JSON.stringify(res.body, null, 2));
      console.error('Delete session error:', res.body);
    }
    expect(res.statusCode).toBe(200);
    expect(res.body.message).toMatch(/تم حذف الجلسة/);
  });
});
