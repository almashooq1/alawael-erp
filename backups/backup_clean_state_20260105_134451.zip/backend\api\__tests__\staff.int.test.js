const request = require('supertest');
const app = require('../app');
const Staff = require('../models/Staff');
const User = require('../models/User');

describe('Staff API', () => {
  beforeAll(async () => {
    // Ensure tables exist fresh in test sqlite
    await User.sync({ force: true });
    await Staff.sync({ force: true });
  });

  let id;

  it('should create a staff record', async () => {
    const u = await User.create({ name: 'U-Staff', role: 'employee' });
    const res = await request(app)
      .post('/api/staff')
      .send({ position: 'Therapist', performance: 85, schedule: 'Mon-Fri', user_id: u.id });
    if (res.statusCode !== 201) {
      require('fs').writeFileSync('staff-test-error.json', JSON.stringify(res.body, null, 2));
      console.error('Create staff error:', res.body);
    }
    expect(res.statusCode).toBe(201);
    expect(res.body.position).toBe('Therapist');
    id = res.body.id;
  });

  it('should get all staff', async () => {
    const res = await request(app).get('/api/staff');
    if (res.statusCode !== 200) {
      require('fs').writeFileSync('staff-test-error.json', JSON.stringify(res.body, null, 2));
      console.error('Get staff error:', res.body);
    }
    expect(res.statusCode).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
    expect(res.body.length).toBeGreaterThan(0);
  });

  it('should update a staff record', async () => {
    const res = await request(app).put(`/api/staff/${id}`).send({ performance: 90 });
    if (res.statusCode !== 200) {
      require('fs').writeFileSync('staff-test-error.json', JSON.stringify(res.body, null, 2));
      console.error('Update staff error:', res.body);
    }
    expect(res.statusCode).toBe(200);
    expect(res.body.performance).toBe(90);
  });

  it('should delete a staff record', async () => {
    const res = await request(app).delete(`/api/staff/${id}`);
    if (res.statusCode !== 200) {
      require('fs').writeFileSync('staff-test-error.json', JSON.stringify(res.body, null, 2));
      console.error('Delete staff error:', res.body);
    }
    expect(res.statusCode).toBe(200);
    expect(res.body.message).toMatch(/تم حذف الموظف/);
  });
});
