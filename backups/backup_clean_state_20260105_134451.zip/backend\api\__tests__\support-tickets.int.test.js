const request = require('supertest');
const app = require('../app');
const SupportTicket = require('../models/SupportTicket');
const Staff = require('../models/Staff');
const User = require('../models/User');

describe('Support Tickets API', () => {
  let ticketId, userId, staffId;

  beforeAll(async () => {
    // Sync models with force to recreate tables
    await User.sync({ force: true });
    await Staff.sync({ force: true });
    await SupportTicket.sync({ force: true });

    // Create user and staff for tests
    const u = await User.create({ name: 'Reporter', role: 'member' });
    const s = await Staff.create({
      position: 'Agent',
      performance: 80,
      schedule: 'Mon-Fri',
      user_id: u.id,
    });
    userId = u.id;
    staffId = s.id;
  });

  it('should create a support ticket via API', async () => {
    const res = await request(app).post('/api/support-tickets').send({
      channel: 'email',
      issue: 'Login problem',
      status: 'open',
      user_id: userId,
      assigned_to: staffId,
    });
    if (res.statusCode !== 201) {
      require('fs').writeFileSync(
        'support-tickets-test-error.json',
        JSON.stringify(res.body, null, 2)
      );
      console.error('Create ticket error:', res.body);
    }
    expect(res.statusCode).toBe(201);
    expect(res.body.status).toBe('open');
    ticketId = res.body.id; // Save ID for later tests

    // Verify ticket exists immediately after creation
    const verifyTicket = await SupportTicket.findByPk(ticketId);
    console.log(
      'Verification after create:',
      verifyTicket ? `Ticket ${ticketId} exists` : `Ticket ${ticketId} NOT found`
    );
  });

  it('should get all support tickets', async () => {
    const res = await request(app).get('/api/support-tickets');
    if (res.statusCode !== 200) {
      require('fs').writeFileSync(
        'support-tickets-test-error.json',
        JSON.stringify(res.body, null, 2)
      );
      console.error('Get tickets error:', res.body);
    }
    expect(res.statusCode).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
    expect(res.body.length).toBeGreaterThan(0);
  });

  it('should update a support ticket', async () => {
    console.log('UPDATE: ticketId =', ticketId);

    // Verify ticket exists before update
    const checkTicket = await SupportTicket.findByPk(ticketId);
    console.log(
      'Before UPDATE:',
      checkTicket
        ? `Ticket ${ticketId} exists, status=${checkTicket.status}`
        : `Ticket ${ticketId} NOT found`
    );

    const res = await request(app)
      .put(`/api/support-tickets/${ticketId}`)
      .send({ status: 'resolved' });
    if (res.statusCode !== 200) {
      require('fs').writeFileSync(
        'support-tickets-test-error.json',
        JSON.stringify(res.body, null, 2)
      );
      console.error('Update ticket error:', res.body);
    }
    expect(res.statusCode).toBe(200);
    expect(res.body.status).toBe('resolved');
  });

  it('should delete a support ticket', async () => {
    const res = await request(app).delete(`/api/support-tickets/${ticketId}`);
    if (res.statusCode !== 200) {
      require('fs').writeFileSync(
        'support-tickets-test-error.json',
        JSON.stringify(res.body, null, 2)
      );
      console.error('Delete ticket error:', res.body);
    }
    expect(res.statusCode).toBe(200);
    expect(res.body.message).toMatch(/تم حذف تذكرة الدعم/);
  });
});
