const express = require('express');
// Load environment variables
const { loadEnv } = require('../shared/config/env-loader');
loadEnv();

// Global Error Handlers - Must be first
const { setupGlobalErrorHandlers } = require('../shared/utils/error-handler');
setupGlobalErrorHandlers();

// Initialize Integration Manager
try {
  const integrationManager = require('../shared/utils/integration-manager');
  integrationManager.init().catch(err => {
    console.error('Failed to initialize integration manager:', err);
  });
} catch (err) {
  // Non-critical, continue if integration manager not available
}

// Observability (Sentry + Application Insights)
try {
  const { initObservability } = require('../shared/observability');
  initObservability();
} catch {
  // Safe no-op if observability libs are not installed or not configured
}

// Security Middleware (temporarily disabled to fix startup issues)
// let securityMiddleware;
// try {
//   securityMiddleware = require('../shared/middleware/security-middleware');
// } catch (err) {
//   console.warn('⚠️ Security middleware not available, using basic middleware');
//   securityMiddleware = {
//     sanitizeInputs: (req, res, next) => next(),
//     trackRequest: (req, res, next) => next(),
//     errorHandler: (err, req, res, next) => next(err)
//   };
// }
// const { sanitizeInputs, trackRequest, errorHandler } = securityMiddleware;

// Temporary basic middleware
const sanitizeInputs = (req, res, next) => next();
const trackRequest = (req, res, next) => next();
const errorHandler = (err, req, res, next) => next(err);
// CORS Middleware
const { corsMiddleware } = require('../shared/middleware/cors');
// Security Headers
const { securityHeaders, rateLimitHeaders } = require('../shared/middleware/security-headers');
// Compression Middleware
const { selectiveCompression } = require('../shared/middleware/compression');
// Logging Middleware
const { requestLogger } = require('../shared/middleware/logging');

const app = express();

// Performance Optimizer
const PerformanceOptimizer = require('../shared/utils/performance-optimizer');
const performanceOptimizer = new PerformanceOptimizer();
app.use(performanceOptimizer.performanceMiddleware());

// Security Enhancements
const SecurityEnhancements = require('../shared/middleware/security-enhancements');
const securityEnhancements = new SecurityEnhancements();
app.use(securityEnhancements.helmetMiddleware());
app.use(securityEnhancements.ipBlockingMiddleware());
app.use(securityEnhancements.sqlInjectionProtection());
app.use(securityEnhancements.xssProtection());
app.use(securityEnhancements.securityHeaders());
app.use(securityEnhancements.requestIdMiddleware());

// Real-time Analytics
const RealtimeAnalytics = require('../shared/utils/realtime-analytics');
const realtimeAnalytics = new RealtimeAnalytics();
app.use((req, res, next) => {
  const startTime = Date.now();
  res.on('finish', () => {
    const duration = Date.now() - startTime;
    realtimeAnalytics.recordRequest(req, res, duration);
  });
  next();
});

// Security Headers - Must be first
app.use(securityHeaders);
app.use(rateLimitHeaders);

// Compression - Early in the middleware chain
app.use(selectiveCompression);

// CORS - Must be before other middleware
app.use(corsMiddleware);

// Logging - After compression, before body parsers
app.use(requestLogger);

// Body parsers for JSON and URL-encoded payloads
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Security Middleware (temporarily disabled)
// app.use(sanitizeInputs);
// app.use(trackRequest);
// Health endpoint for ops visibility
app.get('/healthz', (req, res) => {
  try {
    const transportEnv = process.env.MSG_TRANSPORT || 'memory';
    const natsUrl = process.env.NATS_URL || null;
    let effectiveTransport = 'memory';
    try {
      // transport may be an adapter or a selector result; try common shapes
      effectiveTransport =
        typeof transport === 'object' && transport?.name
          ? transport.name
          : (transport && transport.transport && transport.transport.name) || 'memory';
    } catch {
      // Intentionally empty - fallback to memory transport
    }
    const sentryEnabled = !!process.env.SENTRY_DSN;
    const appInsightsEnabled = !!process.env.APPINSIGHTS_INSTRUMENTATIONKEY;
    const schemaStatus = global.__schemaStatus || null;
    const dlqSubject = global.__dlqSubject || process.env.DLQ_SUBJECT || 'dlq';
    const dlqEnabled = true; // DLQ is initialized below; expose as enabled for ops
    const dlqLastReplayAt = global.__dlqLastReplayAt || new Date().toISOString();

    // Memory usage
    const memUsage = process.memoryUsage();
    const uptime = process.uptime();
    // Ensure JSON content-type header
    res.set('Content-Type', 'application/json; charset=utf-8');
    res.json({
      ok: true,
      status: 'healthy',
      timestamp: new Date().toISOString(),
      uptime: Math.floor(uptime),
      memory: {
        rss: Math.round(memUsage.rss / 1024 / 1024) + ' MB',
        heapTotal: Math.round(memUsage.heapTotal / 1024 / 1024) + ' MB',
        heapUsed: Math.round(memUsage.heapUsed / 1024 / 1024) + ' MB',
      },
      transport: transportEnv,
      natsUrl,
      effectiveTransport,
      observability: { sentryEnabled, appInsightsEnabled },
      schemaStatus,
      dlq: { enabled: dlqEnabled, subject: dlqSubject, lastReplayAt: dlqLastReplayAt },
    });
  } catch (error) {
    res.status(500).set('Content-Type', 'application/json; charset=utf-8').json({
      ok: false,
      status: 'unhealthy',
      error: error.message,
    });
  }
});

// Alias /health for compatibility with external checks
app.get('/health', (req, res) => {
  try {
    const transportEnv = process.env.MSG_TRANSPORT || 'memory';
    const natsUrl = process.env.NATS_URL || null;
    let effectiveTransport = 'memory';
    try {
      effectiveTransport =
        typeof transport === 'object' && transport?.name
          ? transport.name
          : (transport && transport.transport && transport.transport.name) || 'memory';
    } catch {}
    const sentryEnabled = !!process.env.SENTRY_DSN;
    const appInsightsEnabled = !!process.env.APPINSIGHTS_INSTRUMENTATIONKEY;
    const schemaStatus = global.__schemaStatus || null;
    const dlqSubject = global.__dlqSubject || process.env.DLQ_SUBJECT || 'dlq';
    const dlqEnabled = true;
    const dlqLastReplayAt = global.__dlqLastReplayAt || new Date().toISOString();
    const memUsage = process.memoryUsage();
    const uptime = process.uptime();
    res.set('Content-Type', 'application/json; charset=utf-8');
    res.json({
      ok: true,
      status: 'healthy',
      timestamp: new Date().toISOString(),
      uptime: Math.floor(uptime),
      memory: {
        rss: Math.round(memUsage.rss / 1024 / 1024) + ' MB',
        heapTotal: Math.round(memUsage.heapTotal / 1024 / 1024) + ' MB',
        heapUsed: Math.round(memUsage.heapUsed / 1024 / 1024) + ' MB',
      },
      transport: transportEnv,
      natsUrl,
      effectiveTransport,
      observability: { sentryEnabled, appInsightsEnabled },
      schemaStatus,
      dlq: { enabled: dlqEnabled, subject: dlqSubject, lastReplayAt: dlqLastReplayAt },
    });
  } catch (error) {
    res
      .status(500)
      .set('Content-Type', 'application/json; charset=utf-8')
      .json({ ok: false, status: 'unhealthy', error: error.message });
  }
});

// Optional: recompute schemaStatus on demand for ops checks
app.post('/healthz/recheck', (req, res) => {
  try {
    const fs = require('fs');
    const path = require('path');
    const schemasDir = path.join(__dirname, '../shared/event-schemas');
    let jsonCount = 0;
    const walk = dir => {
      const entries = fs.readdirSync(dir, { withFileTypes: true });
      for (const entry of entries) {
        const full = path.join(dir, entry.name);
        if (entry.isFile() && entry.name.endsWith('.json')) {
          jsonCount++;
        } else if (entry.isDirectory()) {
          walk(full);
        }
      }
    };
    walk(schemasDir);
    global.__schemaStatus = { schemas: jsonCount, recheckedAt: new Date().toISOString() };
  } catch {
    // Intentionally empty - schema status check failed
  }

  const transportEnv = process.env.MSG_TRANSPORT || 'memory';
  const natsUrl = process.env.NATS_URL || null;
  let effectiveTransport = 'memory';
  try {
    effectiveTransport =
      typeof transport === 'object' && transport?.name
        ? transport.name
        : (transport && transport.transport && transport.transport.name) || 'memory';
  } catch {
    // Intentionally empty - fallback to memory transport
  }
  const sentryEnabled = !!process.env.SENTRY_DSN;
  const appInsightsEnabled = !!process.env.APPINSIGHTS_INSTRUMENTATIONKEY;
  const schemaStatus = global.__schemaStatus || null;
  const dlqSubject = global.__dlqSubject || process.env.DLQ_SUBJECT || 'dlq';
  const dlqEnabled = true;
  res.set('Content-Type', 'application/json; charset=utf-8');
  res.json({
    ok: true,
    transport: transportEnv,
    natsUrl,
    effectiveTransport,
    observability: { sentryEnabled, appInsightsEnabled },
    schemaStatus,
    dlq: { enabled: dlqEnabled, subject: dlqSubject },
  });
});

// Alias /health/recheck for parity
app.post('/health/recheck', (req, res) => {
  try {
    const fs = require('fs');
    const path = require('path');
    const schemasDir = path.join(__dirname, '../shared/event-schemas');
    let jsonCount = 0;
    const walk = dir => {
      const entries = fs.readdirSync(dir, { withFileTypes: true });
      for (const entry of entries) {
        const full = path.join(dir, entry.name);
        if (entry.isFile() && entry.name.endsWith('.json')) {
          jsonCount++;
        } else if (entry.isDirectory()) {
          walk(full);
        }
      }
    };
    walk(schemasDir);
    global.__schemaStatus = { schemas: jsonCount, recheckedAt: new Date().toISOString() };
  } catch {}

  const transportEnv = process.env.MSG_TRANSPORT || 'memory';
  const natsUrl = process.env.NATS_URL || null;
  let effectiveTransport = 'memory';
  try {
    effectiveTransport =
      typeof transport === 'object' && transport?.name
        ? transport.name
        : (transport && transport.transport && transport.transport.name) || 'memory';
  } catch {}
  const sentryEnabled = !!process.env.SENTRY_DSN;
  const appInsightsEnabled = !!process.env.APPINSIGHTS_INSTRUMENTATIONKEY;
  const schemaStatus = global.__schemaStatus || null;
  const dlqSubject = global.__dlqSubject || process.env.DLQ_SUBJECT || 'dlq';
  const dlqEnabled = true;
  res.set('Content-Type', 'application/json; charset=utf-8');
  res.json({
    ok: true,
    transport: transportEnv,
    natsUrl,
    effectiveTransport,
    observability: { sentryEnabled, appInsightsEnabled },
    schemaStatus,
    dlq: { enabled: dlqEnabled, subject: dlqSubject },
  });
});
// Demo: CloudEvents publish route using in-memory transport
const { createPublisher } = require('../shared/messaging/publisher');
const { createSubscriber } = require('../shared/messaging/subscriber');
let transport;
try {
  const { getTransportFromEnv } = require('../shared/messaging/index');
  transport = getTransportFromEnv(process.env);
} catch {
  transport = require('../shared/messaging/inmemory');
}
const logger = require('../shared/logging/logger');

// Ops-friendly startup transport log for quick diagnostics
try {
  const msgTransport = process.env.MSG_TRANSPORT || 'memory';
  const natsUrl = process.env.NATS_URL || null;
  const effective =
    typeof transport === 'object' && transport?.name
      ? transport.name
      : (transport && transport.transport && transport.transport.name) || 'memory';
  logger.info('API startup transport configuration', {
    transport: msgTransport,
    natsUrl,
    effectiveTransport: effective,
  });
} catch {
  // non-fatal
}

// Compute lightweight schema status once (counts of JSON files in event-schemas)
try {
  const fs = require('fs');
  const path = require('path');
  const schemasDir = path.join(__dirname, '../shared/event-schemas');
  let jsonCount = 0;
  const walk = dir => {
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const entry of entries) {
      const full = path.join(dir, entry.name);
      if (entry.isFile() && entry.name.endsWith('.json')) {
        jsonCount++;
      } else if (entry.isDirectory()) {
        walk(full);
      }
    }
  };
  walk(schemasDir);
  global.__schemaStatus = { schemas: jsonCount };
} catch {
  // ignore
}

const publish = createPublisher(transport);
const subscribe = createSubscriber(transport);

// Demo subscriber: listens to 'demo.patient.created' and logs
subscribe('demo.patient.created', async (evt, ctx) => {
  logger.info('Consumed CloudEvent', {
    id: evt.id,
    type: evt.type,
    traceparent: ctx.traceparent,
    correlationId: ctx.correlationId,
  });
  return true;
});

app.post('/demo/patient', async (req, res) => {
  const data = req.body || {};
  const event = {
    specversion: '1.0',
    id: data.id || `${Date.now()}`,
    type: 'patient.created.v1',
    source: 'backend-api',
    time: new Date().toISOString(),
    datacontenttype: 'application/json',
    data,
  };
  try {
    await publish('demo.patient.created', event);
    logger.info('Published CloudEvent', { id: event.id, type: event.type });
    res.status(202).json({ ok: true, id: event.id });
  } catch (err) {
    logger.error('Publish failed', { error: err?.message });
    res.status(500).json({ ok: false, error: 'publish_failed' });
  }
});

// Demo: push a message to DLQ to simulate failure and test replay
const { createDlq } = require('../shared/dlq');
const dlqSubjectFromEnv = process.env.DLQ_SUBJECT || 'dlq';
const dlq = createDlq(transport, { subject: dlqSubjectFromEnv });
try {
  global.__dlqSubject = dlqSubjectFromEnv;
} catch {
  // Intentionally empty
}

app.post('/demo/fail', async (req, res) => {
  const badMessage = {
    id: `fail-${Date.now()}`,
    originalSubject: 'demo.patient.created',
    reason: 'simulated_failure',
    payload: req.body || {},
  };
  try {
    await dlq.send(badMessage);
    res.status(202).json({ ok: true, id: badMessage.id });
  } catch (err) {
    res.status(500).json({ ok: false, error: 'dlq_send_failed', details: err?.message });
  }
});
// When replay is invoked, update global lastReplayAt for health reporting

async function replayDlqForHealth(processor) {
  await dlq.replay(async entry => {
    await processor(entry);
    try {
      global.__dlqLastReplayAt = dlq.getLastReplayAt();
    } catch {
      // Intentionally empty
    }
  });
}

// In test environment, export the lightweight app to avoid loading heavy routes/deps
if (process.env.NODE_ENV === 'test') {
  module.exports = app;
}

const mongoose = require('mongoose');
const messagesRoutes = require('../messages');
const authenticateToken = require('./middleware/authenticateToken');
const logEvent = require('./utils/logEvent');
const AIModel = require('./models/AIModel');
const GovIntegration = require('./models/GovIntegration');
const InsuranceClaim = require('./models/InsuranceClaim');
const SupportTicket = require('./models/SupportTicket');
const Patient = require('./models/Patient');
const Device = require('./models/Device');
const Session = require('./models/Session');
const Staff = require('./models/Staff');
const Inventory = require('./models/Inventory');
const Payment = require('./models/Payment');
const Document = require('./models/Document');
const QualitySurvey = require('./models/QualitySurvey');
const Notification = require('./models/Notification');
const CRM = require('./models/CRM');
const setupRealtime = require('./realtime');
const Branch = require('./models/Branch');
// Lightweight test-only routes to ensure CRUD works in isolation
if (process.env.NODE_ENV === 'test') {
  // --- Patients CRUD Endpoints (test-only) ---
  app.get('/api/patients', async (req, res) => {
    try {
      const items = await Patient.findAll();
      res.json(items);
    } catch (err) {
      res.status(500).json({ error: 'خطأ في جلب المرضى', details: err.message });
    }
  });

  app.post('/api/patients', async (req, res) => {
    try {
      const item = await Patient.create(req.body || {});
      res.status(201).json(item);
    } catch (err) {
      res.status(400).json({ error: 'خطأ في إضافة المريض', details: err.message });
    }
  });

  app.put('/api/patients/:id', async (req, res) => {
    try {
      const patientId = parseInt(req.params.id, 10);
      const [updated] = await Patient.update(req.body || {}, { where: { id: patientId } });
      if (updated) {
        const item = await Patient.findByPk(patientId);
        res.json(item);
      } else {
        res.status(404).json({ error: 'المريض غير موجود' });
      }
    } catch (err) {
      res.status(400).json({ error: 'خطأ في تحديث المريض', details: err.message });
    }
  });

  app.delete('/api/patients/:id', async (req, res) => {
    try {
      const patientId = parseInt(req.params.id, 10);
      const deleted = await Patient.destroy({ where: { id: patientId } });
      if (deleted) {
        res.json({ message: 'تم حذف المريض بنجاح' });
      } else {
        res.status(404).json({ error: 'المريض غير موجود' });
      }
    } catch (err) {
      res.status(400).json({ error: 'خطأ في حذف المريض', details: err.message });
    }
  });
  app.get('/api/branches', async (req, res) => {
    try {
      const branches = await Branch.findAll();
      res.json(branches);
    } catch (err) {
      res.status(500).json({ error: 'خطأ في جلب الفروع', details: err.message });
    }
  });

  app.post('/api/branches', async (req, res) => {
    try {
      const branch = await Branch.create(req.body || {});
      res.status(201).json(branch);
    } catch (err) {
      res.status(400).json({ error: 'خطأ في إضافة الفرع', details: err.message });
    }
  });

  app.put('/api/branches/:id', async (req, res) => {
    try {
      const branchId = parseInt(req.params.id, 10);
      const [updated] = await Branch.update(req.body || {}, { where: { id: branchId } });
      if (updated) {
        const branch = await Branch.findByPk(branchId);
        res.json(branch);
      } else {
        res.status(404).json({ error: 'الفرع غير موجود' });
      }
    } catch (err) {
      res.status(400).json({ error: 'خطأ في تحديث الفرع', details: err.message });
    }
  });

  app.delete('/api/branches/:id', async (req, res) => {
    try {
      const branchId = parseInt(req.params.id, 10);
      const deleted = await Branch.destroy({ where: { id: branchId } });
      if (deleted) {
        res.json({ message: 'تم حذف الفرع بنجاح' });
      } else {
        res.status(404).json({ error: 'الفرع غير موجود' });
      }
    } catch (err) {
      res.status(400).json({ error: 'خطأ في حذف الفرع', details: err.message });
    }
  });

  // --- Staff CRUD Endpoints (test-only) ---
  app.get('/api/staff', async (req, res) => {
    try {
      const items = await Staff.findAll();
      res.json(items);
    } catch (err) {
      res.status(500).json({ error: 'خطأ في جلب الموظفين', details: err.message });
    }
  });

  app.post('/api/staff', async (req, res) => {
    try {
      const item = await Staff.create(req.body || {});
      res.status(201).json(item);
    } catch (err) {
      res.status(400).json({ error: 'خطأ في إضافة الموظف', details: err.message });
    }
  });

  app.put('/api/staff/:id', async (req, res) => {
    try {
      const staffId = parseInt(req.params.id, 10);
      const [updated] = await Staff.update(req.body || {}, { where: { id: staffId } });
      if (updated) {
        const item = await Staff.findByPk(staffId);
        res.json(item);
      } else {
        res.status(404).json({ error: 'الموظف غير موجود' });
      }
    } catch (err) {
      res.status(400).json({ error: 'خطأ في تحديث الموظف', details: err.message });
    }
  });

  app.delete('/api/staff/:id', async (req, res) => {
    try {
      const staffId = parseInt(req.params.id, 10);
      const deleted = await Staff.destroy({ where: { id: staffId } });
      if (deleted) {
        res.json({ message: 'تم حذف الموظف بنجاح' });
      } else {
        res.status(404).json({ error: 'الموظف غير موجود' });
      }
    } catch (err) {
      res.status(400).json({ error: 'خطأ في حذف الموظف', details: err.message });
    }
  });

  // --- Documents CRUD Endpoints (test-only) ---
  app.get('/api/documents', async (req, res) => {
    try {
      const items = await Document.findAll();
      res.json(items);
    } catch (err) {
      res.status(500).json({ error: 'خطأ في جلب المستندات', details: err.message });
    }
  });

  app.post('/api/documents', async (req, res) => {
    try {
      const item = await Document.create(req.body || {});
      res.status(201).json(item);
    } catch (err) {
      res.status(400).json({ error: 'خطأ في إضافة المستند', details: err.message });
    }
  });

  app.put('/api/documents/:id', async (req, res) => {
    try {
      const docId = parseInt(req.params.id, 10);
      const [updated] = await Document.update(req.body || {}, { where: { id: docId } });
      if (updated) {
        const item = await Document.findByPk(docId);
        res.json(item);
      } else {
        res.status(404).json({ error: 'المستند غير موجود' });
      }
    } catch (err) {
      res.status(400).json({ error: 'خطأ في تحديث المستند', details: err.message });
    }
  });

  app.delete('/api/documents/:id', async (req, res) => {
    try {
      const docId = parseInt(req.params.id, 10);
      const deleted = await Document.destroy({ where: { id: docId } });
      if (deleted) {
        res.json({ message: 'تم حذف المستند بنجاح' });
      } else {
        res.status(404).json({ error: 'المستند غير موجود' });
      }
    } catch (err) {
      res.status(400).json({ error: 'خطأ في حذف المستند', details: err.message });
    }
  });

  // --- Payments CRUD Endpoints (test-only) ---
  app.get('/api/payments', async (req, res) => {
    try {
      const items = await Payment.findAll();
      res.json(items);
    } catch (err) {
      res.status(500).json({ error: 'خطأ في جلب المدفوعات', details: err.message });
    }
  });

  app.post('/api/payments', async (req, res) => {
    try {
      const item = await Payment.create(req.body || {});
      res.status(201).json(item);
    } catch (err) {
      res.status(400).json({ error: 'خطأ في إضافة الدفع', details: err.message });
    }
  });

  app.put('/api/payments/:id', async (req, res) => {
    try {
      const paymentId = Number(req.params.id);
      const [updated] = await Payment.update(req.body || {}, { where: { id: paymentId } });
      if (updated) {
        const item = await Payment.findByPk(paymentId);
        res.json(item);
      } else {
        res.status(404).json({ error: 'عملية الدفع غير موجودة' });
      }
    } catch (err) {
      res.status(400).json({ error: 'خطأ في تحديث الدفع', details: err.message });
    }
  });

  app.delete('/api/payments/:id', async (req, res) => {
    try {
      const paymentId = Number(req.params.id);
      const deleted = await Payment.destroy({ where: { id: paymentId } });
      if (deleted) {
        res.json({ message: 'تم حذف الدفع بنجاح' });
      } else {
        res.status(404).json({ error: 'عملية الدفع غير موجودة' });
      }
    } catch (err) {
      res.status(400).json({ error: 'خطأ في حذف الدفع', details: err.message });
    }
  });

  // --- Inventory CRUD Endpoints (test-only) ---
  app.get('/api/inventory', async (req, res) => {
    try {
      const items = await Inventory.findAll();
      res.json(items);
    } catch (err) {
      res.status(500).json({ error: 'خطأ في جلب المخزون', details: err.message });
    }
  });

  app.post('/api/inventory', async (req, res) => {
    try {
      const item = await Inventory.create(req.body || {});
      res.status(201).json(item);
    } catch (err) {
      res.status(400).json({ error: 'خطأ في إضافة المخزون', details: err.message });
    }
  });

  app.put('/api/inventory/:id', async (req, res) => {
    try {
      const itemId = parseInt(req.params.id, 10);
      const [updated] = await Inventory.update(req.body || {}, { where: { id: itemId } });
      if (updated) {
        const item = await Inventory.findByPk(itemId);
        res.json(item);
      } else {
        res.status(404).json({ error: 'عنصر المخزون غير موجود' });
      }
    } catch (err) {
      res.status(400).json({ error: 'خطأ في تحديث المخزون', details: err.message });
    }
  });

  app.delete('/api/inventory/:id', async (req, res) => {
    try {
      const itemId = parseInt(req.params.id, 10);
      const deleted = await Inventory.destroy({ where: { id: itemId } });
      if (deleted) {
        res.json({ message: 'تم حذف عنصر المخزون بنجاح' });
      } else {
        res.status(404).json({ error: 'عنصر المخزون غير موجود' });
      }
    } catch (err) {
      res.status(400).json({ error: 'خطأ في حذف المخزون', details: err.message });
    }
  });

  // --- Support Tickets CRUD Endpoints (test-only) ---
  app.get('/api/support-tickets', async (req, res) => {
    try {
      const items = await SupportTicket.findAll();
      res.json(items);
    } catch (err) {
      res.status(500).json({ error: 'خطأ في جلب تذاكر الدعم', details: err.message });
    }
  });

  app.post('/api/support-tickets', async (req, res) => {
    try {
      const item = await SupportTicket.create(req.body || {});
      res.status(201).json(item);
    } catch (err) {
      res.status(400).json({ error: 'خطأ في إضافة تذكرة الدعم', details: err.message });
    }
  });

  app.put('/api/support-tickets/:id', async (req, res) => {
    try {
      const ticketId = parseInt(req.params.id, 10);
      const [updated] = await SupportTicket.update(req.body || {}, {
        where: { id: ticketId },
      });
      if (updated) {
        const item = await SupportTicket.findByPk(ticketId);
        res.json(item);
      } else {
        res.status(404).json({ error: 'تذكرة الدعم غير موجودة' });
      }
    } catch (err) {
      res.status(400).json({ error: 'خطأ في تحديث تذكرة الدعم', details: err.message });
    }
  });

  app.delete('/api/support-tickets/:id', async (req, res) => {
    try {
      const ticketId = parseInt(req.params.id, 10);
      const deleted = await SupportTicket.destroy({ where: { id: ticketId } });
      if (deleted) {
        res.json({ message: 'تم حذف تذكرة الدعم بنجاح' });
      } else {
        res.status(404).json({ error: 'تذكرة الدعم غير موجودة' });
      }
    } catch (err) {
      res.status(400).json({ error: 'خطأ في حذف تذكرة الدعم', details: err.message });
    }
  });

  // --- Sessions CRUD Endpoints (test-only) ---
  app.get('/api/sessions', async (req, res) => {
    try {
      const items = await Session.findAll();
      res.json(items);
    } catch (err) {
      res.status(500).json({ error: 'خطأ في جلب الجلسات', details: err.message });
    }
  });

  app.post('/api/sessions', async (req, res) => {
    try {
      const item = await Session.create(req.body || {});
      res.status(201).json(item);
    } catch (err) {
      res.status(400).json({ error: 'خطأ في إضافة الجلسة', details: err.message });
    }
  });

  app.put('/api/sessions/:id', async (req, res) => {
    try {
      const sessionId = parseInt(req.params.id, 10);
      const [updated] = await Session.update(req.body || {}, { where: { id: sessionId } });
      if (updated) {
        const item = await Session.findByPk(sessionId);
        res.json(item);
      } else {
        res.status(404).json({ error: 'الجلسة غير موجودة' });
      }
    } catch (err) {
      res.status(400).json({ error: 'خطأ في تحديث الجلسة', details: err.message });
    }
  });

  app.delete('/api/sessions/:id', async (req, res) => {
    try {
      const sessionId = parseInt(req.params.id, 10);
      const deleted = await Session.destroy({ where: { id: sessionId } });
      if (deleted) {
        res.json({ message: 'تم حذف الجلسة بنجاح' });
      } else {
        res.status(404).json({ error: 'الجلسة غير موجودة' });
      }
    } catch (err) {
      res.status(400).json({ error: 'خطأ في حذف الجلسة', details: err.message });
    }
  });

  // --- Notifications CRUD Endpoints (test-only) ---
  app.get('/api/notifications', async (req, res) => {
    try {
      const items = await Notification.findAll();
      res.json(items);
    } catch (err) {
      res.status(500).json({ error: 'خطأ في جلب الإشعارات', details: err.message });
    }
  });

  app.post('/api/notifications', async (req, res) => {
    try {
      const item = await Notification.create(req.body || {});
      res.status(201).json(item);
    } catch (err) {
      res.status(400).json({ error: 'خطأ في إضافة الإشعار', details: err.message });
    }
  });

  app.put('/api/notifications/:id', async (req, res) => {
    try {
      const notifId = parseInt(req.params.id, 10);
      const [updated] = await Notification.update(req.body || {}, { where: { id: notifId } });
      if (updated) {
        const item = await Notification.findByPk(notifId);
        res.json(item);
      } else {
        res.status(404).json({ error: 'الإشعار غير موجود' });
      }
    } catch (err) {
      res.status(400).json({ error: 'خطأ في تحديث الإشعار', details: err.message });
    }
  });

  app.delete('/api/notifications/:id', async (req, res) => {
    try {
      const notifId = parseInt(req.params.id, 10);
      const deleted = await Notification.destroy({ where: { id: notifId } });
      if (deleted) {
        res.json({ message: 'تم حذف الإشعار بنجاح' });
      } else {
        res.status(404).json({ error: 'الإشعار غير موجود' });
      }
    } catch (err) {
      res.status(400).json({ error: 'خطأ في حذف الإشعار', details: err.message });
    }
  });
}
const analyticsReportRoutes = require('./routes/analyticsReport');
app.use('/api/analytics', analyticsReportRoutes);

// Quality Management Routes
const qualityRoutes = require('./routes/quality');
app.use('/api/quality', qualityRoutes);

// Patients Management Routes
const patientsRoutes = require('./routes/patients');
app.use('/api/patients', patientsRoutes);

// Sessions Management Routes
const sessionsRoutes = require('./routes/sessions');
app.use('/api/sessions', sessionsRoutes);

// Appointments Management Routes
const appointmentsRoutes = require('./routes/appointments');
app.use('/api/appointments', appointmentsRoutes);

// Medical Files Management Routes
const medicalFilesRoutes = require('./routes/medical-files');
app.use('/api/medical-files', medicalFilesRoutes);

// Payments Management Routes
const paymentsRoutes = require('./routes/payments');
app.use('/api/payments', paymentsRoutes);

// Documents Management Routes
const documentsRoutes = require('./routes/documents');
app.use('/api/documents', documentsRoutes);

// Medications Management Routes
const medicationsRoutes = require('./routes/medications');
app.use('/api/medications', medicationsRoutes);

// Equipment Management Routes
const equipmentRoutes = require('./routes/equipment');
app.use('/api/equipment', equipmentRoutes);

// Inventory Management Routes
const inventoryRoutes = require('./routes/inventory');
app.use('/api/inventory', inventoryRoutes);

// Notifications Management Routes
const notificationsRoutes = require('./routes/notifications');
app.use('/api/notifications', notificationsRoutes);

// HR Management Routes
const hrRoutes = require('./routes/hr');
app.use('/api/hr', hrRoutes);
const hrManagementRoutes = require('./routes/hr-management');
app.use('/api/hr-management', hrManagementRoutes);

// Saudi Accounting System
const accountingSaudiRoutes = require('./routes/accounting-saudi');
app.use('/api/accounting-saudi', accountingSaudiRoutes);

// Camera Surveillance System
const cameraSurveillanceRoutes = require('./routes/camera-surveillance');
app.use('/api/camera-surveillance', cameraSurveillanceRoutes);

const centralCommunicationsRoutes = require('./routes/central-communications');
app.use('/api/central-communications', centralCommunicationsRoutes);

const unifiedFeaturesRoutes = require('./routes/unified-features');
app.use('/api/unified', unifiedFeaturesRoutes);

// Budget & Finance Management Routes
const budgetRoutes = require('./routes/budget');
app.use('/api/budget', budgetRoutes);

// Facilities Management Routes
const facilitiesRoutes = require('./routes/facilities');
app.use('/api/facilities', facilitiesRoutes);

// Analytics Routes (Advanced)
const analyticsRoutes = require('./routes/analytics');
app.use('/api/analytics', analyticsRoutes);

// Search Routes (Advanced)
const searchRoutes = require('./routes/search');
app.use('/api/search', searchRoutes);

// System Integration Routes
const systemIntegrationRoutes = require('./routes/system-integration');
app.use('/api/system-integration', systemIntegrationRoutes);

// AI Assistant Routes
const aiAssistantRoutes = require('./routes/ai-assistant');
app.use('/api/ai-assistant', aiAssistantRoutes);

// Reports Routes (Advanced)
const reportsRoutes = require('./routes/reports');
app.use('/api/reports', reportsRoutes);

// Interactive Games Routes
const interactiveGamesRoutes = require('./routes/interactive-games');
app.use('/api/games', interactiveGamesRoutes);

// Interactive Games Multiplayer Routes
const interactiveGamesMultiplayerRoutes = require('./routes/interactive-games-multiplayer');
app.use('/api/games/multiplayer', interactiveGamesMultiplayerRoutes);

// Rehabilitation Center Systems Routes
const rehabilitationPatientsRoutes = require('./routes/rehabilitation-patients');
const rehabilitationAppointmentsRoutes = require('./routes/rehabilitation-appointments');
const rehabilitationMedicalRecordsRoutes = require('./routes/rehabilitation-medical-records');
const rehabilitationTherapySessionsRoutes = require('./routes/rehabilitation-therapy-sessions');
const rehabilitationAssessmentsRoutes = require('./routes/rehabilitation-assessments');
const rehabilitationTreatmentPlansRoutes = require('./routes/rehabilitation-treatment-plans');
const rehabilitationStaffRoutes = require('./routes/rehabilitation-staff');
const rehabilitationParentCommunicationRoutes = require('./routes/rehabilitation-parent-communication');

app.use('/api/rehabilitation/patients', rehabilitationPatientsRoutes);
app.use('/api/rehabilitation/appointments', rehabilitationAppointmentsRoutes);
app.use('/api/rehabilitation/medical-records', rehabilitationMedicalRecordsRoutes);
app.use('/api/rehabilitation/therapy-sessions', rehabilitationTherapySessionsRoutes);
app.use('/api/rehabilitation/assessments', rehabilitationAssessmentsRoutes);
app.use('/api/rehabilitation/treatment-plans', rehabilitationTreatmentPlansRoutes);
app.use('/api/rehabilitation/staff', rehabilitationStaffRoutes);
app.use('/api/rehabilitation/parent-communication', rehabilitationParentCommunicationRoutes);

// Financial Management Routes
const financialManagementRoutes = require('./routes/financial-management');
app.use('/api/financial', financialManagementRoutes);

// Government Integration Routes
const governmentIntegrationRoutes = require('./routes/government-integration');
app.use('/api/government', governmentIntegrationRoutes);

// Transportation Management Routes
const transportationManagementRoutes = require('./routes/transportation-management');
app.use('/api/transportation', transportationManagementRoutes);

// Inventory & Equipment Management Routes
const inventoryEquipmentManagementRoutes = require('./routes/inventory-equipment-management');
app.use('/api/inventory-equipment', inventoryEquipmentManagementRoutes);

// Additional Systems Routes
const additionalSystemsRoutes = require('./routes/additional-systems');
app.use('/api/additional', additionalSystemsRoutes);

// Additional Systems Routes V2
const additionalSystemsV2Routes = require('./routes/additional-systems-v2');
app.use('/api/systems', additionalSystemsV2Routes);

// Advanced Systems Routes V3
const advancedSystemsV3Routes = require('./routes/advanced-systems-v3');
app.use('/api/advanced', advancedSystemsV3Routes);

// Additional Systems Routes V4
const additionalSystemsV4Routes = require('./routes/additional-systems-v4');
app.use('/api/additional-v4', additionalSystemsV4Routes);

// Additional Systems Routes V5
const additionalSystemsV5Routes = require('./routes/additional-systems-v5');
app.use('/api/additional-v5', additionalSystemsV5Routes);

// Additional Systems Routes V6
const additionalSystemsV6Routes = require('./routes/additional-systems-v6');
app.use('/api/additional-v6', additionalSystemsV6Routes);

// Additional Systems Routes V7
const additionalSystemsV7Routes = require('./routes/additional-systems-v7');
app.use('/api/additional-v7', additionalSystemsV7Routes);

// Attendance Management Routes
const attendanceRoutes = require('./routes/attendance-management');
app.use('/api/attendance', attendanceRoutes);

// Additional Systems Routes V8
const additionalSystemsV8Routes = require('./routes/additional-systems-v8');
app.use('/api/additional-v8', additionalSystemsV8Routes);

// Additional Systems Routes V9
const additionalSystemsV9Routes = require('./routes/additional-systems-v9');
app.use('/api/additional-v9', additionalSystemsV9Routes);

// Additional Systems Routes V10
const additionalSystemsV10Routes = require('./routes/additional-systems-v10');
app.use('/api/additional-v10', additionalSystemsV10Routes);

// Additional Systems Routes V11
const additionalSystemsV11Routes = require('./routes/additional-systems-v11');
app.use('/api/additional-v11', additionalSystemsV11Routes);

// Saudi Specialized Systems Routes
const saudiSpecializedRoutes = require('./routes/saudi-specialized-systems');
app.use('/api/saudi-specialized', saudiSpecializedRoutes);

// Permissions Management Routes
const permissionsRoutes = require('./routes/permissions-management');
app.use('/api/permissions', permissionsRoutes);

// Advanced Permissions Management Routes
const advancedPermissionsRoutes = require('./routes/advanced-permissions-management');
app.use('/api/permissions/advanced', advancedPermissionsRoutes);

// Permissions Enhancements Routes
const permissionsEnhancementsRoutes = require('./routes/permissions-enhancements');
app.use('/api/permissions/enhancements', permissionsEnhancementsRoutes);

// Security Monitoring Routes
const securityMonitoringRoutes = require('./routes/security-monitoring');
app.use('/api/security', securityMonitoringRoutes);

// Permissions Integration Routes
const permissionsIntegrationRoutes = require('./routes/permissions-integration');
app.use('/api/permissions/integration', permissionsIntegrationRoutes);

// Permissions Performance Routes
const permissionsPerformanceRoutes = require('./routes/permissions-performance');
app.use('/api/permissions/performance', permissionsPerformanceRoutes);

// Permissions Analytics Routes
const permissionsAnalyticsRoutes = require('./routes/permissions-analytics');
app.use('/api/permissions/analytics', permissionsAnalyticsRoutes);

// Permissions Error Handling Routes
const permissionsErrorsRoutes = require('./routes/permissions-errors');
app.use('/api/permissions/errors', permissionsErrorsRoutes);

// Smart Archive Routes
const smartArchiveRoutes = require('./routes/smart-archive');
app.use('/api/archive', smartArchiveRoutes);

// Archive Advanced Routes
const archiveAdvancedRoutes = require('./routes/archive-advanced');
app.use('/api/archive/advanced', archiveAdvancedRoutes);

// Student Files Routes
const studentFilesRoutes = require('./routes/student-files');
const studentAttendanceRoutes = require('./routes/student-attendance');
app.use('/api/student-files', studentFilesRoutes);
app.use('/api/student-attendance', studentAttendanceRoutes);

// Emergency Management Routes
const emergencyRoutes = require('./routes/emergency');
app.use('/api/emergency', emergencyRoutes);

// Volunteers Management Routes
const volunteersRoutes = require('./routes/volunteers');
app.use('/api/volunteers', volunteersRoutes);

// Events Management Routes
const eventsRoutes = require('./routes/events');
app.use('/api/events', eventsRoutes);

// Treatment Plans Management Routes
const treatmentPlansRoutes = require('./routes/treatment-plans');
app.use('/api/treatment-plans', treatmentPlansRoutes);

// Programs Management Routes
const programsRoutes = require('./routes/programs');
app.use('/api/programs', programsRoutes);

// Goals Management Routes
const goalsRoutes = require('./routes/goals');
app.use('/api/goals', goalsRoutes);

// Progress Management Routes
const progressRoutes = require('./routes/progress');
app.use('/api/progress', progressRoutes);

// Team Management Routes
const teamRoutes = require('./routes/team');
app.use('/api/team', teamRoutes);

// Medical Security Management Routes
const medicalSecurityRoutes = require('./routes/medical-security');
app.use('/api/medical-security', medicalSecurityRoutes);

// Certifications Management Routes
const certificationsRoutes = require('./routes/certifications');
app.use('/api/certifications', certificationsRoutes);

// Follow-up Management Routes
const followUpRoutes = require('./routes/follow-up');
app.use('/api/follow-up', followUpRoutes);

// Activities Management Routes
const activitiesRoutes = require('./routes/activities');
app.use('/api/activities', activitiesRoutes);

// Group Sessions Management Routes
const groupSessionsRoutes = require('./routes/group-sessions');
app.use('/api/group-sessions', groupSessionsRoutes);

// Continuous Training Management Routes
const continuousTrainingRoutes = require('./routes/continuous-training');
app.use('/api/continuous-training', continuousTrainingRoutes);

// Parent Communication Management Routes
const parentCommunicationRoutes = require('./routes/parent-communication');
app.use('/api/parent-communication', parentCommunicationRoutes);

// Advanced Reports Management Routes
const advancedReportsModule = require('./routes/advanced-reports');
app.use('/api/advanced-reports', advancedReportsModule.router || advancedReportsModule);

// Advanced Security Routes
const advancedSecurityModule = require('./routes/advanced-security');
app.use('/api/advanced-security', advancedSecurityModule.router || advancedSecurityModule);

// Advanced Integration Routes
const advancedIntegrationModule = require('./routes/advanced-integration');
app.use('/api/advanced-integration', advancedIntegrationModule.router || advancedIntegrationModule);

// Advanced Quality Management Routes
const advancedQualityModule = require('./routes/advanced-quality');
app.use('/api/advanced-quality', advancedQualityModule.router || advancedQualityModule);

// Advanced Performance Management Routes
const advancedPerformanceModule = require('./routes/advanced-performance');
app.use('/api/advanced-performance', advancedPerformanceModule.router || advancedPerformanceModule);

// Advanced Projects Management Routes
const advancedProjectsModule = require('./routes/advanced-projects');
app.use('/api/advanced-projects', advancedProjectsModule.router || advancedProjectsModule);

// Advanced Assets Management Routes
const advancedAssetsModule = require('./routes/advanced-assets');
app.use('/api/advanced-assets', advancedAssetsModule.router || advancedAssetsModule);

// Advanced Change Management Routes
const advancedChangeManagementModule = require('./routes/advanced-change-management');
app.use(
  '/api/advanced-change-management',
  advancedChangeManagementModule.router || advancedChangeManagementModule
);

// Advanced Contracts Management Routes
const advancedContractsModule = require('./routes/advanced-contracts');
app.use('/api/advanced-contracts', advancedContractsModule.router || advancedContractsModule);

// Advanced Vendors Management Routes
const advancedVendorsModule = require('./routes/advanced-vendors');
app.use('/api/advanced-vendors', advancedVendorsModule.router || advancedVendorsModule);

// Advanced Inventory Management Routes
const advancedInventoryModule = require('./routes/advanced-inventory');
app.use('/api/advanced-inventory', advancedInventoryModule.router || advancedInventoryModule);

// Advanced Maintenance Management Routes
const advancedMaintenanceManagementModule = require('./routes/advanced-maintenance-management');
app.use(
  '/api/advanced-maintenance',
  advancedMaintenanceManagementModule.router || advancedMaintenanceManagementModule
);

// Advanced Complaints Management Routes
const advancedComplaintsModule = require('./routes/advanced-complaints');
app.use('/api/advanced-complaints', advancedComplaintsModule.router || advancedComplaintsModule);

// Advanced Sales Management Routes
const advancedSalesModule = require('./routes/advanced-sales');
app.use('/api/advanced-sales', advancedSalesModule.router || advancedSalesModule);

// Advanced Marketing Management Routes
const advancedMarketingModule = require('./routes/advanced-marketing');
app.use('/api/advanced-marketing', advancedMarketingModule.router || advancedMarketingModule);

// Advanced Customers Management Routes
const advancedCustomersModule = require('./routes/advanced-customers');
app.use('/api/advanced-customers', advancedCustomersModule.router || advancedCustomersModule);

// Advanced Invoices Management Routes
const advancedInvoicesModule = require('./routes/advanced-invoices');
app.use('/api/advanced-invoices', advancedInvoicesModule.router || advancedInvoicesModule);

// Advanced Payments Management Routes
const advancedPaymentsModule = require('./routes/advanced-payments');
app.use('/api/advanced-payments', advancedPaymentsModule.router || advancedPaymentsModule);

// Advanced HR Management Routes
const advancedHRManagementModule = require('./routes/advanced-hr-management');
app.use(
  '/api/advanced-hr-management',
  advancedHRManagementModule.router || advancedHRManagementModule
);

// Advanced Training Management Routes
const advancedTrainingManagementModule = require('./routes/advanced-training-management');
app.use(
  '/api/advanced-training-management',
  advancedTrainingManagementModule.router || advancedTrainingManagementModule
);

// Advanced Certifications Management Routes
const advancedCertificationsManagementModule = require('./routes/advanced-certifications-management');
app.use(
  '/api/advanced-certifications-management',
  advancedCertificationsManagementModule.router || advancedCertificationsManagementModule
);

// Advanced Communications Management Routes
const advancedCommunicationsManagementModule = require('./routes/advanced-communications-management');
app.use(
  '/api/advanced-communications-management',
  advancedCommunicationsManagementModule.router || advancedCommunicationsManagementModule
);

// Advanced Reports Management Routes
const advancedReportsManagementModule = require('./routes/advanced-reports-management');

app.use(
  '/api/advanced-reports-management',
  advancedReportsManagementModule.router || advancedReportsManagementModule
);
// Advanced WhatsApp Management Routes
const advancedWhatsAppModule = require('./routes/advanced-whatsapp');

app.use('/api/advanced-whatsapp', advancedWhatsAppModule.router || advancedWhatsAppModule);
// Advanced Email Management Routes
const advancedEmailModule = require('./routes/advanced-email');

app.use('/api/advanced-email', advancedEmailModule.router || advancedEmailModule);
// Advanced SMS Management Routes
const advancedSMSModule = require('./routes/advanced-sms');

app.use('/api/advanced-sms', advancedSMSModule.router || advancedSMSModule);
// Comprehensive Assessments Management Routes
const comprehensiveAssessmentsModule = require('./routes/comprehensive-assessments');

app.use(
  '/api/comprehensive-assessments',
  comprehensiveAssessmentsModule.router || comprehensiveAssessmentsModule
);
// Advanced Sessions Management Routes
const advancedSessionsModule = require('./routes/advanced-sessions');

app.use('/api/advanced-sessions', advancedSessionsModule.router || advancedSessionsModule);
// Advanced Rehabilitation Programs Management Routes
const advancedRehabilitationProgramsModule = require('./routes/advanced-rehabilitation-programs');

app.use(
  '/api/advanced-rehabilitation-programs',
  advancedRehabilitationProgramsModule.router || advancedRehabilitationProgramsModule
);
// Advanced Goals & Plans Management Routes
const advancedGoalsPlansModule = require('./routes/advanced-goals-plans');

app.use('/api/advanced-goals-plans', advancedGoalsPlansModule.router || advancedGoalsPlansModule);
// Advanced Appointments Management Routes
const advancedAppointmentsModule = require('./routes/advanced-appointments');

app.use(
  '/api/advanced-appointments',
  advancedAppointmentsModule.router || advancedAppointmentsModule
);
// Advanced Medications & Treatments Management Routes
const advancedMedicationsModule = require('./routes/advanced-medications');

app.use('/api/advanced-medications', advancedMedicationsModule.router || advancedMedicationsModule);
// Advanced Medical Records Management Routes
const advancedMedicalRecordsModule = require('./routes/advanced-medical-records');

app.use(
  '/api/advanced-medical-records',
  advancedMedicalRecordsModule.router || advancedMedicalRecordsModule
);
// Advanced Medical Reports Management Routes
const advancedMedicalReportsModule = require('./routes/advanced-medical-reports');

app.use(
  '/api/advanced-medical-reports',
  advancedMedicalReportsModule.router || advancedMedicalReportsModule
);
// Advanced Follow-up Management Routes
const advancedFollowUpModule = require('./routes/advanced-follow-up');

app.use('/api/advanced-follow-up', advancedFollowUpModule.router || advancedFollowUpModule);
// Advanced Evaluations Management Routes
const advancedEvaluationsModule = require('./routes/advanced-evaluations');

app.use('/api/advanced-evaluations', advancedEvaluationsModule.router || advancedEvaluationsModule);
// Advanced HR Management Routes
const advancedHRModule = require('./routes/advanced-hr');

app.use('/api/advanced-hr', advancedHRModule.router || advancedHRModule);
// Advanced Accounting & Financial Management Routes
const advancedAccountingModule = require('./routes/advanced-accounting');

app.use('/api/advanced-accounting', advancedAccountingModule.router || advancedAccountingModule);
// Advanced E-Learning Management Routes
const advancedELearningModule = require('./routes/advanced-elearning');

app.use('/api/advanced-elearning', advancedELearningModule.router || advancedELearningModule);
// Advanced Maintenance Management Routes
const advancedMaintenanceModule = require('./routes/advanced-maintenance');

app.use('/api/advanced-maintenance', advancedMaintenanceModule.router || advancedMaintenanceModule);
// Advanced Events & Activities Management Routes
const advancedEventsModule = require('./routes/advanced-events');

app.use('/api/advanced-events', advancedEventsModule.router || advancedEventsModule);
// Advanced Complaints & Suggestions Management Routes (already defined above)

// Advanced Quality Management Routes (already defined above)
// Advanced Security & Safety Management Routes (already defined above)

// Advanced Transportation Management Routes
const advancedTransportationModule = require('./routes/advanced-transportation');

app.use(
  '/api/advanced-transportation',
  advancedTransportationModule.router || advancedTransportationModule
);
// Advanced Restaurant & Meals Management Routes
const advancedRestaurantModule = require('./routes/advanced-restaurant');

app.use('/api/advanced-restaurant', advancedRestaurantModule.router || advancedRestaurantModule);
// Advanced Facilities & Services Management Routes
const advancedFacilitiesModule = require('./routes/advanced-facilities');

app.use('/api/advanced-facilities', advancedFacilitiesModule.router || advancedFacilitiesModule);
// Advanced Volunteers Management Routes
const advancedVolunteersModule = require('./routes/advanced-volunteers');

app.use('/api/advanced-volunteers', advancedVolunteersModule.router || advancedVolunteersModule);
// Advanced Partnerships Management Routes
const advancedPartnershipsModule = require('./routes/advanced-partnerships');
app.use('/api/advanced-partnerships', advancedPartnershipsModule.router);

// Advanced Branches Management Routes
const advancedBranchesModule = require('./routes/advanced-branches');
app.use('/api/advanced-branches', advancedBranchesModule.router || advancedBranchesModule);

// Advanced Call Center Management Routes
const advancedCallCenterModule = require('./routes/advanced-call-center');
app.use('/api/advanced-call-center', advancedCallCenterModule.router || advancedCallCenterModule);

// Advanced Research Management Routes
const advancedResearchModule = require('./routes/advanced-research');
app.use('/api/advanced-research', advancedResearchModule.router || advancedResearchModule);

// Advanced Referrals Management Routes
const advancedReferralsModule = require('./routes/advanced-referrals');
app.use('/api/advanced-referrals', advancedReferralsModule.router || advancedReferralsModule);

// Advanced Library Management Routes
const advancedLibraryModule = require('./routes/advanced-library');
app.use('/api/advanced-library', advancedLibraryModule.router || advancedLibraryModule);

// Advanced PR Management Routes
const advancedPRModule = require('./routes/advanced-pr');
app.use('/api/advanced-pr', advancedPRModule.router);

// Advanced Funding Management Routes
const advancedFundingModule = require('./routes/advanced-funding');
app.use('/api/advanced-funding', advancedFundingModule.router);

// Training & Development Management Routes
const trainingDevelopmentRoutes = require('./routes/training-development');
app.use('/api/training-development', trainingDevelopmentRoutes);

// Referrals Management Routes
const referralsRoutes = require('./routes/referrals');
app.use('/api/referrals', referralsRoutes);

// Education Management Routes
const educationRoutes = require('./routes/education');
app.use('/api/education', educationRoutes);

// Life Skills Management Routes
const lifeSkillsRoutes = require('./routes/life-skills');
app.use('/api/life-skills', lifeSkillsRoutes);

// Employment Management Routes
const employmentRoutes = require('./routes/employment');
app.use('/api/employment', employmentRoutes);

// Recreation Management Routes
const recreationRoutes = require('./routes/recreation');
app.use('/api/recreation', recreationRoutes);

// Safety & Security Management Routes
const safetySecurityRoutes = require('./routes/safety-security');
app.use('/api/safety-security', safetySecurityRoutes);

// Complaints & Suggestions Management Routes
const complaintsSuggestionsRoutes = require('./routes/complaints-suggestions');
app.use('/api/complaints-suggestions', complaintsSuggestionsRoutes);

// Maintenance Management Routes
const maintenanceRoutes = require('./routes/maintenance');
app.use('/api/maintenance', maintenanceRoutes);

// Partnerships Management Routes
const partnershipsRoutes = require('./routes/partnerships');
app.use('/api/partnerships', partnershipsRoutes);

// Specialized Assessments Management Routes
const specializedAssessmentsRoutes = require('./routes/specialized-assessments');
app.use('/api/specialized-assessments', specializedAssessmentsRoutes);

// Research Management Routes
const researchRoutes = require('./routes/research');
app.use('/api/research', researchRoutes);

// Public Relations Management Routes
const publicRelationsRoutes = require('./routes/public-relations');
app.use('/api/public-relations', publicRelationsRoutes);

// Mobile App Management Routes
const mobileAppRoutes = require('./routes/mobile-app');
app.use('/api/mobile-app', mobileAppRoutes);

// Accessibility Management Routes
const accessibilityRoutes = require('./routes/accessibility');
app.use('/api/accessibility', accessibilityRoutes);

// Nutrition Management Routes
const nutritionRoutes = require('./routes/nutrition');
app.use('/api/nutrition', nutritionRoutes);

// Evaluations Management Routes
const evaluationsRoutes = require('./routes/evaluations');
app.use('/api/evaluations', evaluationsRoutes);

// Billing & Invoicing Management Routes
const billingModule = require('./routes/billing');
app.use('/api/billing', billingModule.router);

// Advanced Scheduling Management Routes
const schedulingModule = require('./routes/scheduling');
app.use('/api/scheduling', schedulingModule.router);

// Asset Management Routes
const assetManagementModule = require('./routes/asset-management');
app.use('/api/assets', assetManagementModule.router);

// Project Management Routes
const projectManagementModule = require('./routes/project-management');
app.use('/api/projects', projectManagementModule.router);

// Knowledge Management Routes
const knowledgeManagementModule = require('./routes/knowledge-management');
app.use('/api/knowledge', knowledgeManagementModule.router);

// Library Management Routes
const libraryManagementModule = require('./routes/library-management');
app.use('/api/library', libraryManagementModule.router);

// Advanced Certifications Routes
const certificationsAdvancedModule = require('./routes/certifications-advanced');
app.use('/api/certifications-advanced', certificationsAdvancedModule.router);

// Advanced Complaints Routes
const complaintsAdvancedModule = require('./routes/complaints-advanced');
app.use('/api/complaints-advanced', complaintsAdvancedModule.router);

// Advanced Analytics Routes
const analyticsAdvancedModule = require('./routes/analytics-advanced');
app.use('/api/analytics-advanced', analyticsAdvancedModule.router);

// Workflow Management Routes
const workflowManagementModule = require('./routes/workflow-management');
app.use('/api/workflow', workflowManagementModule.router);

// Integration Management Routes
const integrationManagementModule = require('./routes/integration-management');
app.use('/api/integration', integrationManagementModule.router);

// Backup Management Routes
const backupManagementModule = require('./routes/backup-management');
app.use('/api/backup', backupManagementModule.router);

// Configuration Management Routes
const configurationManagementModule = require('./routes/configuration-management');
app.use('/api/configuration', configurationManagementModule.router);

// Audit & Logging Routes
const auditLoggingModule = require('./routes/audit-logging');
app.use('/api/audit', auditLoggingModule.router);

// Performance Monitoring Routes
// Performance Monitoring Routes (already defined above)

// Security Management Routes
const securityManagementModule = require('./routes/security-management');
app.use('/api/security', securityManagementModule.router);

// Template Management Routes
const templateManagementModule = require('./routes/template-management');
app.use('/api/template', templateManagementModule.router);

// Custom Reports Routes
const customReportsModule = require('./routes/custom-reports');
app.use('/api/custom-reports', customReportsModule.router);

// Advanced Permissions Routes
const permissionsAdvancedModule = require('./routes/permissions-advanced');
app.use('/api/permissions', permissionsAdvancedModule.router);

// Big Data Management Routes
const dataManagementModule = require('./routes/data-management');
app.use('/api/data-management', dataManagementModule.router);

// Advanced Notifications Routes
const notificationAdvancedModule = require('./routes/notification-advanced');
app.use('/api/notification-advanced', notificationAdvancedModule.router);

// Social Media Management Routes
const socialMediaModule = require('./routes/social-media');
app.use('/api/social-media', socialMediaModule.router);

// Psychological Assessments Routes
const psychologicalAssessmentsModule = require('./routes/psychological-assessments');
app.use('/api/psychological-assessments', psychologicalAssessmentsModule.router);

// Physical Therapy Routes
const physicalTherapyModule = require('./routes/physical-therapy');
app.use('/api/physical-therapy', physicalTherapyModule.router);

// Occupational Therapy Routes
const occupationalTherapyModule = require('./routes/occupational-therapy');
app.use('/api/occupational-therapy', occupationalTherapyModule.router);

// Speech & Language Therapy Routes
const speechLanguageTherapyModule = require('./routes/speech-language-therapy');
app.use('/api/speech-language-therapy', speechLanguageTherapyModule.router);

// Behavioral Therapy Routes
const behavioralTherapyModule = require('./routes/behavioral-therapy');
app.use('/api/behavioral-therapy', behavioralTherapyModule.router);

// Aquatic Therapy Routes
const aquaticTherapyModule = require('./routes/aquatic-therapy');
app.use('/api/aquatic-therapy', aquaticTherapyModule.router);

// Music Therapy Routes
const musicTherapyModule = require('./routes/music-therapy');
app.use('/api/music-therapy', musicTherapyModule.router);

// Art Therapy Routes
const artTherapyModule = require('./routes/art-therapy');
app.use('/api/art-therapy', artTherapyModule.router);

// Animal-Assisted Therapy Routes
const animalAssistedTherapyModule = require('./routes/animal-assisted-therapy');
app.use('/api/animal-assisted-therapy', animalAssistedTherapyModule.router);

// Sports Therapy Routes
const sportsTherapyModule = require('./routes/sports-therapy');
app.use('/api/sports-therapy', sportsTherapyModule.router);

// VR Therapy Routes
const vrTherapyModule = require('./routes/vr-therapy');
app.use('/api/vr-therapy', vrTherapyModule.router);

// Robotic Therapy Routes
const roboticTherapyModule = require('./routes/robotic-therapy');
app.use('/api/robotic-therapy', roboticTherapyModule.router);

// Electrotherapy Routes
const electrotherapyModule = require('./routes/electrotherapy');
app.use('/api/electrotherapy', electrotherapyModule.router);

// Thermotherapy Routes
const thermotherapyModule = require('./routes/thermotherapy');
app.use('/api/thermotherapy', thermotherapyModule.router);

// Laser Therapy Routes
const laserTherapyModule = require('./routes/laser-therapy');
app.use('/api/laser-therapy', laserTherapyModule.router);

// Massage Therapy Routes
const massageTherapyModule = require('./routes/massage-therapy');
app.use('/api/massage-therapy', massageTherapyModule.router);

// Acupuncture Therapy Routes
const acupunctureTherapyModule = require('./routes/acupuncture-therapy');
app.use('/api/acupuncture-therapy', acupunctureTherapyModule.router);

// Unified Dashboard Routes
const unifiedDashboardModule = require('./routes/unified-dashboard');
app.use('/api/dashboard', unifiedDashboardModule.router);

// Unified Search Routes
const unifiedSearchModule = require('./routes/unified-search');
app.use('/api/search', unifiedSearchModule.router);

// Unified Reports Routes
const unifiedReportsModule = require('./routes/unified-reports');
app.use('/api/reports', unifiedReportsModule.router);

// Smart Notifications Routes
const smartNotificationsModule = require('./routes/smart-notifications');
app.use('/api/notifications', smartNotificationsModule.router);

// Performance Monitoring Routes (Enhanced)
// Performance Monitoring Routes (already defined above)

// System Health Routes
const systemHealthModule = require('./routes/system-health');
app.use('/api/system-health', systemHealthModule.router);

// Backup & Restore Routes
const backupRestoreModule = require('./routes/backup-restore');
app.use('/api/backup', backupRestoreModule.router);

// Accounting Routes
const accountingModule = require('./routes/accounting');
app.use('/api/accounting', accountingModule.router);

// Risk Management Routes
const riskManagementModule = require('./routes/risk-management');
app.use('/api/risk-management', riskManagementModule.router);

// Compliance Management Routes
const complianceManagementModule = require('./routes/compliance-management');
app.use('/api/compliance', complianceManagementModule.router);

// Comprehensive Student File Routes
const comprehensiveStudentFileModule = require('./routes/comprehensive-student-file');
app.use('/api/student-file', comprehensiveStudentFileModule.router);

// Smart Automation Routes
const smartAutomationModule = require('./routes/smart-automation');
app.use('/api/automation', smartAutomationModule.router);

// Knowledge Management Routes (already defined above)

// Yoga Therapy Routes
const yogaTherapyModule = require('./routes/yoga-therapy');
app.use('/api/yoga-therapy', yogaTherapyModule.router);

// Breathing Therapy Routes
const breathingTherapyModule = require('./routes/breathing-therapy');
app.use('/api/breathing-therapy', breathingTherapyModule.router);
// const User = require('./models/User'); // Unused
// تدقيق مركزي غير قابل للتغيير عبر Azure Confidential Ledger
let auditAllRequests = () => (req, res, next) => next();
try {
  if (process.env.NODE_ENV !== 'test') {
    ({ auditAllRequests } = require('../../services/auditMiddleware.js'));
  }
} catch {
  // Intentionally empty - audit middleware not available
}
// ...existing code...
// نموذج لتخزين إجابات التقييم
const mongooseAssessmentSchema = new mongoose.Schema({
  metricKey: String,
  username: String,
  answers: Object,
  createdAt: { type: Date, default: Date.now },
});
const AssessmentResponse = mongoose.model('AssessmentResponse', mongooseAssessmentSchema);

// نقطة نهاية لحفظ إجابات التقييم
app.post('/api/assessments/save', async (req, res) => {
  try {
    const { metricKey, username, answers } = req.body;
    if (!metricKey || !username || !answers) {
      return res.status(400).json({ error: 'جميع الحقول مطلوبة' });
    }
    const saved = await AssessmentResponse.create({ metricKey, username, answers });
    // يمكن إضافة تحليل ذكي هنا لاحقاً
    res.status(201).json({ message: 'تم حفظ الإجابات بنجاح', id: saved._id });
  } catch (err) {
    res.status(500).json({ error: 'خطأ في حفظ الإجابات', details: err.message });
  }
});

// نقطة نهاية لاستعراض جميع الإجابات أو حسب اسم المستخدم
app.get('/api/assessments/responses', async (req, res) => {
  try {
    const { username, metricKey } = req.query;
    const query = {};
    if (username) query.username = username;
    if (metricKey) query.metricKey = metricKey;
    const responses = await AssessmentResponse.find(query).sort({ createdAt: -1 });
    res.json(responses);
  } catch (err) {
    res.status(500).json({ error: 'خطأ في جلب الإجابات', details: err.message });
  }
});
// اتصال بقاعدة بيانات MongoDB
if (process.env.NODE_ENV !== 'test') {
  mongoose
    .connect(process.env.MONGO_URI || 'mongodb://localhost:27017/parents_portal', {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    })
    .then(() => console.log('MongoDB Connected'))
    .catch(err =>
      console.warn('MongoDB Connection Failed (Non-critical if using PostgreSQL):', err.message)
    );
}
// تفعيل التدقيق المركزي لجميع الطلبات
// Disable heavy auditing in test to avoid side effects
if (process.env.NODE_ENV !== 'test') {
  app.use(auditAllRequests);
}
// ...existing code...
// مسارات الرسائل
app.use('/api', messagesRoutes);
/**
 * @swagger
 * /payments/external-sync:
/**
 * @swagger
/**
 * @swagger
 * /users:
 *   post:
 *     summary: إضافة مستخدم جديد
 *     tags: [Users]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/User'
 *     responses:
 *       201:
 *         description: تم إنشاء المستخدم
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/User'
// ...existing code...
app.post('/users', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const user = await User.create(req.body);
      logEvent('CREATE_USER', req.user, req.body);
      res.status(201).json(user);
    } catch (err) {
      res.status(400).json({ error: 'خطأ في إضافة المستخدم', details: err.message });
    }
  });
});
}
// ...existing code...

/**
 * @swagger
 * /users/{id}:
 *   put:
 *     summary: تحديث بيانات مستخدم
 *     tags: [Users]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/User'
 *     responses:
 *       200:
 *         description: تم تحديث المستخدم
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/User'
// ...existing code...
app.put('/users/:id', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const [updated] = await User.update(req.body, { where: { id: req.params.id } });
      if (updated) {
        const user = await User.findByPk(req.params.id);
        logEvent('UPDATE_USER', req.user, req.body);
        res.json(user);
      } else {
        res.status(404).json({ error: 'غير موجود' });
      }
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });
});
// ...existing code...

/**
 * @swagger
 * /aimodel/{id}:
 *   put:
 *     summary: تحديث بيانات نموذج الذكاء الاصطناعي
 *     tags: [AIModel]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/AIModel'
 *     responses:
 *       200:
 *         description: تم تحديث النموذج
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/AIModel'
 *       */
// تحديث بيانات نموذج الذكاء الاصطناعي
app.put('/aimodel/:id', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const [updated] = await AIModel.update(req.body, { where: { id: req.params.id } });
      if (updated) {
        const model = await AIModel.findByPk(req.params.id);
        logEvent('UPDATE_AIMODEL', req.user, req.body);
        res.json(model);
      } else {
        res.status(404).json({ error: 'غير موجود' });
      }
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });
});

// تحديث بيانات عنصر التكامل الحكومي
app.put('/govintegration/:id', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const [updated] = await GovIntegration.update(req.body, { where: { id: req.params.id } });
      if (updated) {
        const item = await GovIntegration.findByPk(req.params.id);
        logEvent('UPDATE_GOVINTEGRATION', req.user, req.body);
        res.json(item);
      } else {
        res.status(404).json({ error: 'غير موجود' });
      }
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });
});

// تحديث بيانات مطالبة التأمين
app.put('/insuranceclaim/:id', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const [updated] = await InsuranceClaim.update(req.body, { where: { id: req.params.id } });
      if (updated) {
        const claim = await InsuranceClaim.findByPk(req.params.id);
        logEvent('UPDATE_INSURANCECLAIM', req.user, req.body);
        res.json(claim);
      } else {
        res.status(404).json({ error: 'غير موجود' });
      }
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });
});
// ...existing code...
app.get('/patients', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const patients = await Patient.findAll();
      logEvent('GET_PATIENTS', req.user, {});
      res.json(patients);
    } catch (err) {
      res.status(500).json({ error: 'خطأ في جلب المرضى', details: err.message });
    }
  });
});
// تحديث بيانات مريض
/**
 * @swagger
 * /patients/{id}:
 *   put:
 *     summary: تحديث بيانات مريض
 *     tags: [Patients]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Patient'
 *     responses:
 *       200:
 *         description: تم تحديث المريض
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Patient'
 */
app.put('/patients/:id', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const [updated] = await Patient.update(req.body, { where: { id: req.params.id } });
      if (updated) {
        const patient = await Patient.findByPk(req.params.id);
        logEvent('UPDATE_PATIENT', req.user, req.body);
        res.json(patient);
      } else {
        res.status(404).json({ error: 'المريض غير موجود' });
      }
    } catch (err) {
      res.status(400).json({ error: 'خطأ في تحديث المريض', details: err.message });
    }
  });
});

// حذف مريض
/**
 * @swagger
 * /patients/{id}:
 *   delete:
 *     summary: حذف مريض
 *     tags: [Patients]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: تم حذف المريض بنجاح
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 */
app.delete('/patients/:id', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const deleted = await Patient.destroy({ where: { id: req.params.id } });
      if (deleted) {
        logEvent('DELETE_PATIENT', req.user, { id: req.params.id });
        res.json({ message: 'تم حذف المريض بنجاح' });
      } else {
        res.status(404).json({ error: 'المريض غير موجود' });
      }
    } catch (err) {
      res.status(400).json({ error: 'خطأ في حذف المريض', details: err.message });
    }
  });
});
// نقاط نهاية إضافية لكل جدول ...

// ...existing code...

// جلب جميع الأجهزة الطبية
app.get('/devices', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const devices = await Device.findAll();
      logEvent('GET_DEVICES', req.user, {});
      res.json(devices);
    } catch (err) {
      res.status(500).json({ error: 'خطأ في جلب الأجهزة الطبية', details: err.message });
    }
  });
});
// إضافة جهاز طبي جديد
app.post('/devices', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const device = await Device.create(req.body);
      logEvent('CREATE_DEVICE', req.user, req.body);
      res.status(201).json(device);
    } catch (err) {
      res.status(400).json({ error: 'خطأ في إضافة الجهاز الطبي', details: err.message });
    }
  });
});
// تحديث بيانات جهاز طبي
app.put('/devices/:id', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const [updated] = await Device.update(req.body, { where: { id: req.params.id } });
      if (updated) {
        const device = await Device.findByPk(req.params.id);
        logEvent('UPDATE_DEVICE', req.user, req.body);
        res.json(device);
      } else {
        res.status(404).json({ error: 'الجهاز الطبي غير موجود' });
      }
    } catch (err) {
      res.status(400).json({ error: 'خطأ في تحديث الجهاز الطبي', details: err.message });
    }
  });
});

// حذف جهاز طبي
app.delete('/devices/:id', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const deleted = await Device.destroy({ where: { id: req.params.id } });
      if (deleted) {
        logEvent('DELETE_DEVICE', req.user, { id: req.params.id });
        res.json({ message: 'تم حذف الجهاز الطبي بنجاح' });
      } else {
        res.status(404).json({ error: 'الجهاز الطبي غير موجود' });
      }
    } catch (err) {
      res.status(400).json({ error: 'خطأ في حذف الجهاز الطبي', details: err.message });
    }
  });
});

// ...existing code...

// جلب جميع الجلسات
app.get('/sessions', async (req, res) => {
  try {
    const sessions = await Session.findAll();
    logEvent('GET_SESSIONS', req.user, {});
    res.json(sessions);
  } catch (err) {
    res.status(500).json({ error: 'خطأ في جلب الجلسات', details: err.message });
  }
});

// إضافة جلسة جديدة
app.post('/sessions', async (req, res) => {
  try {
    const session = await Session.create(req.body);
    logEvent('CREATE_SESSION', req.user, req.body);
    res.status(201).json(session);
  } catch (err) {
    res.status(400).json({ error: 'خطأ في إضافة الجلسة', details: err.message });
  }
});

// تحديث بيانات جلسة
app.put('/sessions/:id', async (req, res) => {
  try {
    const [updated] = await Session.update(req.body, { where: { id: req.params.id } });
    logEvent('UPDATE_SESSION', req.user, req.body);
    if (updated) {
      const session = await Session.findByPk(req.params.id);
      res.json(session);
    } else {
      res.status(404).json({ error: 'الجلسة غير موجودة' });
    }
  } catch (err) {
    res.status(400).json({ error: 'خطأ في تحديث الجلسة', details: err.message });
  }
});

// حذف جلسة
app.delete('/sessions/:id', async (req, res) => {
  try {
    const deleted = await Session.destroy({ where: { id: req.params.id } });
    logEvent('DELETE_SESSION', req.user, { id: req.params.id });
    if (deleted) {
      res.json({ message: 'تم حذف الجلسة بنجاح' });
    } else {
      res.status(404).json({ error: 'الجلسة غير موجودة' });
    }
  } catch (err) {
    res.status(400).json({ error: 'خطأ في حذف الجلسة', details: err.message });
  }
});

// جلب جميع الموظفين
app.get('/staff', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const staff = await Staff.findAll();
      logEvent('GET_STAFF', req.user, {});
      res.json(staff);
    } catch (err) {
      res.status(500).json({ error: 'خطأ في جلب الموظفين', details: err.message });
    }
  });
});

// إضافة موظف جديد
app.post('/staff', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const staff = await Staff.create(req.body);
      res.status(201).json(staff);
    } catch (err) {
      res.status(400).json({ error: 'خطأ في إضافة الموظف', details: err.message });
    }
  });
});

// تحديث بيانات موظف
app.put('/staff/:id', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const [updated] = await Staff.update(req.body, { where: { id: req.params.id } });
      if (updated) {
        const staff = await Staff.findByPk(req.params.id);
        res.json(staff);
      } else {
        res.status(404).json({ error: 'الموظف غير موجود' });
      }
    } catch (err) {
      res.status(400).json({ error: 'خطأ في تحديث الموظف', details: err.message });
    }
  });
});

// حذف موظف
app.delete('/staff/:id', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const deleted = await Staff.destroy({ where: { id: req.params.id } });
      if (deleted) {
        res.json({ message: 'تم حذف الموظف بنجاح' });
      } else {
        res.status(404).json({ error: 'الموظف غير موجود' });
      }
    } catch (err) {
      res.status(400).json({ error: 'خطأ في حذف الموظف', details: err.message });
    }
  });
});

// نقطة نهاية ذكية لتحليل البيانات
// --- نقاط CRUD للجداول الذكية المتبقية ---
app.get('/inventory', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const items = await Inventory.findAll();
      logEvent('GET_INVENTORY', req.user, {});
      res.json(items);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });
});
app.post('/inventory', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const item = await Inventory.create(req.body);
      logEvent('CREATE_INVENTORY', req.user, req.body);
      res.status(201).json(item);
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });
});
app.put('/inventory/:id', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const [updated] = await Inventory.update(req.body, { where: { id: req.params.id } });
      if (updated) {
        const item = await Inventory.findByPk(req.params.id);
        logEvent('UPDATE_INVENTORY', req.user, req.body);
        res.json(item);
      } else {
        res.status(404).json({ error: 'غير موجود' });
      }
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });
});
app.delete('/inventory/:id', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const deleted = await Inventory.destroy({ where: { id: req.params.id } });
      if (deleted) {
        logEvent('DELETE_INVENTORY', req.user, { id: req.params.id });
        res.json({ message: 'تم الحذف' });
      } else {
        res.status(404).json({ error: 'غير موجود' });
      }
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });
});

/**
 * @swagger
 * /payments:
 *   get:
 *     summary: جلب جميع عمليات الدفع
 *     tags: [Payments]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: قائمة عمليات الدفع
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Payment'
 */
app.get('/payments', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const payments = await Payment.findAll();
      logEvent('GET_PAYMENTS', req.user, {});
      res.json(payments);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });
});
/**
 * @swagger
 * /payments:
 *   post:
 *     summary: إضافة عملية دفع جديدة
 *     tags: [Payments]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Payment'
 *     responses:
 *       201:
 *         description: تم إنشاء عملية الدفع
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Payment'
 */
app.post('/payments', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const payment = await Payment.create(req.body);
      logEvent('CREATE_PAYMENT', req.user, req.body);
      res.status(201).json(payment);
    } catch (err) {
      res.status(400).json({ error: 'خطأ في إضافة الدفع', details: err.message });
    }
  });
});
/**
 * @swagger
 * /payments/{id}:
 *   put:
 *     summary: تحديث بيانات عملية دفع
 *     tags: [Payments]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Payment'
 *     responses:
 *       200:
 *         description: تم تحديث عملية الدفع
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Payment'
 */
app.put('/payments/:id', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const [updated] = await Payment.update(req.body, { where: { id: req.params.id } });
      if (updated) {
        const payment = await Payment.findByPk(req.params.id);
        logEvent('UPDATE_PAYMENT', req.user, req.body);
        res.json(payment);
      } else {
        res.status(404).json({ error: 'الدفع غير موجود' });
      }
    } catch (err) {
      res.status(400).json({ error: 'خطأ في تحديث الدفع', details: err.message });
    }
  });
});
/**
 * @swagger
 * /payments/{id}:
 *   delete:
 *     summary: حذف عملية دفع
 *     tags: [Payments]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: تم حذف عملية الدفع بنجاح
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 */
app.delete('/payments/:id', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const deleted = await Payment.destroy({ where: { id: req.params.id } });
      if (deleted) {
        logEvent('DELETE_PAYMENT', req.user, { id: req.params.id });
        res.json({ message: 'تم حذف الدفع بنجاح' });
      } else {
        res.status(404).json({ error: 'الدفع غير موجود' });
      }
    } catch (err) {
      res.status(400).json({ error: 'خطأ في حذف الدفع', details: err.message });
    }
  });
});

/**
 * @swagger
 * /documents:
 *   get:
 *     summary: جلب جميع الوثائق
 *     tags: [Documents]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: قائمة الوثائق
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Document'
 */
app.get('/documents', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const docs = await Document.findAll();
      logEvent('GET_DOCUMENTS', req.user, {});
      res.json(docs);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });
});
/**
 * @swagger
 * /documents:
 *   post:
 *     summary: إضافة وثيقة جديدة
 *     tags: [Documents]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Document'
 *     responses:
 *       201:
 *         description: تم إنشاء الوثيقة
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Document'
 */
app.post('/documents', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const doc = await Document.create(req.body);
      logEvent('CREATE_DOCUMENT', req.user, req.body);
      res.status(201).json(doc);
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });
});
/**
 * @swagger
 * /documents/{id}:
 *   put:
 *     summary: تحديث بيانات وثيقة
 *     tags: [Documents]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Document'
 *     responses:
 *       200:
 *         description: تم تحديث الوثيقة
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Document'
 */
app.put('/documents/:id', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const [updated] = await Document.update(req.body, { where: { id: req.params.id } });
      if (updated) {
        const doc = await Document.findByPk(req.params.id);
        logEvent('UPDATE_DOCUMENT', req.user, req.body);
        res.json(doc);
      } else {
        res.status(404).json({ error: 'غير موجود' });
      }
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });
});
/**
 * @swagger
 * /documents/{id}:
 *   delete:
 *     summary: حذف وثيقة
 *     tags: [Documents]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: تم حذف الوثيقة بنجاح
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 */
app.delete('/documents/:id', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const deleted = await Document.destroy({ where: { id: req.params.id } });
      if (deleted) {
        logEvent('DELETE_DOCUMENT', req.user, { id: req.params.id });
        res.json({ message: 'تم الحذف' });
      } else {
        res.status(404).json({ error: 'غير موجود' });
      }
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });
});

/**
 * @swagger
 * /quality_surveys:
 *   get:
 *     summary: جلب جميع استطلاعات الجودة
 *     tags: [QualitySurveys]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: قائمة استطلاعات الجودة
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/QualitySurvey'
 */
app.get('/quality_surveys', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const surveys = await QualitySurvey.findAll();
      logEvent('GET_QUALITY_SURVEYS', req.user, {});
      res.json(surveys);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });
});
/**
 * @swagger
 * /quality_surveys:
 *   post:
 *     summary: إضافة استطلاع جودة جديد
 *     tags: [QualitySurveys]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/QualitySurvey'
 *     responses:
 *       201:
 *         description: تم إنشاء استطلاع الجودة
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/QualitySurvey'
 */
app.post('/quality_surveys', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const survey = await QualitySurvey.create(req.body);
      logEvent('CREATE_QUALITY_SURVEY', req.user, req.body);
      res.status(201).json(survey);
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });
});
/**
 * @swagger
 * /quality_surveys/{id}:
 *   put:
 *     summary: تحديث بيانات استطلاع جودة
 *     tags: [QualitySurveys]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/QualitySurvey'
 *     responses:
 *       200:
 *         description: تم تحديث استطلاع الجودة
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/QualitySurvey'
 */
app.put('/quality_surveys/:id', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const [updated] = await QualitySurvey.update(req.body, { where: { id: req.params.id } });
      if (updated) {
        const survey = await QualitySurvey.findByPk(req.params.id);
        logEvent('UPDATE_QUALITY_SURVEY', req.user, req.body);
        res.json(survey);
      } else {
        res.status(404).json({ error: 'غير موجود' });
      }
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });
});
/**
 * @swagger
 * /quality_surveys/{id}:
 *   delete:
 *     summary: حذف استطلاع جودة
 *     tags: [QualitySurveys]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: تم حذف استطلاع الجودة بنجاح
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 */
app.delete('/quality_surveys/:id', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const deleted = await QualitySurvey.destroy({ where: { id: req.params.id } });
      if (deleted) {
        logEvent('DELETE_QUALITY_SURVEY', req.user, { id: req.params.id });
        res.json({ message: 'تم الحذف' });
      } else {
        res.status(404).json({ error: 'غير موجود' });
      }
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });
});

/**
 * @swagger
 * /notifications:
 *   get:
 *     summary: جلب جميع الإشعارات
 *     tags: [Notifications]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: قائمة الإشعارات
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Notification'
 */
app.get('/notifications', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const notes = await Notification.findAll();
      logEvent('GET_NOTIFICATIONS', req.user, {});
      res.json(notes);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });
});
/**
 * @swagger
 * /notifications:
 *   post:
 *     summary: إضافة إشعار جديد
 *     tags: [Notifications]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Notification'
 *     responses:
 *       201:
 *         description: تم إنشاء الإشعار
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Notification'
 */
app.post('/notifications', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const note = await Notification.create(req.body);
      logEvent('CREATE_NOTIFICATION', req.user, req.body);
      res.status(201).json(note);
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });
});
/**
 * @swagger
 * /notifications/{id}:
 *   put:
 *     summary: تحديث بيانات إشعار
 *     tags: [Notifications]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Notification'
 *     responses:
 *       200:
 *         description: تم تحديث الإشعار
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Notification'
 */
app.put('/notifications/:id', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const [updated] = await Notification.update(req.body, { where: { id: req.params.id } });
      if (updated) {
        const note = await Notification.findByPk(req.params.id);
        logEvent('UPDATE_NOTIFICATION', req.user, req.body);
        res.json(note);
      } else {
        res.status(404).json({ error: 'غير موجود' });
      }
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });
});
/**
 * @swagger
 * /notifications/{id}:
 *   delete:
 *     summary: حذف إشعار
 *     tags: [Notifications]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: تم حذف الإشعار بنجاح
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 */
app.delete('/notifications/:id', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const deleted = await Notification.destroy({ where: { id: req.params.id } });
      if (deleted) {
        logEvent('DELETE_NOTIFICATION', req.user, { id: req.params.id });
        res.json({ message: 'تم الحذف' });
      } else {
        res.status(404).json({ error: 'غير موجود' });
      }
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });
});

/**
 * @swagger
 * /crm:
 *   get:
 *     summary: جلب جميع عناصر إدارة علاقات العملاء
 *     tags: [CRM]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: قائمة عناصر CRM
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/CRM'
 */
app.get('/crm', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const crm = await CRM.findAll();
      logEvent('GET_CRM', req.user, {});
      res.json(crm);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });
});
/**
 * @swagger
 * /crm:
 *   post:
 *     summary: إضافة عنصر CRM جديد
 *     tags: [CRM]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CRM'
 *     responses:
 *       201:
 *         description: تم إنشاء عنصر CRM
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CRM'
 */
app.post('/crm', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const crmItem = await CRM.create(req.body);
      logEvent('CREATE_CRM', req.user, req.body);
      res.status(201).json(crmItem);
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });
});
/**
 * @swagger
 * /crm/{id}:
 *   put:
 *     summary: تحديث بيانات عنصر CRM
 *     tags: [CRM]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CRM'
 *     responses:
 *       200:
 *         description: تم تحديث عنصر CRM
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CRM'
 */
app.put('/crm/:id', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const [updated] = await CRM.update(req.body, { where: { id: req.params.id } });
      if (updated) {
        const crmItem = await CRM.findByPk(req.params.id);
        logEvent('UPDATE_CRM', req.user, req.body);
        res.json(crmItem);
      } else {
        res.status(404).json({ error: 'غير موجود' });
      }
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });
});
/**
 * @swagger
 * /crm/{id}:
 *   delete:
 *     summary: حذف عنصر CRM
 *     tags: [CRM]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: تم حذف عنصر CRM بنجاح
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 */
app.delete('/crm/:id', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const deleted = await CRM.destroy({ where: { id: req.params.id } });
      if (deleted) {
        logEvent('DELETE_CRM', req.user, { id: req.params.id });
        res.json({ message: 'تم الحذف' });
      } else {
        res.status(404).json({ error: 'غير موجود' });
      }
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });
});

// --- Branches CRUD Endpoints ---
// Get all branches
app.get('/api/branches', async (req, res) => {
  try {
    const branches = await Branch.findAll();
    res.json(branches);
  } catch (err) {
    console.error('Branches GET error:', err);
    res.status(500).json({ error: 'خطأ في جلب الفروع', details: err.stack });
  }
});

// Add a new branch (with real-time notification)
app.post('/api/branches', async (req, res) => {
  try {
    const branch = await Branch.create(req.body);
    // Emit real-time notification if Socket.io is available
    if (req.app.get('io')) {
      req.app.get('io').emit('notification', {
        type: 'branch_created',
        message: `تمت إضافة فرع جديد: ${branch.name}`,
        branch,
      });
    }
    res.status(201).json(branch);
  } catch (err) {
    console.error('Branches POST error:', err);
    res.status(400).json({ error: 'خطأ في إضافة الفرع', details: err.stack });
  }
});

// Update a branch
app.put('/api/branches/:id', async (req, res) => {
  try {
    const [updated] = await Branch.update(req.body, { where: { id: req.params.id } });
    if (updated) {
      const branch = await Branch.findByPk(req.params.id);
      // Emit real-time notification if Socket.io is available
      if (req.app.get('io')) {
        req.app.get('io').emit('notification', {
          type: 'branch_updated',
          message: `تم تعديل بيانات الفرع: ${branch.name}`,
          branch,
        });
      }
      res.json(branch);
    } else {
      res.status(404).json({ error: 'الفرع غير موجود' });
    }
  } catch (err) {
    console.error('Branches PUT error:', err);
    res.status(400).json({ error: 'خطأ في تحديث الفرع', details: err.stack });
  }
});

// Delete a branch
app.delete('/api/branches/:id', async (req, res) => {
  try {
    const branch = await Branch.findByPk(req.params.id);
    const deleted = await Branch.destroy({ where: { id: req.params.id } });
    if (deleted) {
      // Emit real-time notification if Socket.io is available
      if (req.app.get('io') && branch) {
        req.app.get('io').emit('notification', {
          type: 'branch_deleted',
          message: `تم حذف الفرع: ${branch.name}`,
          branch,
        });
      }
      res.json({ message: 'تم حذف الفرع بنجاح' });
    } else {
      res.status(404).json({ error: 'الفرع غير موجود' });
    }
  } catch (err) {
    console.error('Branches DELETE error:', err);
    res.status(400).json({ error: 'خطأ في حذف الفرع', details: err.stack });
  }
});
// ...existing code...
// ...existing code...
// ...existing code...
// ...existing code...
// ...existing code...
// ...existing code...
app.delete('/ai_models/:id', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const deleted = await AIModel.destroy({ where: { id: req.params.id } });
      if (deleted) {
        logEvent('DELETE_AI_MODEL', req.user, { id: req.params.id });
        res.json({ message: 'تم الحذف' });
      } else {
        res.status(404).json({ error: 'غير موجود' });
      }
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });
});

// ...existing code...
app.get('/gov_integration', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const items = await GovIntegration.findAll();
      logEvent('GET_GOV_INTEGRATION', req.user, {});
      res.json(items);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });
});
// ...existing code...
app.post('/gov_integration', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const item = await GovIntegration.create(req.body);
      logEvent('CREATE_GOV_INTEGRATION', req.user, req.body);
      res.status(201).json(item);
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });
});
// ...existing code...
app.put('/gov_integration/:id', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const [updated] = await GovIntegration.update(req.body, { where: { id: req.params.id } });
      if (updated) {
        const item = await GovIntegration.findByPk(req.params.id);
        logEvent('UPDATE_GOV_INTEGRATION', req.user, req.body);
        res.json(item);
      } else {
        res.status(404).json({ error: 'غير موجود' });
      }
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });
});
// ...existing code...
app.delete('/gov_integration/:id', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const deleted = await GovIntegration.destroy({ where: { id: req.params.id } });
      if (deleted) {
        logEvent('DELETE_GOV_INTEGRATION', req.user, { id: req.params.id });
        res.json({ message: 'تم الحذف' });
      } else {
        res.status(404).json({ error: 'غير موجود' });
      }
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });
});

// ...existing code...
app.get('/insurance_claims', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const claims = await InsuranceClaim.findAll();
      logEvent('GET_INSURANCE_CLAIMS', req.user, {});
      res.json(claims);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });
});
// ...existing code...
// ...existing code...
// ...existing code...

app.delete('/insurance_claims/:id', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const deleted = await InsuranceClaim.destroy({ where: { id: req.params.id } });
      if (deleted) {
        logEvent('DELETE_INSURANCE_CLAIM', req.user, { id: req.params.id });
        res.json({ message: 'تم الحذف' });
      } else {
        res.status(404).json({ error: 'غير موجود' });
      }
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });
});

// ...existing code...

app.delete('/support_tickets/:id', async (req, res) => {
  authenticateToken(req, res, async () => {
    try {
      const deleted = await SupportTicket.destroy({ where: { id: req.params.id } });
      if (deleted) {
        logEvent('DELETE_SUPPORT_TICKET', req.user, { id: req.params.id });
        res.json({ message: 'تم الحذف' });
      } else {
        res.status(404).json({ error: 'غير موجود' });
      }
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });
});

app.get('/ai/analysis', (req, res) => {
  // TODO: تحليل ذكي للبيانات
  res.json({ message: 'تحليل ذكي للبيانات' });
});

// ...existing code...

// Final block closure
// Ensure all blocks are closed

// إغلاق جميع الدوال المفتوحة
// --- Server Startup ---
// --- Server Startup ---

// Only start the server if this file is run directly (not required by tests)
if (require.main === module) {
  const PORT = process.env.PORT || 3000;
  const server = setupRealtime(app);
  // Attach io instance to app for notification usage
  if (server && server.io) {
    app.set('io', server.io);
    // Set IO for billing routes
    if (billingModule.setIO) {
      billingModule.setIO(server.io);
    }
    // Set IO for scheduling routes
    if (schedulingModule.setIO) {
      schedulingModule.setIO(server.io);
    }
    // Set IO for asset management routes
    if (assetManagementModule.setIO) {
      assetManagementModule.setIO(server.io);
    }
    // Set IO for project management routes
    if (projectManagementModule.setIO) {
      projectManagementModule.setIO(server.io);
    }
    // Set IO for knowledge management routes
    if (knowledgeManagementModule.setIO) {
      knowledgeManagementModule.setIO(server.io);
    }
    // Set IO for library management routes
    if (libraryManagementModule.setIO) {
      libraryManagementModule.setIO(server.io);
    }
    // Set IO for certifications advanced routes
    if (certificationsAdvancedModule.setIO) {
      certificationsAdvancedModule.setIO(server.io);
    }
    // Set IO for complaints advanced routes
    if (complaintsAdvancedModule.setIO) {
      complaintsAdvancedModule.setIO(server.io);
    }
    // Set IO for analytics advanced routes
    if (analyticsAdvancedModule.setIO) {
      analyticsAdvancedModule.setIO(server.io);
    }
    // Set IO for workflow management routes
    if (workflowManagementModule.setIO) {
      workflowManagementModule.setIO(server.io);
    }
    // Set IO for integration management routes
    if (integrationManagementModule.setIO) {
      integrationManagementModule.setIO(server.io);
    }
    // Set IO for backup management routes
    if (backupManagementModule.setIO) {
      backupManagementModule.setIO(server.io);
    }
    // Set IO for configuration management routes
    if (configurationManagementModule.setIO) {
      configurationManagementModule.setIO(server.io);
    }
    // Set IO for audit logging routes
    if (auditLoggingModule.setIO) {
      auditLoggingModule.setIO(server.io);
    }
    // Set IO for performance monitoring routes
    if (performanceMonitoringModule.setIO) {
      performanceMonitoringModule.setIO(server.io);
    }
    // Set IO for security management routes
    if (securityManagementModule.setIO) {
      securityManagementModule.setIO(server.io);
    }
    // Set IO for template management routes
    if (templateManagementModule.setIO) {
      templateManagementModule.setIO(server.io);
    }
    // Set IO for custom reports routes
    if (customReportsModule.setIO) {
      customReportsModule.setIO(server.io);
    }
    // Set IO for permissions advanced routes
    if (permissionsAdvancedModule.setIO) {
      permissionsAdvancedModule.setIO(server.io);
    }
    // Set IO for data management routes
    if (dataManagementModule.setIO) {
      dataManagementModule.setIO(server.io);
    }
    // Set IO for notification advanced routes
    if (notificationAdvancedModule.setIO) {
      notificationAdvancedModule.setIO(server.io);
    }
    // Set IO for social media routes
    if (socialMediaModule.setIO) {
      socialMediaModule.setIO(server.io);
    }
    // Set IO for psychological assessments routes
    if (psychologicalAssessmentsModule.setIO) {
      psychologicalAssessmentsModule.setIO(server.io);
    }
    // Set IO for physical therapy routes
    if (physicalTherapyModule.setIO) {
      physicalTherapyModule.setIO(server.io);
    }
    // Set IO for occupational therapy routes
    if (occupationalTherapyModule.setIO) {
      occupationalTherapyModule.setIO(server.io);
    }
    // Set IO for speech & language therapy routes
    if (speechLanguageTherapyModule.setIO) {
      speechLanguageTherapyModule.setIO(server.io);
    }
    // Set IO for behavioral therapy routes
    if (behavioralTherapyModule.setIO) {
      behavioralTherapyModule.setIO(server.io);
    }
    // Set IO for aquatic therapy routes
    if (aquaticTherapyModule.setIO) {
      aquaticTherapyModule.setIO(server.io);
    }
    // Set IO for music therapy routes
    if (musicTherapyModule.setIO) {
      musicTherapyModule.setIO(server.io);
    }
    // Set IO for art therapy routes
    if (artTherapyModule.setIO) {
      artTherapyModule.setIO(server.io);
    }
    // Set IO for animal-assisted therapy routes
    if (animalAssistedTherapyModule.setIO) {
      animalAssistedTherapyModule.setIO(server.io);
    }
    // Set IO for sports therapy routes
    if (sportsTherapyModule.setIO) {
      sportsTherapyModule.setIO(server.io);
    }
    // Set IO for VR therapy routes
    if (vrTherapyModule.setIO) {
      vrTherapyModule.setIO(server.io);
    }
    // Set IO for robotic therapy routes
    if (roboticTherapyModule.setIO) {
      roboticTherapyModule.setIO(server.io);
    }
    // Set IO for electrotherapy routes
    if (electrotherapyModule.setIO) {
      electrotherapyModule.setIO(server.io);
    }
    // Set IO for thermotherapy routes
    if (thermotherapyModule.setIO) {
      thermotherapyModule.setIO(server.io);
    }
    // Set IO for laser therapy routes
    if (laserTherapyModule.setIO) {
      laserTherapyModule.setIO(server.io);
    }
    // Set IO for massage therapy routes
    if (massageTherapyModule.setIO) {
      massageTherapyModule.setIO(server.io);
    }
    // Set IO for acupuncture therapy routes
    if (acupunctureTherapyModule.setIO) {
      acupunctureTherapyModule.setIO(server.io);
    }
    // Set IO for yoga therapy routes
    if (yogaTherapyModule.setIO) {
      yogaTherapyModule.setIO(server.io);
    }
    // Set IO for breathing therapy routes
    if (breathingTherapyModule.setIO) {
      breathingTherapyModule.setIO(server.io);
    }
    // Set IO for unified dashboard routes
    if (unifiedDashboardModule.setIO) {
      unifiedDashboardModule.setIO(server.io);
    }
    // Set IO for unified search routes
    if (unifiedSearchModule.setIO) {
      unifiedSearchModule.setIO(server.io);
    }
    // Set IO for unified reports routes
    if (unifiedReportsModule.setIO) {
      unifiedReportsModule.setIO(server.io);
    }
    // Set IO for smart notifications routes
    if (smartNotificationsModule.setIO) {
      smartNotificationsModule.setIO(server.io);
    }
    // Set IO for performance monitoring routes
    if (performanceMonitoringModule.setIO) {
      performanceMonitoringModule.setIO(server.io);
    }
    // Set IO for system health routes
    if (systemHealthModule.setIO) {
      systemHealthModule.setIO(server.io);
    }
    // Set IO for backup restore routes
    if (backupRestoreModule.setIO) {
      backupRestoreModule.setIO(server.io);
    }
    // Set IO for accounting routes
    if (accountingModule.setIO) {
      accountingModule.setIO(server.io);
    }
    // Set IO for risk management routes
    if (riskManagementModule.setIO) {
      riskManagementModule.setIO(server.io);
    }
    // Set IO for compliance management routes
    if (complianceManagementModule.setIO) {
      complianceManagementModule.setIO(server.io);
    }
    // Set IO for comprehensive student file routes
    if (comprehensiveStudentFileModule.setIO) {
      comprehensiveStudentFileModule.setIO(server.io);
    }
    // Set IO for smart automation routes
    if (smartAutomationModule.setIO) {
      smartAutomationModule.setIO(server.io);
    }
    // Set IO for knowledge management routes
    if (knowledgeManagementModule.setIO) {
      knowledgeManagementModule.setIO(server.io);
    }
    // Set IO for content management routes
    if (contentManagementModule.setIO) {
      contentManagementModule.setIO(server.io);
    }
    // Set IO for digital assets routes
    if (digitalAssetsModule.setIO) {
      digitalAssetsModule.setIO(server.io);
    }
    // Set IO for partnerships routes
    if (partnershipsModule.setIO) {
      partnershipsModule.setIO(server.io);
    }
    // Set IO for events management routes
    if (eventsManagementModule.setIO) {
      eventsManagementModule.setIO(server.io);
    }
    // Set IO for advanced assessments routes
    if (advancedAssessmentsModule.setIO) {
      advancedAssessmentsModule.setIO(server.io);
    }
    // Set IO for advanced HR routes
    if (advancedHRModule.setIO) {
      advancedHRModule.setIO(server.io);
    }
    // Set IO for advanced budget routes
    if (advancedBudgetModule.setIO) {
      advancedBudgetModule.setIO(server.io);
    }
    // Set IO for advanced training routes
    if (advancedTrainingModule.setIO) {
      advancedTrainingModule.setIO(server.io);
    }
    // Set IO for advanced certifications routes
    if (advancedCertificationsModule.setIO) {
      advancedCertificationsModule.setIO(server.io);
    }
    // Set IO for advanced communication routes
    if (advancedCommunicationModule.setIO) {
      advancedCommunicationModule.setIO(server.io);
    }
    // Set IO for advanced reports routes
    if (advancedReportsModule && advancedReportsModule.setIO) {
      advancedReportsModule.setIO(server.io);
    }
    // Set IO for advanced security routes
    if (advancedSecurityModule && advancedSecurityModule.setIO) {
      advancedSecurityModule.setIO(server.io);
    }
    // Set IO for advanced integration routes
    if (advancedIntegrationModule && advancedIntegrationModule.setIO) {
      advancedIntegrationModule.setIO(server.io);
    }
    // Set IO for advanced quality routes
    if (advancedQualityModule && advancedQualityModule.setIO) {
      advancedQualityModule.setIO(server.io);
    }
    // Set IO for advanced performance routes
    if (advancedPerformanceModule && advancedPerformanceModule.setIO) {
      advancedPerformanceModule.setIO(server.io);
    }
    // Set IO for advanced projects routes
    if (advancedProjectsModule && advancedProjectsModule.setIO) {
      advancedProjectsModule.setIO(server.io);
    }
    // Set IO for advanced assets routes
    if (advancedAssetsModule && advancedAssetsModule.setIO) {
      advancedAssetsModule.setIO(server.io);
    }
    // Set IO for advanced change management routes
    if (advancedChangeManagementModule && advancedChangeManagementModule.setIO) {
      advancedChangeManagementModule.setIO(server.io);
    }
    // Set IO for advanced contracts routes
    if (advancedContractsModule && advancedContractsModule.setIO) {
      advancedContractsModule.setIO(server.io);
    }
    // Set IO for advanced vendors routes
    if (advancedVendorsModule && advancedVendorsModule.setIO) {
      advancedVendorsModule.setIO(server.io);
    }
    // Set IO for advanced inventory routes
    if (advancedInventoryModule && advancedInventoryModule.setIO) {
      advancedInventoryModule.setIO(server.io);
    }
    // Set IO for advanced maintenance routes
    if (advancedMaintenanceManagementModule && advancedMaintenanceManagementModule.setIO) {
      advancedMaintenanceManagementModule.setIO(server.io);
    }
    // Set IO for advanced complaints routes
    if (advancedComplaintsModule && advancedComplaintsModule.setIO) {
      advancedComplaintsModule.setIO(server.io);
    }
    // Set IO for advanced sales routes
    if (advancedSalesModule && advancedSalesModule.setIO) {
      advancedSalesModule.setIO(server.io);
    }
    // Set IO for advanced marketing routes
    if (advancedMarketingModule && advancedMarketingModule.setIO) {
      advancedMarketingModule.setIO(server.io);
    }
    // Set IO for advanced customers routes
    if (advancedCustomersModule && advancedCustomersModule.setIO) {
      advancedCustomersModule.setIO(server.io);
    }
    // Set IO for advanced invoices routes
    if (advancedInvoicesModule && advancedInvoicesModule.setIO) {
      advancedInvoicesModule.setIO(server.io);
    }
    // Set IO for advanced payments routes
    if (advancedPaymentsModule && advancedPaymentsModule.setIO) {
      advancedPaymentsModule.setIO(server.io);
    }
    // Set IO for advanced HR management routes
    if (advancedHRManagementModule && advancedHRManagementModule.setIO) {
      advancedHRManagementModule.setIO(server.io);
    }
    // Set IO for advanced training management routes
    if (advancedTrainingManagementModule && advancedTrainingManagementModule.setIO) {
      advancedTrainingManagementModule.setIO(server.io);
    }
    // Set IO for advanced certifications management routes
    if (advancedCertificationsManagementModule && advancedCertificationsManagementModule.setIO) {
      advancedCertificationsManagementModule.setIO(server.io);
    }
    // Set IO for advanced communications management routes
    if (advancedCommunicationsManagementModule && advancedCommunicationsManagementModule.setIO) {
      advancedCommunicationsManagementModule.setIO(server.io);
    }
    // Set IO for advanced reports management routes
    if (advancedReportsManagementModule && advancedReportsManagementModule.setIO) {
      advancedReportsManagementModule.setIO(server.io);
    }
    // Set IO for advanced WhatsApp routes
    if (advancedWhatsAppModule && advancedWhatsAppModule.setIO) {
      advancedWhatsAppModule.setIO(server.io);
    }
    // Set IO for advanced Email routes
    if (advancedEmailModule && advancedEmailModule.setIO) {
      advancedEmailModule.setIO(server.io);
    }
    // Set IO for advanced SMS routes
    if (advancedSMSModule && advancedSMSModule.setIO) {
      advancedSMSModule.setIO(server.io);
    }
    // Set IO for comprehensive assessments routes
    if (comprehensiveAssessmentsModule && comprehensiveAssessmentsModule.setIO) {
      comprehensiveAssessmentsModule.setIO(server.io);
    }
    // Set IO for advanced sessions routes
    if (advancedSessionsModule && advancedSessionsModule.setIO) {
      advancedSessionsModule.setIO(server.io);
    }
    // Set IO for advanced rehabilitation programs routes
    if (advancedRehabilitationProgramsModule && advancedRehabilitationProgramsModule.setIO) {
      advancedRehabilitationProgramsModule.setIO(server.io);
    }
    // Set IO for advanced goals and plans routes
    if (advancedGoalsPlansModule && advancedGoalsPlansModule.setIO) {
      advancedGoalsPlansModule.setIO(server.io);
    }
    // Set IO for advanced appointments routes
    if (advancedAppointmentsModule && advancedAppointmentsModule.setIO) {
      advancedAppointmentsModule.setIO(server.io);
    }
    // Set IO for advanced medications routes
    if (advancedMedicationsModule && advancedMedicationsModule.setIO) {
      advancedMedicationsModule.setIO(server.io);
    }
    // Set IO for advanced medical records routes
    if (advancedMedicalRecordsModule && advancedMedicalRecordsModule.setIO) {
      advancedMedicalRecordsModule.setIO(server.io);
    }
    // Set IO for advanced medical reports routes
    if (advancedMedicalReportsModule && advancedMedicalReportsModule.setIO) {
      advancedMedicalReportsModule.setIO(server.io);
    }
    // Set IO for advanced follow-up routes
    if (advancedFollowUpModule && advancedFollowUpModule.setIO) {
      advancedFollowUpModule.setIO(server.io);
    }
    // Set IO for advanced evaluations routes
    if (advancedEvaluationsModule && advancedEvaluationsModule.setIO) {
      advancedEvaluationsModule.setIO(server.io);
    }
    // Set IO for advanced HR routes
    if (advancedHRModule && advancedHRModule.setIO) {
      advancedHRModule.setIO(server.io);
    }
    // Set IO for advanced accounting routes
    if (advancedAccountingModule && advancedAccountingModule.setIO) {
      advancedAccountingModule.setIO(server.io);
    }
    // Set IO for advanced inventory routes
    if (advancedInventoryModule && advancedInventoryModule.setIO) {
      advancedInventoryModule.setIO(server.io);
    }
    // Set IO for advanced e-learning routes
    if (advancedELearningModule && advancedELearningModule.setIO) {
      advancedELearningModule.setIO(server.io);
    }
    // Set IO for advanced maintenance routes
    if (advancedMaintenanceModule && advancedMaintenanceModule.setIO) {
      advancedMaintenanceModule.setIO(server.io);
    }
    // Set IO for advanced events routes
    if (advancedEventsModule && advancedEventsModule.setIO) {
      advancedEventsModule.setIO(server.io);
    }
    // Set IO for advanced complaints routes
    if (advancedComplaintsModule && advancedComplaintsModule.setIO) {
      advancedComplaintsModule.setIO(server.io);
    }
    // Set IO for advanced quality routes
    if (advancedQualityModule && advancedQualityModule.setIO) {
      advancedQualityModule.setIO(server.io);
    }
    // Set IO for advanced security routes
    if (advancedSecurityModule && advancedSecurityModule.setIO) {
      advancedSecurityModule.setIO(server.io);
    }
    // Set IO for advanced transportation routes
    if (advancedTransportationModule && advancedTransportationModule.setIO) {
      advancedTransportationModule.setIO(server.io);
    }
    // Set IO for advanced restaurant routes
    if (advancedRestaurantModule && advancedRestaurantModule.setIO) {
      advancedRestaurantModule.setIO(server.io);
    }
    // Set IO for advanced facilities routes
    if (advancedFacilitiesModule && advancedFacilitiesModule.setIO) {
      advancedFacilitiesModule.setIO(server.io);
    }
    // Set IO for advanced volunteers routes
    if (advancedVolunteersModule && advancedVolunteersModule.setIO) {
      advancedVolunteersModule.setIO(server.io);
    }
    // Set IO for advanced partnerships routes
    if (advancedPartnershipsModule && advancedPartnershipsModule.setIO) {
      advancedPartnershipsModule.setIO(server.io);
    }
    // Set IO for advanced branches routes
    if (advancedBranchesModule && advancedBranchesModule.setIO) {
      advancedBranchesModule.setIO(server.io);
    }
    // Set IO for advanced call center routes
    if (advancedCallCenterModule && advancedCallCenterModule.setIO) {
      advancedCallCenterModule.setIO(server.io);
    }
    // Set IO for advanced research routes
    if (advancedResearchModule && advancedResearchModule.setIO) {
      advancedResearchModule.setIO(server.io);
    }
    // Set IO for advanced referrals routes
    if (advancedReferralsModule && advancedReferralsModule.setIO) {
      advancedReferralsModule.setIO(server.io);
    }
    // Set IO for advanced library routes
    if (advancedLibraryModule && advancedLibraryModule.setIO) {
      advancedLibraryModule.setIO(server.io);
    }
    // Set IO for advanced PR routes
    if (advancedPRModule && advancedPRModule.setIO) {
      advancedPRModule.setIO(server.io);
    }
    // Set IO for advanced funding routes
    if (advancedFundingModule && advancedFundingModule.setIO) {
      advancedFundingModule.setIO(server.io);
    }
  }
  server
    .listen(PORT, () => {
      console.log(`Smart API + Realtime running on port ${PORT}`);
    })
    .on('error', error => {
      if (error.code === 'EADDRINUSE') {
        console.error(`❌ Port ${PORT} is already in use`);
        console.error(
          'Please change the PORT in your .env file or stop the process using this port'
        );
        process.exit(1);
      } else {
        console.error('❌ Server error:', error);
        process.exit(1);
      }
    });
} else {
  // Error Handler (must be last)
  app.use(errorHandler);

  // For testing: export app and setupRealtime for supertest
  module.exports = app;
}
