const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const AIModel = sequelize.define(
  'AIModel',
  {
    type: { type: DataTypes.STRING },
    version: { type: DataTypes.STRING },
    status: { type: DataTypes.STRING },
    last_train: { type: DataTypes.DATE },
    metrics: { type: DataTypes.TEXT },
  },
  {
    tableName: 'ai_models',
    timestamps: false,
  }
);

module.exports = AIModel;
