const mockModel = {
  find: () => Promise.resolve([]),
  findById: () => Promise.resolve(null),
  findOne: () => Promise.resolve(null),
  create: () => Promise.resolve({}),
  updateOne: () => Promise.resolve({ modifiedCount: 0 }),
  deleteOne: () => Promise.resolve({ deletedCount: 0 }),
  countDocuments: () => Promise.resolve(0),
  aggregate: () => ({
    sort: function() { return this; },
    limit: function() { return this; },
    skip: function() { return this; },
    toArray: () => Promise.resolve([]),
  }),
};

module.exports = mockModel;
