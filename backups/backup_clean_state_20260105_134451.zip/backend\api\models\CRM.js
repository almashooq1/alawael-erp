const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const User = require('./User');

const CRM = sequelize.define(
  'CRM',
  {
    interaction_type: { type: DataTypes.STRING },
    feedback: { type: DataTypes.TEXT },
    rating: { type: DataTypes.INTEGER },
    followup: { type: DataTypes.DATE },
  },
  {
    tableName: 'crm',
    timestamps: false,
  }
);

CRM.belongsTo(User, { foreignKey: 'user_id' });

module.exports = CRM;
