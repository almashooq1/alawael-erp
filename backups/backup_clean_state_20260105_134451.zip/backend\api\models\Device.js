// نموذج الجهاز الطبي الذكي
const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Device = sequelize.define(
  'Device',
  {
    type: { type: DataTypes.STRING },
    status: { type: DataTypes.STRING },
    last_maintenance: { type: DataTypes.DATE },
    location: { type: DataTypes.STRING },
    alerts: { type: DataTypes.TEXT },
  },
  {
    tableName: 'devices',
    timestamps: false,
  }
);

module.exports = Device;
