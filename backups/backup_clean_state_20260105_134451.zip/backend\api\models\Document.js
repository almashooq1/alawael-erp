const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const User = require('./User');

const Document = sequelize.define(
  'Document',
  {
    type: { type: DataTypes.STRING },
    content: { type: DataTypes.TEXT },
    expiry: { type: DataTypes.DATE },
    access_level: { type: DataTypes.STRING },
  },
  {
    tableName: 'documents',
    timestamps: false,
  }
);

Document.belongsTo(User, { foreignKey: 'owner_id' });

module.exports = Document;
