const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const GovIntegration = sequelize.define(
  'GovIntegration',
  {
    external_id: { type: DataTypes.STRING },
    type: { type: DataTypes.STRING },
    status: { type: DataTypes.STRING },
    last_sync: { type: DataTypes.DATE },
  },
  {
    tableName: 'gov_integration',
    timestamps: false,
  }
);

module.exports = GovIntegration;
