const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const Patient = require('./Patient');

const InsuranceClaim = sequelize.define(
  'InsuranceClaim',
  {
    status: { type: DataTypes.STRING },
    amount: { type: DataTypes.DECIMAL(12, 2) },
    response: { type: DataTypes.TEXT },
    last_update: { type: DataTypes.DATE },
  },
  {
    tableName: 'insurance_claims',
    timestamps: false,
  }
);

InsuranceClaim.belongsTo(Patient, { foreignKey: 'patient_id' });

module.exports = InsuranceClaim;
