const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Inventory = sequelize.define(
  'Inventory',
  {
    item_name: { type: DataTypes.STRING },
    quantity: { type: DataTypes.INTEGER },
    expiry: { type: DataTypes.DATE },
    alerts: { type: DataTypes.TEXT },
  },
  {
    tableName: 'inventory',
    timestamps: false,
  }
);

module.exports = Inventory;
