// نموذج المريض الذكي
const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const User = require('./User');

const Patient = sequelize.define(
  'Patient',
  {
    medical_info: { type: DataTypes.TEXT },
    disability_type: { type: DataTypes.STRING },
    sessions: { type: DataTypes.INTEGER },
    insurance_id: { type: DataTypes.INTEGER },
  },
  {
    tableName: 'patients',
    timestamps: false,
  }
);

Patient.belongsTo(User, { foreignKey: 'user_id' });

module.exports = Patient;
