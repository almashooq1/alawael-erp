const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const User = require('./User');

const Payment = sequelize.define(
  'Payment',
  {
    amount: { type: DataTypes.DECIMAL(12, 2) },
    method: { type: DataTypes.STRING },
    status: { type: DataTypes.STRING },
    fraud_flag: { type: DataTypes.BOOLEAN },
  },
  {
    tableName: 'payments',
    timestamps: false,
  }
);

Payment.belongsTo(User, { foreignKey: 'user_id' });

module.exports = Payment;
