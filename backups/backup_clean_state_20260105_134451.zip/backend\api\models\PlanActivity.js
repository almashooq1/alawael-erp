/**
 * PlanActivity Model Stub
 */

const mockModel = {
  find: () => Promise.resolve([]),
  findById: () => Promise.resolve(null),
  findOne: () => Promise.resolve(null),
  create: data => Promise.resolve({ _id: 'mock-id', ...data }),
  updateOne: () => Promise.resolve({ nModified: 1 }),
  deleteOne: () => Promise.resolve({ deletedCount: 1 }),
  countDocuments: () => Promise.resolve(0),
  aggregate: () => Promise.resolve([]),
};

module.exports = mockModel;
