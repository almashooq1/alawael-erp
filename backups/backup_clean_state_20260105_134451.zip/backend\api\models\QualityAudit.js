/**
 * ⭐ Quality Audit Model
 * نموذج تدقيقات الجودة
 */

const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const QualityAudit = sequelize.define(
  'QualityAudit',
  {
    title: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    type: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    date: {
      type: DataTypes.DATE,
      allowNull: false,
    },
    score: {
      type: DataTypes.INTEGER,
    },
    status: {
      type: DataTypes.STRING,
      defaultValue: 'مكتمل',
    },
    notes: {
      type: DataTypes.TEXT,
    },
  },
  {
    tableName: 'quality_audits',
    timestamps: true,
  }
);

module.exports = QualityAudit;
