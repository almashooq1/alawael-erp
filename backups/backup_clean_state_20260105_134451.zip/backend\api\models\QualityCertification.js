/**
 * ⭐ Quality Certification Model
 * نموذج الشهادات والاعتمادات
 */

const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const QualityCertification = sequelize.define(
  'QualityCertification',
  {
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    issuer: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    issueDate: {
      type: DataTypes.DATE,
    },
    expiryDate: {
      type: DataTypes.DATE,
    },
    status: {
      type: DataTypes.STRING,
      defaultValue: 'نشط',
    },
    certificateNumber: {
      type: DataTypes.STRING,
    },
    description: {
      type: DataTypes.TEXT,
    },
  },
  {
    tableName: 'quality_certifications',
    timestamps: true,
  }
);

module.exports = QualityCertification;
