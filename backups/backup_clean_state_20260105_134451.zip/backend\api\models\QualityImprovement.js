/**
 * ⭐ Quality Improvement Model
 * نموذج خطط التحسين
 */

const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const QualityImprovement = sequelize.define(
  'QualityImprovement',
  {
    title: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    priority: {
      type: DataTypes.STRING,
      allowNull: false,
      defaultValue: 'متوسط',
    },
    description: {
      type: DataTypes.TEXT,
    },
    date: {
      type: DataTypes.DATE,
      allowNull: false,
    },
    status: {
      type: DataTypes.STRING,
      defaultValue: 'قيد التنفيذ',
    },
    completionDate: {
      type: DataTypes.DATE,
    },
  },
  {
    tableName: 'quality_improvements',
    timestamps: true,
  }
);

module.exports = QualityImprovement;
