/**
 * ⭐ Quality Standard Model
 * نموذج معايير الجودة
 */

const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const QualityStandard = sequelize.define(
  'QualityStandard',
  {
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    category: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    status: {
      type: DataTypes.STRING,
      allowNull: false,
      defaultValue: 'قيد التطبيق',
    },
    description: {
      type: DataTypes.TEXT,
    },
    icon: {
      type: DataTypes.STRING,
      defaultValue: '⭐',
    },
  },
  {
    tableName: 'quality_standards',
    timestamps: true,
  }
);

module.exports = QualityStandard;
