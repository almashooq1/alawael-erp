const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const User = require('./User');
const Session = require('./Session');

const QualitySurvey = sequelize.define(
  'QualitySurvey',
  {
    answers: { type: DataTypes.TEXT },
    score: { type: DataTypes.INTEGER },
    improvement: { type: DataTypes.TEXT },
  },
  {
    tableName: 'quality_surveys',
    timestamps: false,
  }
);

QualitySurvey.belongsTo(User, { foreignKey: 'user_id' });
QualitySurvey.belongsTo(Session, { foreignKey: 'session_id' });

module.exports = QualitySurvey;
