const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Route = sequelize.define(
  'Route',
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    startLocation: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    endLocation: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    stops: {
      type: DataTypes.TEXT,
      get() {
        const raw = this.getDataValue('stops');
        return raw ? JSON.parse(raw) : [];
      },
      set(val) {
        this.setDataValue('stops', JSON.stringify(val));
      },
    },
    status: {
      type: DataTypes.STRING,
      defaultValue: 'active',
      validate: {
        isIn: [['active', 'inactive']],
      },
    },
    notes: {
      type: DataTypes.TEXT,
    },
  },
  {
    tableName: 'routes',
    timestamps: true,
  }
);

module.exports = Route;
