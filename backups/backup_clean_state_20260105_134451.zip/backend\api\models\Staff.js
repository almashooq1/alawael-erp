// نموذج الموظف الذكي
const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const User = require('./User');

const Staff = sequelize.define(
  'Staff',
  {
    position: { type: DataTypes.STRING },
    performance: { type: DataTypes.INTEGER },
    schedule: { type: DataTypes.TEXT },
  },
  {
    tableName: 'staff',
    timestamps: false,
  }
);

Staff.belongsTo(User, { foreignKey: 'user_id' });

// Ensure sync exists when using lightweight mocks
if (typeof Staff.sync !== 'function') {
  Staff.sync = async () => Staff;
}

module.exports = Staff;
