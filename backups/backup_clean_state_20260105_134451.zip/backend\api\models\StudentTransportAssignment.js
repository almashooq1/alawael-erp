const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const StudentTransportAssignment = sequelize.define(
  'StudentTransportAssignment',
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    studentId: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    busId: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    routeId: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    driverId: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    pickupLocation: {
      type: DataTypes.STRING,
    },
    dropoffLocation: {
      type: DataTypes.STRING,
    },
    schedule: {
      type: DataTypes.STRING,
    },
    status: {
      type: DataTypes.STRING,
      allowNull: false,
      defaultValue: 'active',
      validate: {
        isIn: [['active', 'inactive', 'pending', 'cancelled']],
      },
    },
    notes: {
      type: DataTypes.TEXT,
    },
  },
  {
    tableName: 'student_transport_assignments',
    timestamps: true,
  }
);

module.exports = StudentTransportAssignment;
