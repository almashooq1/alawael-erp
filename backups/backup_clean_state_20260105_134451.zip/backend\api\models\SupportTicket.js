const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const User = require('./User');
const Staff = require('./Staff');

const SupportTicket = sequelize.define(
  'SupportTicket',
  {
    channel: { type: DataTypes.STRING },
    issue: { type: DataTypes.TEXT },
    status: { type: DataTypes.STRING },
  },
  {
    tableName: 'support_tickets',
    timestamps: false,
  }
);

SupportTicket.belongsTo(User, { foreignKey: 'user_id' });
SupportTicket.belongsTo(Staff, { foreignKey: 'assigned_to' });

module.exports = SupportTicket;
