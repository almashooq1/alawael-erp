const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

// Basic User model backed by the in-memory Sequelize mock during tests.
const User = sequelize.define(
  'User',
  {
    id: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
    name: { type: DataTypes.STRING },
    email: { type: DataTypes.STRING },
    role: { type: DataTypes.STRING },
    status: { type: DataTypes.STRING },
  },
  {
    tableName: 'users',
    timestamps: false,
  }
);

// Ensure sync exists when using lightweight mocks
if (typeof User.sync !== 'function') {
  User.sync = async () => User;
}

module.exports = User;
