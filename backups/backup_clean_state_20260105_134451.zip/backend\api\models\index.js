// Aggregate and export all models for use in recommendations and other modules
const fs = require('fs');
const path = require('path');

const models = {};
const basename = path.basename(__filename);
const modelsDir = __dirname;

fs.readdirSync(modelsDir)
  .filter(file => file.indexOf('.') !== 0 && file !== basename && file.slice(-3) === '.js')
  .forEach(file => {
    const model = require(path.join(modelsDir, file));
    // Use model name if available, otherwise filename
    const name = model?.name || path.basename(file, '.js');
    models[name] = model;
  });

module.exports = models;
