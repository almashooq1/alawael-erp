/**
 * 🔄 Real-time WebSocket Server
 * خادم WebSocket للإشعارات الفورية والمزامنة
 */

const http = require('http');
const socketio = require('socket.io');
const { getAllowedOrigins } = require('../shared/middleware/cors');

function setupRealtime(app) {
  const server = http.createServer(app);

  // CORS configuration for Socket.IO
  const allowedOrigins = getAllowedOrigins();
  const corsOptions = {
    origin: (origin, callback) => {
      if (!origin || process.env.NODE_ENV === 'development') {
        return callback(null, true);
      }
      if (allowedOrigins.includes(origin)) {
        callback(null, true);
      } else {
        callback(new Error('Not allowed by CORS'));
      }
    },
    credentials: true,
    methods: ['GET', 'POST'],
  };

  const io = socketio(server, { cors: corsOptions });

  // Store connected users
  const connectedUsers = new Map();
  const userRooms = new Map();

  io.on('connection', socket => {
    console.log(`🔔 مستخدم متصل: ${socket.id}`);

    // Handle authentication
    socket.on('authenticate', async data => {
      try {
        const { userId, token } = data;

        // TODO: Verify token with auth service
        // For now, just store user info
        connectedUsers.set(socket.id, { userId, token, connectedAt: new Date() });
        socket.userId = userId;

        // Join user's personal room
        socket.join(`user:${userId}`);
        userRooms.set(socket.id, [`user:${userId}`]);

        socket.emit('authenticated', { success: true, userId });
        console.log(`✅ مستخدم مصادق: ${userId} (${socket.id})`);
      } catch (error) {
        console.error('❌ خطأ في المصادقة:', error);
        socket.emit('authenticated', { success: false, error: error.message });
      }
    });

    // Handle joining a room
    socket.on('join-room', roomId => {
      if (socket.userId) {
        socket.join(roomId);
        const rooms = userRooms.get(socket.id) || [];
        if (!rooms.includes(roomId)) {
          rooms.push(roomId);
          userRooms.set(socket.id, rooms);
        }
        console.log(`📥 ${socket.userId} انضم إلى: ${roomId}`);
      }
    });

    // Handle leaving a room
    socket.on('leave-room', roomId => {
      socket.leave(roomId);
      const rooms = userRooms.get(socket.id) || [];
      const index = rooms.indexOf(roomId);
      if (index > -1) {
        rooms.splice(index, 1);
        userRooms.set(socket.id, rooms);
      }
      console.log(`📤 ${socket.userId} غادر: ${roomId}`);
    });

    // Handle data update events
    socket.on('data-updated', data => {
      // Broadcast to relevant rooms
      const { entityType, entityId } = data;
      const roomId = `${entityType}:${entityId}`;
      socket.to(roomId).emit('data-updated', data);
    });

    // Handle disconnect
    socket.on('disconnect', () => {
      console.log(`❌ قطع الاتصال: ${socket.id}`);
      connectedUsers.delete(socket.id);
      userRooms.delete(socket.id);
    });

    // Handle errors
    socket.on('error', error => {
      console.error(`❌ خطأ في Socket ${socket.id}:`, error);
    });
  });

  // Helper function to send notification to user
  app.sendNotificationToUser = (userId, notification) => {
    io.to(`user:${userId}`).emit('notification', notification);
  };

  // Helper function to send notification to all users
  app.sendNotification = notification => {
    io.emit('notification', notification);
  };

  // Helper function to broadcast data update
  app.broadcastDataUpdate = (entityType, entityId, action, payload) => {
    const roomId = `${entityType}:${entityId}`;
    io.to(roomId).emit('data-updated', {
      entityType,
      entityId,
      action,
      payload,
      timestamp: new Date().toISOString(),
    });
  };

  // Helper function to get connected users count
  app.getConnectedUsersCount = () => {
    return connectedUsers.size;
  };

  // Helper function to get connected users
  app.getConnectedUsers = () => {
    return Array.from(connectedUsers.values());
  };

  return server;
}

module.exports = setupRealtime;
