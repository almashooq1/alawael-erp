/**
 * ♿ Accessibility Management Routes
 * مسارات إدارة إمكانية الوصول
 */

const express = require('express');
const router = express.Router();
const AccessibilitySettings = require('../models/AccessibilitySettings');
const authenticateToken = require('../middleware/authenticateToken');
const logger = require('../../shared/logging/logger');

// Real-time event emitter (if available)
let io = null;
try {
  const realtimeModule = require('../realtime');
  io = realtimeModule.io;
} catch (error) {
  // Real-time not available
}

/**
 * Emit real-time event
 */
function emitEvent(eventType, entityType, data) {
  if (io) {
    io.emit('accessibility:update', {
      action: eventType,
      entityType: entityType,
      data: data,
    });
  }
}

// Apply authentication to all routes
router.use(authenticateToken);

/**
 * Accessibility Settings Routes
 */
router.get('/settings', async (req, res) => {
  try {
    const settings = await AccessibilitySettings.findOne({
      where: { userId: req.user.id },
    });
    if (!settings) {
      // Return default settings
      return res.json({
        screenReader: false,
        fontSize: 'medium',
        contrast: 'normal',
        language: 'ar',
        keyboardNavigation: true,
        highContrast: false,
        reducedMotion: false,
      });
    }
    res.json(settings);
  } catch (error) {
    logger.error('Error fetching accessibility settings:', error);
    res.status(500).json({ error: 'خطأ في جلب إعدادات إمكانية الوصول' });
  }
});

router.put('/settings', async (req, res) => {
  try {
    const [settings, created] = await AccessibilitySettings.upsert(
      {
        ...req.body,
        userId: req.user.id,
      },
      {
        returning: true,
      }
    );
    emitEvent('update', 'settings', settings);
    logger.info('Accessibility settings updated', { userId: req.user.id });
    res.json(settings);
  } catch (error) {
    logger.error('Error updating accessibility settings:', error);
    res.status(400).json({ error: 'خطأ في تحديث إعدادات إمكانية الوصول' });
  }
});

module.exports = router;
