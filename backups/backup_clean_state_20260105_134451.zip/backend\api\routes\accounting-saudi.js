/**
 * 🇸🇦 API Routes for Saudi Accounting System
 * مسارات API لنظام المحاسبة السعودي
 */

const express = require('express');
const router = express.Router();
const AccountingSaudiManager = require('../../shared/utils/accounting-saudi-manager');
const AccountingSaudiInvoicing = require('../../shared/utils/accounting-saudi-invoicing');
const AccountingSaudiTaxZakat = require('../../shared/utils/accounting-saudi-tax-zakat');
const AccountingSaudiBudget = require('../../shared/utils/accounting-saudi-budget');
const AccountingSaudiReports = require('../../shared/utils/accounting-saudi-reports');
const AccountingSaudiGovernmentIntegration = require('../../shared/utils/accounting-saudi-government-integration');
const AccountingSaudiBankReconciliation = require('../../shared/utils/accounting-saudi-bank-reconciliation');
const AccountingSaudiCashManagement = require('../../shared/utils/accounting-saudi-cash-management');
const AccountingSaudiReceivablesPayables = require('../../shared/utils/accounting-saudi-receivables-payables');
const AccountingSaudiNotifications = require('../../shared/utils/accounting-saudi-notifications');
const AccountingSaudiBackup = require('../../shared/utils/accounting-saudi-backup');
const { requirePermission } = require('../../shared/middleware/permissions-middleware');

const accountingManager = new AccountingSaudiManager();
const invoicingManager = new AccountingSaudiInvoicing(accountingManager);
const taxZakatManager = new AccountingSaudiTaxZakat(accountingManager);
const budgetManager = new AccountingSaudiBudget(accountingManager);
const reportsManager = new AccountingSaudiReports(
  accountingManager,
  invoicingManager,
  taxZakatManager,
  budgetManager
);
const governmentIntegration = new AccountingSaudiGovernmentIntegration(
  accountingManager,
  invoicingManager,
  taxZakatManager
);
const bankReconciliation = new AccountingSaudiBankReconciliation(accountingManager);
const cashManagement = new AccountingSaudiCashManagement(accountingManager);
const receivablesPayables = new AccountingSaudiReceivablesPayables(
  accountingManager,
  invoicingManager
);
const accountingNotifications = new AccountingSaudiNotifications(
  accountingManager,
  invoicingManager,
  taxZakatManager
);
const accountingBackup = new AccountingSaudiBackup(
  accountingManager,
  invoicingManager,
  taxZakatManager,
  budgetManager
);

// ========== Accounts ==========

router.get('/accounts', requirePermission('accounting.accounts.view'), async (req, res) => {
  try {
    const accounts = accountingManager.getAccounts(req.query);
    res.json({ success: true, data: accounts });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get(
  '/accounts/:accountId',
  requirePermission('accounting.accounts.view'),
  async (req, res) => {
    try {
      const account = accountingManager.getAccount(req.params.accountId);
      if (account) {
        res.json({ success: true, data: account });
      } else {
        res.status(404).json({ success: false, error: 'Account not found' });
      }
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Journal Entries ==========

router.post('/journal-entries', requirePermission('accounting.journal.edit'), async (req, res) => {
  try {
    const entry = accountingManager.createJournalEntry(req.body);
    res.json({ success: true, data: entry });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/journal-entries', requirePermission('accounting.journal.view'), async (req, res) => {
  try {
    const entries = accountingManager.getJournalEntries(req.query);
    res.json({ success: true, data: entries });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Trial Balance ==========

router.get('/trial-balance', requirePermission('accounting.reports.view'), async (req, res) => {
  try {
    const date = req.query.date ? new Date(req.query.date) : new Date();
    const trialBalance = accountingManager.getTrialBalance(date);
    res.json({ success: true, data: trialBalance });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Financial Statements ==========

router.get('/income-statement', requirePermission('accounting.reports.view'), async (req, res) => {
  try {
    const startDate = req.query.startDate || new Date(new Date().getFullYear(), 0, 1).toISOString();
    const endDate = req.query.endDate || new Date().toISOString();
    const statement = accountingManager.getIncomeStatement(startDate, endDate);
    res.json({ success: true, data: statement });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/balance-sheet', requirePermission('accounting.reports.view'), async (req, res) => {
  try {
    const date = req.query.date ? new Date(req.query.date) : new Date();
    const balanceSheet = accountingManager.getBalanceSheet(date);
    res.json({ success: true, data: balanceSheet });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Invoices ==========

router.post('/invoices', requirePermission('accounting.invoices.edit'), async (req, res) => {
  try {
    const invoice = invoicingManager.createInvoice(req.body);
    res.json({ success: true, data: invoice });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/invoices', requirePermission('accounting.invoices.view'), async (req, res) => {
  try {
    const invoices = invoicingManager.getInvoices(req.query);
    res.json({ success: true, data: invoices });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get(
  '/invoices/:invoiceId',
  requirePermission('accounting.invoices.view'),
  async (req, res) => {
    try {
      const invoice = invoicingManager.getInvoice(req.params.invoiceId);
      if (invoice) {
        res.json({ success: true, data: invoice });
      } else {
        res.status(404).json({ success: false, error: 'Invoice not found' });
      }
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.post(
  '/invoices/:invoiceId/submit-zatca',
  requirePermission('accounting.invoices.edit'),
  async (req, res) => {
    try {
      const result = await invoicingManager.submitToZATCA(req.params.invoiceId);
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/invoices/statistics',
  requirePermission('accounting.invoices.view'),
  async (req, res) => {
    try {
      const startDate =
        req.query.startDate ||
        new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString();
      const endDate = req.query.endDate || new Date().toISOString();
      const statistics = invoicingManager.getInvoiceStatistics(startDate, endDate);
      res.json({ success: true, data: statistics });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Tax & Zakat ==========

router.post('/tax/transactions', requirePermission('accounting.tax.edit'), async (req, res) => {
  try {
    const transaction = taxZakatManager.recordTaxTransaction(req.body);
    res.json({ success: true, data: transaction });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/zakat/transactions', requirePermission('accounting.zakat.edit'), async (req, res) => {
  try {
    const transaction = taxZakatManager.recordZakatTransaction(req.body);
    res.json({ success: true, data: transaction });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get(
  '/tax/report/:month/:year',
  requirePermission('accounting.tax.view'),
  async (req, res) => {
    try {
      const report = taxZakatManager.generateTaxReport(
        parseInt(req.params.month),
        parseInt(req.params.year)
      );
      res.json({ success: true, data: report });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get('/zakat/report/:year', requirePermission('accounting.zakat.view'), async (req, res) => {
  try {
    const report = taxZakatManager.generateZakatReport(parseInt(req.params.year));
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Budgets ==========

router.post('/budgets', requirePermission('accounting.budgets.edit'), async (req, res) => {
  try {
    const budget = budgetManager.createBudget(req.body);
    res.json({ success: true, data: budget });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post(
  '/budgets/:budgetId/items',
  requirePermission('accounting.budgets.edit'),
  async (req, res) => {
    try {
      const item = budgetManager.addBudgetItem(req.params.budgetId, req.body);
      res.json({ success: true, data: item });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.post(
  '/budgets/:budgetId/approve',
  requirePermission('accounting.budgets.edit'),
  async (req, res) => {
    try {
      const budget = budgetManager.approveBudget(req.params.budgetId, req.body.approvedBy);
      res.json({ success: true, data: budget });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get('/budgets', requirePermission('accounting.budgets.view'), async (req, res) => {
  try {
    const budgets = budgetManager.getBudgets(req.query);
    res.json({ success: true, data: budgets });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/budgets/:budgetId', requirePermission('accounting.budgets.view'), async (req, res) => {
  try {
    const budget = budgetManager.getBudget(req.params.budgetId);
    if (budget) {
      res.json({ success: true, data: budget });
    } else {
      res.status(404).json({ success: false, error: 'Budget not found' });
    }
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get(
  '/budgets/:budgetId/analysis',
  requirePermission('accounting.budgets.view'),
  async (req, res) => {
    try {
      const analysis = budgetManager.analyzeBudget(req.params.budgetId);
      res.json({ success: true, data: analysis });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Reports ==========

router.get(
  '/reports/comprehensive',
  requirePermission('accounting.reports.view'),
  async (req, res) => {
    try {
      const startDate =
        req.query.startDate || new Date(new Date().getFullYear(), 0, 1).toISOString();
      const endDate = req.query.endDate || new Date().toISOString();
      const report = reportsManager.generateComprehensiveReport(startDate, endDate);
      res.json({ success: true, data: report });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/reports/tax/:month/:year',
  requirePermission('accounting.reports.view'),
  async (req, res) => {
    try {
      const report = reportsManager.generateTaxReport(
        parseInt(req.params.month),
        parseInt(req.params.year)
      );
      res.json({ success: true, data: report });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/reports/zakat/:year',
  requirePermission('accounting.reports.view'),
  async (req, res) => {
    try {
      const report = reportsManager.generateZakatReport(parseInt(req.params.year));
      res.json({ success: true, data: report });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get('/reports/cash-flow', requirePermission('accounting.reports.view'), async (req, res) => {
  try {
    const startDate = req.query.startDate || new Date(new Date().getFullYear(), 0, 1).toISOString();
    const endDate = req.query.endDate || new Date().toISOString();
    const statement = reportsManager.generateCashFlowStatement(startDate, endDate);
    res.json({ success: true, data: statement });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get(
  '/reports/accounts-receivable',
  requirePermission('accounting.reports.view'),
  async (req, res) => {
    try {
      const date = req.query.date ? new Date(req.query.date) : new Date();
      const report = reportsManager.generateAccountsReceivableReport(date);
      res.json({ success: true, data: report });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Government Integration ==========

router.get(
  '/government/integration/status',
  requirePermission('accounting.government.view'),
  async (req, res) => {
    try {
      const status = governmentIntegration.getIntegrationStatus();
      res.json({ success: true, data: status });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.post(
  '/government/invoices/:invoiceId/submit-zatca',
  requirePermission('accounting.government.edit'),
  async (req, res) => {
    try {
      const result = await governmentIntegration.submitInvoiceToZATCA(req.params.invoiceId);
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.post(
  '/government/tax-return/:month/:year',
  requirePermission('accounting.government.edit'),
  async (req, res) => {
    try {
      const result = await governmentIntegration.submitTaxReturn(
        parseInt(req.params.month),
        parseInt(req.params.year)
      );
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.post(
  '/government/zakat-return/:year',
  requirePermission('accounting.government.edit'),
  async (req, res) => {
    try {
      const result = await governmentIntegration.submitZakatReturn(parseInt(req.params.year));
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.post(
  '/government/verify-vat',
  requirePermission('accounting.government.view'),
  async (req, res) => {
    try {
      const result = await governmentIntegration.verifyVATNumber(req.body.vatNumber);
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Bank Reconciliation ==========

router.post(
  '/bank-reconciliation/statements',
  requirePermission('accounting.reconciliation.edit'),
  async (req, res) => {
    try {
      const statement = bankReconciliation.importBankStatement(req.body);
      res.json({ success: true, data: statement });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.post(
  '/bank-reconciliation',
  requirePermission('accounting.reconciliation.edit'),
  async (req, res) => {
    try {
      const reconciliation = bankReconciliation.createReconciliation(req.body);
      res.json({ success: true, data: reconciliation });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.post(
  '/bank-reconciliation/:reconciliationId/auto-reconcile',
  requirePermission('accounting.reconciliation.edit'),
  async (req, res) => {
    try {
      const reconciliation = bankReconciliation.autoReconcile(req.params.reconciliationId);
      res.json({ success: true, data: reconciliation });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.post(
  '/bank-reconciliation/:reconciliationId/complete',
  requirePermission('accounting.reconciliation.edit'),
  async (req, res) => {
    try {
      const reconciliation = bankReconciliation.completeReconciliation(req.params.reconciliationId);
      res.json({ success: true, data: reconciliation });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/bank-reconciliation',
  requirePermission('accounting.reconciliation.view'),
  async (req, res) => {
    try {
      const reconciliations = bankReconciliation.getReconciliations(req.query);
      res.json({ success: true, data: reconciliations });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Cash Management ==========

router.post('/cash/registers', requirePermission('accounting.cash.edit'), async (req, res) => {
  try {
    const register = cashManagement.createCashRegister(req.body);
    res.json({ success: true, data: register });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/cash/transactions', requirePermission('accounting.cash.edit'), async (req, res) => {
  try {
    const transaction = cashManagement.recordCashTransaction(req.body);
    res.json({ success: true, data: transaction });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post(
  '/cash/transactions/:transactionId/approve',
  requirePermission('accounting.cash.edit'),
  async (req, res) => {
    try {
      const transaction = cashManagement.approveCashTransaction(
        req.params.transactionId,
        req.body.approvedBy
      );
      res.json({ success: true, data: transaction });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.post(
  '/cash/registers/:registerId/close',
  requirePermission('accounting.cash.edit'),
  async (req, res) => {
    try {
      const register = cashManagement.closeCashRegister(req.params.registerId, req.body);
      res.json({ success: true, data: register });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get('/cash/registers', requirePermission('accounting.cash.view'), async (req, res) => {
  try {
    const registers = cashManagement.getCashRegisters(req.query);
    res.json({ success: true, data: registers });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/cash/transactions', requirePermission('accounting.cash.view'), async (req, res) => {
  try {
    const transactions = cashManagement.getCashTransactions(req.query);
    res.json({ success: true, data: transactions });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get(
  '/cash/reports/:registerId',
  requirePermission('accounting.cash.view'),
  async (req, res) => {
    try {
      const startDate =
        req.query.startDate || new Date(new Date().getFullYear(), 0, 1).toISOString();
      const endDate = req.query.endDate || new Date().toISOString();
      const report = cashManagement.generateCashReport(req.params.registerId, startDate, endDate);
      res.json({ success: true, data: report });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Receivables & Payables ==========

router.post(
  '/receivables/from-invoice/:invoiceId',
  requirePermission('accounting.receivables.edit'),
  async (req, res) => {
    try {
      const receivable = receivablesPayables.createReceivableFromInvoice(req.params.invoiceId);
      res.json({ success: true, data: receivable });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.post(
  '/receivables/:receivableId/payments',
  requirePermission('accounting.receivables.edit'),
  async (req, res) => {
    try {
      const payment = receivablesPayables.recordReceivablePayment({
        receivableId: req.params.receivableId,
        ...req.body,
      });
      res.json({ success: true, data: payment });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.post('/payables', requirePermission('accounting.payables.edit'), async (req, res) => {
  try {
    const payable = receivablesPayables.createPayable(req.body);
    res.json({ success: true, data: payable });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post(
  '/payables/:payableId/payments',
  requirePermission('accounting.payables.edit'),
  async (req, res) => {
    try {
      const payment = receivablesPayables.recordPayablePayment({
        payableId: req.params.payableId,
        ...req.body,
      });
      res.json({ success: true, data: payment });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get('/receivables', requirePermission('accounting.receivables.view'), async (req, res) => {
  try {
    const receivables = receivablesPayables.getReceivables(req.query);
    res.json({ success: true, data: receivables });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/payables', requirePermission('accounting.payables.view'), async (req, res) => {
  try {
    const payables = receivablesPayables.getPayables(req.query);
    res.json({ success: true, data: payables });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get(
  '/aging-report/:type',
  requirePermission('accounting.receivables.view'),
  async (req, res) => {
    try {
      const report = receivablesPayables.getAgingReport(req.params.type);
      res.json({ success: true, data: report });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Notifications ==========

router.get(
  '/notifications',
  requirePermission('accounting.notifications.view'),
  async (req, res) => {
    try {
      const notifications = accountingNotifications.getNotifications(req.query);
      res.json({ success: true, data: notifications });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.post(
  '/notifications/check',
  requirePermission('accounting.notifications.edit'),
  async (req, res) => {
    try {
      const notifications = accountingNotifications.checkAllNotifications();
      res.json({ success: true, data: notifications, count: notifications.length });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.post(
  '/notifications/:notificationId/read',
  requirePermission('accounting.notifications.edit'),
  async (req, res) => {
    try {
      const success = accountingNotifications.markAsRead(req.params.notificationId);
      res.json({ success });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.delete(
  '/notifications/:notificationId',
  requirePermission('accounting.notifications.edit'),
  async (req, res) => {
    try {
      const success = accountingNotifications.deleteNotification(req.params.notificationId);
      res.json({ success });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/notifications/statistics',
  requirePermission('accounting.notifications.view'),
  async (req, res) => {
    try {
      const statistics = accountingNotifications.getNotificationStatistics();
      res.json({ success: true, data: statistics });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Backup ==========

router.post('/backup/full', requirePermission('accounting.backup.edit'), async (req, res) => {
  try {
    const backup = accountingBackup.createFullBackup(req.body);
    res.json({ success: true, data: backup });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/backup/accounts', requirePermission('accounting.backup.edit'), async (req, res) => {
  try {
    const backup = accountingBackup.createAccountsBackup(req.body);
    res.json({ success: true, data: backup });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/backup/invoices', requirePermission('accounting.backup.edit'), async (req, res) => {
  try {
    const backup = accountingBackup.createInvoicesBackup(req.body);
    res.json({ success: true, data: backup });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post(
  '/backup/:backupId/restore',
  requirePermission('accounting.backup.edit'),
  async (req, res) => {
    try {
      const result = accountingBackup.restoreBackup(req.params.backupId, req.body);
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get('/backup', requirePermission('accounting.backup.view'), async (req, res) => {
  try {
    const backups = accountingBackup.getBackups(req.query);
    res.json({ success: true, data: backups });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.delete(
  '/backup/:backupId',
  requirePermission('accounting.backup.edit'),
  async (req, res) => {
    try {
      const success = accountingBackup.deleteBackup(req.params.backupId);
      res.json({ success });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.post('/backup/cleanup', requirePermission('accounting.backup.edit'), async (req, res) => {
  try {
    const deletedCount = accountingBackup.cleanupOldBackups();
    res.json({ success: true, deletedCount });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/backup/statistics', requirePermission('accounting.backup.view'), async (req, res) => {
  try {
    const statistics = accountingBackup.getBackupStatistics();
    res.json({ success: true, data: statistics });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
