/**
 * 💰 Accounting Routes
 * API routes for comprehensive accounting system
 */

const express = require('express');
const router = express.Router();

// Mock data storage (replace with database)
const accounts = [];
const journalEntries = [];
const transactions = [];
const budgets = [];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Accounts (Chart of Accounts) ====================

/**
 * GET /api/accounting/accounts
 * Get all accounts
 */
router.get('/accounts', async (req, res) => {
  try {
    res.json({
      success: true,
      data: accounts,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * GET /api/accounting/accounts/:id
 * Get account by ID
 */
router.get('/accounts/:id', async (req, res) => {
  try {
    const account = accounts.find(a => a.id === parseInt(req.params.id));
    if (!account) {
      return res.status(404).json({
        success: false,
        error: 'Account not found',
      });
    }
    res.json({
      success: true,
      data: account,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * POST /api/accounting/accounts
 * Create new account
 */
router.post('/accounts', async (req, res) => {
  try {
    const account = {
      id: accounts.length > 0 ? Math.max(...accounts.map(a => a.id)) + 1 : 1,
      ...req.body,
      balance: req.body.openingBalance || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    accounts.push(account);

    emitEvent('accounting:account:updated', {
      action: 'create',
      entityId: account.id,
      data: account,
    });

    res.json({
      success: true,
      data: account,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * PUT /api/accounting/accounts/:id
 * Update account
 */
router.put('/accounts/:id', async (req, res) => {
  try {
    const index = accounts.findIndex(a => a.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Account not found',
      });
    }

    accounts[index] = {
      ...accounts[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    emitEvent('accounting:account:updated', {
      action: 'update',
      entityId: accounts[index].id,
      data: accounts[index],
    });

    res.json({
      success: true,
      data: accounts[index],
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * DELETE /api/accounting/accounts/:id
 * Delete account
 */
router.delete('/accounts/:id', async (req, res) => {
  try {
    const index = accounts.findIndex(a => a.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Account not found',
      });
    }

    accounts.splice(index, 1);

    emitEvent('accounting:account:updated', {
      action: 'delete',
      entityId: parseInt(req.params.id),
    });

    res.json({
      success: true,
      message: 'Account deleted successfully',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Journal Entries ====================

/**
 * GET /api/accounting/journal-entries
 * Get all journal entries
 */
router.get('/journal-entries', async (req, res) => {
  try {
    const { startDate, endDate, status } = req.query;
    let filtered = journalEntries;

    if (startDate && endDate) {
      filtered = filtered.filter(entry => {
        const entryDate = new Date(entry.date || entry.createdAt);
        return entryDate >= new Date(startDate) && entryDate <= new Date(endDate);
      });
    }

    if (status) {
      filtered = filtered.filter(entry => entry.status === status);
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * GET /api/accounting/journal-entries/:id
 * Get journal entry by ID
 */
router.get('/journal-entries/:id', async (req, res) => {
  try {
    const entry = journalEntries.find(e => e.id === parseInt(req.params.id));
    if (!entry) {
      return res.status(404).json({
        success: false,
        error: 'Journal entry not found',
      });
    }
    res.json({
      success: true,
      data: entry,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * POST /api/accounting/journal-entries
 * Create new journal entry
 */
router.post('/journal-entries', async (req, res) => {
  try {
    const { entries } = req.body;

    // Validate entry balance
    const totalDebit = entries.reduce((sum, e) => sum + (e.debit || 0), 0);
    const totalCredit = entries.reduce((sum, e) => sum + (e.credit || 0), 0);

    if (Math.abs(totalDebit - totalCredit) > 0.01) {
      return res.status(400).json({
        success: false,
        error: 'القيد غير متوازن. يجب أن يكون مجموع المدين يساوي مجموع الدائن',
      });
    }

    const entry = {
      id: journalEntries.length > 0 ? Math.max(...journalEntries.map(e => e.id)) + 1 : 1,
      ...req.body,
      totalDebit,
      totalCredit,
      status: req.body.status || 'draft',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    journalEntries.push(entry);

    // Apply entry to accounts if approved
    if (entry.status === 'approved' || entry.status === 'posted') {
      applyJournalEntryToAccounts(entry);
    }

    emitEvent('accounting:journal:updated', {
      action: 'create',
      entityId: entry.id,
      data: entry,
    });

    res.json({
      success: true,
      data: entry,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * PUT /api/accounting/journal-entries/:id
 * Update journal entry
 */
router.put('/journal-entries/:id', async (req, res) => {
  try {
    const index = journalEntries.findIndex(e => e.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Journal entry not found',
      });
    }

    const oldEntry = journalEntries[index];
    const { entries } = req.body;

    // Validate entry balance if entries are being updated
    if (entries) {
      const totalDebit = entries.reduce((sum, e) => sum + (e.debit || 0), 0);
      const totalCredit = entries.reduce((sum, e) => sum + (e.credit || 0), 0);

      if (Math.abs(totalDebit - totalCredit) > 0.01) {
        return res.status(400).json({
          success: false,
          error: 'القيد غير متوازن',
        });
      }

      req.body.totalDebit = totalDebit;
      req.body.totalCredit = totalCredit;
    }

    journalEntries[index] = {
      ...journalEntries[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    // Reapply entry if status changed to approved/posted
    if (req.body.status === 'approved' || req.body.status === 'posted') {
      if (oldEntry.status !== 'approved' && oldEntry.status !== 'posted') {
        applyJournalEntryToAccounts(journalEntries[index]);
      }
    }

    emitEvent('accounting:journal:updated', {
      action: 'update',
      entityId: journalEntries[index].id,
      data: journalEntries[index],
    });

    res.json({
      success: true,
      data: journalEntries[index],
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * DELETE /api/accounting/journal-entries/:id
 * Delete journal entry
 */
router.delete('/journal-entries/:id', async (req, res) => {
  try {
    const index = journalEntries.findIndex(e => e.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Journal entry not found',
      });
    }

    journalEntries.splice(index, 1);

    emitEvent('accounting:journal:updated', {
      action: 'delete',
      entityId: parseInt(req.params.id),
    });

    res.json({
      success: true,
      message: 'Journal entry deleted successfully',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Financial Reports ====================

/**
 * POST /api/accounting/reports/generate
 * Generate financial report
 */
router.post('/reports/generate', async (req, res) => {
  try {
    const { type, period } = req.body;

    let report = null;

    switch (type) {
      case 'balance-sheet':
        report = generateBalanceSheet(period);
        break;
      case 'income-statement':
        report = generateIncomeStatement(period);
        break;
      case 'cash-flow':
        report = generateCashFlow(period);
        break;
      default:
        return res.status(400).json({
          success: false,
          error: 'Invalid report type',
        });
    }

    res.json({
      success: true,
      data: report,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Budgets ====================

/**
 * GET /api/accounting/budgets
 * Get all budgets
 */
router.get('/budgets', async (req, res) => {
  try {
    res.json({
      success: true,
      data: budgets,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * POST /api/accounting/budgets
 * Create new budget
 */
router.post('/budgets', async (req, res) => {
  try {
    const budget = {
      id: budgets.length > 0 ? Math.max(...budgets.map(b => b.id)) + 1 : 1,
      ...req.body,
      spent: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    budgets.push(budget);

    emitEvent('accounting:budget:updated', {
      action: 'create',
      entityId: budget.id,
      data: budget,
    });

    res.json({
      success: true,
      data: budget,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Helper Functions ====================

function applyJournalEntryToAccounts(entry) {
  entry.entries.forEach(e => {
    const account = accounts.find(a => a.id === e.accountId);
    if (account) {
      if (account.type === 'assets' || account.type === 'expenses') {
        account.balance = (account.balance || 0) + (e.debit || 0) - (e.credit || 0);
      } else {
        account.balance = (account.balance || 0) + (e.credit || 0) - (e.debit || 0);
      }
      account.updatedAt = new Date().toISOString();
    }
  });

  emitEvent('accounting:account:updated', {
    action: 'update',
    data: accounts,
  });
}

function generateBalanceSheet(period) {
  const assets = accounts
    .filter(a => a.type === 'assets')
    .reduce((sum, a) => sum + (a.balance || 0), 0);
  const liabilities = accounts
    .filter(a => a.type === 'liabilities')
    .reduce((sum, a) => sum + (a.balance || 0), 0);
  const equity = accounts
    .filter(a => a.type === 'equity')
    .reduce((sum, a) => sum + (a.balance || 0), 0);

  return {
    type: 'balance-sheet',
    period,
    assets: { total: assets },
    liabilities: { total: liabilities },
    equity: { total: equity },
    total: assets,
  };
}

function generateIncomeStatement(period) {
  const revenue = accounts
    .filter(a => a.type === 'revenue')
    .reduce((sum, a) => sum + (a.balance || 0), 0);
  const expenses = accounts
    .filter(a => a.type === 'expenses')
    .reduce((sum, a) => sum + (a.balance || 0), 0);
  const netIncome = revenue - expenses;

  return {
    type: 'income-statement',
    period,
    revenue: { total: revenue },
    expenses: { total: expenses },
    netIncome,
  };
}

function generateCashFlow(period) {
  // TODO: Implement cash flow calculation
  return {
    type: 'cash-flow',
    period,
    operating: 0,
    investing: 0,
    financing: 0,
    netChange: 0,
  };
}

module.exports = { router, setIO };
