/**
 * 🎯 Activities Management Routes
 * مسارات إدارة الأنشطة
 */

const express = require('express');
const router = express.Router();

const Activity = (() => {
  try {
    return require('../models/Activity');
  } catch (e) {
    return {
      find: async () => [],
      findById: async () => null,
      findOne: async () => null,
      create: async () => ({}),
      updateOne: async () => ({ modifiedCount: 0 }),
      deleteOne: async () => ({ deletedCount: 0 }),
      countDocuments: async () => 0,
      aggregate: () => ({
        sort: () => ({ limit: () => ({ skip: () => ({ toArray: async () => [] }) }) }),
      }),
    };
  }
})();

const authenticateToken = require('../middleware/authenticateToken');
const logger = require('../../shared/logging/logger');

// Real-time event emitter (if available)
let io = null;
try {
  const realtimeModule = require('../realtime');
  io = realtimeModule.io;
} catch (error) {
  // Real-time not available
}

/**
 * Emit real-time event
 */
function emitEvent(eventType, entityType, data) {
  if (io) {
    io.emit('activities:update', {
      action: eventType,
      entityType: entityType,
      entityId: data.id,
      data: data,
    });
  }
}

// Apply authentication to all routes
router.use(authenticateToken);

/**
 * Activities Routes
 */
router.get('/', async (req, res) => {
  try {
    const activities = await Activity.findAll({
      order: [['createdAt', 'DESC']],
    });
    res.json(activities);
  } catch (error) {
    logger.error('Error fetching activities:', error);
    res.status(500).json({ error: 'خطأ في جلب الأنشطة' });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const activity = await Activity.findByPk(req.params.id);
    if (!activity) {
      return res.status(404).json({ error: 'النشاط غير موجود' });
    }
    res.json(activity);
  } catch (error) {
    logger.error('Error fetching activity:', error);
    res.status(500).json({ error: 'خطأ في جلب النشاط' });
  }
});

router.post('/', async (req, res) => {
  try {
    const activity = await Activity.create(req.body);
    emitEvent('create', 'activity', activity);
    logger.info('Activity created', { id: activity.id, name: activity.name });
    res.status(201).json(activity);
  } catch (error) {
    logger.error('Error creating activity:', error);
    res.status(400).json({ error: 'خطأ في إضافة النشاط' });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const [updated] = await Activity.update(req.body, {
      where: { id: req.params.id },
    });
    if (updated) {
      const activity = await Activity.findByPk(req.params.id);
      emitEvent('update', 'activity', activity);
      logger.info('Activity updated', { id: activity.id });
      res.json(activity);
    } else {
      res.status(404).json({ error: 'النشاط غير موجود' });
    }
  } catch (error) {
    logger.error('Error updating activity:', error);
    res.status(400).json({ error: 'خطأ في تحديث النشاط' });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    const deleted = await Activity.destroy({
      where: { id: req.params.id },
    });
    if (deleted) {
      emitEvent('delete', 'activity', { id: req.params.id });
      logger.info('Activity deleted', { id: req.params.id });
      res.json({ message: 'تم حذف النشاط بنجاح' });
    } else {
      res.status(404).json({ error: 'النشاط غير موجود' });
    }
  } catch (error) {
    logger.error('Error deleting activity:', error);
    res.status(400).json({ error: 'خطأ في حذف النشاط' });
  }
});

module.exports = router;
