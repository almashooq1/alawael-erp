/**
 * Additional Systems Routes V11
 * Routes for continuous improvement, innovation, sustainability, knowledge, and organizational development
 */

const express = require('express');
const router = express.Router();

// Continuous Improvement Advanced
const ContinuousImprovementAdvancedManager = require('../../shared/utils/continuous-improvement-advanced-manager');
const improvementManager = new ContinuousImprovementAdvancedManager();

router.post('/improvement/initiatives', async (req, res) => {
  try {
    const initiative = improvementManager.createInitiative(req.body);
    res.json({ success: true, data: initiative });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/improvement/kaizen', async (req, res) => {
  try {
    const kaizen = improvementManager.recordKaizen(req.body);
    res.json({ success: true, data: kaizen });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/improvement/report', async (req, res) => {
  try {
    const report = improvementManager.getImprovementReport();
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Innovation Advanced
const InnovationAdvancedManager = require('../../shared/utils/innovation-advanced-manager');
const innovationManager = new InnovationAdvancedManager();

router.post('/innovation/ideas', async (req, res) => {
  try {
    const idea = innovationManager.addIdea(req.body);
    res.json({ success: true, data: idea });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/innovation/projects', async (req, res) => {
  try {
    const project = innovationManager.createProject(req.body);
    res.json({ success: true, data: project });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/innovation/patents', async (req, res) => {
  try {
    const patent = innovationManager.addPatent(req.body);
    res.json({ success: true, data: patent });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/innovation/report', async (req, res) => {
  try {
    const report = innovationManager.getInnovationReport();
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Sustainability Advanced
const SustainabilityAdvancedManager = require('../../shared/utils/sustainability-advanced-manager');
const sustainabilityManager = new SustainabilityAdvancedManager();

router.post('/sustainability/initiatives', async (req, res) => {
  try {
    const initiative = sustainabilityManager.createInitiative(req.body);
    res.json({ success: true, data: initiative });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/sustainability/goals', async (req, res) => {
  try {
    const goal = sustainabilityManager.addGoal(req.body);
    res.json({ success: true, data: goal });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/sustainability/report', async (req, res) => {
  try {
    const report = sustainabilityManager.getSustainabilityReport();
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Knowledge Advanced
const KnowledgeAdvancedManager = require('../../shared/utils/knowledge-advanced-manager');
const knowledgeManager = new KnowledgeAdvancedManager();

router.post('/knowledge/articles', async (req, res) => {
  try {
    const article = knowledgeManager.addArticle(req.body);
    res.json({ success: true, data: article });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/knowledge/search', async (req, res) => {
  try {
    const results = knowledgeManager.searchKnowledge(req.query.q, req.query);
    res.json({ success: true, data: results });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/knowledge/report', async (req, res) => {
  try {
    const report = knowledgeManager.getKnowledgeReport();
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Organizational Development Advanced
const OrganizationalDevelopmentAdvancedManager = require('../../shared/utils/organizational-development-advanced-manager');
const orgDevManager = new OrganizationalDevelopmentAdvancedManager();

router.post('/org-dev/initiatives', async (req, res) => {
  try {
    const initiative = orgDevManager.createInitiative(req.body);
    res.json({ success: true, data: initiative });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/org-dev/strategies', async (req, res) => {
  try {
    const strategy = orgDevManager.createStrategy(req.body);
    res.json({ success: true, data: strategy });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/org-dev/kpis', async (req, res) => {
  try {
    const kpi = orgDevManager.addKPI(req.body);
    res.json({ success: true, data: kpi });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/org-dev/report', async (req, res) => {
  try {
    const report = orgDevManager.getDevelopmentReport();
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
