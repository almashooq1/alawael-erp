/**
 * Additional Systems Routes V2
 * Routes for the new additional systems
 */

const express = require('express');
const router = express.Router();

// Events & Activities
const EventsActivitiesManager = require('../../shared/utils/events-activities-manager');
const eventsManager = new EventsActivitiesManager();

router.post('/events', async (req, res) => {
  try {
    const event = eventsManager.createEvent(req.body);
    res.json({ success: true, data: event });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/events', async (req, res) => {
  try {
    const events = eventsManager.getEvents(req.query);
    res.json({ success: true, data: events });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/events/:id/register', async (req, res) => {
  try {
    const participant = eventsManager.registerParticipant(req.params.id, req.body);
    res.json({ success: true, data: participant });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/events/stats', async (req, res) => {
  try {
    const stats = eventsManager.getEventsStats(
      req.query.startDate || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
      req.query.endDate || new Date().toISOString()
    );
    res.json({ success: true, data: stats });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Complaints & Suggestions
const ComplaintsSuggestionsManager = require('../../shared/utils/complaints-suggestions-manager');
const complaintsManager = new ComplaintsSuggestionsManager();

router.post('/complaints', async (req, res) => {
  try {
    const complaint = complaintsManager.submitComplaint(req.body);
    res.json({ success: true, data: complaint });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/complaints', async (req, res) => {
  try {
    const complaints = complaintsManager.getComplaints(req.query);
    res.json({ success: true, data: complaints });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/complaints/:id/status', async (req, res) => {
  try {
    const complaint = complaintsManager.updateComplaintStatus(
      req.params.id,
      req.body.status,
      req.body.resolution
    );
    res.json({ success: true, data: complaint });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/suggestions', async (req, res) => {
  try {
    const suggestion = complaintsManager.submitSuggestion(req.body);
    res.json({ success: true, data: suggestion });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/complaints-suggestions/stats', async (req, res) => {
  try {
    const stats = complaintsManager.getStats();
    res.json({ success: true, data: stats });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Quality & Accreditation
const QualityAccreditationManager = require('../../shared/utils/quality-accreditation-manager');
const qualityManager = new QualityAccreditationManager();

router.post('/quality/standards', async (req, res) => {
  try {
    const standard = qualityManager.addStandard(req.body);
    res.json({ success: true, data: standard });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/quality/assessments', async (req, res) => {
  try {
    const assessment = qualityManager.conductAssessment(req.body);
    res.json({ success: true, data: assessment });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/quality/audits', async (req, res) => {
  try {
    const audit = qualityManager.conductAudit(req.body);
    res.json({ success: true, data: audit });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/quality/report', async (req, res) => {
  try {
    const report = qualityManager.getQualityReport(
      req.query.startDate || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
      req.query.endDate || new Date().toISOString()
    );
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Fixed Assets
const FixedAssetsManager = require('../../shared/utils/fixed-assets-manager');
const assetsManager = new FixedAssetsManager();

router.post('/assets', async (req, res) => {
  try {
    const asset = assetsManager.addAsset(req.body);
    res.json({ success: true, data: asset });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/assets', async (req, res) => {
  try {
    const assets = assetsManager.getAssets(req.query);
    res.json({ success: true, data: assets });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/assets/:id/depreciation', async (req, res) => {
  try {
    const depreciation = assetsManager.calculateDepreciation(
      req.params.id,
      req.body.asOfDate ? new Date(req.body.asOfDate) : new Date()
    );
    res.json({ success: true, data: depreciation });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/assets/report', async (req, res) => {
  try {
    const report = assetsManager.getAssetsReport();
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Contracts
const ContractsManager = require('../../shared/utils/contracts-manager');
const contractsManager = new ContractsManager();

router.post('/contracts', async (req, res) => {
  try {
    const contract = contractsManager.createContract(req.body);
    res.json({ success: true, data: contract });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/contracts', async (req, res) => {
  try {
    const contracts = contractsManager.getContracts(req.query);
    res.json({ success: true, data: contracts });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/contracts/:id/renew', async (req, res) => {
  try {
    const result = contractsManager.renewContract(req.params.id, req.body);
    res.json({ success: true, data: result });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/contracts/report', async (req, res) => {
  try {
    const report = contractsManager.getContractsReport();
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Funding & Grants
const FundingGrantsManager = require('../../shared/utils/funding-grants-manager');
const fundingManager = new FundingGrantsManager();

router.post('/grants', async (req, res) => {
  try {
    const grant = fundingManager.addGrant(req.body);
    res.json({ success: true, data: grant });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/grants/applications', async (req, res) => {
  try {
    const application = fundingManager.submitApplication(req.body);
    res.json({ success: true, data: application });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/grants/disbursements', async (req, res) => {
  try {
    const disbursement = fundingManager.recordDisbursement(req.body.grantId, req.body);
    res.json({ success: true, data: disbursement });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/grants/report', async (req, res) => {
  try {
    const report = fundingManager.getFundingReport();
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Advanced Communications
const AdvancedCommunicationsManager = require('../../shared/utils/advanced-communications-manager');
const communicationsManager = new AdvancedCommunicationsManager();

router.post('/communications/channels', async (req, res) => {
  try {
    const channel = communicationsManager.addChannel(req.body);
    res.json({ success: true, data: channel });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/communications/send', async (req, res) => {
  try {
    const message = communicationsManager.sendMessage(req.body);
    res.json({ success: true, data: message });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/communications/campaigns', async (req, res) => {
  try {
    const campaign = communicationsManager.createCampaign(req.body);
    res.json({ success: true, data: campaign });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/communications/stats', async (req, res) => {
  try {
    const stats = communicationsManager.getCommunicationsStats(
      req.query.startDate || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
      req.query.endDate || new Date().toISOString()
    );
    res.json({ success: true, data: stats });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Educational Content
const EducationalContentManager = require('../../shared/utils/educational-content-manager');
const contentManager = new EducationalContentManager();

router.post('/educational-content', async (req, res) => {
  try {
    const content = contentManager.addContent(req.body);
    res.json({ success: true, data: content });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/courses', async (req, res) => {
  try {
    const course = contentManager.createCourse(req.body);
    res.json({ success: true, data: course });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/courses/:id/enroll', async (req, res) => {
  try {
    const enrollment = contentManager.enrollInCourse(req.params.id, req.body.studentId);
    res.json({ success: true, data: enrollment });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/educational-content/stats', async (req, res) => {
  try {
    const stats = contentManager.getContentStats();
    res.json({ success: true, data: stats });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Evaluations & Surveys
const EvaluationsSurveysManager = require('../../shared/utils/evaluations-surveys-manager');
const surveysManager = new EvaluationsSurveysManager();

router.post('/surveys', async (req, res) => {
  try {
    const survey = surveysManager.createSurvey(req.body);
    res.json({ success: true, data: survey });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/surveys/:id/responses', async (req, res) => {
  try {
    const response = surveysManager.submitResponse(req.params.id, req.body);
    res.json({ success: true, data: response });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/surveys/:id/analyze', async (req, res) => {
  try {
    const analysis = surveysManager.analyzeSurvey(req.params.id);
    res.json({ success: true, data: analysis });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Emergency & Crisis
const EmergencyCrisisManager = require('../../shared/utils/emergency-crisis-manager');
const emergencyManager = new EmergencyCrisisManager();

router.post('/emergency/incidents', async (req, res) => {
  try {
    const incident = emergencyManager.reportIncident(req.body);
    res.json({ success: true, data: incident });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/emergency/plans', async (req, res) => {
  try {
    const plan = emergencyManager.createEmergencyPlan(req.body);
    res.json({ success: true, data: plan });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/emergency/incidents/:id/resolve', async (req, res) => {
  try {
    const incident = emergencyManager.resolveIncident(req.params.id, req.body);
    res.json({ success: true, data: incident });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/emergency/report', async (req, res) => {
  try {
    const report = emergencyManager.getEmergencyReport(
      req.query.startDate || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
      req.query.endDate || new Date().toISOString()
    );
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
