/**
 * Additional Systems Routes V4
 * Routes for the latest additional systems
 */

const express = require('express');
const router = express.Router();

// Branches & Centers
const BranchesCentersManager = require('../../shared/utils/branches-centers-manager');
const branchesManager = new BranchesCentersManager();

router.post('/branches', async (req, res) => {
  try {
    const branch = branchesManager.addBranch(req.body);
    res.json({ success: true, data: branch });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/branches', async (req, res) => {
  try {
    const branches = branchesManager.getBranches(req.query);
    res.json({ success: true, data: branches });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/branches/report', async (req, res) => {
  try {
    const report = branchesManager.getBranchesReport();
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Restaurant & Meals
const RestaurantMealsManager = require('../../shared/utils/restaurant-meals-manager');
const restaurantManager = new RestaurantMealsManager();

router.post('/restaurant/menus', async (req, res) => {
  try {
    const menu = restaurantManager.createMenu(req.body);
    res.json({ success: true, data: menu });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/restaurant/orders', async (req, res) => {
  try {
    const order = restaurantManager.createOrder(req.body);
    res.json({ success: true, data: order });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/restaurant/orders/:id/status', async (req, res) => {
  try {
    const order = restaurantManager.updateOrderStatus(req.params.id, req.body.status);
    res.json({ success: true, data: order });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/restaurant/report', async (req, res) => {
  try {
    const report = restaurantManager.getRestaurantReport(
      req.query.startDate || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
      req.query.endDate || new Date().toISOString()
    );
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Comprehensive Maintenance
const ComprehensiveMaintenanceManager = require('../../shared/utils/comprehensive-maintenance-manager');
const maintenanceManager = new ComprehensiveMaintenanceManager();

router.post('/maintenance/assets', async (req, res) => {
  try {
    const asset = maintenanceManager.addAsset(req.body);
    res.json({ success: true, data: asset });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/maintenance/work-orders', async (req, res) => {
  try {
    const workOrder = maintenanceManager.createWorkOrder(req.body);
    res.json({ success: true, data: workOrder });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/maintenance/work-orders/:id/complete', async (req, res) => {
  try {
    const workOrder = maintenanceManager.completeWorkOrder(req.params.id, req.body);
    res.json({ success: true, data: workOrder });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/maintenance/report', async (req, res) => {
  try {
    const report = maintenanceManager.getMaintenanceReport(
      req.query.startDate || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
      req.query.endDate || new Date().toISOString()
    );
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Security & Guarding
const SecurityGuardingManager = require('../../shared/utils/security-guarding-manager');
const securityManager = new SecurityGuardingManager();

router.post('/security/guards', async (req, res) => {
  try {
    const guard = securityManager.addGuard(req.body);
    res.json({ success: true, data: guard });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/security/shifts', async (req, res) => {
  try {
    const shift = securityManager.scheduleShift(req.body);
    res.json({ success: true, data: shift });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/security/incidents', async (req, res) => {
  try {
    const incident = securityManager.recordIncident(req.body);
    res.json({ success: true, data: incident });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/security/visitors', async (req, res) => {
  try {
    const visitor = securityManager.registerVisitor(req.body);
    res.json({ success: true, data: visitor });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/security/report', async (req, res) => {
  try {
    const report = securityManager.getSecurityReport(
      req.query.startDate || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
      req.query.endDate || new Date().toISOString()
    );
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Electronic Invoicing
const ElectronicInvoicingManager = require('../../shared/utils/electronic-invoicing-manager');
const invoicingManager = new ElectronicInvoicingManager();

router.post('/invoicing/electronic', async (req, res) => {
  try {
    const invoice = invoicingManager.createElectronicInvoice(req.body);
    res.json({ success: true, data: invoice });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/invoicing/verify/:uuid', async (req, res) => {
  try {
    const result = invoicingManager.verifyInvoice(req.params.uuid);
    res.json(result);
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/invoicing/send', async (req, res) => {
  try {
    const result = invoicingManager.sendInvoice(req.body.invoiceId, req.body);
    res.json(result);
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Call Center
const CallCenterManager = require('../../shared/utils/call-center-manager');
const callCenterManager = new CallCenterManager();

router.post('/call-center/agents', async (req, res) => {
  try {
    const agent = callCenterManager.addAgent(req.body);
    res.json({ success: true, data: agent });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/call-center/calls', async (req, res) => {
  try {
    const call = callCenterManager.logIncomingCall(req.body);
    res.json({ success: true, data: call });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/call-center/calls/:id/answer', async (req, res) => {
  try {
    const call = callCenterManager.answerCall(req.params.id, req.body.agentId);
    res.json({ success: true, data: call });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/call-center/calls/:id/end', async (req, res) => {
  try {
    const call = callCenterManager.endCall(req.params.id, req.body);
    res.json({ success: true, data: call });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/call-center/report', async (req, res) => {
  try {
    const report = callCenterManager.getCallCenterReport(
      req.query.startDate || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
      req.query.endDate || new Date().toISOString()
    );
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Advanced Funding
const AdvancedFundingGrantsManager = require('../../shared/utils/advanced-funding-grants-manager');
const advancedFundingManager = new AdvancedFundingGrantsManager();

router.post('/funding/grants', async (req, res) => {
  try {
    const grant = advancedFundingManager.addGrant(req.body);
    res.json({ success: true, data: grant });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/funding/budgets', async (req, res) => {
  try {
    const budget = advancedFundingManager.allocateBudget(req.body.grantId, req.body);
    res.json({ success: true, data: budget });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Partnerships & Alliances
const PartnershipsAlliancesManager = require('../../shared/utils/partnerships-alliances-manager');
const partnershipsManager = new PartnershipsAlliancesManager();

router.post('/partnerships', async (req, res) => {
  try {
    const partnership = partnershipsManager.createPartnership(req.body);
    res.json({ success: true, data: partnership });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/partnerships/mous', async (req, res) => {
  try {
    const mou = partnershipsManager.createMOU(req.body);
    res.json({ success: true, data: mou });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Continuous Improvement
const ContinuousImprovementManager = require('../../shared/utils/continuous-improvement-manager');
const improvementManager = new ContinuousImprovementManager();

router.post('/improvement', async (req, res) => {
  try {
    const improvement = improvementManager.recordImprovement(req.body);
    res.json({ success: true, data: improvement });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/improvement/kaizen', async (req, res) => {
  try {
    const kaizen = improvementManager.recordKaizen(req.body);
    res.json({ success: true, data: kaizen });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/improvement/report', async (req, res) => {
  try {
    const report = improvementManager.getImprovementReport();
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
