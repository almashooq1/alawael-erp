/**
 * Additional Systems Routes V5
 * Routes for the latest additional systems
 */

const express = require('express');
const router = express.Router();

// Documents & Files
const DocumentsFilesManager = require('../../shared/utils/documents-files-manager');
const documentsManager = new DocumentsFilesManager();

router.post('/documents', async (req, res) => {
  try {
    const document = documentsManager.addDocument(req.body);
    res.json({ success: true, data: document });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/documents', async (req, res) => {
  try {
    const documents = documentsManager.getDocuments(req.query);
    res.json({ success: true, data: documents });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/documents/search', async (req, res) => {
  try {
    const documents = documentsManager.searchDocuments(req.query.q, req.query);
    res.json({ success: true, data: documents });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/documents/report', async (req, res) => {
  try {
    const report = documentsManager.getDocumentsReport();
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Meetings
const MeetingsManager = require('../../shared/utils/meetings-manager');
const meetingsManager = new MeetingsManager();

router.post('/meetings', async (req, res) => {
  try {
    const meeting = meetingsManager.createMeeting(req.body);
    res.json({ success: true, data: meeting });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/meetings/:id/attendees', async (req, res) => {
  try {
    const attendee = meetingsManager.addAttendee(req.params.id, req.body);
    res.json({ success: true, data: attendee });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/meetings/:id/minutes', async (req, res) => {
  try {
    const minutes = meetingsManager.createMinutes(req.params.id, req.body);
    res.json({ success: true, data: minutes });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/meetings/report', async (req, res) => {
  try {
    const report = meetingsManager.getMeetingsReport(
      req.query.startDate || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
      req.query.endDate || new Date().toISOString()
    );
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Daily Tasks
const DailyTasksManager = require('../../shared/utils/daily-tasks-manager');
const tasksManager = new DailyTasksManager();

router.post('/tasks', async (req, res) => {
  try {
    const task = tasksManager.addTask(req.body);
    res.json({ success: true, data: task });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/tasks/:id/status', async (req, res) => {
  try {
    const task = tasksManager.updateTaskStatus(req.params.id, req.body.status);
    res.json({ success: true, data: task });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/tasks/report', async (req, res) => {
  try {
    const report = tasksManager.getTasksReport(
      req.query.startDate || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
      req.query.endDate || new Date().toISOString()
    );
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Certifications & Accreditations
const CertificationsAccreditationsManager = require('../../shared/utils/certifications-accreditations-manager');
const certificationsManager = new CertificationsAccreditationsManager();

router.post('/certifications', async (req, res) => {
  try {
    const certification = certificationsManager.addCertification(req.body);
    res.json({ success: true, data: certification });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/certifications/:id/requirements', async (req, res) => {
  try {
    const requirement = certificationsManager.addRequirement(req.params.id, req.body);
    res.json({ success: true, data: requirement });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Advanced Evaluations & Surveys
const AdvancedEvaluationsSurveysManager = require('../../shared/utils/advanced-evaluations-surveys-manager');
const surveysManager = new AdvancedEvaluationsSurveysManager();

router.post('/surveys', async (req, res) => {
  try {
    const survey = surveysManager.createSurvey(req.body);
    res.json({ success: true, data: survey });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/surveys/:id/questions', async (req, res) => {
  try {
    const question = surveysManager.addQuestion(req.params.id, req.body);
    res.json({ success: true, data: question });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/surveys/:id/responses', async (req, res) => {
  try {
    const response = surveysManager.submitResponse(req.params.id, req.body);
    res.json({ success: true, data: response });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/surveys/:id/analyze', async (req, res) => {
  try {
    const analysis = surveysManager.analyzeSurvey(req.params.id);
    res.json({ success: true, data: analysis });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Digital Content
const DigitalContentManager = require('../../shared/utils/digital-content-manager');
const contentManager = new DigitalContentManager();

router.post('/content', async (req, res) => {
  try {
    const content = contentManager.addContent(req.body);
    res.json({ success: true, data: content });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/content/search', async (req, res) => {
  try {
    const content = contentManager.searchContent(req.query.q, req.query);
    res.json({ success: true, data: content });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Advanced PR
const AdvancedPRManager = require('../../shared/utils/advanced-pr-manager');
const prManager = new AdvancedPRManager();

router.post('/pr/campaigns', async (req, res) => {
  try {
    const campaign = prManager.createCampaign(req.body);
    res.json({ success: true, data: campaign });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/pr/press-releases', async (req, res) => {
  try {
    const pressRelease = prManager.addPressRelease(req.body);
    res.json({ success: true, data: pressRelease });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Advanced Volunteers
const AdvancedVolunteersManager = require('../../shared/utils/advanced-volunteers-manager');
const volunteersManager = new AdvancedVolunteersManager();

router.post('/volunteers', async (req, res) => {
  try {
    const volunteer = volunteersManager.addVolunteer(req.body);
    res.json({ success: true, data: volunteer });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/volunteers/programs', async (req, res) => {
  try {
    const program = volunteersManager.createProgram(req.body);
    res.json({ success: true, data: program });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/volunteers/hours', async (req, res) => {
  try {
    const hourLog = volunteersManager.logHours(req.body.volunteerId, req.body);
    res.json({ success: true, data: hourLog });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
