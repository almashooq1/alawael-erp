/**
 * Additional Systems Routes V6
 * Routes for the latest additional systems
 */

const express = require('express');
const router = express.Router();

// Ticketing & Support
const TicketingSupportManager = require('../../shared/utils/ticketing-support-manager');
const ticketingManager = new TicketingSupportManager();

router.post('/tickets', async (req, res) => {
  try {
    const ticket = ticketingManager.createTicket(req.body);
    res.json({ success: true, data: ticket });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/tickets/:id/assign', async (req, res) => {
  try {
    const ticket = ticketingManager.assignTicket(req.params.id, req.body.agentId);
    res.json({ success: true, data: ticket });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/tickets/:id/resolve', async (req, res) => {
  try {
    const ticket = ticketingManager.resolveTicket(req.params.id, req.body);
    res.json({ success: true, data: ticket });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/tickets/report', async (req, res) => {
  try {
    const report = ticketingManager.getTicketsReport(
      req.query.startDate || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
      req.query.endDate || new Date().toISOString()
    );
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Educational Resources
const EducationalResourcesManager = require('../../shared/utils/educational-resources-manager');
const resourcesManager = new EducationalResourcesManager();

router.post('/resources', async (req, res) => {
  try {
    const resource = resourcesManager.addResource(req.body);
    res.json({ success: true, data: resource });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/resources/courses', async (req, res) => {
  try {
    const course = resourcesManager.createCourse(req.body);
    res.json({ success: true, data: course });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/resources/courses/:id/enroll', async (req, res) => {
  try {
    const enrollment = resourcesManager.enrollInCourse(req.params.id, req.body);
    res.json({ success: true, data: enrollment });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Advanced Medical Assessments
const AdvancedMedicalAssessmentsManager = require('../../shared/utils/advanced-medical-assessments-manager');
const assessmentsManager = new AdvancedMedicalAssessmentsManager();

router.post('/assessments/medical', async (req, res) => {
  try {
    const assessment = assessmentsManager.createAssessment(req.body);
    res.json({ success: true, data: assessment });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/assessments/:id/results', async (req, res) => {
  try {
    const result = assessmentsManager.saveResults(req.params.id, req.body);
    res.json({ success: true, data: result });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/assessments/:id/review', async (req, res) => {
  try {
    const assessment = assessmentsManager.reviewAssessment(req.params.id, req.body);
    res.json({ success: true, data: assessment });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Specialized Rehabilitation Programs
const SpecializedRehabilitationProgramsManager = require('../../shared/utils/specialized-rehabilitation-programs-manager');
const programsManager = new SpecializedRehabilitationProgramsManager();

router.post('/programs/rehabilitation', async (req, res) => {
  try {
    const program = programsManager.createProgram(req.body);
    res.json({ success: true, data: program });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/programs/:id/participants', async (req, res) => {
  try {
    const participant = programsManager.addParticipant(req.params.id, req.body);
    res.json({ success: true, data: participant });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/programs/:id/sessions', async (req, res) => {
  try {
    const session = programsManager.recordSession(req.params.id, req.body);
    res.json({ success: true, data: session });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Professional Development
const ProfessionalDevelopmentManager = require('../../shared/utils/professional-development-manager');
const developmentManager = new ProfessionalDevelopmentManager();

router.post('/development/courses', async (req, res) => {
  try {
    const course = developmentManager.addCourse(req.body);
    res.json({ success: true, data: course });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/development/enroll', async (req, res) => {
  try {
    const enrollment = developmentManager.enrollEmployee(
      req.body.courseId,
      req.body.employeeId,
      req.body
    );
    res.json({ success: true, data: enrollment });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Advanced Quality & Accreditation
const AdvancedQualityAccreditationManager = require('../../shared/utils/advanced-quality-accreditation-manager');
const qualityManager = new AdvancedQualityAccreditationManager();

router.post('/quality/audits', async (req, res) => {
  try {
    const audit = qualityManager.createAudit(req.body);
    res.json({ success: true, data: audit });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/quality/non-conformities', async (req, res) => {
  try {
    const nc = qualityManager.recordNonConformity(req.body.auditId, req.body);
    res.json({ success: true, data: nc });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Advanced Strategic Partnerships
const AdvancedStrategicPartnershipsManager = require('../../shared/utils/advanced-strategic-partnerships-manager');
const partnershipsManager = new AdvancedStrategicPartnershipsManager();

router.post('/partnerships/strategic', async (req, res) => {
  try {
    const partnership = partnershipsManager.createPartnership(req.body);
    res.json({ success: true, data: partnership });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/partnerships/:id/collaborations', async (req, res) => {
  try {
    const collaboration = partnershipsManager.recordCollaboration(req.params.id, req.body);
    res.json({ success: true, data: collaboration });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
