/**
 * Additional Systems Routes V8
 * Routes for payroll, tasks, and correspondence
 */

const express = require('express');
const router = express.Router();

// Payroll Management
const PayrollManager = require('../../shared/utils/payroll-manager');
const payrollManager = new PayrollManager();

router.post('/payroll/employees', async (req, res) => {
  try {
    const employee = payrollManager.addEmployee(req.body);
    res.json({ success: true, data: employee });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/payroll/generate', async (req, res) => {
  try {
    const payroll = payrollManager.generatePayroll(req.body.employeeId, req.body);
    res.json({ success: true, data: payroll });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/payroll/bonuses', async (req, res) => {
  try {
    const bonus = payrollManager.addBonus(req.body.employeeId, req.body);
    res.json({ success: true, data: bonus });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/payroll/report', async (req, res) => {
  try {
    const report = payrollManager.getPayrollReport(req.query.period);
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Tasks & Assignments
const TasksAssignmentsManager = require('../../shared/utils/tasks-assignments-manager');
const tasksManager = new TasksAssignmentsManager();

router.post('/tasks', async (req, res) => {
  try {
    const task = tasksManager.createTask(req.body);
    res.json({ success: true, data: task });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/tasks/:id/status', async (req, res) => {
  try {
    const task = tasksManager.updateTaskStatus(req.params.id, req.body.status);
    res.json({ success: true, data: task });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/tasks/:id/comments', async (req, res) => {
  try {
    const comment = tasksManager.addComment(req.params.id, req.body);
    res.json({ success: true, data: comment });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/tasks/report', async (req, res) => {
  try {
    const report = tasksManager.getTasksReport(
      req.query.startDate || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
      req.query.endDate || new Date().toISOString()
    );
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Correspondence Management
const CorrespondenceManager = require('../../shared/utils/correspondence-manager');
const correspondenceManager = new CorrespondenceManager();

router.post('/correspondence', async (req, res) => {
  try {
    const correspondence = correspondenceManager.createCorrespondence(req.body);
    res.json({ success: true, data: correspondence });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/correspondence/:id/send', async (req, res) => {
  try {
    const correspondence = correspondenceManager.sendCorrespondence(req.params.id, req.body);
    res.json({ success: true, data: correspondence });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/correspondence/:id/reply', async (req, res) => {
  try {
    const reply = correspondenceManager.replyToCorrespondence(req.params.id, req.body);
    res.json({ success: true, data: reply });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/correspondence/report', async (req, res) => {
  try {
    const report = correspondenceManager.getCorrespondenceReport(
      req.query.startDate || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
      req.query.endDate || new Date().toISOString()
    );
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
