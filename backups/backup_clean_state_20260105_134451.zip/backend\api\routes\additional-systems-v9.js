/**
 * Additional Systems Routes V9
 * Routes for performance evaluation, training, budget, and contracts
 */

const express = require('express');
const router = express.Router();

// Performance Evaluation
const PerformanceEvaluationManager = require('../../shared/utils/performance-evaluation-manager');
const evaluationManager = new PerformanceEvaluationManager();

router.post('/evaluation', async (req, res) => {
  try {
    const evaluation = evaluationManager.createEvaluation(req.body);
    res.json({ success: true, data: evaluation });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/evaluation/criteria', async (req, res) => {
  try {
    const criterion = evaluationManager.addCriterion(req.body);
    res.json({ success: true, data: criterion });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/evaluation/promotions', async (req, res) => {
  try {
    const promotion = evaluationManager.requestPromotion(req.body.employeeId, req.body);
    res.json({ success: true, data: promotion });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/evaluation/promotions/:id/approve', async (req, res) => {
  try {
    const promotion = evaluationManager.approvePromotion(req.params.id, req.body.approverId);
    res.json({ success: true, data: promotion });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/evaluation/report', async (req, res) => {
  try {
    const report = evaluationManager.getEvaluationReport(
      req.query.startDate || new Date(Date.now() - 365 * 24 * 60 * 60 * 1000).toISOString(),
      req.query.endDate || new Date().toISOString()
    );
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Advanced Training & Development
const AdvancedTrainingDevelopmentManager = require('../../shared/utils/advanced-training-development-manager');
const trainingManager = new AdvancedTrainingDevelopmentManager();

router.post('/training/programs', async (req, res) => {
  try {
    const program = trainingManager.createProgram(req.body);
    res.json({ success: true, data: program });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/training/enroll', async (req, res) => {
  try {
    const enrollment = trainingManager.enrollInProgram(req.body.programId, req.body);
    res.json({ success: true, data: enrollment });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/training/certifications', async (req, res) => {
  try {
    const certification = trainingManager.addCertification(req.body.enrollmentId, req.body);
    res.json({ success: true, data: certification });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Budget Management
const BudgetManagementManager = require('../../shared/utils/budget-management-manager');
const budgetManager = new BudgetManagementManager();

router.post('/budget', async (req, res) => {
  try {
    const budget = budgetManager.createBudget(req.body);
    res.json({ success: true, data: budget });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/budget/:id/approve', async (req, res) => {
  try {
    const budget = budgetManager.approveBudget(req.params.id, req.body.approverId);
    res.json({ success: true, data: budget });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/budget/expenses', async (req, res) => {
  try {
    const expense = budgetManager.recordExpense(req.body.budgetId, req.body);
    res.json({ success: true, data: expense });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/budget/report', async (req, res) => {
  try {
    const report = budgetManager.getBudgetReport(req.query.fiscalYear || new Date().getFullYear());
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Contracts & Agreements
const ContractsAgreementsManager = require('../../shared/utils/contracts-agreements-manager');
const contractsManager = new ContractsAgreementsManager();

router.post('/contracts', async (req, res) => {
  try {
    const contract = contractsManager.createContract(req.body);
    res.json({ success: true, data: contract });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/contracts/:id/sign', async (req, res) => {
  try {
    const contract = contractsManager.signContract(req.params.id, req.body);
    res.json({ success: true, data: contract });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/contracts/:id/renew', async (req, res) => {
  try {
    const renewal = contractsManager.renewContract(req.params.id, req.body);
    res.json({ success: true, data: renewal });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/contracts/:id/terminate', async (req, res) => {
  try {
    const termination = contractsManager.terminateContract(req.params.id, req.body);
    res.json({ success: true, data: termination });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/contracts/report', async (req, res) => {
  try {
    const report = contractsManager.getContractsReport();
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
