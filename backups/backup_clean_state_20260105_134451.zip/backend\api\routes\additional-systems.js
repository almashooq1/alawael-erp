/**
 * Additional Systems Routes
 * Routes for all remaining systems
 */

const express = require('express');
const router = express.Router();

// Facilities
const FacilitiesManager = require('../../shared/utils/facilities-manager');
const facilitiesManager = new FacilitiesManager();

router.post('/facilities', async (req, res) => {
  try {
    const facility = facilitiesManager.addFacility(req.body);
    res.json({ success: true, data: facility });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/facilities', async (req, res) => {
  try {
    const facilities = facilitiesManager.getFacilities(req.query);
    res.json({ success: true, data: facilities });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/facilities/:id/book', async (req, res) => {
  try {
    const booking = facilitiesManager.bookFacility({ ...req.body, facilityId: req.params.id });
    res.json({ success: true, data: booking });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Certifications
const CertificationsManager = require('../../shared/utils/certifications-manager');
const certificationsManager = new CertificationsManager();

router.post('/certifications', async (req, res) => {
  try {
    const certificate = certificationsManager.issueCertificate(req.body);
    res.json({ success: true, data: certificate });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/certifications/verify/:number', async (req, res) => {
  try {
    const result = certificationsManager.verifyCertificate(req.params.number);
    res.json(result);
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Rehabilitation Programs
const RehabilitationProgramsManager = require('../../shared/utils/rehabilitation-programs-manager');
const programsManager = new RehabilitationProgramsManager();

router.post('/rehabilitation-programs', async (req, res) => {
  try {
    const program = programsManager.createProgram(req.body);
    res.json({ success: true, data: program });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/rehabilitation-programs/:id/enroll', async (req, res) => {
  try {
    const enrollment = programsManager.enrollPatient(req.params.id, req.body.patientId);
    res.json({ success: true, data: enrollment });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Training & Development
const TrainingDevelopmentManager = require('../../shared/utils/training-development-manager');
const trainingManager = new TrainingDevelopmentManager();

router.post('/training/courses', async (req, res) => {
  try {
    const course = trainingManager.createCourse(req.body);
    res.json({ success: true, data: course });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/training/enroll', async (req, res) => {
  try {
    const enrollment = trainingManager.enrollStaff(req.body.courseId, req.body.staffId);
    res.json({ success: true, data: enrollment });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Nutrition
const NutritionManager = require('../../shared/utils/nutrition-manager');
const nutritionManager = new NutritionManager();

router.post('/nutrition/meal-plans', async (req, res) => {
  try {
    const plan = nutritionManager.createMealPlan(req.body);
    res.json({ success: true, data: plan });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/nutrition/meals', async (req, res) => {
  try {
    const meal = nutritionManager.recordMeal(req.body);
    res.json({ success: true, data: meal });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Safety & Security
const SafetySecurityManager = require('../../shared/utils/safety-security-manager');
const safetyManager = new SafetySecurityManager();

router.post('/safety/incidents', async (req, res) => {
  try {
    const incident = safetyManager.recordIncident(req.body);
    res.json({ success: true, data: incident });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/safety/checks', async (req, res) => {
  try {
    const check = safetyManager.scheduleSafetyCheck(req.body);
    res.json({ success: true, data: check });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Library
const LibraryManager = require('../../shared/utils/library-manager');
const libraryManager = new LibraryManager();

router.post('/library/resources', async (req, res) => {
  try {
    const resource = libraryManager.addResource(req.body);
    res.json({ success: true, data: resource });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/library/borrow', async (req, res) => {
  try {
    const borrow = libraryManager.borrowResource(
      req.body.resourceId,
      req.body.borrowerId,
      req.body.dueDate
    );
    res.json({ success: true, data: borrow });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Research
const ResearchManager = require('../../shared/utils/research-manager');
const researchManager = new ResearchManager();

router.post('/research/studies', async (req, res) => {
  try {
    const study = researchManager.createStudy(req.body);
    res.json({ success: true, data: study });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/research/enroll', async (req, res) => {
  try {
    const enrollment = researchManager.enrollParticipant(req.body.studyId, req.body.participantId);
    res.json({ success: true, data: enrollment });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Public Relations
const PublicRelationsManager = require('../../shared/utils/public-relations-manager');
const prManager = new PublicRelationsManager();

router.post('/pr/events', async (req, res) => {
  try {
    const event = prManager.createEvent(req.body);
    res.json({ success: true, data: event });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/pr/partnerships', async (req, res) => {
  try {
    const partnership = prManager.addPartnership(req.body);
    res.json({ success: true, data: partnership });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Volunteers
const VolunteersManager = require('../../shared/utils/volunteers-manager');
const volunteersManager = new VolunteersManager();

router.post('/volunteers/register', async (req, res) => {
  try {
    const volunteer = volunteersManager.registerVolunteer(req.body);
    res.json({ success: true, data: volunteer });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/volunteers/activities', async (req, res) => {
  try {
    const activity = volunteersManager.recordActivity(req.body);
    res.json({ success: true, data: activity });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/volunteers/stats', async (req, res) => {
  try {
    const stats = volunteersManager.getVolunteerStats();
    res.json({ success: true, data: stats });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
