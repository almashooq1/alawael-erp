/**
 * 💰 Advanced Accounting & Financial Management Routes
 */

const express = require('express');
const router = express.Router();

const accounts = [];
const transactions = [];
const invoices = [];
const payments = [];
const expenses = [];
const revenues = [];
const budgets = [];
const reports = [];
const analytics = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/accounts', async (req, res) => {
  try {
    const { type } = req.query;
    let filtered = accounts;
    if (type) filtered = filtered.filter(a => a.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/accounts', async (req, res) => {
  try {
    const account = {
      id: accounts.length > 0 ? Math.max(...accounts.map(a => a.id)) + 1 : 1,
      ...req.body,
      type: req.body.type || 'bank',
      balance: req.body.balance || 0,
      transactionsCount: req.body.transactionsCount || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    accounts.push(account);
    emitEvent('advanced-accounting:updated', {
      action: 'create',
      entityType: 'account',
      entityId: account.id,
      data: account,
    });
    res.json({ success: true, data: account });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/transactions', async (req, res) => {
  try {
    const { type, category, status, accountId } = req.query;
    let filtered = transactions;
    if (type) filtered = filtered.filter(t => t.type === type);
    if (category) filtered = filtered.filter(t => t.category === category);
    if (status) filtered = filtered.filter(t => t.status === status);
    if (accountId)
      filtered = filtered.filter(
        t => t.fromAccountId === parseInt(accountId) || t.toAccountId === parseInt(accountId)
      );
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/transactions', async (req, res) => {
  try {
    const transaction = {
      id: transactions.length > 0 ? Math.max(...transactions.map(t => t.id)) + 1 : 1,
      ...req.body,
      type: req.body.type || 'expense',
      status: req.body.status || 'pending',
      amount: req.body.amount || 0,
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    transactions.push(transaction);

    // Update account balances
    if (transaction.fromAccountId) {
      const fromAccount = accounts.find(a => a.id === transaction.fromAccountId);
      if (fromAccount && transaction.type === 'expense') {
        fromAccount.balance = (fromAccount.balance || 0) - transaction.amount;
        fromAccount.transactionsCount = (fromAccount.transactionsCount || 0) + 1;
      }
    }
    if (transaction.toAccountId) {
      const toAccount = accounts.find(a => a.id === transaction.toAccountId);
      if (toAccount && transaction.type === 'income') {
        toAccount.balance = (toAccount.balance || 0) + transaction.amount;
        toAccount.transactionsCount = (toAccount.transactionsCount || 0) + 1;
      }
    }

    emitEvent('advanced-accounting:updated', {
      action: 'create',
      entityType: 'transaction',
      entityId: transaction.id,
      data: transaction,
    });
    res.json({ success: true, data: transaction });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/invoices', async (req, res) => {
  try {
    const { status, clientId } = req.query;
    let filtered = invoices;
    if (status) filtered = filtered.filter(i => i.status === status);
    if (clientId) filtered = filtered.filter(i => i.clientId === parseInt(clientId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/invoices', async (req, res) => {
  try {
    const invoice = {
      id: invoices.length > 0 ? Math.max(...invoices.map(i => i.id)) + 1 : 1,
      ...req.body,
      number: req.body.number || `INV-${Date.now()}`,
      status: req.body.status || 'unpaid',
      total: req.body.total || 0,
      paid: req.body.paid || 0,
      date: req.body.date || new Date().toISOString(),
      dueDate: req.body.dueDate || new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    invoices.push(invoice);
    emitEvent('advanced-accounting:updated', {
      action: 'create',
      entityType: 'invoice',
      entityId: invoice.id,
      data: invoice,
    });
    res.json({ success: true, data: invoice });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/payments', async (req, res) => {
  try {
    const { status, method, invoiceId } = req.query;
    let filtered = payments;
    if (status) filtered = filtered.filter(p => p.status === status);
    if (method) filtered = filtered.filter(p => p.method === method);
    if (invoiceId) filtered = filtered.filter(p => p.invoiceId === parseInt(invoiceId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/payments', async (req, res) => {
  try {
    const payment = {
      id: payments.length > 0 ? Math.max(...payments.map(p => p.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'pending',
      method: req.body.method || 'cash',
      amount: req.body.amount || 0,
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    payments.push(payment);

    // Update invoice if linked
    if (payment.invoiceId) {
      const invoice = invoices.find(i => i.id === payment.invoiceId);
      if (invoice) {
        invoice.paid = (invoice.paid || 0) + payment.amount;
        if (invoice.paid >= invoice.total) {
          invoice.status = 'paid';
        }
      }
    }

    emitEvent('advanced-accounting:updated', {
      action: 'create',
      entityType: 'payment',
      entityId: payment.id,
      data: payment,
    });
    res.json({ success: true, data: payment });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/expenses', async (req, res) => {
  try {
    const { category, date } = req.query;
    let filtered = expenses;
    if (category) filtered = filtered.filter(e => e.category === category);
    if (date) filtered = filtered.filter(e => e.date === date);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/expenses', async (req, res) => {
  try {
    const expense = {
      id: expenses.length > 0 ? Math.max(...expenses.map(e => e.id)) + 1 : 1,
      ...req.body,
      category: req.body.category || 'general',
      amount: req.body.amount || 0,
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    expenses.push(expense);
    emitEvent('advanced-accounting:updated', {
      action: 'create',
      entityType: 'expense',
      entityId: expense.id,
      data: expense,
    });
    res.json({ success: true, data: expense });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/revenues', async (req, res) => {
  try {
    const { category, date } = req.query;
    let filtered = revenues;
    if (category) filtered = filtered.filter(r => r.category === category);
    if (date) filtered = filtered.filter(r => r.date === date);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/revenues', async (req, res) => {
  try {
    const revenue = {
      id: revenues.length > 0 ? Math.max(...revenues.map(r => r.id)) + 1 : 1,
      ...req.body,
      category: req.body.category || 'general',
      amount: req.body.amount || 0,
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    revenues.push(revenue);
    emitEvent('advanced-accounting:updated', {
      action: 'create',
      entityType: 'revenue',
      entityId: revenue.id,
      data: revenue,
    });
    res.json({ success: true, data: revenue });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/budgets', async (req, res) => {
  try {
    const { period } = req.query;
    let filtered = budgets;
    if (period) filtered = filtered.filter(b => b.period === period);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/budgets', async (req, res) => {
  try {
    const budget = {
      id: budgets.length > 0 ? Math.max(...budgets.map(b => b.id)) + 1 : 1,
      ...req.body,
      allocated: req.body.allocated || 0,
      used: req.body.used || 0,
      period: req.body.period || new Date().toISOString().split('-').slice(0, 2).join('-'),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    budgets.push(budget);
    emitEvent('advanced-accounting:updated', {
      action: 'create',
      entityType: 'budget',
      entityId: budget.id,
      data: budget,
    });
    res.json({ success: true, data: budget });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/reports', async (req, res) => {
  try {
    const { type, period } = req.query;
    let filtered = reports;
    if (type) filtered = filtered.filter(r => r.type === type);
    if (period) filtered = filtered.filter(r => r.period === period);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/reports', async (req, res) => {
  try {
    const report = {
      id: reports.length > 0 ? Math.max(...reports.map(r => r.id)) + 1 : 1,
      ...req.body,
      type: req.body.type || 'general',
      period: req.body.period || new Date().toISOString().split('-').slice(0, 2).join('-'),
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    reports.push(report);
    emitEvent('advanced-accounting:updated', {
      action: 'create',
      entityType: 'report',
      entityId: report.id,
      data: report,
    });
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/analytics', async (req, res) => {
  try {
    const totalAccounts = accounts.length;
    const totalBalance = accounts.reduce((sum, a) => sum + (a.balance || 0), 0);
    const totalTransactions = transactions.length;
    const totalInvoices = invoices.length;
    const paidInvoices = invoices.filter(i => i.status === 'paid').length;
    const unpaidInvoices = invoices.filter(i => i.status === 'unpaid').length;
    const totalRevenue = revenues.reduce((sum, r) => sum + (r.amount || 0), 0);
    const totalExpenses = expenses.reduce((sum, e) => sum + (e.amount || 0), 0);
    const netProfit = totalRevenue - totalExpenses;
    const totalPayments = payments.reduce((sum, p) => sum + (p.amount || 0), 0);
    const totalBudgets = budgets.length;
    const totalBudgetAllocated = budgets.reduce((sum, b) => sum + (b.allocated || 0), 0);
    const totalBudgetUsed = budgets.reduce((sum, b) => sum + (b.used || 0), 0);

    const analyticsData = [
      {
        id: 1,
        metric: 'إجمالي الحسابات',
        value: totalAccounts,
        description: 'عدد الحسابات الكلي',
        trend: null,
      },
      {
        id: 2,
        metric: 'إجمالي الرصيد',
        value: `${totalBalance.toLocaleString()} ريال`,
        description: 'إجمالي رصيد جميع الحسابات',
        trend: null,
      },
      {
        id: 3,
        metric: 'إجمالي المعاملات',
        value: totalTransactions,
        description: 'عدد المعاملات الكلي',
        trend: null,
      },
      {
        id: 4,
        metric: 'إجمالي الفواتير',
        value: totalInvoices,
        description: 'عدد الفواتير الكلي',
        trend: null,
      },
      {
        id: 5,
        metric: 'الفواتير المدفوعة',
        value: paidInvoices,
        description: 'عدد الفواتير المدفوعة',
        trend: null,
      },
      {
        id: 6,
        metric: 'الفواتير غير المدفوعة',
        value: unpaidInvoices,
        description: 'عدد الفواتير غير المدفوعة',
        trend: null,
      },
      {
        id: 7,
        metric: 'إجمالي الإيرادات',
        value: `${totalRevenue.toLocaleString()} ريال`,
        description: 'إجمالي الإيرادات',
        trend: null,
      },
      {
        id: 8,
        metric: 'إجمالي المصروفات',
        value: `${totalExpenses.toLocaleString()} ريال`,
        description: 'إجمالي المصروفات',
        trend: null,
      },
      {
        id: 9,
        metric: 'صافي الربح',
        value: `${netProfit.toLocaleString()} ريال`,
        description: 'صافي الربح (الإيرادات - المصروفات)',
        trend: null,
      },
      {
        id: 10,
        metric: 'إجمالي المدفوعات',
        value: `${totalPayments.toLocaleString()} ريال`,
        description: 'إجمالي المدفوعات',
        trend: null,
      },
      {
        id: 11,
        metric: 'إجمالي الميزانيات',
        value: totalBudgets,
        description: 'عدد الميزانيات الكلي',
        trend: null,
      },
      {
        id: 12,
        metric: 'الميزانيات المخصصة',
        value: `${totalBudgetAllocated.toLocaleString()} ريال`,
        description: 'إجمالي الميزانيات المخصصة',
        trend: null,
      },
      {
        id: 13,
        metric: 'الميزانيات المستخدمة',
        value: `${totalBudgetUsed.toLocaleString()} ريال`,
        description: 'إجمالي الميزانيات المستخدمة',
        trend: null,
      },
    ];

    res.json({ success: true, data: analyticsData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
module.exports.setIO = setIO;
