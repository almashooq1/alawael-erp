/**
 * 📅 Advanced Appointments Management Routes
 */

const express = require('express');
const router = express.Router();

const appointments = [];
const schedules = [];
const availability = [];
const reminders = [];
const cancellations = [];
const reschedules = [];
const waitlist = [];
const analytics = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/appointments', async (req, res) => {
  try {
    const { status, type, providerId, patientId, date } = req.query;
    let filtered = appointments;
    if (status) filtered = filtered.filter(a => a.status === status);
    if (type) filtered = filtered.filter(a => a.type === type);
    if (providerId) filtered = filtered.filter(a => a.providerId === parseInt(providerId));
    if (patientId) filtered = filtered.filter(a => a.patientId === parseInt(patientId));
    if (date) filtered = filtered.filter(a => a.date === date);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/appointments', async (req, res) => {
  try {
    const appointment = {
      id: appointments.length > 0 ? Math.max(...appointments.map(a => a.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'scheduled',
      type: req.body.type || 'consultation',
      urgent: req.body.urgent || false,
      date: req.body.date || new Date().toISOString(),
      startTime: req.body.startTime || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    appointments.push(appointment);
    emitEvent('advanced-appointments:updated', {
      action: 'create',
      entityType: 'appointment',
      entityId: appointment.id,
      data: appointment,
    });
    res.json({ success: true, data: appointment });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/appointments/:id/confirm', async (req, res) => {
  try {
    const index = appointments.findIndex(a => a.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Appointment not found' });
    }
    appointments[index].status = 'confirmed';
    appointments[index].confirmedAt = new Date().toISOString();
    emitEvent('advanced-appointments:updated', {
      action: 'update',
      entityType: 'appointment',
      entityId: appointments[index].id,
      data: appointments[index],
    });
    res.json({ success: true, data: appointments[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/appointments/:id/start', async (req, res) => {
  try {
    const index = appointments.findIndex(a => a.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Appointment not found' });
    }
    appointments[index].status = 'in-progress';
    appointments[index].startedAt = new Date().toISOString();
    emitEvent('advanced-appointments:updated', {
      action: 'update',
      entityType: 'appointment',
      entityId: appointments[index].id,
      data: appointments[index],
    });
    res.json({ success: true, data: appointments[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/appointments/:id/cancel', async (req, res) => {
  try {
    const index = appointments.findIndex(a => a.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Appointment not found' });
    }
    appointments[index].status = 'cancelled';
    appointments[index].cancelledAt = new Date().toISOString();
    appointments[index].cancellationReason = req.body.reason || 'غير محدد';

    // Add to cancellations
    const cancellation = {
      id: cancellations.length > 0 ? Math.max(...cancellations.map(c => c.id)) + 1 : 1,
      appointmentId: appointments[index].id,
      appointmentName: `${appointments[index].patientName} - ${appointments[index].type}`,
      patientName: appointments[index].patientName,
      reason: req.body.reason || 'غير محدد',
      cancelledBy: req.body.cancelledBy || 'غير محدد',
      date: new Date().toISOString(),
    };
    cancellations.push(cancellation);

    emitEvent('advanced-appointments:updated', {
      action: 'update',
      entityType: 'appointment',
      entityId: appointments[index].id,
      data: appointments[index],
    });
    res.json({ success: true, data: appointments[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/appointments/:id/reschedule', async (req, res) => {
  try {
    const index = appointments.findIndex(a => a.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Appointment not found' });
    }

    const oldDateTime = appointments[index].startTime;
    appointments[index].date = req.body.newDate || appointments[index].date;
    appointments[index].startTime = req.body.newStartTime || appointments[index].startTime;

    // Add to reschedules
    const reschedule = {
      id: reschedules.length > 0 ? Math.max(...reschedules.map(r => r.id)) + 1 : 1,
      appointmentId: appointments[index].id,
      appointmentName: `${appointments[index].patientName} - ${appointments[index].type}`,
      oldDateTime: oldDateTime,
      newDateTime: appointments[index].startTime,
      reason: req.body.reason || 'غير محدد',
      date: new Date().toISOString(),
    };
    reschedules.push(reschedule);

    emitEvent('advanced-appointments:updated', {
      action: 'update',
      entityType: 'appointment',
      entityId: appointments[index].id,
      data: appointments[index],
    });
    res.json({ success: true, data: appointments[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/schedules', async (req, res) => {
  try {
    const { date, providerId } = req.query;
    let filtered = schedules;
    if (date) filtered = filtered.filter(s => s.date === date);
    if (providerId) filtered = filtered.filter(s => s.providerId === parseInt(providerId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/availability', async (req, res) => {
  try {
    const { date, providerId } = req.query;
    let filtered = availability;
    if (date) filtered = filtered.filter(a => a.date === date);
    if (providerId) filtered = filtered.filter(a => a.providerId === parseInt(providerId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/reminders', async (req, res) => {
  try {
    const { sent, appointmentId } = req.query;
    let filtered = reminders;
    if (sent !== undefined) filtered = filtered.filter(r => r.sent === (sent === 'true'));
    if (appointmentId) filtered = filtered.filter(r => r.appointmentId === parseInt(appointmentId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/cancellations', async (req, res) => {
  try {
    res.json({ success: true, data: cancellations });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/reschedules', async (req, res) => {
  try {
    res.json({ success: true, data: reschedules });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/waitlist', async (req, res) => {
  try {
    const { priority } = req.query;
    let filtered = waitlist;
    if (priority) filtered = filtered.filter(w => w.priority === priority);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/waitlist', async (req, res) => {
  try {
    const item = {
      id: waitlist.length > 0 ? Math.max(...waitlist.map(w => w.id)) + 1 : 1,
      ...req.body,
      priority: req.body.priority || 'medium',
      position: waitlist.length + 1,
      requestDate: req.body.requestDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    waitlist.push(item);
    emitEvent('advanced-appointments:updated', {
      action: 'create',
      entityType: 'waitlist',
      entityId: item.id,
      data: item,
    });
    res.json({ success: true, data: item });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/analytics', async (req, res) => {
  try {
    const totalAppointments = appointments.length;
    const scheduledAppointments = appointments.filter(a => a.status === 'scheduled').length;
    const confirmedAppointments = appointments.filter(a => a.status === 'confirmed').length;
    const completedAppointments = appointments.filter(a => a.status === 'completed').length;
    const cancelledAppointments = appointments.filter(a => a.status === 'cancelled').length;
    const noShowAppointments = appointments.filter(a => a.status === 'no-show').length;
    const totalWaitlist = waitlist.length;
    const cancellationRate =
      totalAppointments > 0 ? Math.round((cancelledAppointments / totalAppointments) * 100) : 0;

    const analyticsData = [
      {
        id: 1,
        metric: 'إجمالي المواعيد',
        value: totalAppointments,
        description: 'عدد المواعيد الكلي',
        trend: null,
      },
      {
        id: 2,
        metric: 'المواعيد المجدولة',
        value: scheduledAppointments,
        description: 'عدد المواعيد المجدولة',
        trend: null,
      },
      {
        id: 3,
        metric: 'المواعيد المؤكدة',
        value: confirmedAppointments,
        description: 'عدد المواعيد المؤكدة',
        trend: null,
      },
      {
        id: 4,
        metric: 'المواعيد المكتملة',
        value: completedAppointments,
        description: 'عدد المواعيد المكتملة',
        trend: null,
      },
      {
        id: 5,
        metric: 'المواعيد الملغاة',
        value: cancelledAppointments,
        description: 'عدد المواعيد الملغاة',
        trend: null,
      },
      {
        id: 6,
        metric: 'معدل الإلغاء',
        value: `${cancellationRate}%`,
        description: 'نسبة المواعيد الملغاة',
        trend: null,
      },
      {
        id: 7,
        metric: 'لم يحضر',
        value: noShowAppointments,
        description: 'عدد المواعيد التي لم يحضرها المريض',
        trend: null,
      },
      {
        id: 8,
        metric: 'قائمة الانتظار',
        value: totalWaitlist,
        description: 'عدد الأشخاص في قائمة الانتظار',
        trend: null,
      },
    ];

    res.json({ success: true, data: analyticsData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
