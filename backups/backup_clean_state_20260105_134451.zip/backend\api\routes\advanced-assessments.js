/**
 * 📊 Advanced Assessments Routes
 * API routes for advanced assessments management system
 */

const express = require('express');
const router = express.Router();

// Mock data storage (replace with database)
const assessments = [];
const questions = [];
const results = [];
const templates = [];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Assessments ====================

router.get('/assessments', async (req, res) => {
  try {
    const { type, status, search } = req.query;
    let filtered = assessments;

    if (type) {
      filtered = filtered.filter(a => a.type === type);
    }

    if (status) {
      filtered = filtered.filter(a => a.status === status);
    }

    if (search) {
      const query = search.toLowerCase();
      filtered = filtered.filter(
        a =>
          a.title.toLowerCase().includes(query) ||
          (a.description && a.description.toLowerCase().includes(query))
      );
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.get('/assessments/:id', async (req, res) => {
  try {
    const assessment = assessments.find(a => a.id === parseInt(req.params.id));
    if (!assessment) {
      return res.status(404).json({
        success: false,
        error: 'Assessment not found',
      });
    }
    res.json({
      success: true,
      data: assessment,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/assessments', async (req, res) => {
  try {
    const assessment = {
      id: assessments.length > 0 ? Math.max(...assessments.map(a => a.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      questionsCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    assessments.push(assessment);

    emitEvent('assessments:updated', {
      action: 'create',
      entityId: assessment.id,
      data: assessment,
    });

    res.json({
      success: true,
      data: assessment,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.put('/assessments/:id', async (req, res) => {
  try {
    const index = assessments.findIndex(a => a.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Assessment not found',
      });
    }

    assessments[index] = {
      ...assessments[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    emitEvent('assessments:updated', {
      action: 'update',
      entityId: assessments[index].id,
      data: assessments[index],
    });

    res.json({
      success: true,
      data: assessments[index],
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.delete('/assessments/:id', async (req, res) => {
  try {
    const index = assessments.findIndex(a => a.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Assessment not found',
      });
    }

    assessments.splice(index, 1);

    emitEvent('assessments:updated', {
      action: 'delete',
      entityId: parseInt(req.params.id),
    });

    res.json({
      success: true,
      message: 'Assessment deleted successfully',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Questions ====================

router.get('/questions', async (req, res) => {
  try {
    const { assessmentId } = req.query;
    let filtered = questions;

    if (assessmentId) {
      filtered = filtered.filter(q => q.assessmentId === parseInt(assessmentId));
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/questions', async (req, res) => {
  try {
    const question = {
      id: questions.length > 0 ? Math.max(...questions.map(q => q.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
    };

    questions.push(question);

    // Update assessment questions count
    if (question.assessmentId) {
      const assessment = assessments.find(a => a.id === question.assessmentId);
      if (assessment) {
        assessment.questionsCount = (assessment.questionsCount || 0) + 1;
      }
    }

    res.json({
      success: true,
      data: question,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Results ====================

router.get('/results', async (req, res) => {
  try {
    const { assessmentId, participantId } = req.query;
    let filtered = results;

    if (assessmentId) {
      filtered = filtered.filter(r => r.assessmentId === parseInt(assessmentId));
    }

    if (participantId) {
      filtered = filtered.filter(r => r.participantId === parseInt(participantId));
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/results', async (req, res) => {
  try {
    const result = {
      id: results.length > 0 ? Math.max(...results.map(r => r.id)) + 1 : 1,
      ...req.body,
      completedAt: new Date().toISOString(),
    };

    // Calculate if passed
    const assessment = assessments.find(a => a.id === result.assessmentId);
    if (assessment) {
      result.passed = result.score >= (assessment.passingScore || 70);
    }

    results.push(result);

    emitEvent('assessments:result:updated', {
      action: 'create',
      entityId: result.id,
      data: result,
    });

    res.json({
      success: true,
      data: result,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Templates ====================

router.get('/templates', async (req, res) => {
  try {
    res.json({
      success: true,
      data: templates,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/templates', async (req, res) => {
  try {
    const template = {
      id: templates.length > 0 ? Math.max(...templates.map(t => t.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
    };

    templates.push(template);

    res.json({
      success: true,
      data: template,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

module.exports = { router, setIO };
