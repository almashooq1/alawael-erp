/**
 * 💼 Advanced Assets Management Routes
 * API routes for advanced assets management system
 */

const express = require('express');
const router = express.Router();

// Mock data storage (replace with database)
const assets = [];
const categories = [];
const maintenance = [];
const depreciation = [];
const locations = [];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Assets ====================

router.get('/assets', async (req, res) => {
  try {
    const { status, category, location } = req.query;
    let filtered = assets;

    if (status) {
      filtered = filtered.filter(a => a.status === status);
    }

    if (category) {
      filtered = filtered.filter(a => a.category === category);
    }

    if (location) {
      filtered = filtered.filter(a => a.location === location);
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.get('/assets/:id', async (req, res) => {
  try {
    const asset = assets.find(a => a.id === parseInt(req.params.id));
    if (!asset) {
      return res.status(404).json({
        success: false,
        error: 'Asset not found',
      });
    }
    res.json({
      success: true,
      data: asset,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/assets', async (req, res) => {
  try {
    const asset = {
      id: assets.length > 0 ? Math.max(...assets.map(a => a.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      value: req.body.value || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    assets.push(asset);

    emitEvent('advanced-assets:updated', {
      action: 'create',
      entityType: 'asset',
      entityId: asset.id,
      data: asset,
    });

    res.json({
      success: true,
      data: asset,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.put('/assets/:id', async (req, res) => {
  try {
    const index = assets.findIndex(a => a.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Asset not found',
      });
    }

    assets[index] = {
      ...assets[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    emitEvent('advanced-assets:updated', {
      action: 'update',
      entityType: 'asset',
      entityId: assets[index].id,
      data: assets[index],
    });

    res.json({
      success: true,
      data: assets[index],
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.delete('/assets/:id', async (req, res) => {
  try {
    const index = assets.findIndex(a => a.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Asset not found',
      });
    }

    const deleted = assets.splice(index, 1)[0];

    emitEvent('advanced-assets:updated', {
      action: 'delete',
      entityType: 'asset',
      entityId: deleted.id,
    });

    res.json({
      success: true,
      message: 'Asset deleted successfully',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Categories ====================

router.get('/categories', async (req, res) => {
  try {
    res.json({
      success: true,
      data: categories,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/categories', async (req, res) => {
  try {
    const category = {
      id: categories.length > 0 ? Math.max(...categories.map(c => c.id)) + 1 : 1,
      ...req.body,
      assetsCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    categories.push(category);

    emitEvent('advanced-assets:updated', {
      action: 'create',
      entityType: 'category',
      entityId: category.id,
      data: category,
    });

    res.json({
      success: true,
      data: category,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Maintenance ====================

router.get('/maintenance', async (req, res) => {
  try {
    const { status, assetId } = req.query;
    let filtered = maintenance;

    if (status) {
      filtered = filtered.filter(m => m.status === status);
    }

    if (assetId) {
      filtered = filtered.filter(m => m.assetId === parseInt(assetId));
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/maintenance', async (req, res) => {
  try {
    const maint = {
      id: maintenance.length > 0 ? Math.max(...maintenance.map(m => m.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'scheduled',
      cost: req.body.cost || 0,
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    maintenance.push(maint);

    emitEvent('advanced-assets:updated', {
      action: 'create',
      entityType: 'maintenance',
      entityId: maint.id,
      data: maint,
    });

    res.json({
      success: true,
      data: maint,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Depreciation ====================

router.get('/depreciation', async (req, res) => {
  try {
    const { assetId } = req.query;
    let filtered = depreciation;

    if (assetId) {
      filtered = filtered.filter(d => d.assetId === parseInt(assetId));
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/depreciation', async (req, res) => {
  try {
    const dep = {
      id: depreciation.length > 0 ? Math.max(...depreciation.map(d => d.id)) + 1 : 1,
      ...req.body,
      originalValue: req.body.originalValue || 0,
      currentValue: req.body.currentValue || 0,
      rate: req.body.rate || 0,
      totalDepreciation: req.body.totalDepreciation || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    depreciation.push(dep);

    emitEvent('advanced-assets:updated', {
      action: 'create',
      entityType: 'depreciation',
      entityId: dep.id,
      data: dep,
    });

    res.json({
      success: true,
      data: dep,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Locations ====================

router.get('/locations', async (req, res) => {
  try {
    res.json({
      success: true,
      data: locations,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/locations', async (req, res) => {
  try {
    const location = {
      id: locations.length > 0 ? Math.max(...locations.map(l => l.id)) + 1 : 1,
      ...req.body,
      assetsCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    locations.push(location);

    emitEvent('advanced-assets:updated', {
      action: 'create',
      entityType: 'location',
      entityId: location.id,
      data: location,
    });

    res.json({
      success: true,
      data: location,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

module.exports = router;
module.exports.setIO = setIO;
