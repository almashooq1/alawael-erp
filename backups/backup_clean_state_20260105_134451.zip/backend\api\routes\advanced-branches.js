/**
 * 🏢 Advanced Branches Management Routes
 */

const express = require('express');
const router = express.Router();

const branches = [];
let mainBranch = null;
const connections = [];
const syncStatus = [];
const transfers = [];
const sharedResources = [];
const analytics = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/branches', async (req, res) => {
  try {
    const { status, type } = req.query;
    let filtered = branches;
    if (status) filtered = filtered.filter(b => b.status === status);
    if (type) filtered = filtered.filter(b => b.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/branches', async (req, res) => {
  try {
    const branch = {
      id: branches.length > 0 ? Math.max(...branches.map(b => b.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'inactive',
      type: req.body.type || 'sub',
      connected: req.body.connected || false,
      patientsCount: req.body.patientsCount || 0,
      staffCount: req.body.staffCount || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    branches.push(branch);
    emitEvent('advanced-branches:updated', {
      action: 'create',
      entityType: 'branch',
      entityId: branch.id,
      data: branch,
    });
    res.json({ success: true, data: branch });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/main-branch', async (req, res) => {
  try {
    if (!mainBranch) {
      // Create default main branch if not exists
      mainBranch = {
        id: 1,
        name: 'الفرع الرئيسي',
        code: 'MAIN-001',
        type: 'main',
        status: 'active',
        location: 'الرياض',
        phone: '+966500000000',
        email: 'main@rehabcenter.com',
        totalPatients: 0,
        totalStaff: 0,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
    }
    res.json({ success: true, data: mainBranch });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/main-branch', async (req, res) => {
  try {
    mainBranch = {
      id: 1,
      ...req.body,
      type: 'main',
      status: 'active',
      totalPatients: req.body.totalPatients || 0,
      totalStaff: req.body.totalStaff || 0,
      updatedAt: new Date().toISOString(),
    };
    emitEvent('advanced-branches:updated', {
      action: 'update',
      entityType: 'mainBranch',
      entityId: 1,
      data: mainBranch,
    });
    res.json({ success: true, data: mainBranch });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/connections', async (req, res) => {
  try {
    const { status, branchId } = req.query;
    let filtered = connections;
    if (status) filtered = filtered.filter(c => c.status === status);
    if (branchId)
      filtered = filtered.filter(
        c => c.fromBranchId === parseInt(branchId) || c.toBranchId === parseInt(branchId)
      );
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/connections', async (req, res) => {
  try {
    const connection = {
      id: connections.length > 0 ? Math.max(...connections.map(c => c.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      type: req.body.type || 'direct',
      speed: req.body.speed || '100 Mbps',
      stability: req.body.stability || 100,
      connectedAt: req.body.connectedAt || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    connections.push(connection);

    // Update branch connection status
    const fromBranch = branches.find(b => b.id === connection.fromBranchId);
    const toBranch = branches.find(b => b.id === connection.toBranchId);
    if (fromBranch) fromBranch.connected = true;
    if (toBranch) toBranch.connected = true;

    emitEvent('advanced-branches:updated', {
      action: 'create',
      entityType: 'connection',
      entityId: connection.id,
      data: connection,
    });
    res.json({ success: true, data: connection });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/sync-status', async (req, res) => {
  try {
    const { status, branchId } = req.query;
    let filtered = syncStatus;
    if (status) filtered = filtered.filter(s => s.status === status);
    if (branchId) filtered = filtered.filter(s => s.branchId === parseInt(branchId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/sync-status', async (req, res) => {
  try {
    const sync = {
      id: syncStatus.length > 0 ? Math.max(...syncStatus.map(s => s.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'pending',
      type: req.body.type || 'automatic',
      progress: req.body.progress || 0,
      syncedRecords: req.body.syncedRecords || 0,
      lastSync: req.body.lastSync || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    syncStatus.push(sync);
    emitEvent('advanced-branches:updated', {
      action: 'create',
      entityType: 'sync',
      entityId: sync.id,
      data: sync,
    });
    res.json({ success: true, data: sync });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/sync-all', async (req, res) => {
  try {
    const connectedBranches = branches.filter(b => b.connected && b.type !== 'main');
    const syncTasks = connectedBranches.map(branch => ({
      id: syncStatus.length > 0 ? Math.max(...syncStatus.map(s => s.id)) + 1 : 1,
      branchId: branch.id,
      branchName: branch.name,
      status: 'syncing',
      type: 'full',
      progress: 0,
      syncedRecords: 0,
      lastSync: new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }));

    syncStatus.push(...syncTasks);
    emitEvent('advanced-branches:updated', {
      action: 'sync-all',
      entityType: 'sync',
      data: syncTasks,
    });
    res.json({ success: true, data: syncTasks, message: `تم بدء مزامنة ${syncTasks.length} فرع` });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/transfers', async (req, res) => {
  try {
    const { status, fromBranchId, toBranchId } = req.query;
    let filtered = transfers;
    if (status) filtered = filtered.filter(t => t.status === status);
    if (fromBranchId) filtered = filtered.filter(t => t.fromBranchId === parseInt(fromBranchId));
    if (toBranchId) filtered = filtered.filter(t => t.toBranchId === parseInt(toBranchId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/transfers', async (req, res) => {
  try {
    const transfer = {
      id: transfers.length > 0 ? Math.max(...transfers.map(t => t.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'pending',
      type: req.body.type || 'data',
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    transfers.push(transfer);
    emitEvent('advanced-branches:updated', {
      action: 'create',
      entityType: 'transfer',
      entityId: transfer.id,
      data: transfer,
    });
    res.json({ success: true, data: transfer });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/resources', async (req, res) => {
  try {
    const { status, type } = req.query;
    let filtered = sharedResources;
    if (status) filtered = filtered.filter(r => r.status === status);
    if (type) filtered = filtered.filter(r => r.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/resources', async (req, res) => {
  try {
    const resource = {
      id: sharedResources.length > 0 ? Math.max(...sharedResources.map(r => r.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      type: req.body.type || 'data',
      sharedBranches: req.body.sharedBranches || 0,
      sharedAt: req.body.sharedAt || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    sharedResources.push(resource);
    emitEvent('advanced-branches:updated', {
      action: 'create',
      entityType: 'resource',
      entityId: resource.id,
      data: resource,
    });
    res.json({ success: true, data: resource });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/analytics', async (req, res) => {
  try {
    const totalBranches = branches.length;
    const activeBranches = branches.filter(b => b.status === 'active').length;
    const connectedBranches = branches.filter(b => b.connected).length;
    const totalConnections = connections.length;
    const activeConnections = connections.filter(c => c.status === 'active').length;
    const totalSyncs = syncStatus.length;
    const completedSyncs = syncStatus.filter(s => s.status === 'completed').length;
    const totalTransfers = transfers.length;
    const completedTransfers = transfers.filter(t => t.status === 'completed').length;
    const totalResources = sharedResources.length;
    const activeResources = sharedResources.filter(r => r.status === 'active').length;
    const totalPatients =
      branches.reduce((sum, b) => sum + (b.patientsCount || 0), 0) +
      (mainBranch?.totalPatients || 0);
    const totalStaff =
      branches.reduce((sum, b) => sum + (b.staffCount || 0), 0) + (mainBranch?.totalStaff || 0);

    const analyticsData = [
      {
        id: 1,
        metric: 'إجمالي الفروع',
        value: totalBranches + (mainBranch ? 1 : 0),
        description: 'عدد الفروع الكلي (بما في ذلك الرئيسي)',
      },
      {
        id: 2,
        metric: 'الفروع النشطة',
        value: activeBranches + (mainBranch ? 1 : 0),
        description: 'عدد الفروع النشطة',
      },
      {
        id: 3,
        metric: 'الفروع المتصلة',
        value: connectedBranches,
        description: 'عدد الفروع المتصلة بالفرع الرئيسي',
      },
      {
        id: 4,
        metric: 'إجمالي الاتصالات',
        value: totalConnections,
        description: 'عدد الاتصالات بين الفروع',
      },
      {
        id: 5,
        metric: 'الاتصالات النشطة',
        value: activeConnections,
        description: 'عدد الاتصالات النشطة',
      },
      {
        id: 6,
        metric: 'إجمالي عمليات المزامنة',
        value: totalSyncs,
        description: 'عدد عمليات المزامنة الكلي',
      },
      {
        id: 7,
        metric: 'المزامنات المكتملة',
        value: completedSyncs,
        description: 'عدد المزامنات المكتملة',
      },
      {
        id: 8,
        metric: 'إجمالي التحويلات',
        value: totalTransfers,
        description: 'عدد التحويلات الكلي',
      },
      {
        id: 9,
        metric: 'التحويلات المكتملة',
        value: completedTransfers,
        description: 'عدد التحويلات المكتملة',
      },
      {
        id: 10,
        metric: 'إجمالي الموارد المشتركة',
        value: totalResources,
        description: 'عدد الموارد المشتركة الكلي',
      },
      {
        id: 11,
        metric: 'الموارد النشطة',
        value: activeResources,
        description: 'عدد الموارد المشتركة النشطة',
      },
      {
        id: 12,
        metric: 'إجمالي المرضى',
        value: totalPatients,
        description: 'إجمالي عدد المرضى في جميع الفروع',
      },
      {
        id: 13,
        metric: 'إجمالي الموظفين',
        value: totalStaff,
        description: 'إجمالي عدد الموظفين في جميع الفروع',
      },
    ];

    res.json({ success: true, data: analyticsData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
module.exports.setIO = setIO;
