/**
 * 💰 Advanced Budget Routes
 * API routes for advanced budget management system
 */

const express = require('express');
const router = express.Router();

// Mock data storage (replace with database)
const budgets = [];
const expenses = [];
const revenues = [];
const categories = [];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Budgets ====================

router.get('/budgets', async (req, res) => {
  try {
    const { status, year } = req.query;
    let filtered = budgets;

    if (status) {
      filtered = filtered.filter(b => b.status === status);
    }

    if (year) {
      filtered = filtered.filter(b => b.year === parseInt(year));
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.get('/budgets/:id', async (req, res) => {
  try {
    const budget = budgets.find(b => b.id === parseInt(req.params.id));
    if (!budget) {
      return res.status(404).json({
        success: false,
        error: 'Budget not found',
      });
    }
    res.json({
      success: true,
      data: budget,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/budgets', async (req, res) => {
  try {
    const budget = {
      id: budgets.length > 0 ? Math.max(...budgets.map(b => b.id)) + 1 : 1,
      ...req.body,
      allocatedAmount: 0,
      remainingAmount: req.body.totalAmount || 0,
      status: req.body.status || 'active',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    budgets.push(budget);

    emitEvent('budget:updated', {
      action: 'create',
      entityId: budget.id,
      data: budget,
    });

    res.json({
      success: true,
      data: budget,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.put('/budgets/:id', async (req, res) => {
  try {
    const index = budgets.findIndex(b => b.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Budget not found',
      });
    }

    budgets[index] = {
      ...budgets[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    // Recalculate remaining amount
    if (budgets[index].totalAmount !== undefined) {
      budgets[index].remainingAmount =
        budgets[index].totalAmount - (budgets[index].allocatedAmount || 0);
    }

    emitEvent('budget:updated', {
      action: 'update',
      entityId: budgets[index].id,
      data: budgets[index],
    });

    res.json({
      success: true,
      data: budgets[index],
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.delete('/budgets/:id', async (req, res) => {
  try {
    const index = budgets.findIndex(b => b.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Budget not found',
      });
    }

    budgets.splice(index, 1);

    emitEvent('budget:updated', {
      action: 'delete',
      entityId: parseInt(req.params.id),
    });

    res.json({
      success: true,
      message: 'Budget deleted successfully',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Expenses ====================

router.get('/expenses', async (req, res) => {
  try {
    const { budgetId, categoryId, startDate, endDate } = req.query;
    let filtered = expenses;

    if (budgetId) {
      filtered = filtered.filter(e => e.budgetId === parseInt(budgetId));
    }

    if (categoryId) {
      filtered = filtered.filter(e => e.categoryId === parseInt(categoryId));
    }

    if (startDate) {
      filtered = filtered.filter(e => new Date(e.date) >= new Date(startDate));
    }

    if (endDate) {
      filtered = filtered.filter(e => new Date(e.date) <= new Date(endDate));
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/expenses', async (req, res) => {
  try {
    const expense = {
      id: expenses.length > 0 ? Math.max(...expenses.map(e => e.id)) + 1 : 1,
      ...req.body,
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
    };

    expenses.push(expense);

    // Update budget allocated amount
    if (expense.budgetId) {
      const budget = budgets.find(b => b.id === expense.budgetId);
      if (budget) {
        budget.allocatedAmount = (budget.allocatedAmount || 0) + (expense.amount || 0);
        budget.remainingAmount = budget.totalAmount - budget.allocatedAmount;
      }
    }

    emitEvent('budget:expense:updated', {
      action: 'create',
      entityId: expense.id,
      data: expense,
    });

    res.json({
      success: true,
      data: expense,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Revenues ====================

router.get('/revenues', async (req, res) => {
  try {
    const { budgetId, categoryId, startDate, endDate } = req.query;
    let filtered = revenues;

    if (budgetId) {
      filtered = filtered.filter(r => r.budgetId === parseInt(budgetId));
    }

    if (categoryId) {
      filtered = filtered.filter(r => r.categoryId === parseInt(categoryId));
    }

    if (startDate) {
      filtered = filtered.filter(r => new Date(r.date) >= new Date(startDate));
    }

    if (endDate) {
      filtered = filtered.filter(r => new Date(r.date) <= new Date(endDate));
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/revenues', async (req, res) => {
  try {
    const revenue = {
      id: revenues.length > 0 ? Math.max(...revenues.map(r => r.id)) + 1 : 1,
      ...req.body,
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
    };

    revenues.push(revenue);

    res.json({
      success: true,
      data: revenue,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Categories ====================

router.get('/categories', async (req, res) => {
  try {
    res.json({
      success: true,
      data: categories,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/categories', async (req, res) => {
  try {
    const category = {
      id: categories.length > 0 ? Math.max(...categories.map(c => c.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
    };

    categories.push(category);

    res.json({
      success: true,
      data: category,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

module.exports = router;
module.exports.setIO = setIO;
