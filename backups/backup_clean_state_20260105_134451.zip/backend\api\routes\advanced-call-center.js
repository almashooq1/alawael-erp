/**
 * 📞 Advanced Call Center Management Routes
 */

const express = require('express');
const router = express.Router();

let unifiedNumber = null;
const branches = [];
const agents = [];
const calls = [];
const queues = [];
const routes = [];
const recordings = [];
const analytics = [];
const ivrMenus = [];
const ivrFlows = [];
let stcIntegration = null;

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/unified-number', async (req, res) => {
  try {
    if (!unifiedNumber) {
      unifiedNumber = {
        id: 1,
        number: '920000000',
        type: 'toll-free',
        provider: 'STC',
        status: 'active',
        totalCalls: 0,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
    }
    res.json({ success: true, data: unifiedNumber });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/unified-number', async (req, res) => {
  try {
    unifiedNumber = {
      id: 1,
      ...req.body,
      status: req.body.status || 'active',
      totalCalls: req.body.totalCalls || 0,
      updatedAt: new Date().toISOString(),
    };
    emitEvent('advanced-call-center:updated', {
      action: 'update',
      entityType: 'unifiedNumber',
      entityId: 1,
      data: unifiedNumber,
    });
    res.json({ success: true, data: unifiedNumber });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/branches', async (req, res) => {
  try {
    const { status, connected } = req.query;
    let filtered = branches;
    if (status) filtered = filtered.filter(b => b.status === status);
    if (connected !== undefined)
      filtered = filtered.filter(b => b.connected === (connected === 'true'));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/branches', async (req, res) => {
  try {
    const branch = {
      id: branches.length > 0 ? Math.max(...branches.map(b => b.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      connected: req.body.connected || false,
      agentsCount: req.body.agentsCount || 0,
      todayCalls: req.body.todayCalls || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    branches.push(branch);
    emitEvent('advanced-call-center:updated', {
      action: 'create',
      entityType: 'branch',
      entityId: branch.id,
      data: branch,
    });
    res.json({ success: true, data: branch });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/agents', async (req, res) => {
  try {
    const { status, branchId } = req.query;
    let filtered = agents;
    if (status) filtered = filtered.filter(a => a.status === status);
    if (branchId) filtered = filtered.filter(a => a.branchId === parseInt(branchId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/agents', async (req, res) => {
  try {
    const agent = {
      id: agents.length > 0 ? Math.max(...agents.map(a => a.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'available',
      extension: req.body.extension || `EXT${agents.length + 1}`,
      activeCalls: req.body.activeCalls || 0,
      todayCalls: req.body.todayCalls || 0,
      avgCallDuration: req.body.avgCallDuration || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    agents.push(agent);

    // Update branch agents count
    const branch = branches.find(b => b.id === agent.branchId);
    if (branch) {
      branch.agentsCount = (branch.agentsCount || 0) + 1;
    }

    emitEvent('advanced-call-center:updated', {
      action: 'create',
      entityType: 'agent',
      entityId: agent.id,
      data: agent,
    });
    res.json({ success: true, data: agent });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/calls', async (req, res) => {
  try {
    const { status, branchId, agentId, date } = req.query;
    let filtered = calls;
    if (status) filtered = filtered.filter(c => c.status === status);
    if (branchId) filtered = filtered.filter(c => c.branchId === parseInt(branchId));
    if (agentId) filtered = filtered.filter(c => c.agentId === parseInt(agentId));
    if (date)
      filtered = filtered.filter(
        c => new Date(c.date).toDateString() === new Date(date).toDateString()
      );
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/calls', async (req, res) => {
  try {
    const call = {
      id: calls.length > 0 ? Math.max(...calls.map(c => c.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      duration: req.body.duration || 0,
      waitTime: req.body.waitTime || 0,
      rating: req.body.rating || 0,
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    calls.push(call);

    // Update unified number total calls
    if (unifiedNumber) {
      unifiedNumber.totalCalls = (unifiedNumber.totalCalls || 0) + 1;
    }

    // Update branch today calls
    const branch = branches.find(b => b.id === call.branchId);
    if (branch) {
      branch.todayCalls = (branch.todayCalls || 0) + 1;
    }

    // Update agent stats
    const agent = agents.find(a => a.id === call.agentId);
    if (agent) {
      agent.todayCalls = (agent.todayCalls || 0) + 1;
      if (call.status === 'active') {
        agent.activeCalls = (agent.activeCalls || 0) + 1;
        agent.status = 'busy';
      }
    }

    emitEvent('advanced-call-center:call', {
      action: 'create',
      entityType: 'call',
      entityId: call.id,
      data: call,
    });
    res.json({ success: true, data: call });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/queues', async (req, res) => {
  try {
    const { status } = req.query;
    let filtered = queues;
    if (status) filtered = filtered.filter(q => q.status === status);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/queues', async (req, res) => {
  try {
    const queue = {
      id: queues.length > 0 ? Math.max(...queues.map(q => q.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      waitingCalls: req.body.waitingCalls || 0,
      avgWaitTime: req.body.avgWaitTime || 0,
      maxWaitTime: req.body.maxWaitTime || 0,
      agentsCount: req.body.agentsCount || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    queues.push(queue);
    emitEvent('advanced-call-center:updated', {
      action: 'create',
      entityType: 'queue',
      entityId: queue.id,
      data: queue,
    });
    res.json({ success: true, data: queue });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/routes', async (req, res) => {
  try {
    const { status } = req.query;
    let filtered = routes;
    if (status) filtered = filtered.filter(r => r.status === status);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/routes', async (req, res) => {
  try {
    const route = {
      id: routes.length > 0 ? Math.max(...routes.map(r => r.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      priority: req.body.priority || 0,
      appliedCalls: req.body.appliedCalls || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    routes.push(route);
    emitEvent('advanced-call-center:updated', {
      action: 'create',
      entityType: 'route',
      entityId: route.id,
      data: route,
    });
    res.json({ success: true, data: route });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/recordings', async (req, res) => {
  try {
    const { callId, agentId, date } = req.query;
    let filtered = recordings;
    if (callId) filtered = filtered.filter(r => r.callId === parseInt(callId));
    if (agentId) filtered = filtered.filter(r => r.agentId === parseInt(agentId));
    if (date)
      filtered = filtered.filter(
        r => new Date(r.date).toDateString() === new Date(date).toDateString()
      );
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/recordings', async (req, res) => {
  try {
    const recording = {
      id: recordings.length > 0 ? Math.max(...recordings.map(r => r.id)) + 1 : 1,
      ...req.body,
      duration: req.body.duration || 0,
      size: req.body.size || 0,
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    recordings.push(recording);
    emitEvent('advanced-call-center:updated', {
      action: 'create',
      entityType: 'recording',
      entityId: recording.id,
      data: recording,
    });
    res.json({ success: true, data: recording });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/analytics', async (req, res) => {
  try {
    const totalCalls = calls.length;
    const todayCalls = calls.filter(c => {
      const today = new Date();
      const callDate = new Date(c.date);
      return today.toDateString() === callDate.toDateString();
    }).length;
    const activeCalls = calls.filter(c => c.status === 'active').length;
    const completedCalls = calls.filter(c => c.status === 'completed').length;
    const missedCalls = calls.filter(c => c.status === 'missed').length;
    const totalAgents = agents.length;
    const availableAgents = agents.filter(a => a.status === 'available').length;
    const busyAgents = agents.filter(a => a.status === 'busy').length;
    const totalBranches = branches.length;
    const connectedBranches = branches.filter(b => b.connected).length;
    const avgWaitTime =
      calls.length > 0
        ? Math.round(
            calls.filter(c => c.waitTime > 0).reduce((sum, c) => sum + (c.waitTime || 0), 0) /
              calls.filter(c => c.waitTime > 0).length /
              60
          )
        : 0;
    const answerRate = calls.length > 0 ? Math.round((completedCalls / totalCalls) * 100) : 0;
    const avgCallDuration =
      calls.length > 0
        ? Math.round(
            calls.filter(c => c.duration > 0).reduce((sum, c) => sum + (c.duration || 0), 0) /
              calls.filter(c => c.duration > 0).length
          )
        : 0;
    const satisfactionRate =
      calls.filter(c => c.rating > 0).length > 0
        ? Math.round(
            (calls.filter(c => c.rating > 0).reduce((sum, c) => sum + (c.rating || 0), 0) /
              calls.filter(c => c.rating > 0).length /
              5) *
              100
          )
        : 0;

    const analyticsData = [
      {
        id: 1,
        metric: 'إجمالي المكالمات',
        value: totalCalls,
        description: 'عدد المكالمات الكلي',
      },
      {
        id: 2,
        metric: 'مكالمات اليوم',
        value: todayCalls,
        description: 'عدد المكالمات اليوم',
      },
      {
        id: 3,
        metric: 'المكالمات النشطة',
        value: activeCalls,
        description: 'عدد المكالمات النشطة حالياً',
      },
      {
        id: 4,
        metric: 'المكالمات المكتملة',
        value: completedCalls,
        description: 'عدد المكالمات المكتملة',
      },
      {
        id: 5,
        metric: 'المكالمات الفائتة',
        value: missedCalls,
        description: 'عدد المكالمات الفائتة',
      },
      {
        id: 6,
        metric: 'إجمالي الوكلاء',
        value: totalAgents,
        description: 'عدد الوكلاء الكلي',
      },
      {
        id: 7,
        metric: 'الوكلاء المتاحون',
        value: availableAgents,
        description: 'عدد الوكلاء المتاحين',
      },
      {
        id: 8,
        metric: 'الوكلاء المشغولون',
        value: busyAgents,
        description: 'عدد الوكلاء المشغولين',
      },
      {
        id: 9,
        metric: 'إجمالي الفروع',
        value: totalBranches,
        description: 'عدد الفروع الكلي',
      },
      {
        id: 10,
        metric: 'الفروع المتصلة',
        value: connectedBranches,
        description: 'عدد الفروع المتصلة بالرقم الموحد',
      },
      {
        id: 11,
        metric: 'متوسط وقت الانتظار',
        value: `${avgWaitTime} دقيقة`,
        description: 'متوسط وقت انتظار المكالمات',
      },
      {
        id: 12,
        metric: 'معدل الإجابة',
        value: `${answerRate}%`,
        description: 'نسبة المكالمات المجابة',
      },
      {
        id: 13,
        metric: 'متوسط مدة المكالمة',
        value: `${Math.round(avgCallDuration / 60)} دقيقة`,
        description: 'متوسط مدة المكالمات',
      },
      {
        id: 14,
        metric: 'معدل الرضا',
        value: `${satisfactionRate}%`,
        description: 'معدل رضا العملاء',
      },
    ];

    res.json({ success: true, data: analyticsData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// IVR Menus Routes
router.get('/ivr-menus', async (req, res) => {
  try {
    const { status } = req.query;
    let filtered = ivrMenus;
    if (status) filtered = filtered.filter(m => m.status === status);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/ivr-menus', async (req, res) => {
  try {
    const menu = {
      id: ivrMenus.length > 0 ? Math.max(...ivrMenus.map(m => m.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      options: req.body.options || [],
      processedCalls: req.body.processedCalls || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    ivrMenus.push(menu);
    emitEvent('advanced-call-center:updated', {
      action: 'create',
      entityType: 'ivrMenu',
      entityId: menu.id,
      data: menu,
    });
    res.json({ success: true, data: menu });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/ivr-menus/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const index = ivrMenus.findIndex(m => m.id === id);
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Menu not found' });
    }
    ivrMenus[index] = { ...ivrMenus[index], ...req.body, updatedAt: new Date().toISOString() };
    emitEvent('advanced-call-center:updated', {
      action: 'update',
      entityType: 'ivrMenu',
      entityId: id,
      data: ivrMenus[index],
    });
    res.json({ success: true, data: ivrMenus[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// IVR Flows Routes
router.get('/ivr-flows', async (req, res) => {
  try {
    const { status } = req.query;
    let filtered = ivrFlows;
    if (status) filtered = filtered.filter(f => f.status === status);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/ivr-flows', async (req, res) => {
  try {
    const flow = {
      id: ivrFlows.length > 0 ? Math.max(...ivrFlows.map(f => f.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      steps: req.body.steps || [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    ivrFlows.push(flow);
    emitEvent('advanced-call-center:updated', {
      action: 'create',
      entityType: 'ivrFlow',
      entityId: flow.id,
      data: flow,
    });
    res.json({ success: true, data: flow });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// STC Integration Routes
router.get('/stc-integration', async (req, res) => {
  try {
    if (!stcIntegration) {
      stcIntegration = {
        id: 1,
        unifiedNumber: '920000000',
        serviceType: 'unified-number',
        status: 'inactive',
        connected: false,
        apiKey: null,
        apiSecret: null,
        lastSync: null,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
    }
    res.json({ success: true, data: stcIntegration });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/stc-integration', async (req, res) => {
  try {
    stcIntegration = {
      id: 1,
      ...req.body,
      status: req.body.status || 'active',
      connected: req.body.connected || false,
      lastSync: req.body.lastSync || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    emitEvent('advanced-call-center:updated', {
      action: 'update',
      entityType: 'stcIntegration',
      entityId: 1,
      data: stcIntegration,
    });
    res.json({ success: true, data: stcIntegration });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/stc-integration/test', async (req, res) => {
  try {
    // Simulate STC API test
    const testResult = {
      success: true,
      message: 'تم اختبار الاتصال بنجاح',
      responseTime: Math.floor(Math.random() * 100) + 50,
      timestamp: new Date().toISOString(),
    };
    res.json({ success: true, data: testResult });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/stc-integration/sync', async (req, res) => {
  try {
    if (!stcIntegration || !stcIntegration.connected) {
      return res.status(400).json({ success: false, error: 'STC integration not connected' });
    }

    // Simulate sync with STC
    stcIntegration.lastSync = new Date().toISOString();
    emitEvent('advanced-call-center:updated', {
      action: 'sync',
      entityType: 'stcIntegration',
      data: stcIntegration,
    });
    res.json({ success: true, data: stcIntegration, message: 'تمت المزامنة بنجاح' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
module.exports.setIO = setIO;
