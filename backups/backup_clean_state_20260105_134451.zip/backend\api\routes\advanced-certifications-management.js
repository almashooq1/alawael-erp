/**
 * 🏆 Advanced Certifications Management Routes
 */

const express = require('express');
const router = express.Router();

const certifications = [];
const issuances = [];
const validations = [];
const renewals = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/certifications', async (req, res) => {
  try {
    const { status, type, issuer } = req.query;
    let filtered = certifications;
    if (status) filtered = filtered.filter(c => c.status === status);
    if (type) filtered = filtered.filter(c => c.type === type);
    if (issuer) filtered = filtered.filter(c => c.issuer === issuer);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/certifications', async (req, res) => {
  try {
    const certification = {
      id: certifications.length > 0 ? Math.max(...certifications.map(c => c.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    certifications.push(certification);
    emitEvent('advanced-certifications-management:updated', {
      action: 'create',
      entityType: 'certification',
      entityId: certification.id,
      data: certification,
    });
    res.json({ success: true, data: certification });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/issuances', async (req, res) => {
  try {
    const { certificationId, recipientId } = req.query;
    let filtered = issuances;
    if (certificationId)
      filtered = filtered.filter(i => i.certificationId === parseInt(certificationId));
    if (recipientId) filtered = filtered.filter(i => i.recipientId === parseInt(recipientId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/issuances', async (req, res) => {
  try {
    const issuance = {
      id: issuances.length > 0 ? Math.max(...issuances.map(i => i.id)) + 1 : 1,
      ...req.body,
      serialNumber: req.body.serialNumber || `ISSUE-${Date.now()}`,
      issueDate: req.body.issueDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    issuances.push(issuance);
    emitEvent('advanced-certifications-management:updated', {
      action: 'create',
      entityType: 'issuance',
      entityId: issuance.id,
      data: issuance,
    });
    res.json({ success: true, data: issuance });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/validations', async (req, res) => {
  try {
    const { serialNumber } = req.query;
    let filtered = validations;
    if (serialNumber) filtered = filtered.filter(v => v.serialNumber === serialNumber);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/validations', async (req, res) => {
  try {
    const validation = {
      id: validations.length > 0 ? Math.max(...validations.map(v => v.id)) + 1 : 1,
      ...req.body,
      isValid: req.body.isValid !== undefined ? req.body.isValid : true,
      validationDate: req.body.validationDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    validations.push(validation);
    emitEvent('advanced-certifications-management:updated', {
      action: 'create',
      entityType: 'validation',
      entityId: validation.id,
      data: validation,
    });
    res.json({ success: true, data: validation });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/renewals', async (req, res) => {
  try {
    const { certificationId } = req.query;
    let filtered = renewals;
    if (certificationId)
      filtered = filtered.filter(r => r.certificationId === parseInt(certificationId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/renewals', async (req, res) => {
  try {
    const renewal = {
      id: renewals.length > 0 ? Math.max(...renewals.map(r => r.id)) + 1 : 1,
      ...req.body,
      renewalDate: req.body.renewalDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    renewals.push(renewal);
    emitEvent('advanced-certifications-management:updated', {
      action: 'create',
      entityType: 'renewal',
      entityId: renewal.id,
      data: renewal,
    });
    res.json({ success: true, data: renewal });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
