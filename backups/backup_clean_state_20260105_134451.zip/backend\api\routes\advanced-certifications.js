/**
 * 🏆 Advanced Certifications Routes
 * API routes for advanced certifications management system
 */

const express = require('express');
const router = express.Router();

// Mock data storage (replace with database)
const certifications = [];
const standards = [];
const verifications = [];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Certifications ====================

router.get('/certifications', async (req, res) => {
  try {
    const { type, status } = req.query;
    let filtered = certifications;

    if (type) {
      filtered = filtered.filter(c => c.type === type);
    }

    if (status) {
      filtered = filtered.filter(c => c.status === status);
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/certifications', async (req, res) => {
  try {
    const certification = {
      id: certifications.length > 0 ? Math.max(...certifications.map(c => c.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'pending',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    certifications.push(certification);

    emitEvent('certifications:updated', {
      action: 'create',
      entityId: certification.id,
      data: certification,
    });

    res.json({
      success: true,
      data: certification,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.delete('/certifications/:id', async (req, res) => {
  try {
    const index = certifications.findIndex(c => c.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Certification not found',
      });
    }

    certifications.splice(index, 1);

    emitEvent('certifications:updated', {
      action: 'delete',
      entityId: parseInt(req.params.id),
    });

    res.json({
      success: true,
      message: 'Certification deleted successfully',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Standards ====================

router.get('/standards', async (req, res) => {
  try {
    res.json({
      success: true,
      data: standards,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/standards', async (req, res) => {
  try {
    const standard = {
      id: standards.length > 0 ? Math.max(...standards.map(s => s.id)) + 1 : 1,
      ...req.body,
      releaseDate: req.body.releaseDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
    };

    standards.push(standard);

    res.json({
      success: true,
      data: standard,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Verifications ====================

router.get('/verifications', async (req, res) => {
  try {
    const { certificationId, status } = req.query;
    let filtered = verifications;

    if (certificationId) {
      filtered = filtered.filter(v => v.certificationId === parseInt(certificationId));
    }

    if (status) {
      filtered = filtered.filter(v => v.status === status);
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/verifications', async (req, res) => {
  try {
    const verification = {
      id: verifications.length > 0 ? Math.max(...verifications.map(v => v.id)) + 1 : 1,
      ...req.body,
      verificationDate: new Date().toISOString(),
      status: req.body.status || 'pending',
    };

    verifications.push(verification);

    res.json({
      success: true,
      data: verification,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

module.exports = { router, setIO };
