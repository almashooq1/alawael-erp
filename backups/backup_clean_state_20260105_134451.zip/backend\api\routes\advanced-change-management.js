/**
 * 🔄 Advanced Change Management Routes
 * API routes for advanced change management system
 */

const express = require('express');
const router = express.Router();

// Mock data storage (replace with database)
const changeRequests = [];
const approvals = [];
const implementations = [];
const rollbacks = [];
const impactAssessments = [];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Change Requests ====================

router.get('/change-requests', async (req, res) => {
  try {
    const { status, priority, type } = req.query;
    let filtered = changeRequests;

    if (status) {
      filtered = filtered.filter(r => r.status === status);
    }

    if (priority) {
      filtered = filtered.filter(r => r.priority === priority);
    }

    if (type) {
      filtered = filtered.filter(r => r.type === type);
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.get('/change-requests/:id', async (req, res) => {
  try {
    const request = changeRequests.find(r => r.id === parseInt(req.params.id));
    if (!request) {
      return res.status(404).json({
        success: false,
        error: 'Change request not found',
      });
    }
    res.json({
      success: true,
      data: request,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/change-requests', async (req, res) => {
  try {
    const request = {
      id: changeRequests.length > 0 ? Math.max(...changeRequests.map(r => r.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'draft',
      priority: req.body.priority || 'medium',
      requestedDate: req.body.requestedDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    changeRequests.push(request);

    emitEvent('advanced-change-management:updated', {
      action: 'create',
      entityType: 'changeRequest',
      entityId: request.id,
      data: request,
    });

    res.json({
      success: true,
      data: request,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.put('/change-requests/:id', async (req, res) => {
  try {
    const index = changeRequests.findIndex(r => r.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Change request not found',
      });
    }

    changeRequests[index] = {
      ...changeRequests[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    emitEvent('advanced-change-management:updated', {
      action: 'update',
      entityType: 'changeRequest',
      entityId: changeRequests[index].id,
      data: changeRequests[index],
    });

    res.json({
      success: true,
      data: changeRequests[index],
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Approvals ====================

router.get('/approvals', async (req, res) => {
  try {
    const { status, requestId } = req.query;
    let filtered = approvals;

    if (status) {
      filtered = filtered.filter(a => a.status === status);
    }

    if (requestId) {
      filtered = filtered.filter(a => a.requestId === parseInt(requestId));
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/approvals', async (req, res) => {
  try {
    const approval = {
      id: approvals.length > 0 ? Math.max(...approvals.map(a => a.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'approved',
      approvalDate: req.body.approvalDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    approvals.push(approval);

    // Update change request status
    const requestIndex = changeRequests.findIndex(r => r.id === approval.requestId);
    if (requestIndex !== -1) {
      changeRequests[requestIndex].status =
        approval.status === 'approved' ? 'approved' : 'rejected';
    }

    emitEvent('advanced-change-management:updated', {
      action: 'create',
      entityType: 'approval',
      entityId: approval.id,
      data: approval,
    });

    res.json({
      success: true,
      data: approval,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Implementations ====================

router.get('/implementations', async (req, res) => {
  try {
    const { status, requestId } = req.query;
    let filtered = implementations;

    if (status) {
      filtered = filtered.filter(i => i.status === status);
    }

    if (requestId) {
      filtered = filtered.filter(i => i.requestId === parseInt(requestId));
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/implementations', async (req, res) => {
  try {
    const implementation = {
      id: implementations.length > 0 ? Math.max(...implementations.map(i => i.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'in-progress',
      progress: req.body.progress || 0,
      startDate: req.body.startDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    implementations.push(implementation);

    emitEvent('advanced-change-management:updated', {
      action: 'create',
      entityType: 'implementation',
      entityId: implementation.id,
      data: implementation,
    });

    res.json({
      success: true,
      data: implementation,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.put('/implementations/:id', async (req, res) => {
  try {
    const index = implementations.findIndex(i => i.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Implementation not found',
      });
    }

    implementations[index] = {
      ...implementations[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    emitEvent('advanced-change-management:updated', {
      action: 'update',
      entityType: 'implementation',
      entityId: implementations[index].id,
      data: implementations[index],
    });

    res.json({
      success: true,
      data: implementations[index],
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Rollbacks ====================

router.get('/rollbacks', async (req, res) => {
  try {
    const { status, requestId } = req.query;
    let filtered = rollbacks;

    if (status) {
      filtered = filtered.filter(r => r.status === status);
    }

    if (requestId) {
      filtered = filtered.filter(r => r.requestId === parseInt(requestId));
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/rollbacks', async (req, res) => {
  try {
    const rollback = {
      id: rollbacks.length > 0 ? Math.max(...rollbacks.map(r => r.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'completed',
      rollbackDate: req.body.rollbackDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    rollbacks.push(rollback);

    emitEvent('advanced-change-management:updated', {
      action: 'create',
      entityType: 'rollback',
      entityId: rollback.id,
      data: rollback,
    });

    res.json({
      success: true,
      data: rollback,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Impact Assessments ====================

router.get('/impact-assessments', async (req, res) => {
  try {
    const { requestId, impactLevel } = req.query;
    let filtered = impactAssessments;

    if (requestId) {
      filtered = filtered.filter(a => a.requestId === parseInt(requestId));
    }

    if (impactLevel) {
      filtered = filtered.filter(a => a.impactLevel === impactLevel);
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/impact-assessments', async (req, res) => {
  try {
    const assessment = {
      id: impactAssessments.length > 0 ? Math.max(...impactAssessments.map(a => a.id)) + 1 : 1,
      ...req.body,
      impactLevel: req.body.impactLevel || 'medium',
      estimatedCost: req.body.estimatedCost || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    impactAssessments.push(assessment);

    emitEvent('advanced-change-management:updated', {
      action: 'create',
      entityType: 'impactAssessment',
      entityId: assessment.id,
      data: assessment,
    });

    res.json({
      success: true,
      data: assessment,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

module.exports = { router, setIO };
