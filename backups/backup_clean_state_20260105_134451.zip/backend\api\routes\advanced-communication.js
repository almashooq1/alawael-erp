/**
 * 💬 Advanced Communication Routes
 * API routes for advanced communication management system
 */

const express = require('express');
const router = express.Router();

// Mock data storage (replace with database)
const conversations = [];
const messages = [];
const templates = [];
const announcements = [];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Conversations ====================

router.get('/conversations', async (req, res) => {
  try {
    const { type, search } = req.query;
    let filtered = conversations;

    if (type) {
      filtered = filtered.filter(c => c.type === type);
    }

    if (search) {
      const query = search.toLowerCase();
      filtered = filtered.filter(
        c =>
          c.title.toLowerCase().includes(query) ||
          (c.lastMessage && c.lastMessage.toLowerCase().includes(query))
      );
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/conversations', async (req, res) => {
  try {
    const conversation = {
      id: conversations.length > 0 ? Math.max(...conversations.map(c => c.id)) + 1 : 1,
      ...req.body,
      type: req.body.type || 'direct',
      participantsCount: req.body.participantsCount || 1,
      unreadCount: 0,
      lastMessageTime: new Date().toISOString(),
      createdAt: new Date().toISOString(),
    };

    conversations.push(conversation);

    emitEvent('communication:conversation:updated', {
      action: 'create',
      entityId: conversation.id,
      data: conversation,
    });

    res.json({
      success: true,
      data: conversation,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Messages ====================

router.get('/messages', async (req, res) => {
  try {
    const { conversationId } = req.query;
    let filtered = messages;

    if (conversationId) {
      filtered = filtered.filter(m => m.conversationId === parseInt(conversationId));
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/messages', async (req, res) => {
  try {
    const message = {
      id: messages.length > 0 ? Math.max(...messages.map(m => m.id)) + 1 : 1,
      ...req.body,
      direction: req.body.direction || 'outgoing',
      read: false,
      timestamp: new Date().toISOString(),
    };

    messages.push(message);

    // Update conversation last message
    if (message.conversationId) {
      const conversation = conversations.find(c => c.id === message.conversationId);
      if (conversation) {
        conversation.lastMessage = message.content;
        conversation.lastMessageTime = message.timestamp;
        if (message.direction === 'incoming') {
          conversation.unreadCount = (conversation.unreadCount || 0) + 1;
        }
      }
    }

    emitEvent('communication:message:updated', {
      action: 'create',
      entityId: message.id,
      data: message,
    });

    res.json({
      success: true,
      data: message,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Templates ====================

router.get('/templates', async (req, res) => {
  try {
    const { category } = req.query;
    let filtered = templates;

    if (category) {
      filtered = filtered.filter(t => t.category === category);
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/templates', async (req, res) => {
  try {
    const template = {
      id: templates.length > 0 ? Math.max(...templates.map(t => t.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
    };

    templates.push(template);

    res.json({
      success: true,
      data: template,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Announcements ====================

router.get('/announcements', async (req, res) => {
  try {
    const { priority, status } = req.query;
    let filtered = announcements;

    if (priority) {
      filtered = filtered.filter(a => a.priority === priority);
    }

    if (status) {
      filtered = filtered.filter(a => a.status === status);
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/announcements', async (req, res) => {
  try {
    const announcement = {
      id: announcements.length > 0 ? Math.max(...announcements.map(a => a.id)) + 1 : 1,
      ...req.body,
      priority: req.body.priority || 'medium',
      status: req.body.status || 'published',
      viewsCount: 0,
      publishDate: new Date().toISOString(),
      createdAt: new Date().toISOString(),
    };

    announcements.push(announcement);

    res.json({
      success: true,
      data: announcement,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

module.exports = { router, setIO };
