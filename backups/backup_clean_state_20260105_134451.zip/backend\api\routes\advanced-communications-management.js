/**
 * 📞 Advanced Communications Management Routes
 */

const express = require('express');
const router = express.Router();

const messages = [];
const announcements = [];
const notifications = [];
const channels = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/messages', async (req, res) => {
  try {
    const { status, type, channel } = req.query;
    let filtered = messages;
    if (status) filtered = filtered.filter(m => m.status === status);
    if (type) filtered = filtered.filter(m => m.type === type);
    if (channel) filtered = filtered.filter(m => m.channel === channel);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/messages', async (req, res) => {
  try {
    const message = {
      id: messages.length > 0 ? Math.max(...messages.map(m => m.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'sent',
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    messages.push(message);
    emitEvent('advanced-communications-management:updated', {
      action: 'create',
      entityType: 'message',
      entityId: message.id,
      data: message,
    });
    res.json({ success: true, data: message });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/announcements', async (req, res) => {
  try {
    const { priority, status } = req.query;
    let filtered = announcements;
    if (priority) filtered = filtered.filter(a => a.priority === priority);
    if (status) filtered = filtered.filter(a => a.status === status);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/announcements', async (req, res) => {
  try {
    const announcement = {
      id: announcements.length > 0 ? Math.max(...announcements.map(a => a.id)) + 1 : 1,
      ...req.body,
      priority: req.body.priority || 'medium',
      viewsCount: 0,
      publishDate: req.body.publishDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    announcements.push(announcement);
    emitEvent('advanced-communications-management:updated', {
      action: 'create',
      entityType: 'announcement',
      entityId: announcement.id,
      data: announcement,
    });
    res.json({ success: true, data: announcement });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/notifications', async (req, res) => {
  try {
    const { type, read, userId } = req.query;
    let filtered = notifications;
    if (type) filtered = filtered.filter(n => n.type === type);
    if (read !== undefined) filtered = filtered.filter(n => n.read === (read === 'true'));
    if (userId) filtered = filtered.filter(n => n.userId === parseInt(userId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/notifications', async (req, res) => {
  try {
    const notification = {
      id: notifications.length > 0 ? Math.max(...notifications.map(n => n.id)) + 1 : 1,
      ...req.body,
      read: false,
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    notifications.push(notification);
    emitEvent('advanced-communications-management:updated', {
      action: 'create',
      entityType: 'notification',
      entityId: notification.id,
      data: notification,
    });
    res.json({ success: true, data: notification });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/channels', async (req, res) => {
  try {
    const { active, type } = req.query;
    let filtered = channels;
    if (active !== undefined) filtered = filtered.filter(c => c.active === (active === 'true'));
    if (type) filtered = filtered.filter(c => c.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/channels', async (req, res) => {
  try {
    const channel = {
      id: channels.length > 0 ? Math.max(...channels.map(c => c.id)) + 1 : 1,
      ...req.body,
      active: req.body.active !== undefined ? req.body.active : true,
      subscribersCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    channels.push(channel);
    emitEvent('advanced-communications-management:updated', {
      action: 'create',
      entityType: 'channel',
      entityId: channel.id,
      data: channel,
    });
    res.json({ success: true, data: channel });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
