/**
 * 📝 Advanced Complaints & Suggestions Management Routes
 */

const express = require('express');
const router = express.Router();

const complaints = [];
const suggestions = [];
const categories = [];
const resolutions = [];
const feedback = [];
const analytics = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/complaints', async (req, res) => {
  try {
    const { status, categoryId, priority } = req.query;
    let filtered = complaints;
    if (status) filtered = filtered.filter(c => c.status === status);
    if (categoryId) filtered = filtered.filter(c => c.categoryId === parseInt(categoryId));
    if (priority) filtered = filtered.filter(c => c.priority === priority);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/complaints', async (req, res) => {
  try {
    const complaint = {
      id: complaints.length > 0 ? Math.max(...complaints.map(c => c.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'new',
      priority: req.body.priority || 'medium',
      submittedDate: req.body.submittedDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    complaints.push(complaint);
    emitEvent('advanced-complaints:updated', {
      action: 'create',
      entityType: 'complaint',
      entityId: complaint.id,
      data: complaint,
    });
    res.json({ success: true, data: complaint });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/complaints/:id/assign', async (req, res) => {
  try {
    const index = complaints.findIndex(c => c.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Complaint not found' });
    }
    complaints[index].status = 'in-progress';
    complaints[index].assignedTo = req.body.assignedTo || null;
    complaints[index].assignedToName = req.body.assignedToName || 'غير محدد';
    complaints[index].assignedAt = new Date().toISOString();
    emitEvent('advanced-complaints:updated', {
      action: 'update',
      entityType: 'complaint',
      entityId: complaints[index].id,
      data: complaints[index],
    });
    res.json({ success: true, data: complaints[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/complaints/:id/resolve', async (req, res) => {
  try {
    const index = complaints.findIndex(c => c.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Complaint not found' });
    }
    complaints[index].status = 'resolved';
    complaints[index].resolvedAt = new Date().toISOString();
    complaints[index].resolvedBy = req.body.resolvedBy || 'غير محدد';

    // Create resolution record
    const resolution = {
      id: resolutions.length > 0 ? Math.max(...resolutions.map(r => r.id)) + 1 : 1,
      complaintId: complaints[index].id,
      complaintTitle: complaints[index].title,
      solution: req.body.solution || 'غير محدد',
      resolvedBy: req.body.resolvedBy || 'غير محدد',
      resolvedDate: new Date().toISOString(),
    };
    resolutions.push(resolution);

    emitEvent('advanced-complaints:updated', {
      action: 'update',
      entityType: 'complaint',
      entityId: complaints[index].id,
      data: complaints[index],
    });
    res.json({ success: true, data: complaints[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/suggestions', async (req, res) => {
  try {
    const { status } = req.query;
    let filtered = suggestions;
    if (status) filtered = filtered.filter(s => s.status === status);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/suggestions', async (req, res) => {
  try {
    const suggestion = {
      id: suggestions.length > 0 ? Math.max(...suggestions.map(s => s.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'underreview',
      rating: req.body.rating || 0,
      submittedDate: req.body.submittedDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    suggestions.push(suggestion);
    emitEvent('advanced-complaints:updated', {
      action: 'create',
      entityType: 'suggestion',
      entityId: suggestion.id,
      data: suggestion,
    });
    res.json({ success: true, data: suggestion });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/categories', async (req, res) => {
  try {
    res.json({ success: true, data: categories });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/categories', async (req, res) => {
  try {
    const category = {
      id: categories.length > 0 ? Math.max(...categories.map(c => c.id)) + 1 : 1,
      ...req.body,
      itemsCount: req.body.itemsCount || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    categories.push(category);
    emitEvent('advanced-complaints:updated', {
      action: 'create',
      entityType: 'category',
      entityId: category.id,
      data: category,
    });
    res.json({ success: true, data: category });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/resolutions', async (req, res) => {
  try {
    const { complaintId } = req.query;
    let filtered = resolutions;
    if (complaintId) filtered = filtered.filter(r => r.complaintId === parseInt(complaintId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/feedback', async (req, res) => {
  try {
    const { complaintId } = req.query;
    let filtered = feedback;
    if (complaintId) filtered = filtered.filter(f => f.complaintId === parseInt(complaintId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/feedback', async (req, res) => {
  try {
    const fb = {
      id: feedback.length > 0 ? Math.max(...feedback.map(f => f.id)) + 1 : 1,
      ...req.body,
      rating: req.body.rating || 0,
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    feedback.push(fb);
    emitEvent('advanced-complaints:updated', {
      action: 'create',
      entityType: 'feedback',
      entityId: fb.id,
      data: fb,
    });
    res.json({ success: true, data: fb });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/analytics', async (req, res) => {
  try {
    const totalComplaints = complaints.length;
    const newComplaints = complaints.filter(c => c.status === 'new').length;
    const inProgressComplaints = complaints.filter(c => c.status === 'in-progress').length;
    const resolvedComplaints = complaints.filter(c => c.status === 'resolved').length;
    const totalSuggestions = suggestions.length;
    const implementedSuggestions = suggestions.filter(s => s.status === 'implemented').length;
    const totalCategories = categories.length;
    const totalResolutions = resolutions.length;
    const totalFeedback = feedback.length;
    const averageRating =
      feedback.length > 0
        ? (feedback.reduce((sum, f) => sum + (f.rating || 0), 0) / feedback.length).toFixed(1)
        : 0;

    const analyticsData = [
      {
        id: 1,
        metric: 'إجمالي الشكاوى',
        value: totalComplaints,
        description: 'عدد الشكاوى الكلي',
        trend: null,
      },
      {
        id: 2,
        metric: 'الشكاوى الجديدة',
        value: newComplaints,
        description: 'عدد الشكاوى الجديدة',
        trend: null,
      },
      {
        id: 3,
        metric: 'الشكاوى قيد المعالجة',
        value: inProgressComplaints,
        description: 'عدد الشكاوى قيد المعالجة',
        trend: null,
      },
      {
        id: 4,
        metric: 'الشكاوى المحلولة',
        value: resolvedComplaints,
        description: 'عدد الشكاوى المحلولة',
        trend: null,
      },
      {
        id: 5,
        metric: 'إجمالي المقترحات',
        value: totalSuggestions,
        description: 'عدد المقترحات الكلي',
        trend: null,
      },
      {
        id: 6,
        metric: 'المقترحات المطبقة',
        value: implementedSuggestions,
        description: 'عدد المقترحات المطبقة',
        trend: null,
      },
      {
        id: 7,
        metric: 'إجمالي الفئات',
        value: totalCategories,
        description: 'عدد الفئات الكلي',
        trend: null,
      },
      {
        id: 8,
        metric: 'إجمالي الحلول',
        value: totalResolutions,
        description: 'عدد الحلول الكلي',
        trend: null,
      },
      {
        id: 9,
        metric: 'إجمالي التقييمات',
        value: totalFeedback,
        description: 'عدد التقييمات الكلي',
        trend: null,
      },
      {
        id: 10,
        metric: 'متوسط التقييم',
        value: `${averageRating}/5`,
        description: 'متوسط تقييم الحلول',
        trend: null,
      },
    ];

    res.json({ success: true, data: analyticsData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
