/**
 * 📄 Advanced Contracts Management Routes
 */

const express = require('express');
const router = express.Router();

const contracts = [];
const vendors = [];
const renewals = [];
const terms = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/contracts', async (req, res) => {
  try {
    const { status, type, vendor } = req.query;
    let filtered = contracts;

    if (status) filtered = filtered.filter(c => c.status === status);
    if (type) filtered = filtered.filter(c => c.type === type);
    if (vendor) filtered = filtered.filter(c => c.vendorId === parseInt(vendor));

    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/contracts', async (req, res) => {
  try {
    const contract = {
      id: contracts.length > 0 ? Math.max(...contracts.map(c => c.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'draft',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    contracts.push(contract);
    emitEvent('advanced-contracts:updated', {
      action: 'create',
      entityType: 'contract',
      entityId: contract.id,
      data: contract,
    });

    res.json({ success: true, data: contract });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/contracts/:id', async (req, res) => {
  try {
    const index = contracts.findIndex(c => c.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Contract not found' });
    }

    contracts[index] = { ...contracts[index], ...req.body, updatedAt: new Date().toISOString() };
    emitEvent('advanced-contracts:updated', {
      action: 'update',
      entityType: 'contract',
      entityId: contracts[index].id,
      data: contracts[index],
    });

    res.json({ success: true, data: contracts[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/vendors', async (req, res) => {
  try {
    res.json({ success: true, data: vendors });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/vendors', async (req, res) => {
  try {
    const vendor = {
      id: vendors.length > 0 ? Math.max(...vendors.map(v => v.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    vendors.push(vendor);
    emitEvent('advanced-contracts:updated', {
      action: 'create',
      entityType: 'vendor',
      entityId: vendor.id,
      data: vendor,
    });

    res.json({ success: true, data: vendor });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/renewals', async (req, res) => {
  try {
    res.json({ success: true, data: renewals });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/renewals', async (req, res) => {
  try {
    const renewal = {
      id: renewals.length > 0 ? Math.max(...renewals.map(r => r.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'pending',
      renewalDate: req.body.renewalDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    renewals.push(renewal);
    emitEvent('advanced-contracts:updated', {
      action: 'create',
      entityType: 'renewal',
      entityId: renewal.id,
      data: renewal,
    });

    res.json({ success: true, data: renewal });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/terms', async (req, res) => {
  try {
    res.json({ success: true, data: terms });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/terms', async (req, res) => {
  try {
    const term = {
      id: terms.length > 0 ? Math.max(...terms.map(t => t.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    terms.push(term);
    emitEvent('advanced-contracts:updated', {
      action: 'create',
      entityType: 'term',
      entityId: term.id,
      data: term,
    });

    res.json({ success: true, data: term });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
