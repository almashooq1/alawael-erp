/**
 * 👥 Advanced Customers Management Routes
 */

const express = require('express');
const router = express.Router();

const customers = [];
const contacts = [];
const interactions = [];
const segments = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/customers', async (req, res) => {
  try {
    const { status, segment, type } = req.query;
    let filtered = customers;
    if (status) filtered = filtered.filter(c => c.status === status);
    if (segment) filtered = filtered.filter(c => c.segment === segment);
    if (type) filtered = filtered.filter(c => c.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/customers', async (req, res) => {
  try {
    const customer = {
      id: customers.length > 0 ? Math.max(...customers.map(c => c.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      totalPurchases: req.body.totalPurchases || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    customers.push(customer);
    emitEvent('advanced-customers:updated', {
      action: 'create',
      entityType: 'customer',
      entityId: customer.id,
      data: customer,
    });
    res.json({ success: true, data: customer });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/contacts', async (req, res) => {
  try {
    const { customerId } = req.query;
    let filtered = contacts;
    if (customerId) filtered = filtered.filter(c => c.customerId === parseInt(customerId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/contacts', async (req, res) => {
  try {
    const contact = {
      id: contacts.length > 0 ? Math.max(...contacts.map(c => c.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    contacts.push(contact);
    emitEvent('advanced-customers:updated', {
      action: 'create',
      entityType: 'contact',
      entityId: contact.id,
      data: contact,
    });
    res.json({ success: true, data: contact });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/interactions', async (req, res) => {
  try {
    const { customerId, type } = req.query;
    let filtered = interactions;
    if (customerId) filtered = filtered.filter(i => i.customerId === parseInt(customerId));
    if (type) filtered = filtered.filter(i => i.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/interactions', async (req, res) => {
  try {
    const interaction = {
      id: interactions.length > 0 ? Math.max(...interactions.map(i => i.id)) + 1 : 1,
      ...req.body,
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    interactions.push(interaction);
    emitEvent('advanced-customers:updated', {
      action: 'create',
      entityType: 'interaction',
      entityId: interaction.id,
      data: interaction,
    });
    res.json({ success: true, data: interaction });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/segments', async (req, res) => {
  try {
    res.json({ success: true, data: segments });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/segments', async (req, res) => {
  try {
    const segment = {
      id: segments.length > 0 ? Math.max(...segments.map(s => s.id)) + 1 : 1,
      ...req.body,
      customersCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    segments.push(segment);
    emitEvent('advanced-customers:updated', {
      action: 'create',
      entityType: 'segment',
      entityId: segment.id,
      data: segment,
    });
    res.json({ success: true, data: segment });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
