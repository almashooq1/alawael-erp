/**
 * 🎓 Advanced E-Learning Management Routes
 */

const express = require('express');
const router = express.Router();

const courses = [];
const lessons = [];
const students = [];
const enrollments = [];
const assignments = [];
const quizzes = [];
const resources = [];
const liveSessions = [];
const certificates = [];
const analytics = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/courses', async (req, res) => {
  try {
    const { category, status, level } = req.query;
    let filtered = courses;
    if (category) filtered = filtered.filter(c => c.category === category);
    if (status) filtered = filtered.filter(c => c.status === status);
    if (level) filtered = filtered.filter(c => c.level === level);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/courses', async (req, res) => {
  try {
    const course = {
      id: courses.length > 0 ? Math.max(...courses.map(c => c.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'draft',
      category: req.body.category || 'educational',
      level: req.body.level || 'beginner',
      lessonsCount: req.body.lessonsCount || 0,
      studentsCount: req.body.studentsCount || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    courses.push(course);
    emitEvent('advanced-elearning:updated', {
      action: 'create',
      entityType: 'course',
      entityId: course.id,
      data: course,
    });
    res.json({ success: true, data: course });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/lessons', async (req, res) => {
  try {
    const { courseId, type } = req.query;
    let filtered = lessons;
    if (courseId) filtered = filtered.filter(l => l.courseId === parseInt(courseId));
    if (type) filtered = filtered.filter(l => l.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/lessons', async (req, res) => {
  try {
    const lesson = {
      id: lessons.length > 0 ? Math.max(...lessons.map(l => l.id)) + 1 : 1,
      ...req.body,
      type: req.body.type || 'video',
      status: req.body.status || 'draft',
      order: req.body.order || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    lessons.push(lesson);
    emitEvent('advanced-elearning:updated', {
      action: 'create',
      entityType: 'lesson',
      entityId: lesson.id,
      data: lesson,
    });
    res.json({ success: true, data: lesson });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/students', async (req, res) => {
  try {
    res.json({ success: true, data: students });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/students', async (req, res) => {
  try {
    const student = {
      id: students.length > 0 ? Math.max(...students.map(s => s.id)) + 1 : 1,
      ...req.body,
      coursesCount: req.body.coursesCount || 0,
      certificatesCount: req.body.certificatesCount || 0,
      progress: req.body.progress || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    students.push(student);
    emitEvent('advanced-elearning:updated', {
      action: 'create',
      entityType: 'student',
      entityId: student.id,
      data: student,
    });
    res.json({ success: true, data: student });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/enrollments', async (req, res) => {
  try {
    const { studentId, courseId, status } = req.query;
    let filtered = enrollments;
    if (studentId) filtered = filtered.filter(e => e.studentId === parseInt(studentId));
    if (courseId) filtered = filtered.filter(e => e.courseId === parseInt(courseId));
    if (status) filtered = filtered.filter(e => e.status === status);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/enrollments', async (req, res) => {
  try {
    const enrollment = {
      id: enrollments.length > 0 ? Math.max(...enrollments.map(e => e.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'enrolled',
      progress: req.body.progress || 0,
      enrollmentDate: req.body.enrollmentDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    enrollments.push(enrollment);

    // Update course students count
    const course = courses.find(c => c.id === enrollment.courseId);
    if (course) {
      course.studentsCount = (course.studentsCount || 0) + 1;
    }

    emitEvent('advanced-elearning:updated', {
      action: 'create',
      entityType: 'enrollment',
      entityId: enrollment.id,
      data: enrollment,
    });
    res.json({ success: true, data: enrollment });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/assignments', async (req, res) => {
  try {
    const { courseId, status } = req.query;
    let filtered = assignments;
    if (courseId) filtered = filtered.filter(a => a.courseId === parseInt(courseId));
    if (status) filtered = filtered.filter(a => a.status === status);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/assignments', async (req, res) => {
  try {
    const assignment = {
      id: assignments.length > 0 ? Math.max(...assignments.map(a => a.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'pending',
      submissionsCount: req.body.submissionsCount || 0,
      deadline: req.body.deadline || new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    assignments.push(assignment);
    emitEvent('advanced-elearning:updated', {
      action: 'create',
      entityType: 'assignment',
      entityId: assignment.id,
      data: assignment,
    });
    res.json({ success: true, data: assignment });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/quizzes', async (req, res) => {
  try {
    const { courseId, status } = req.query;
    let filtered = quizzes;
    if (courseId) filtered = filtered.filter(q => q.courseId === parseInt(courseId));
    if (status) filtered = filtered.filter(q => q.status === status);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/quizzes', async (req, res) => {
  try {
    const quiz = {
      id: quizzes.length > 0 ? Math.max(...quizzes.map(q => q.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'draft',
      questionsCount: req.body.questionsCount || 0,
      passingScore: req.body.passingScore || 60,
      duration: req.body.duration || '30 دقيقة',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    quizzes.push(quiz);
    emitEvent('advanced-elearning:updated', {
      action: 'create',
      entityType: 'quiz',
      entityId: quiz.id,
      data: quiz,
    });
    res.json({ success: true, data: quiz });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/resources', async (req, res) => {
  try {
    const { courseId, type } = req.query;
    let filtered = resources;
    if (courseId) filtered = filtered.filter(r => r.courseId === parseInt(courseId));
    if (type) filtered = filtered.filter(r => r.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/resources', async (req, res) => {
  try {
    const resource = {
      id: resources.length > 0 ? Math.max(...resources.map(r => r.id)) + 1 : 1,
      ...req.body,
      type: req.body.type || 'document',
      downloadsCount: req.body.downloadsCount || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    resources.push(resource);
    emitEvent('advanced-elearning:updated', {
      action: 'create',
      entityType: 'resource',
      entityId: resource.id,
      data: resource,
    });
    res.json({ success: true, data: resource });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/live-sessions', async (req, res) => {
  try {
    const { courseId, status } = req.query;
    let filtered = liveSessions;
    if (courseId) filtered = filtered.filter(s => s.courseId === parseInt(courseId));
    if (status) filtered = filtered.filter(s => s.status === status);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/live-sessions', async (req, res) => {
  try {
    const session = {
      id: liveSessions.length > 0 ? Math.max(...liveSessions.map(s => s.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'scheduled',
      participantsCount: req.body.participantsCount || 0,
      scheduledAt: req.body.scheduledAt || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    liveSessions.push(session);
    emitEvent('advanced-elearning:updated', {
      action: 'create',
      entityType: 'liveSession',
      entityId: session.id,
      data: session,
    });
    res.json({ success: true, data: session });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/live-sessions/:id/start', async (req, res) => {
  try {
    const index = liveSessions.findIndex(s => s.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Session not found' });
    }
    liveSessions[index].status = 'live';
    liveSessions[index].startedAt = new Date().toISOString();
    emitEvent('advanced-elearning:updated', {
      action: 'update',
      entityType: 'liveSession',
      entityId: liveSessions[index].id,
      data: liveSessions[index],
    });
    res.json({ success: true, data: liveSessions[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/certificates', async (req, res) => {
  try {
    const { studentId, courseId } = req.query;
    let filtered = certificates;
    if (studentId) filtered = filtered.filter(c => c.studentId === parseInt(studentId));
    if (courseId) filtered = filtered.filter(c => c.courseId === parseInt(courseId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/certificates', async (req, res) => {
  try {
    const certificate = {
      id: certificates.length > 0 ? Math.max(...certificates.map(c => c.id)) + 1 : 1,
      ...req.body,
      serialNumber: req.body.serialNumber || `CERT-${Date.now()}`,
      score: req.body.score || 0,
      issueDate: req.body.issueDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    certificates.push(certificate);

    // Update student certificates count
    const student = students.find(s => s.id === certificate.studentId);
    if (student) {
      student.certificatesCount = (student.certificatesCount || 0) + 1;
    }

    emitEvent('advanced-elearning:updated', {
      action: 'create',
      entityType: 'certificate',
      entityId: certificate.id,
      data: certificate,
    });
    res.json({ success: true, data: certificate });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/analytics', async (req, res) => {
  try {
    const totalCourses = courses.length;
    const publishedCourses = courses.filter(c => c.status === 'published').length;
    const totalStudents = students.length;
    const totalEnrollments = enrollments.length;
    const activeEnrollments = enrollments.filter(e => e.status === 'inprogress').length;
    const completedEnrollments = enrollments.filter(e => e.status === 'completed').length;
    const totalAssignments = assignments.length;
    const totalQuizzes = quizzes.length;
    const totalLiveSessions = liveSessions.length;
    const liveSessionsNow = liveSessions.filter(s => s.status === 'live').length;
    const totalCertificates = certificates.length;
    const averageProgress =
      enrollments.length > 0
        ? (enrollments.reduce((sum, e) => sum + (e.progress || 0), 0) / enrollments.length).toFixed(
            1
          )
        : 0;

    const analyticsData = [
      {
        id: 1,
        metric: 'إجمالي الدورات',
        value: totalCourses,
        description: 'عدد الدورات الكلي',
        trend: null,
      },
      {
        id: 2,
        metric: 'الدورات المنشورة',
        value: publishedCourses,
        description: 'عدد الدورات المنشورة',
        trend: null,
      },
      {
        id: 3,
        metric: 'إجمالي الطلاب',
        value: totalStudents,
        description: 'عدد الطلاب الكلي',
        trend: null,
      },
      {
        id: 4,
        metric: 'إجمالي التسجيلات',
        value: totalEnrollments,
        description: 'عدد التسجيلات الكلي',
        trend: null,
      },
      {
        id: 5,
        metric: 'التسجيلات النشطة',
        value: activeEnrollments,
        description: 'عدد التسجيلات النشطة',
        trend: null,
      },
      {
        id: 6,
        metric: 'التسجيلات المكتملة',
        value: completedEnrollments,
        description: 'عدد التسجيلات المكتملة',
        trend: null,
      },
      {
        id: 7,
        metric: 'إجمالي الواجبات',
        value: totalAssignments,
        description: 'عدد الواجبات الكلي',
        trend: null,
      },
      {
        id: 8,
        metric: 'إجمالي الاختبارات',
        value: totalQuizzes,
        description: 'عدد الاختبارات الكلي',
        trend: null,
      },
      {
        id: 9,
        metric: 'إجمالي الجلسات المباشرة',
        value: totalLiveSessions,
        description: 'عدد الجلسات المباشرة الكلي',
        trend: null,
      },
      {
        id: 10,
        metric: 'الجلسات المباشرة الآن',
        value: liveSessionsNow,
        description: 'عدد الجلسات المباشرة النشطة',
        trend: null,
      },
      {
        id: 11,
        metric: 'إجمالي الشهادات',
        value: totalCertificates,
        description: 'عدد الشهادات الكلي',
        trend: null,
      },
      {
        id: 12,
        metric: 'متوسط التقدم',
        value: `${averageProgress}%`,
        description: 'متوسط تقدم الطلاب',
        trend: null,
      },
    ];

    res.json({ success: true, data: analyticsData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
