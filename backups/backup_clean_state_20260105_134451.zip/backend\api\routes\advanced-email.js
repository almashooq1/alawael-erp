/**
 * 📧 Advanced Email Management Routes
 */

const express = require('express');
const router = express.Router();

const accounts = [];
const inbox = [];
const sent = [];
const drafts = [];
const templates = [];
const campaigns = [];
const contacts = [];
const autoReplies = [];
const analytics = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/accounts', async (req, res) => {
  try {
    res.json({ success: true, data: accounts });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/accounts', async (req, res) => {
  try {
    const account = {
      id: accounts.length > 0 ? Math.max(...accounts.map(a => a.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    accounts.push(account);
    emitEvent('advanced-email:updated', {
      action: 'create',
      entityType: 'account',
      entityId: account.id,
      data: account,
    });
    res.json({ success: true, data: account });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/inbox', async (req, res) => {
  try {
    const { accountId, unread, important } = req.query;
    let filtered = inbox;
    if (accountId) filtered = filtered.filter(e => e.accountId === parseInt(accountId));
    if (unread === 'true') filtered = filtered.filter(e => e.unread);
    if (important === 'true') filtered = filtered.filter(e => e.important);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/inbox', async (req, res) => {
  try {
    const email = {
      id: inbox.length > 0 ? Math.max(...inbox.map(e => e.id)) + 1 : 1,
      ...req.body,
      unread: req.body.unread !== undefined ? req.body.unread : true,
      important: req.body.important || false,
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    inbox.push(email);
    emitEvent('advanced-email:updated', {
      action: 'create',
      entityType: 'email',
      entityId: email.id,
      data: email,
    });
    res.json({ success: true, data: email });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/sent', async (req, res) => {
  try {
    const { accountId, status } = req.query;
    let filtered = sent;
    if (accountId) filtered = filtered.filter(e => e.accountId === parseInt(accountId));
    if (status) filtered = filtered.filter(e => e.status === status);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/sent', async (req, res) => {
  try {
    const email = {
      id: sent.length > 0 ? Math.max(...sent.map(e => e.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'sent',
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    sent.push(email);
    emitEvent('advanced-email:updated', {
      action: 'create',
      entityType: 'email',
      entityId: email.id,
      data: email,
    });
    res.json({ success: true, data: email });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/drafts', async (req, res) => {
  try {
    const { accountId } = req.query;
    let filtered = drafts;
    if (accountId) filtered = filtered.filter(d => d.accountId === parseInt(accountId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/drafts', async (req, res) => {
  try {
    const draft = {
      id: drafts.length > 0 ? Math.max(...drafts.map(d => d.id)) + 1 : 1,
      ...req.body,
      updatedAt: new Date().toISOString(),
      createdAt: new Date().toISOString(),
    };
    drafts.push(draft);
    emitEvent('advanced-email:updated', {
      action: 'create',
      entityType: 'draft',
      entityId: draft.id,
      data: draft,
    });
    res.json({ success: true, data: draft });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/templates', async (req, res) => {
  try {
    const { category } = req.query;
    let filtered = templates;
    if (category) filtered = filtered.filter(t => t.category === category);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/templates', async (req, res) => {
  try {
    const template = {
      id: templates.length > 0 ? Math.max(...templates.map(t => t.id)) + 1 : 1,
      ...req.body,
      category: req.body.category || 'general',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    templates.push(template);
    emitEvent('advanced-email:updated', {
      action: 'create',
      entityType: 'template',
      entityId: template.id,
      data: template,
    });
    res.json({ success: true, data: template });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/campaigns', async (req, res) => {
  try {
    const { status } = req.query;
    let filtered = campaigns;
    if (status) filtered = filtered.filter(c => c.status === status);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/campaigns', async (req, res) => {
  try {
    const campaign = {
      id: campaigns.length > 0 ? Math.max(...campaigns.map(c => c.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      recipientsCount: req.body.recipientsCount || 0,
      sentCount: 0,
      openedCount: 0,
      clickedCount: 0,
      progress: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    campaigns.push(campaign);
    emitEvent('advanced-email:updated', {
      action: 'create',
      entityType: 'campaign',
      entityId: campaign.id,
      data: campaign,
    });
    res.json({ success: true, data: campaign });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/contacts', async (req, res) => {
  try {
    res.json({ success: true, data: contacts });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/contacts', async (req, res) => {
  try {
    const contact = {
      id: contacts.length > 0 ? Math.max(...contacts.map(c => c.id)) + 1 : 1,
      ...req.body,
      messagesCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    contacts.push(contact);
    emitEvent('advanced-email:updated', {
      action: 'create',
      entityType: 'contact',
      entityId: contact.id,
      data: contact,
    });
    res.json({ success: true, data: contact });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/auto-replies', async (req, res) => {
  try {
    const { enabled } = req.query;
    let filtered = autoReplies;
    if (enabled !== undefined) filtered = filtered.filter(r => r.enabled === (enabled === 'true'));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/auto-replies', async (req, res) => {
  try {
    const autoReply = {
      id: autoReplies.length > 0 ? Math.max(...autoReplies.map(r => r.id)) + 1 : 1,
      ...req.body,
      enabled: req.body.enabled !== undefined ? req.body.enabled : true,
      conditions: req.body.conditions || [],
      usageCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    autoReplies.push(autoReply);
    emitEvent('advanced-email:updated', {
      action: 'create',
      entityType: 'autoReply',
      entityId: autoReply.id,
      data: autoReply,
    });
    res.json({ success: true, data: autoReply });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/auto-replies/:id/toggle', async (req, res) => {
  try {
    const index = autoReplies.findIndex(r => r.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Auto reply not found' });
    }
    autoReplies[index].enabled = !autoReplies[index].enabled;
    emitEvent('advanced-email:updated', {
      action: 'update',
      entityType: 'autoReply',
      entityId: autoReplies[index].id,
      data: autoReplies[index],
    });
    res.json({ success: true, data: autoReplies[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/analytics', async (req, res) => {
  try {
    const totalEmails = inbox.length + sent.length;
    const unreadEmails = inbox.filter(e => e.unread).length;
    const sentEmails = sent.length;
    const openedEmails = sent.filter(e => e.status === 'opened').length;
    const clickedEmails = sent.filter(e => e.status === 'clicked').length;
    const activeCampaigns = campaigns.filter(c => c.status === 'active').length;

    const analyticsData = [
      {
        id: 1,
        metric: 'إجمالي الإيميلات',
        value: totalEmails,
        description: 'عدد الإيميلات الكلي',
        trend: null,
      },
      {
        id: 2,
        metric: 'غير المقروءة',
        value: unreadEmails,
        description: 'عدد الإيميلات غير المقروءة',
        trend: null,
      },
      {
        id: 3,
        metric: 'المرسلة',
        value: sentEmails,
        description: 'عدد الإيميلات المرسلة',
        trend: null,
      },
      {
        id: 4,
        metric: 'معدل الفتح',
        value: sentEmails > 0 ? Math.round((openedEmails / sentEmails) * 100) : 0,
        description: 'نسبة الإيميلات المفتوحة',
        trend: null,
      },
      {
        id: 5,
        metric: 'معدل النقر',
        value: openedEmails > 0 ? Math.round((clickedEmails / openedEmails) * 100) : 0,
        description: 'نسبة الإيميلات التي تم النقر عليها',
        trend: null,
      },
      {
        id: 6,
        metric: 'الحملات النشطة',
        value: activeCampaigns,
        description: 'عدد الحملات النشطة',
        trend: null,
      },
    ];

    res.json({ success: true, data: analyticsData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
