/**
 * 📊 Advanced Evaluations Management Routes
 */

const express = require('express');
const router = express.Router();

const evaluations = [];
const templates = [];
const questions = [];
const responses = [];
const scores = [];
const reports = [];
const comparisons = [];
const analytics = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/evaluations', async (req, res) => {
  try {
    const { status, type, category, patientId } = req.query;
    let filtered = evaluations;
    if (status) filtered = filtered.filter(e => e.status === status);
    if (type) filtered = filtered.filter(e => e.type === type);
    if (category) filtered = filtered.filter(e => e.category === category);
    if (patientId) filtered = filtered.filter(e => e.patientId === parseInt(patientId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/evaluations', async (req, res) => {
  try {
    const evaluation = {
      id: evaluations.length > 0 ? Math.max(...evaluations.map(e => e.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'draft',
      type: req.body.type || 'initial',
      questionsCount: req.body.questionsCount || 0,
      responsesCount: req.body.responsesCount || 0,
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    evaluations.push(evaluation);
    emitEvent('advanced-evaluations:updated', {
      action: 'create',
      entityType: 'evaluation',
      entityId: evaluation.id,
      data: evaluation,
    });
    res.json({ success: true, data: evaluation });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/evaluations/:id/start', async (req, res) => {
  try {
    const index = evaluations.findIndex(e => e.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Evaluation not found' });
    }
    evaluations[index].status = 'in-progress';
    evaluations[index].startedAt = new Date().toISOString();
    emitEvent('advanced-evaluations:updated', {
      action: 'update',
      entityType: 'evaluation',
      entityId: evaluations[index].id,
      data: evaluations[index],
    });
    res.json({ success: true, data: evaluations[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/evaluations/:id/complete', async (req, res) => {
  try {
    const index = evaluations.findIndex(e => e.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Evaluation not found' });
    }
    evaluations[index].status = 'completed';
    evaluations[index].completedAt = new Date().toISOString();
    evaluations[index].score = req.body.score || 0;

    // Calculate and create score record
    const score = {
      id: scores.length > 0 ? Math.max(...scores.map(s => s.id)) + 1 : 1,
      evaluationId: evaluations[index].id,
      evaluationTitle: evaluations[index].title,
      patientName: evaluations[index].patientName,
      totalScore: req.body.score || 0,
      maxScore: req.body.maxScore || 100,
      questionsCount: evaluations[index].questionsCount || 0,
      responsesCount: evaluations[index].responsesCount || 0,
      breakdown: req.body.breakdown || {},
      date: new Date().toISOString(),
    };
    scores.push(score);

    emitEvent('advanced-evaluations:updated', {
      action: 'update',
      entityType: 'evaluation',
      entityId: evaluations[index].id,
      data: evaluations[index],
    });
    res.json({ success: true, data: evaluations[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/templates', async (req, res) => {
  try {
    const { category, type } = req.query;
    let filtered = templates;
    if (category) filtered = filtered.filter(t => t.category === category);
    if (type) filtered = filtered.filter(t => t.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/templates', async (req, res) => {
  try {
    const template = {
      id: templates.length > 0 ? Math.max(...templates.map(t => t.id)) + 1 : 1,
      ...req.body,
      category: req.body.category || 'general',
      questionsCount: req.body.questionsCount || 0,
      usageCount: req.body.usageCount || 0,
      lastUsed: null,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    templates.push(template);
    emitEvent('advanced-evaluations:updated', {
      action: 'create',
      entityType: 'template',
      entityId: template.id,
      data: template,
    });
    res.json({ success: true, data: template });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/questions', async (req, res) => {
  try {
    const { category, type } = req.query;
    let filtered = questions;
    if (category) filtered = filtered.filter(q => q.category === category);
    if (type) filtered = filtered.filter(q => q.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/questions', async (req, res) => {
  try {
    const question = {
      id: questions.length > 0 ? Math.max(...questions.map(q => q.id)) + 1 : 1,
      ...req.body,
      type: req.body.type || 'text',
      weight: req.body.weight || 1,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    questions.push(question);
    emitEvent('advanced-evaluations:updated', {
      action: 'create',
      entityType: 'question',
      entityId: question.id,
      data: question,
    });
    res.json({ success: true, data: question });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/responses', async (req, res) => {
  try {
    const { evaluationId, patientId } = req.query;
    let filtered = responses;
    if (evaluationId) filtered = filtered.filter(r => r.evaluationId === parseInt(evaluationId));
    if (patientId) filtered = filtered.filter(r => r.patientId === parseInt(patientId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/responses', async (req, res) => {
  try {
    const response = {
      id: responses.length > 0 ? Math.max(...responses.map(r => r.id)) + 1 : 1,
      ...req.body,
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    responses.push(response);
    emitEvent('advanced-evaluations:updated', {
      action: 'create',
      entityType: 'response',
      entityId: response.id,
      data: response,
    });
    res.json({ success: true, data: response });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/scores', async (req, res) => {
  try {
    const { evaluationId, patientId } = req.query;
    let filtered = scores;
    if (evaluationId) filtered = filtered.filter(s => s.evaluationId === parseInt(evaluationId));
    if (patientId) filtered = filtered.filter(s => s.patientId === parseInt(patientId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/reports', async (req, res) => {
  try {
    const { patientId, type } = req.query;
    let filtered = reports;
    if (patientId) filtered = filtered.filter(r => r.patientId === parseInt(patientId));
    if (type) filtered = filtered.filter(r => r.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/reports', async (req, res) => {
  try {
    const report = {
      id: reports.length > 0 ? Math.max(...reports.map(r => r.id)) + 1 : 1,
      ...req.body,
      type: req.body.type || 'general',
      evaluationsCount: req.body.evaluationsCount || 0,
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    reports.push(report);
    emitEvent('advanced-evaluations:updated', {
      action: 'create',
      entityType: 'report',
      entityId: report.id,
      data: report,
    });
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/comparisons', async (req, res) => {
  try {
    const { patientId } = req.query;
    let filtered = comparisons;
    if (patientId) filtered = filtered.filter(c => c.patientId === parseInt(patientId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/comparisons', async (req, res) => {
  try {
    const comparison = {
      id: comparisons.length > 0 ? Math.max(...comparisons.map(c => c.id)) + 1 : 1,
      ...req.body,
      evaluationsCount: req.body.evaluationsCount || 0,
      changes: req.body.changes || [],
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    comparisons.push(comparison);
    emitEvent('advanced-evaluations:updated', {
      action: 'create',
      entityType: 'comparison',
      entityId: comparison.id,
      data: comparison,
    });
    res.json({ success: true, data: comparison });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/analytics', async (req, res) => {
  try {
    const totalEvaluations = evaluations.length;
    const draftEvaluations = evaluations.filter(e => e.status === 'draft').length;
    const inProgressEvaluations = evaluations.filter(e => e.status === 'in-progress').length;
    const completedEvaluations = evaluations.filter(e => e.status === 'completed').length;
    const reviewedEvaluations = evaluations.filter(e => e.status === 'reviewed').length;
    const totalTemplates = templates.length;
    const totalQuestions = questions.length;
    const totalResponses = responses.length;
    const totalScores = scores.length;
    const averageScore =
      scores.length > 0
        ? (scores.reduce((sum, s) => sum + (s.totalScore || 0), 0) / scores.length).toFixed(1)
        : 0;

    const analyticsData = [
      {
        id: 1,
        metric: 'إجمالي التقييمات',
        value: totalEvaluations,
        description: 'عدد التقييمات الكلي',
        trend: null,
      },
      {
        id: 2,
        metric: 'التقييمات المسودة',
        value: draftEvaluations,
        description: 'عدد التقييمات المسودة',
        trend: null,
      },
      {
        id: 3,
        metric: 'التقييمات قيد التنفيذ',
        value: inProgressEvaluations,
        description: 'عدد التقييمات قيد التنفيذ',
        trend: null,
      },
      {
        id: 4,
        metric: 'التقييمات المكتملة',
        value: completedEvaluations,
        description: 'عدد التقييمات المكتملة',
        trend: null,
      },
      {
        id: 5,
        metric: 'التقييمات المراجعة',
        value: reviewedEvaluations,
        description: 'عدد التقييمات المراجعة',
        trend: null,
      },
      {
        id: 6,
        metric: 'إجمالي القوالب',
        value: totalTemplates,
        description: 'عدد القوالب الكلي',
        trend: null,
      },
      {
        id: 7,
        metric: 'إجمالي الأسئلة',
        value: totalQuestions,
        description: 'عدد الأسئلة الكلي',
        trend: null,
      },
      {
        id: 8,
        metric: 'إجمالي الإجابات',
        value: totalResponses,
        description: 'عدد الإجابات الكلي',
        trend: null,
      },
      {
        id: 9,
        metric: 'إجمالي الدرجات',
        value: totalScores,
        description: 'عدد الدرجات الكلي',
        trend: null,
      },
      {
        id: 10,
        metric: 'متوسط الدرجات',
        value: `${averageScore}%`,
        description: 'متوسط الدرجات',
        trend: null,
      },
    ];

    res.json({ success: true, data: analyticsData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
