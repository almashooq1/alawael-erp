/**
 * 🎉 Advanced Events & Activities Management Routes
 */

const express = require('express');
const router = express.Router();

const events = [];
const activities = [];
const registrations = [];
const attendees = [];
const speakers = [];
const sponsors = [];
const venues = [];
const analytics = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/events', async (req, res) => {
  try {
    const { status, category, type } = req.query;
    let filtered = events;
    if (status) filtered = filtered.filter(e => e.status === status);
    if (category) filtered = filtered.filter(e => e.category === category);
    if (type) filtered = filtered.filter(e => e.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/events', async (req, res) => {
  try {
    const event = {
      id: events.length > 0 ? Math.max(...events.map(e => e.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'draft',
      category: req.body.category || 'conference',
      registrationsCount: req.body.registrationsCount || 0,
      attendeesCount: req.body.attendeesCount || 0,
      startDate: req.body.startDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    events.push(event);
    emitEvent('advanced-events:updated', {
      action: 'create',
      entityType: 'event',
      entityId: event.id,
      data: event,
    });
    res.json({ success: true, data: event });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/activities', async (req, res) => {
  try {
    const { eventId, type, status } = req.query;
    let filtered = activities;
    if (eventId) filtered = filtered.filter(a => a.eventId === parseInt(eventId));
    if (type) filtered = filtered.filter(a => a.type === type);
    if (status) filtered = filtered.filter(a => a.status === status);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/activities', async (req, res) => {
  try {
    const activity = {
      id: activities.length > 0 ? Math.max(...activities.map(a => a.id)) + 1 : 1,
      ...req.body,
      type: req.body.type || 'presentation',
      status: req.body.status || 'scheduled',
      participantsCount: req.body.participantsCount || 0,
      dateTime: req.body.dateTime || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    activities.push(activity);
    emitEvent('advanced-events:updated', {
      action: 'create',
      entityType: 'activity',
      entityId: activity.id,
      data: activity,
    });
    res.json({ success: true, data: activity });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/registrations', async (req, res) => {
  try {
    const { eventId, status, paymentStatus } = req.query;
    let filtered = registrations;
    if (eventId) filtered = filtered.filter(r => r.eventId === parseInt(eventId));
    if (status) filtered = filtered.filter(r => r.status === status);
    if (paymentStatus) filtered = filtered.filter(r => r.paymentStatus === paymentStatus);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/registrations', async (req, res) => {
  try {
    const registration = {
      id: registrations.length > 0 ? Math.max(...registrations.map(r => r.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'registered',
      paymentStatus: req.body.paymentStatus || 'unpaid',
      registrationDate: req.body.registrationDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    registrations.push(registration);

    // Update event registrations count
    const event = events.find(e => e.id === registration.eventId);
    if (event) {
      event.registrationsCount = (event.registrationsCount || 0) + 1;
    }

    emitEvent('advanced-events:updated', {
      action: 'create',
      entityType: 'registration',
      entityId: registration.id,
      data: registration,
    });
    res.json({ success: true, data: registration });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/attendees', async (req, res) => {
  try {
    const { eventId } = req.query;
    let filtered = attendees;
    if (eventId) filtered = filtered.filter(a => a.eventId === parseInt(eventId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/attendees', async (req, res) => {
  try {
    const attendee = {
      id: attendees.length > 0 ? Math.max(...attendees.map(a => a.id)) + 1 : 1,
      ...req.body,
      checkInTime: req.body.checkInTime || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    attendees.push(attendee);

    // Update event attendees count
    const event = events.find(e => e.id === attendee.eventId);
    if (event) {
      event.attendeesCount = (event.attendeesCount || 0) + 1;
    }

    emitEvent('advanced-events:updated', {
      action: 'create',
      entityType: 'attendee',
      entityId: attendee.id,
      data: attendee,
    });
    res.json({ success: true, data: attendee });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/speakers', async (req, res) => {
  try {
    const { eventId } = req.query;
    let filtered = speakers;
    if (eventId) filtered = filtered.filter(s => s.eventId === parseInt(eventId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/speakers', async (req, res) => {
  try {
    const speaker = {
      id: speakers.length > 0 ? Math.max(...speakers.map(s => s.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    speakers.push(speaker);
    emitEvent('advanced-events:updated', {
      action: 'create',
      entityType: 'speaker',
      entityId: speaker.id,
      data: speaker,
    });
    res.json({ success: true, data: speaker });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/sponsors', async (req, res) => {
  try {
    const { eventId, level } = req.query;
    let filtered = sponsors;
    if (eventId) filtered = filtered.filter(s => s.eventId === parseInt(eventId));
    if (level) filtered = filtered.filter(s => s.level === level);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/sponsors', async (req, res) => {
  try {
    const sponsor = {
      id: sponsors.length > 0 ? Math.max(...sponsors.map(s => s.id)) + 1 : 1,
      ...req.body,
      level: req.body.level || 'bronze',
      amount: req.body.amount || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    sponsors.push(sponsor);
    emitEvent('advanced-events:updated', {
      action: 'create',
      entityType: 'sponsor',
      entityId: sponsor.id,
      data: sponsor,
    });
    res.json({ success: true, data: sponsor });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/venues', async (req, res) => {
  try {
    res.json({ success: true, data: venues });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/venues', async (req, res) => {
  try {
    const venue = {
      id: venues.length > 0 ? Math.max(...venues.map(v => v.id)) + 1 : 1,
      ...req.body,
      capacity: req.body.capacity || 0,
      eventsCount: req.body.eventsCount || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    venues.push(venue);
    emitEvent('advanced-events:updated', {
      action: 'create',
      entityType: 'venue',
      entityId: venue.id,
      data: venue,
    });
    res.json({ success: true, data: venue });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/analytics', async (req, res) => {
  try {
    const totalEvents = events.length;
    const publishedEvents = events.filter(e => e.status === 'published').length;
    const ongoingEvents = events.filter(e => e.status === 'ongoing').length;
    const completedEvents = events.filter(e => e.status === 'completed').length;
    const totalActivities = activities.length;
    const totalRegistrations = registrations.length;
    const confirmedRegistrations = registrations.filter(r => r.status === 'confirmed').length;
    const totalAttendees = attendees.length;
    const totalSpeakers = speakers.length;
    const totalSponsors = sponsors.length;
    const totalVenues = venues.length;
    const totalSponsorshipAmount = sponsors.reduce((sum, s) => sum + (s.amount || 0), 0);
    const averageAttendance =
      events.length > 0
        ? (events.reduce((sum, e) => sum + (e.attendeesCount || 0), 0) / events.length).toFixed(1)
        : 0;

    const analyticsData = [
      {
        id: 1,
        metric: 'إجمالي الأحداث',
        value: totalEvents,
        description: 'عدد الأحداث الكلي',
        trend: null,
      },
      {
        id: 2,
        metric: 'الأحداث المنشورة',
        value: publishedEvents,
        description: 'عدد الأحداث المنشورة',
        trend: null,
      },
      {
        id: 3,
        metric: 'الأحداث الجارية',
        value: ongoingEvents,
        description: 'عدد الأحداث الجارية',
        trend: null,
      },
      {
        id: 4,
        metric: 'الأحداث المكتملة',
        value: completedEvents,
        description: 'عدد الأحداث المكتملة',
        trend: null,
      },
      {
        id: 5,
        metric: 'إجمالي الفعاليات',
        value: totalActivities,
        description: 'عدد الفعاليات الكلي',
        trend: null,
      },
      {
        id: 6,
        metric: 'إجمالي التسجيلات',
        value: totalRegistrations,
        description: 'عدد التسجيلات الكلي',
        trend: null,
      },
      {
        id: 7,
        metric: 'التسجيلات المؤكدة',
        value: confirmedRegistrations,
        description: 'عدد التسجيلات المؤكدة',
        trend: null,
      },
      {
        id: 8,
        metric: 'إجمالي الحضور',
        value: totalAttendees,
        description: 'عدد الحضور الكلي',
        trend: null,
      },
      {
        id: 9,
        metric: 'إجمالي المتحدثين',
        value: totalSpeakers,
        description: 'عدد المتحدثين الكلي',
        trend: null,
      },
      {
        id: 10,
        metric: 'إجمالي الرعاة',
        value: totalSponsors,
        description: 'عدد الرعاة الكلي',
        trend: null,
      },
      {
        id: 11,
        metric: 'إجمالي مبلغ الرعاية',
        value: `${totalSponsorshipAmount.toLocaleString()} ريال`,
        description: 'إجمالي مبلغ الرعاية',
        trend: null,
      },
      {
        id: 12,
        metric: 'إجمالي الأماكن',
        value: totalVenues,
        description: 'عدد الأماكن الكلي',
        trend: null,
      },
      {
        id: 13,
        metric: 'متوسط الحضور',
        value: `${averageAttendance} شخص`,
        description: 'متوسط الحضور لكل حدث',
        trend: null,
      },
    ];

    res.json({ success: true, data: analyticsData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
