/**
 * 🏢 Advanced Facilities & Services Management Routes
 */

const express = require('express');
const router = express.Router();

const facilities = [];
const services = [];
const bookings = [];
const equipment = [];
const maintenance = [];
const reservations = [];
const analytics = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/facilities', async (req, res) => {
  try {
    const { status, type } = req.query;
    let filtered = facilities;
    if (status) filtered = filtered.filter(f => f.status === status);
    if (type) filtered = filtered.filter(f => f.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/facilities', async (req, res) => {
  try {
    const facility = {
      id: facilities.length > 0 ? Math.max(...facilities.map(f => f.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'available',
      type: req.body.type || 'room',
      capacity: req.body.capacity || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    facilities.push(facility);
    emitEvent('advanced-facilities:updated', {
      action: 'create',
      entityType: 'facility',
      entityId: facility.id,
      data: facility,
    });
    res.json({ success: true, data: facility });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/services', async (req, res) => {
  try {
    const { status, type } = req.query;
    let filtered = services;
    if (status) filtered = filtered.filter(s => s.status === status);
    if (type) filtered = filtered.filter(s => s.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/services', async (req, res) => {
  try {
    const service = {
      id: services.length > 0 ? Math.max(...services.map(s => s.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      price: req.body.price || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    services.push(service);
    emitEvent('advanced-facilities:updated', {
      action: 'create',
      entityType: 'service',
      entityId: service.id,
      data: service,
    });
    res.json({ success: true, data: service });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/bookings', async (req, res) => {
  try {
    const { status, facilityId } = req.query;
    let filtered = bookings;
    if (status) filtered = filtered.filter(b => b.status === status);
    if (facilityId) filtered = filtered.filter(b => b.facilityId === parseInt(facilityId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/bookings', async (req, res) => {
  try {
    const booking = {
      id: bookings.length > 0 ? Math.max(...bookings.map(b => b.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'pending',
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    bookings.push(booking);
    emitEvent('advanced-facilities:updated', {
      action: 'create',
      entityType: 'booking',
      entityId: booking.id,
      data: booking,
    });
    res.json({ success: true, data: booking });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/equipment', async (req, res) => {
  try {
    const { status, facilityId } = req.query;
    let filtered = equipment;
    if (status) filtered = filtered.filter(e => e.status === status);
    if (facilityId) filtered = filtered.filter(e => e.facilityId === parseInt(facilityId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/equipment', async (req, res) => {
  try {
    const eq = {
      id: equipment.length > 0 ? Math.max(...equipment.map(e => e.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    equipment.push(eq);
    emitEvent('advanced-facilities:updated', {
      action: 'create',
      entityType: 'equipment',
      entityId: eq.id,
      data: eq,
    });
    res.json({ success: true, data: eq });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/maintenance', async (req, res) => {
  try {
    const { status, facilityId } = req.query;
    let filtered = maintenance;
    if (status) filtered = filtered.filter(m => m.status === status);
    if (facilityId) filtered = filtered.filter(m => m.facilityId === parseInt(facilityId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/maintenance', async (req, res) => {
  try {
    const maint = {
      id: maintenance.length > 0 ? Math.max(...maintenance.map(m => m.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'pending',
      cost: req.body.cost || 0,
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    maintenance.push(maint);
    emitEvent('advanced-facilities:updated', {
      action: 'create',
      entityType: 'maintenance',
      entityId: maint.id,
      data: maint,
    });
    res.json({ success: true, data: maint });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/reservations', async (req, res) => {
  try {
    const { status, facilityId } = req.query;
    let filtered = reservations;
    if (status) filtered = filtered.filter(r => r.status === status);
    if (facilityId) filtered = filtered.filter(r => r.facilityId === parseInt(facilityId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/reservations', async (req, res) => {
  try {
    const reservation = {
      id: reservations.length > 0 ? Math.max(...reservations.map(r => r.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'pending',
      startDate: req.body.startDate || new Date().toISOString(),
      endDate: req.body.endDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    reservations.push(reservation);
    emitEvent('advanced-facilities:updated', {
      action: 'create',
      entityType: 'reservation',
      entityId: reservation.id,
      data: reservation,
    });
    res.json({ success: true, data: reservation });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/analytics', async (req, res) => {
  try {
    const totalFacilities = facilities.length;
    const availableFacilities = facilities.filter(f => f.status === 'available').length;
    const totalServices = services.length;
    const activeServices = services.filter(s => s.status === 'active').length;
    const totalBookings = bookings.length;
    const confirmedBookings = bookings.filter(b => b.status === 'confirmed').length;
    const totalEquipment = equipment.length;
    const activeEquipment = equipment.filter(e => e.status === 'active').length;
    const totalMaintenance = maintenance.length;
    const pendingMaintenance = maintenance.filter(m => m.status === 'pending').length;
    const totalReservations = reservations.length;
    const activeReservations = reservations.filter(r => r.status === 'confirmed').length;
    const totalMaintenanceCost = maintenance.reduce((sum, m) => sum + (m.cost || 0), 0);

    const analyticsData = [
      {
        id: 1,
        metric: 'إجمالي المرافق',
        value: totalFacilities,
        description: 'عدد المرافق الكلي',
      },
      {
        id: 2,
        metric: 'المرافق المتاحة',
        value: availableFacilities,
        description: 'عدد المرافق المتاحة',
      },
      {
        id: 3,
        metric: 'إجمالي الخدمات',
        value: totalServices,
        description: 'عدد الخدمات الكلي',
      },
      {
        id: 4,
        metric: 'الخدمات النشطة',
        value: activeServices,
        description: 'عدد الخدمات النشطة',
      },
      {
        id: 5,
        metric: 'إجمالي الحجوزات',
        value: totalBookings,
        description: 'عدد الحجوزات الكلي',
      },
      {
        id: 6,
        metric: 'الحجوزات المؤكدة',
        value: confirmedBookings,
        description: 'عدد الحجوزات المؤكدة',
      },
      {
        id: 7,
        metric: 'إجمالي المعدات',
        value: totalEquipment,
        description: 'عدد المعدات الكلي',
      },
      {
        id: 8,
        metric: 'المعدات النشطة',
        value: activeEquipment,
        description: 'عدد المعدات النشطة',
      },
      {
        id: 9,
        metric: 'إجمالي الصيانة',
        value: totalMaintenance,
        description: 'عدد سجلات الصيانة الكلي',
      },
      {
        id: 10,
        metric: 'الصيانة قيد الانتظار',
        value: pendingMaintenance,
        description: 'عدد سجلات الصيانة قيد الانتظار',
      },
      {
        id: 11,
        metric: 'إجمالي الحجوزات',
        value: totalReservations,
        description: 'عدد الحجوزات الكلي',
      },
      {
        id: 12,
        metric: 'الحجوزات النشطة',
        value: activeReservations,
        description: 'عدد الحجوزات النشطة',
      },
      {
        id: 13,
        metric: 'إجمالي تكلفة الصيانة',
        value: `${totalMaintenanceCost.toLocaleString()} ريال`,
        description: 'إجمالي تكلفة الصيانة',
      },
    ];

    res.json({ success: true, data: analyticsData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
