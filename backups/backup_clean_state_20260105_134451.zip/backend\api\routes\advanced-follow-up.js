/**
 * 📞 Advanced Follow-up Management Routes
 */

const express = require('express');
const router = express.Router();

const followUps = [];
const schedules = [];
const contacts = [];
const reminders = [];
const outcomes = [];
const satisfaction = [];
const feedback = [];
const analytics = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/follow-ups', async (req, res) => {
  try {
    const { status, type, priority, patientId } = req.query;
    let filtered = followUps;
    if (status) filtered = filtered.filter(f => f.status === status);
    if (type) filtered = filtered.filter(f => f.type === type);
    if (priority) filtered = filtered.filter(f => f.priority === priority);
    if (patientId) filtered = filtered.filter(f => f.patientId === parseInt(patientId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/follow-ups', async (req, res) => {
  try {
    const followUp = {
      id: followUps.length > 0 ? Math.max(...followUps.map(f => f.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'scheduled',
      type: req.body.type || 'phone',
      priority: req.body.priority || 'medium',
      scheduledAt: req.body.scheduledAt || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    followUps.push(followUp);
    emitEvent('advanced-follow-up:updated', {
      action: 'create',
      entityType: 'followUp',
      entityId: followUp.id,
      data: followUp,
    });
    res.json({ success: true, data: followUp });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/follow-ups/:id/start', async (req, res) => {
  try {
    const index = followUps.findIndex(f => f.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Follow-up not found' });
    }
    followUps[index].status = 'in-progress';
    followUps[index].startedAt = new Date().toISOString();
    emitEvent('advanced-follow-up:updated', {
      action: 'update',
      entityType: 'followUp',
      entityId: followUps[index].id,
      data: followUps[index],
    });
    res.json({ success: true, data: followUps[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/follow-ups/:id/complete', async (req, res) => {
  try {
    const index = followUps.findIndex(f => f.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Follow-up not found' });
    }
    followUps[index].status = 'completed';
    followUps[index].completedAt = new Date().toISOString();
    followUps[index].outcome = req.body.outcome || 'غير محدد';

    // Create outcome record
    const outcome = {
      id: outcomes.length > 0 ? Math.max(...outcomes.map(o => o.id)) + 1 : 1,
      followUpId: followUps[index].id,
      followUpName: `${followUps[index].patientName} - ${followUps[index].type}`,
      patientName: followUps[index].patientName,
      result: req.body.outcome || 'غير محدد',
      positive: req.body.positive || false,
      actions: req.body.actions || [],
      date: new Date().toISOString(),
    };
    outcomes.push(outcome);

    emitEvent('advanced-follow-up:updated', {
      action: 'update',
      entityType: 'followUp',
      entityId: followUps[index].id,
      data: followUps[index],
    });
    res.json({ success: true, data: followUps[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/schedules', async (req, res) => {
  try {
    const { date, patientId } = req.query;
    let filtered = schedules;
    if (date) filtered = filtered.filter(s => s.date === date);
    if (patientId) filtered = filtered.filter(s => s.patientId === parseInt(patientId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/contacts', async (req, res) => {
  try {
    const { patientId, priority } = req.query;
    let filtered = contacts;
    if (patientId) filtered = filtered.filter(c => c.patientId === parseInt(patientId));
    if (priority) filtered = filtered.filter(c => c.priority === priority);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/contacts', async (req, res) => {
  try {
    const contact = {
      id: contacts.length > 0 ? Math.max(...contacts.map(c => c.id)) + 1 : 1,
      ...req.body,
      priority: req.body.priority || 'medium',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    contacts.push(contact);
    emitEvent('advanced-follow-up:updated', {
      action: 'create',
      entityType: 'contact',
      entityId: contact.id,
      data: contact,
    });
    res.json({ success: true, data: contact });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/reminders', async (req, res) => {
  try {
    const { sent, followUpId } = req.query;
    let filtered = reminders;
    if (sent !== undefined) filtered = filtered.filter(r => r.sent === (sent === 'true'));
    if (followUpId) filtered = filtered.filter(r => r.followUpId === parseInt(followUpId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/outcomes', async (req, res) => {
  try {
    const { patientId, positive } = req.query;
    let filtered = outcomes;
    if (patientId) filtered = filtered.filter(o => o.patientId === parseInt(patientId));
    if (positive === 'true') filtered = filtered.filter(o => o.positive === true);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/satisfaction', async (req, res) => {
  try {
    const { patientId, minRating } = req.query;
    let filtered = satisfaction;
    if (patientId) filtered = filtered.filter(s => s.patientId === parseInt(patientId));
    if (minRating) filtered = filtered.filter(s => s.rating >= parseInt(minRating));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/satisfaction', async (req, res) => {
  try {
    const sat = {
      id: satisfaction.length > 0 ? Math.max(...satisfaction.map(s => s.id)) + 1 : 1,
      ...req.body,
      rating: req.body.rating || 0,
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    satisfaction.push(sat);
    emitEvent('advanced-follow-up:updated', {
      action: 'create',
      entityType: 'satisfaction',
      entityId: sat.id,
      data: sat,
    });
    res.json({ success: true, data: sat });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/feedback', async (req, res) => {
  try {
    const { patientId, type } = req.query;
    let filtered = feedback;
    if (patientId) filtered = filtered.filter(f => f.patientId === parseInt(patientId));
    if (type) filtered = filtered.filter(f => f.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/feedback', async (req, res) => {
  try {
    const fb = {
      id: feedback.length > 0 ? Math.max(...feedback.map(f => f.id)) + 1 : 1,
      ...req.body,
      type: req.body.type || 'general',
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    feedback.push(fb);
    emitEvent('advanced-follow-up:updated', {
      action: 'create',
      entityType: 'feedback',
      entityId: fb.id,
      data: fb,
    });
    res.json({ success: true, data: fb });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/analytics', async (req, res) => {
  try {
    const totalFollowUps = followUps.length;
    const scheduledFollowUps = followUps.filter(f => f.status === 'scheduled').length;
    const completedFollowUps = followUps.filter(f => f.status === 'completed').length;
    const missedFollowUps = followUps.filter(f => f.status === 'missed').length;
    const totalContacts = contacts.length;
    const totalOutcomes = outcomes.length;
    const positiveOutcomes = outcomes.filter(o => o.positive === true).length;
    const averageSatisfaction =
      satisfaction.length > 0
        ? (satisfaction.reduce((sum, s) => sum + (s.rating || 0), 0) / satisfaction.length).toFixed(
            1
          )
        : 0;
    const totalFeedback = feedback.length;

    const analyticsData = [
      {
        id: 1,
        metric: 'إجمالي المتابعات',
        value: totalFollowUps,
        description: 'عدد المتابعات الكلي',
        trend: null,
      },
      {
        id: 2,
        metric: 'المتابعات المجدولة',
        value: scheduledFollowUps,
        description: 'عدد المتابعات المجدولة',
        trend: null,
      },
      {
        id: 3,
        metric: 'المتابعات المكتملة',
        value: completedFollowUps,
        description: 'عدد المتابعات المكتملة',
        trend: null,
      },
      {
        id: 4,
        metric: 'المتابعات الفائتة',
        value: missedFollowUps,
        description: 'عدد المتابعات الفائتة',
        trend: null,
      },
      {
        id: 5,
        metric: 'إجمالي جهات الاتصال',
        value: totalContacts,
        description: 'عدد جهات الاتصال الكلي',
        trend: null,
      },
      {
        id: 6,
        metric: 'إجمالي النتائج',
        value: totalOutcomes,
        description: 'عدد النتائج الكلي',
        trend: null,
      },
      {
        id: 7,
        metric: 'النتائج الإيجابية',
        value: positiveOutcomes,
        description: 'عدد النتائج الإيجابية',
        trend: null,
      },
      {
        id: 8,
        metric: 'متوسط الرضا',
        value: `${averageSatisfaction}/5`,
        description: 'متوسط تقييم الرضا',
        trend: null,
      },
      {
        id: 9,
        metric: 'إجمالي التعليقات',
        value: totalFeedback,
        description: 'عدد التعليقات الكلي',
        trend: null,
      },
    ];

    res.json({ success: true, data: analyticsData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
module.exports.setIO = setIO;
