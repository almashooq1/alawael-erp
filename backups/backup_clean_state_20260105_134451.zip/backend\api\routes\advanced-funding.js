/**
 * 💰 Advanced Funding Management Routes
 */

const express = require('express');
const router = express.Router();

const grants = [];
const donations = [];
const funders = [];
const applications = [];
const budgets = [];
const expenses = [];
const analytics = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/grants', async (req, res) => {
  try {
    const { status, type } = req.query;
    let filtered = grants;
    if (status) filtered = filtered.filter(g => g.status === status);
    if (type) filtered = filtered.filter(g => g.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/grants', async (req, res) => {
  try {
    const grant = {
      id: grants.length > 0 ? Math.max(...grants.map(g => g.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      type: req.body.type || 'government',
      amount: req.body.amount || 0,
      usedAmount: req.body.usedAmount || 0,
      startDate: req.body.startDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    grants.push(grant);
    emitEvent('advanced-funding:updated', {
      action: 'create',
      entityType: 'grant',
      entityId: grant.id,
      data: grant,
    });
    res.json({ success: true, data: grant });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/donations', async (req, res) => {
  try {
    const { type, date } = req.query;
    let filtered = donations;
    if (type) filtered = filtered.filter(d => d.type === type);
    if (date)
      filtered = filtered.filter(
        d => new Date(d.date).toDateString() === new Date(date).toDateString()
      );
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/donations', async (req, res) => {
  try {
    const donation = {
      id: donations.length > 0 ? Math.max(...donations.map(d => d.id)) + 1 : 1,
      ...req.body,
      type: req.body.type || 'cash',
      amount: req.body.amount || 0,
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    donations.push(donation);
    emitEvent('advanced-funding:updated', {
      action: 'create',
      entityType: 'donation',
      entityId: donation.id,
      data: donation,
    });
    res.json({ success: true, data: donation });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/funders', async (req, res) => {
  try {
    const { type } = req.query;
    let filtered = funders;
    if (type) filtered = filtered.filter(f => f.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/funders', async (req, res) => {
  try {
    const funder = {
      id: funders.length > 0 ? Math.max(...funders.map(f => f.id)) + 1 : 1,
      ...req.body,
      type: req.body.type || 'government',
      grantsCount: req.body.grantsCount || 0,
      totalAmount: req.body.totalAmount || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    funders.push(funder);
    emitEvent('advanced-funding:updated', {
      action: 'create',
      entityType: 'funder',
      entityId: funder.id,
      data: funder,
    });
    res.json({ success: true, data: funder });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/applications', async (req, res) => {
  try {
    const { status, funderId } = req.query;
    let filtered = applications;
    if (status) filtered = filtered.filter(a => a.status === status);
    if (funderId) filtered = filtered.filter(a => a.funderId === parseInt(funderId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/applications', async (req, res) => {
  try {
    const application = {
      id: applications.length > 0 ? Math.max(...applications.map(a => a.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'pending',
      requestedAmount: req.body.requestedAmount || 0,
      submitDate: req.body.submitDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    applications.push(application);
    emitEvent('advanced-funding:updated', {
      action: 'create',
      entityType: 'application',
      entityId: application.id,
      data: application,
    });
    res.json({ success: true, data: application });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/budgets', async (req, res) => {
  try {
    const { year } = req.query;
    let filtered = budgets;
    if (year)
      filtered = filtered.filter(b => new Date(b.startDate).getFullYear() === parseInt(year));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/budgets', async (req, res) => {
  try {
    const budget = {
      id: budgets.length > 0 ? Math.max(...budgets.map(b => b.id)) + 1 : 1,
      ...req.body,
      totalAmount: req.body.totalAmount || 0,
      usedAmount: req.body.usedAmount || 0,
      startDate: req.body.startDate || new Date().toISOString(),
      endDate: req.body.endDate || new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    budgets.push(budget);
    emitEvent('advanced-funding:updated', {
      action: 'create',
      entityType: 'budget',
      entityId: budget.id,
      data: budget,
    });
    res.json({ success: true, data: budget });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/expenses', async (req, res) => {
  try {
    const { category, projectId, date } = req.query;
    let filtered = expenses;
    if (category) filtered = filtered.filter(e => e.category === category);
    if (projectId) filtered = filtered.filter(e => e.projectId === parseInt(projectId));
    if (date)
      filtered = filtered.filter(
        e => new Date(e.date).toDateString() === new Date(date).toDateString()
      );
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/expenses', async (req, res) => {
  try {
    const expense = {
      id: expenses.length > 0 ? Math.max(...expenses.map(e => e.id)) + 1 : 1,
      ...req.body,
      amount: req.body.amount || 0,
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    expenses.push(expense);

    // Update budget used amount
    const budget = budgets.find(b => b.id === expense.budgetId);
    if (budget) {
      budget.usedAmount = (budget.usedAmount || 0) + expense.amount;
    }

    // Update grant used amount
    const grant = grants.find(g => g.id === expense.grantId);
    if (grant) {
      grant.usedAmount = (grant.usedAmount || 0) + expense.amount;
    }

    emitEvent('advanced-funding:updated', {
      action: 'create',
      entityType: 'expense',
      entityId: expense.id,
      data: expense,
    });
    res.json({ success: true, data: expense });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/analytics', async (req, res) => {
  try {
    const totalGrants = grants.length;
    const activeGrants = grants.filter(g => g.status === 'active').length;
    const totalGrantsAmount = grants.reduce((sum, g) => sum + (g.amount || 0), 0);
    const usedGrantsAmount = grants.reduce((sum, g) => sum + (g.usedAmount || 0), 0);
    const totalDonations = donations.length;
    const totalDonationsAmount = donations.reduce((sum, d) => sum + (d.amount || 0), 0);
    const totalFunders = funders.length;
    const totalApplications = applications.length;
    const pendingApplications = applications.filter(a => a.status === 'pending').length;
    const approvedApplications = applications.filter(a => a.status === 'approved').length;
    const totalBudgets = budgets.length;
    const totalExpenses = expenses.length;
    const totalExpensesAmount = expenses.reduce((sum, e) => sum + (e.amount || 0), 0);

    const analyticsData = [
      {
        id: 1,
        metric: 'إجمالي المنح',
        value: totalGrants,
        description: 'عدد المنح الكلي',
      },
      {
        id: 2,
        metric: 'المنح النشطة',
        value: activeGrants,
        description: 'عدد المنح النشطة',
      },
      {
        id: 3,
        metric: 'إجمالي قيمة المنح',
        value: `${totalGrantsAmount.toLocaleString('ar-SA')} ر.س`,
        description: 'إجمالي قيمة جميع المنح',
      },
      {
        id: 4,
        metric: 'القيمة المستخدمة من المنح',
        value: `${usedGrantsAmount.toLocaleString('ar-SA')} ر.س`,
        description: 'القيمة المستخدمة من المنح',
      },
      {
        id: 5,
        metric: 'إجمالي التبرعات',
        value: totalDonations,
        description: 'عدد التبرعات الكلي',
      },
      {
        id: 6,
        metric: 'إجمالي قيمة التبرعات',
        value: `${totalDonationsAmount.toLocaleString('ar-SA')} ر.س`,
        description: 'إجمالي قيمة جميع التبرعات',
      },
      {
        id: 7,
        metric: 'إجمالي الممولين',
        value: totalFunders,
        description: 'عدد الممولين الكلي',
      },
      {
        id: 8,
        metric: 'إجمالي طلبات التمويل',
        value: totalApplications,
        description: 'عدد طلبات التمويل الكلي',
      },
      {
        id: 9,
        metric: 'الطلبات قيد الانتظار',
        value: pendingApplications,
        description: 'عدد الطلبات قيد الانتظار',
      },
      {
        id: 10,
        metric: 'الطلبات الموافق عليها',
        value: approvedApplications,
        description: 'عدد الطلبات الموافق عليها',
      },
      {
        id: 11,
        metric: 'إجمالي الميزانيات',
        value: totalBudgets,
        description: 'عدد الميزانيات الكلي',
      },
      {
        id: 12,
        metric: 'إجمالي المصروفات',
        value: totalExpenses,
        description: 'عدد المصروفات الكلي',
      },
      {
        id: 13,
        metric: 'إجمالي قيمة المصروفات',
        value: `${totalExpensesAmount.toLocaleString('ar-SA')} ر.س`,
        description: 'إجمالي قيمة جميع المصروفات',
      },
    ];

    res.json({ success: true, data: analyticsData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
