/**
 * 🎯 Advanced Goals & Plans Management Routes
 */

const express = require('express');
const router = express.Router();

const goals = [];
const plans = [];
const objectives = [];
const milestones = [];
const tasks = [];
const progress = [];
const reviews = [];
const recommendations = [];
const analytics = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/goals', async (req, res) => {
  try {
    const { status, priority, category, patientId } = req.query;
    let filtered = goals;
    if (status) filtered = filtered.filter(g => g.status === status);
    if (priority) filtered = filtered.filter(g => g.priority === priority);
    if (category) filtered = filtered.filter(g => g.category === category);
    if (patientId) filtered = filtered.filter(g => g.patientId === parseInt(patientId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/goals', async (req, res) => {
  try {
    const goal = {
      id: goals.length > 0 ? Math.max(...goals.map(g => g.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'pending',
      priority: req.body.priority || 'medium',
      category: req.body.category || 'general',
      progress: req.body.progress || 0,
      objectivesCount: req.body.objectivesCount || 0,
      tasksCount: req.body.tasksCount || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    goals.push(goal);
    emitEvent('advanced-goals-plans:updated', {
      action: 'create',
      entityType: 'goal',
      entityId: goal.id,
      data: goal,
    });
    res.json({ success: true, data: goal });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/goals/:id/progress', async (req, res) => {
  try {
    const index = goals.findIndex(g => g.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Goal not found' });
    }
    goals[index].progress = req.body.progress || goals[index].progress;
    if (goals[index].progress >= 100) {
      goals[index].status = 'completed';
    } else if (goals[index].progress > 0) {
      goals[index].status = 'in-progress';
    }
    emitEvent('advanced-goals-plans:updated', {
      action: 'update',
      entityType: 'goal',
      entityId: goals[index].id,
      data: goals[index],
    });
    res.json({ success: true, data: goals[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/plans', async (req, res) => {
  try {
    const { status, type, patientId } = req.query;
    let filtered = plans;
    if (status) filtered = filtered.filter(p => p.status === status);
    if (type) filtered = filtered.filter(p => p.type === type);
    if (patientId) filtered = filtered.filter(p => p.patientId === parseInt(patientId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/plans', async (req, res) => {
  try {
    const plan = {
      id: plans.length > 0 ? Math.max(...plans.map(p => p.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'pending',
      type: req.body.type || 'treatment',
      progress: req.body.progress || 0,
      goalsCount: req.body.goalsCount || 0,
      milestonesCount: req.body.milestonesCount || 0,
      startDate: req.body.startDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    plans.push(plan);
    emitEvent('advanced-goals-plans:updated', {
      action: 'create',
      entityType: 'plan',
      entityId: plan.id,
      data: plan,
    });
    res.json({ success: true, data: plan });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/objectives', async (req, res) => {
  try {
    const { goalId, completed } = req.query;
    let filtered = objectives;
    if (goalId) filtered = filtered.filter(o => o.goalId === parseInt(goalId));
    if (completed !== undefined)
      filtered = filtered.filter(o => o.completed === (completed === 'true'));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/objectives', async (req, res) => {
  try {
    const objective = {
      id: objectives.length > 0 ? Math.max(...objectives.map(o => o.id)) + 1 : 1,
      ...req.body,
      completed: req.body.completed || false,
      progress: req.body.progress || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    objectives.push(objective);
    emitEvent('advanced-goals-plans:updated', {
      action: 'create',
      entityType: 'objective',
      entityId: objective.id,
      data: objective,
    });
    res.json({ success: true, data: objective });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/milestones', async (req, res) => {
  try {
    const { planId, achieved } = req.query;
    let filtered = milestones;
    if (planId) filtered = filtered.filter(m => m.planId === parseInt(planId));
    if (achieved !== undefined)
      filtered = filtered.filter(m => m.achieved === (achieved === 'true'));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/milestones', async (req, res) => {
  try {
    const milestone = {
      id: milestones.length > 0 ? Math.max(...milestones.map(m => m.id)) + 1 : 1,
      ...req.body,
      achieved: req.body.achieved || false,
      targetDate: req.body.targetDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    milestones.push(milestone);
    emitEvent('advanced-goals-plans:updated', {
      action: 'create',
      entityType: 'milestone',
      entityId: milestone.id,
      data: milestone,
    });
    res.json({ success: true, data: milestone });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/tasks', async (req, res) => {
  try {
    const { goalId, status, priority } = req.query;
    let filtered = tasks;
    if (goalId) filtered = filtered.filter(t => t.goalId === parseInt(goalId));
    if (status) filtered = filtered.filter(t => t.status === status);
    if (priority) filtered = filtered.filter(t => t.priority === priority);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/tasks', async (req, res) => {
  try {
    const task = {
      id: tasks.length > 0 ? Math.max(...tasks.map(t => t.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'pending',
      priority: req.body.priority || 'medium',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    tasks.push(task);
    emitEvent('advanced-goals-plans:updated', {
      action: 'create',
      entityType: 'task',
      entityId: task.id,
      data: task,
    });
    res.json({ success: true, data: task });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/tasks/:id/complete', async (req, res) => {
  try {
    const index = tasks.findIndex(t => t.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Task not found' });
    }
    tasks[index].status = 'completed';
    tasks[index].completedDate = new Date().toISOString();
    emitEvent('advanced-goals-plans:updated', {
      action: 'update',
      entityType: 'task',
      entityId: tasks[index].id,
      data: tasks[index],
    });
    res.json({ success: true, data: tasks[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/progress', async (req, res) => {
  try {
    const { goalId, planId } = req.query;
    let filtered = progress;
    if (goalId) filtered = filtered.filter(p => p.goalId === parseInt(goalId));
    if (planId) filtered = filtered.filter(p => p.planId === parseInt(planId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/progress', async (req, res) => {
  try {
    const progressData = {
      id: progress.length > 0 ? Math.max(...progress.map(p => p.id)) + 1 : 1,
      ...req.body,
      overallProgress: req.body.overallProgress || 0,
      completedGoals: req.body.completedGoals || 0,
      completedTasks: req.body.completedTasks || 0,
      achievedMilestones: req.body.achievedMilestones || 0,
      history: req.body.history || [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    progress.push(progressData);
    emitEvent('advanced-goals-plans:updated', {
      action: 'create',
      entityType: 'progress',
      entityId: progressData.id,
      data: progressData,
    });
    res.json({ success: true, data: progressData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/reviews', async (req, res) => {
  try {
    const { goalId, planId } = req.query;
    let filtered = reviews;
    if (goalId) filtered = filtered.filter(r => r.goalId === parseInt(goalId));
    if (planId) filtered = filtered.filter(r => r.planId === parseInt(planId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/reviews', async (req, res) => {
  try {
    const review = {
      id: reviews.length > 0 ? Math.max(...reviews.map(r => r.id)) + 1 : 1,
      ...req.body,
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    reviews.push(review);
    emitEvent('advanced-goals-plans:updated', {
      action: 'create',
      entityType: 'review',
      entityId: review.id,
      data: review,
    });
    res.json({ success: true, data: review });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/recommendations', async (req, res) => {
  try {
    const { goalId, planId, priority } = req.query;
    let filtered = recommendations;
    if (goalId) filtered = filtered.filter(r => r.goalId === parseInt(goalId));
    if (planId) filtered = filtered.filter(r => r.planId === parseInt(planId));
    if (priority) filtered = filtered.filter(r => r.priority === priority);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/recommendations', async (req, res) => {
  try {
    const recommendation = {
      id: recommendations.length > 0 ? Math.max(...recommendations.map(r => r.id)) + 1 : 1,
      ...req.body,
      priority: req.body.priority || 'medium',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    recommendations.push(recommendation);
    emitEvent('advanced-goals-plans:updated', {
      action: 'create',
      entityType: 'recommendation',
      entityId: recommendation.id,
      data: recommendation,
    });
    res.json({ success: true, data: recommendation });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/analytics', async (req, res) => {
  try {
    const totalGoals = goals.length;
    const completedGoals = goals.filter(g => g.status === 'completed').length;
    const inProgressGoals = goals.filter(g => g.status === 'in-progress').length;
    const totalPlans = plans.length;
    const activePlans = plans.filter(p => p.status === 'active').length;
    const totalTasks = tasks.length;
    const completedTasks = tasks.filter(t => t.status === 'completed').length;
    const averageProgress =
      goals.length > 0
        ? Math.round(goals.reduce((sum, g) => sum + (g.progress || 0), 0) / goals.length)
        : 0;

    const analyticsData = [
      {
        id: 1,
        metric: 'إجمالي الأهداف',
        value: totalGoals,
        description: 'عدد الأهداف الكلي',
        trend: null,
      },
      {
        id: 2,
        metric: 'الأهداف المكتملة',
        value: completedGoals,
        description: 'عدد الأهداف المكتملة',
        trend: null,
      },
      {
        id: 3,
        metric: 'الأهداف قيد التنفيذ',
        value: inProgressGoals,
        description: 'عدد الأهداف قيد التنفيذ',
        trend: null,
      },
      {
        id: 4,
        metric: 'إجمالي الخطط',
        value: totalPlans,
        description: 'عدد الخطط الكلي',
        trend: null,
      },
      {
        id: 5,
        metric: 'الخطط النشطة',
        value: activePlans,
        description: 'عدد الخطط النشطة',
        trend: null,
      },
      {
        id: 6,
        metric: 'إجمالي المهام',
        value: totalTasks,
        description: 'عدد المهام الكلي',
        trend: null,
      },
      {
        id: 7,
        metric: 'المهام المكتملة',
        value: completedTasks,
        description: 'عدد المهام المكتملة',
        trend: null,
      },
      {
        id: 8,
        metric: 'متوسط التقدم',
        value: `${averageProgress}%`,
        description: 'متوسط التقدم في الأهداف',
        trend: null,
      },
    ];

    res.json({ success: true, data: analyticsData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
