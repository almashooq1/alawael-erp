/**
 * 👔 Advanced HR Management Routes
 */

const express = require('express');
const router = express.Router();

const employees = [];
const departments = [];
const positions = [];
const leaves = [];
const attendance = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/employees', async (req, res) => {
  try {
    const { status, department, position } = req.query;
    let filtered = employees;
    if (status) filtered = filtered.filter(e => e.status === status);
    if (department) filtered = filtered.filter(e => e.department === department);
    if (position) filtered = filtered.filter(e => e.position === position);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/employees', async (req, res) => {
  try {
    const employee = {
      id: employees.length > 0 ? Math.max(...employees.map(e => e.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    employees.push(employee);
    emitEvent('advanced-hr-management:updated', {
      action: 'create',
      entityType: 'employee',
      entityId: employee.id,
      data: employee,
    });
    res.json({ success: true, data: employee });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/departments', async (req, res) => {
  try {
    res.json({ success: true, data: departments });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/departments', async (req, res) => {
  try {
    const department = {
      id: departments.length > 0 ? Math.max(...departments.map(d => d.id)) + 1 : 1,
      ...req.body,
      employeesCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    departments.push(department);
    emitEvent('advanced-hr-management:updated', {
      action: 'create',
      entityType: 'department',
      entityId: department.id,
      data: department,
    });
    res.json({ success: true, data: department });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/positions', async (req, res) => {
  try {
    res.json({ success: true, data: positions });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/positions', async (req, res) => {
  try {
    const position = {
      id: positions.length > 0 ? Math.max(...positions.map(p => p.id)) + 1 : 1,
      ...req.body,
      salary: req.body.salary || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    positions.push(position);
    emitEvent('advanced-hr-management:updated', {
      action: 'create',
      entityType: 'position',
      entityId: position.id,
      data: position,
    });
    res.json({ success: true, data: position });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/leaves', async (req, res) => {
  try {
    const { status, employeeId } = req.query;
    let filtered = leaves;
    if (status) filtered = filtered.filter(l => l.status === status);
    if (employeeId) filtered = filtered.filter(l => l.employeeId === parseInt(employeeId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/leaves', async (req, res) => {
  try {
    const leave = {
      id: leaves.length > 0 ? Math.max(...leaves.map(l => l.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'pending',
      startDate: req.body.startDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    leaves.push(leave);
    emitEvent('advanced-hr-management:updated', {
      action: 'create',
      entityType: 'leave',
      entityId: leave.id,
      data: leave,
    });
    res.json({ success: true, data: leave });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/attendance', async (req, res) => {
  try {
    const { employeeId, date } = req.query;
    let filtered = attendance;
    if (employeeId) filtered = filtered.filter(a => a.employeeId === parseInt(employeeId));
    if (date) filtered = filtered.filter(a => a.date === date);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/attendance', async (req, res) => {
  try {
    const record = {
      id: attendance.length > 0 ? Math.max(...attendance.map(a => a.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'present',
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    attendance.push(record);
    emitEvent('advanced-hr-management:updated', {
      action: 'create',
      entityType: 'attendance',
      entityId: record.id,
      data: record,
    });
    res.json({ success: true, data: record });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
