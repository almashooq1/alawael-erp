/**
 * 👥 Advanced HR Management Routes
 */

const express = require('express');
const router = express.Router();
const notificationManager = require('../../shared/utils/notification-manager');

const employees = [];
const departments = [];
const positions = [];
const leaves = [];
const attendance = [];
const performance = [];
const recruitment = [];
const training = [];
const payroll = [];
const analytics = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/employees', async (req, res) => {
  try {
    const { status, departmentId, positionId } = req.query;
    let filtered = employees;
    if (status) filtered = filtered.filter(e => e.status === status);
    if (departmentId) filtered = filtered.filter(e => e.departmentId === parseInt(departmentId));
    if (positionId) filtered = filtered.filter(e => e.positionId === parseInt(positionId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/employees', async (req, res) => {
  try {
    const employee = {
      id: employees.length > 0 ? Math.max(...employees.map(e => e.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      employeeId: req.body.employeeId || `EMP${Date.now()}`,
      hireDate: req.body.hireDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    employees.push(employee);
    emitEvent('advanced-hr:updated', {
      action: 'create',
      entityType: 'employee',
      entityId: employee.id,
      data: employee,
    });
    res.json({ success: true, data: employee });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/departments', async (req, res) => {
  try {
    res.json({ success: true, data: departments });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/departments', async (req, res) => {
  try {
    const department = {
      id: departments.length > 0 ? Math.max(...departments.map(d => d.id)) + 1 : 1,
      ...req.body,
      code: req.body.code || `DEPT${Date.now()}`,
      employeeCount: req.body.employeeCount || 0,
      budget: req.body.budget || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    departments.push(department);
    emitEvent('advanced-hr:updated', {
      action: 'create',
      entityType: 'department',
      entityId: department.id,
      data: department,
    });
    res.json({ success: true, data: department });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/positions', async (req, res) => {
  try {
    const { departmentId } = req.query;
    let filtered = positions;
    if (departmentId) filtered = filtered.filter(p => p.departmentId === parseInt(departmentId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/positions', async (req, res) => {
  try {
    const position = {
      id: positions.length > 0 ? Math.max(...positions.map(p => p.id)) + 1 : 1,
      ...req.body,
      level: req.body.level || 'junior',
      salary: req.body.salary || 0,
      employeeCount: req.body.employeeCount || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    positions.push(position);
    emitEvent('advanced-hr:updated', {
      action: 'create',
      entityType: 'position',
      entityId: position.id,
      data: position,
    });
    res.json({ success: true, data: position });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/leaves', async (req, res) => {
  try {
    const { status, employeeId, type } = req.query;
    let filtered = leaves;
    if (status) filtered = filtered.filter(l => l.status === status);
    if (employeeId) filtered = filtered.filter(l => l.employeeId === parseInt(employeeId));
    if (type) filtered = filtered.filter(l => l.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/leaves', async (req, res) => {
  try {
    const leave = {
      id: leaves.length > 0 ? Math.max(...leaves.map(l => l.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'pending',
      type: req.body.type || 'annual',
      days: req.body.days || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    leaves.push(leave);
    emitEvent('advanced-hr:updated', {
      action: 'create',
      entityType: 'leave',
      entityId: leave.id,
      data: leave,
    });
    // Notify manager/HR about new leave request
    notificationManager.createNotification(
      'info',
      'طلب إجازة جديد',
      `تم تقديم طلب إجازة من الموظف ${leave.employeeName || leave.employeeId || ''} (${leave.type}) لمدة ${leave.days} يوم.`,
      { leaveId: leave.id, employeeId: leave.employeeId, type: 'leave', status: leave.status }
    );
    res.json({ success: true, data: leave });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/leaves/:id/approve', async (req, res) => {
  try {
    const index = leaves.findIndex(l => l.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Leave not found' });
    }
    leaves[index].status = 'approved';
    leaves[index].approvedAt = new Date().toISOString();
    leaves[index].approvedBy = req.body.approvedBy || 'غير محدد';
    emitEvent('advanced-hr:updated', {
      action: 'update',
      entityType: 'leave',
      entityId: leaves[index].id,
      data: leaves[index],
    });
    // Notify employee about leave approval
    notificationManager.createNotification(
      'success',
      'تمت الموافقة على الإجازة',
      `تمت الموافقة على طلب الإجازة للموظف ${leaves[index].employeeName || leaves[index].employeeId || ''}.`,
      {
        leaveId: leaves[index].id,
        employeeId: leaves[index].employeeId,
        type: 'leave',
        status: 'approved',
      }
    );
    res.json({ success: true, data: leaves[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/leaves/:id/reject', async (req, res) => {
  try {
    const index = leaves.findIndex(l => l.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Leave not found' });
    }
    leaves[index].status = 'rejected';
    leaves[index].rejectedAt = new Date().toISOString();
    leaves[index].rejectionReason = req.body.reason || 'غير محدد';
    emitEvent('advanced-hr:updated', {
      action: 'update',
      entityType: 'leave',
      entityId: leaves[index].id,
      data: leaves[index],
    });
    // Notify employee about leave rejection
    notificationManager.createNotification(
      'warning',
      'تم رفض الإجازة',
      `تم رفض طلب الإجازة للموظف ${leaves[index].employeeName || leaves[index].employeeId || ''}. السبب: ${leaves[index].rejectionReason}`,
      {
        leaveId: leaves[index].id,
        employeeId: leaves[index].employeeId,
        type: 'leave',
        status: 'rejected',
      }
    );
    res.json({ success: true, data: leaves[index] });
    // Contract expiry notifications (run daily or on employee update)
    function checkContractExpiry() {
      const soon = new Date();
      soon.setDate(soon.getDate() + 30);
      employees.forEach(emp => {
        if (emp.contractEndDate) {
          const end = new Date(emp.contractEndDate);
          if (end > new Date() && end <= soon) {
            notificationManager.createNotification(
              'warning',
              'تنبيه انتهاء عقد',
              `عقد الموظف ${emp.name || emp.employeeId} سينتهي خلال 30 يومًا.`,
              {
                employeeId: emp.employeeId,
                contractEndDate: emp.contractEndDate,
                type: 'contract',
                status: 'expiring',
              }
            );
          }
        }
      });
    }

    // Performance review notifications (run on review add)
    function notifyPerformanceReview(perf) {
      notificationManager.createNotification(
        'info',
        'تقييم أداء جديد',
        `تم إضافة تقييم أداء للموظف ${perf.employeeName || perf.employeeId || ''} للفترة ${perf.period || ''}.`,
        { employeeId: perf.employeeId, period: perf.period, type: 'performance', score: perf.score }
      );
    }

    // Training assignment notifications (run on training add)
    function notifyTrainingAssignment(training) {
      notificationManager.createNotification(
        'info',
        'تعيين تدريب جديد',
        `تم تعيين برنامج تدريبي جديد (${training.title}) للموظفين المشاركين.`,
        { trainingId: training.id, type: 'training' }
      );
    }
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/attendance', async (req, res) => {
  try {
    const { employeeId, date, status } = req.query;
    let filtered = attendance;
    if (employeeId) filtered = filtered.filter(a => a.employeeId === parseInt(employeeId));
    if (date) filtered = filtered.filter(a => a.date === date);
    if (status) filtered = filtered.filter(a => a.status === status);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/attendance', async (req, res) => {
  try {
    const record = {
      id: attendance.length > 0 ? Math.max(...attendance.map(a => a.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'present',
      date: req.body.date || new Date().toISOString().split('T')[0],
      hours: req.body.hours || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    attendance.push(record);
    emitEvent('advanced-hr:updated', {
      action: 'create',
      entityType: 'attendance',
      entityId: record.id,
      data: record,
    });
    res.json({ success: true, data: record });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/performance', async (req, res) => {
  try {
    const { employeeId, period } = req.query;
    let filtered = performance;
    if (employeeId) filtered = filtered.filter(p => p.employeeId === parseInt(employeeId));
    if (period) filtered = filtered.filter(p => p.period === period);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/performance', async (req, res) => {
  try {
    const perf = {
      id: performance.length > 0 ? Math.max(...performance.map(p => p.id)) + 1 : 1,
      ...req.body,
      score: req.body.score || 0,
      rating: req.body.rating || 'غير محدد',
      period: req.body.period || new Date().toISOString().split('-').slice(0, 2).join('-'),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    performance.push(perf);
    emitEvent('advanced-hr:updated', {
      action: 'create',
      entityType: 'performance',
      entityId: perf.id,
      data: perf,
    });
    res.json({ success: true, data: perf });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/recruitment', async (req, res) => {
  try {
    const { status } = req.query;
    let filtered = recruitment;
    if (status) filtered = filtered.filter(r => r.status === status);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/recruitment', async (req, res) => {
  try {
    const rec = {
      id: recruitment.length > 0 ? Math.max(...recruitment.map(r => r.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'pending',
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    recruitment.push(rec);
    emitEvent('advanced-hr:updated', {
      action: 'create',
      entityType: 'recruitment',
      entityId: rec.id,
      data: rec,
    });
    res.json({ success: true, data: rec });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/training', async (req, res) => {
  try {
    const { status } = req.query;
    let filtered = training;
    if (status) filtered = filtered.filter(t => t.status === status);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/training', async (req, res) => {
  try {
    const train = {
      id: training.length > 0 ? Math.max(...training.map(t => t.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'scheduled',
      participantsCount: req.body.participantsCount || 0,
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    training.push(train);
    emitEvent('advanced-hr:updated', {
      action: 'create',
      entityType: 'training',
      entityId: train.id,
      data: train,
    });
    res.json({ success: true, data: train });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/payroll', async (req, res) => {
  try {
    const { employeeId, status, period } = req.query;
    let filtered = payroll;
    if (employeeId) filtered = filtered.filter(p => p.employeeId === parseInt(employeeId));
    if (status) filtered = filtered.filter(p => p.status === status);
    if (period) filtered = filtered.filter(p => p.period === period);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/payroll', async (req, res) => {
  try {
    const pay = {
      id: payroll.length > 0 ? Math.max(...payroll.map(p => p.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'unpaid',
      amount: req.body.amount || 0,
      period: req.body.period || new Date().toISOString().split('-').slice(0, 2).join('-'),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    payroll.push(pay);
    emitEvent('advanced-hr:updated', {
      action: 'create',
      entityType: 'payroll',
      entityId: pay.id,
      data: pay,
    });
    res.json({ success: true, data: pay });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/analytics', async (req, res) => {
  try {
    const totalEmployees = employees.length;
    const activeEmployees = employees.filter(e => e.status === 'active').length;
    const onLeaveEmployees = employees.filter(e => e.status === 'on-leave').length;
    const totalDepartments = departments.length;
    const totalPositions = positions.length;
    const pendingLeaves = leaves.filter(l => l.status === 'pending').length;
    const totalAttendance = attendance.length;
    const averagePerformance =
      performance.length > 0
        ? (performance.reduce((sum, p) => sum + (p.score || 0), 0) / performance.length).toFixed(1)
        : 0;
    const totalPayroll = payroll.reduce((sum, p) => sum + (p.amount || 0), 0);

    const analyticsData = [
      {
        id: 1,
        metric: 'إجمالي الموظفين',
        value: totalEmployees,
        description: 'عدد الموظفين الكلي',
        trend: null,
      },
      {
        id: 2,
        metric: 'الموظفين النشطين',
        value: activeEmployees,
        description: 'عدد الموظفين النشطين',
        trend: null,
      },
      {
        id: 3,
        metric: 'الموظفين في إجازة',
        value: onLeaveEmployees,
        description: 'عدد الموظفين في إجازة',
        trend: null,
      },
      {
        id: 4,
        metric: 'إجمالي الأقسام',
        value: totalDepartments,
        description: 'عدد الأقسام الكلي',
        trend: null,
      },
      {
        id: 5,
        metric: 'إجمالي الوظائف',
        value: totalPositions,
        description: 'عدد الوظائف الكلي',
        trend: null,
      },
      {
        id: 6,
        metric: 'الإجازات المعلقة',
        value: pendingLeaves,
        description: 'عدد الإجازات المعلقة',
        trend: null,
      },
      {
        id: 7,
        metric: 'سجلات الحضور',
        value: totalAttendance,
        description: 'عدد سجلات الحضور',
        trend: null,
      },
      {
        id: 8,
        metric: 'متوسط الأداء',
        value: `${averagePerformance}%`,
        description: 'متوسط تقييم الأداء',
        trend: null,
      },
      {
        id: 9,
        metric: 'إجمالي الرواتب',
        value: `${totalPayroll.toLocaleString()} ريال`,
        description: 'إجمالي الرواتب',
        trend: null,
      },
    ];

    res.json({ success: true, data: analyticsData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
module.exports.setIO = setIO;
