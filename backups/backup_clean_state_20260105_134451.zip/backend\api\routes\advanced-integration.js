/**
 * 🔗 Advanced Integration Routes
 * API routes for advanced integration management system
 */

const express = require('express');
const router = express.Router();

// Mock data storage (replace with database)
const integrations = [];
const connections = [];
const webhooks = [];
const apis = [];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Integrations ====================

router.get('/integrations', async (req, res) => {
  try {
    const { status, type } = req.query;
    let filtered = integrations;

    if (status) {
      filtered = filtered.filter(i => i.status === status);
    }

    if (type) {
      filtered = filtered.filter(i => i.type === type);
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/integrations', async (req, res) => {
  try {
    const integration = {
      id: integrations.length > 0 ? Math.max(...integrations.map(i => i.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'inactive',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    integrations.push(integration);

    emitEvent('integration:updated', {
      action: 'create',
      entityId: integration.id,
      data: integration,
    });

    res.json({
      success: true,
      data: integration,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Connections ====================

router.get('/connections', async (req, res) => {
  try {
    const { status } = req.query;
    let filtered = connections;

    if (status) {
      filtered = filtered.filter(c => c.status === status);
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/connections', async (req, res) => {
  try {
    const connection = {
      id: connections.length > 0 ? Math.max(...connections.map(c => c.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'inactive',
      createdAt: new Date().toISOString(),
    };

    connections.push(connection);

    res.json({
      success: true,
      data: connection,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Webhooks ====================

router.get('/webhooks', async (req, res) => {
  try {
    const { status } = req.query;
    let filtered = webhooks;

    if (status) {
      filtered = filtered.filter(w => w.status === status);
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/webhooks', async (req, res) => {
  try {
    const webhook = {
      id: webhooks.length > 0 ? Math.max(...webhooks.map(w => w.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'inactive',
      method: req.body.method || 'POST',
      createdAt: new Date().toISOString(),
    };

    webhooks.push(webhook);

    res.json({
      success: true,
      data: webhook,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== APIs ====================

router.get('/apis', async (req, res) => {
  try {
    const { status } = req.query;
    let filtered = apis;

    if (status) {
      filtered = filtered.filter(a => a.status === status);
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/apis', async (req, res) => {
  try {
    const api = {
      id: apis.length > 0 ? Math.max(...apis.map(a => a.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'inactive',
      requestsCount: 0,
      createdAt: new Date().toISOString(),
    };

    apis.push(api);

    res.json({
      success: true,
      data: api,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

module.exports = { router, setIO };
