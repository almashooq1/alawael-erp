/**
 * 📦 Advanced Inventory Management Routes
 */

const express = require('express');
const router = express.Router();

const items = [];
const categories = [];
const suppliers = [];
const purchases = [];
const sales = [];
const transfers = [];
const adjustments = [];
const alerts = [];
const analytics = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/items', async (req, res) => {
  try {
    const { categoryId, status, supplierId } = req.query;
    let filtered = items;
    if (categoryId) filtered = filtered.filter(i => i.categoryId === parseInt(categoryId));
    if (supplierId) filtered = filtered.filter(i => i.supplierId === parseInt(supplierId));
    if (status) {
      filtered = filtered.filter(i => {
        if (status === 'out-of-stock') return !i.quantity || i.quantity === 0;
        if (status === 'low-stock') return i.minQuantity && i.quantity <= i.minQuantity;
        if (status === 'in-stock') return i.quantity && i.quantity > (i.minQuantity || 0);
        return true;
      });
    }
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/items', async (req, res) => {
  try {
    const item = {
      id: items.length > 0 ? Math.max(...items.map(i => i.id)) + 1 : 1,
      ...req.body,
      code: req.body.code || `ITEM-${Date.now()}`,
      quantity: req.body.quantity || 0,
      price: req.body.price || 0,
      minQuantity: req.body.minQuantity || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    items.push(item);

    // Check for alerts
    if (item.quantity <= item.minQuantity) {
      const alert = {
        id: alerts.length > 0 ? Math.max(...alerts.map(a => a.id)) + 1 : 1,
        itemId: item.id,
        itemName: item.name,
        level: item.quantity === 0 ? 'critical' : 'warning',
        message: item.quantity === 0 ? 'نفد المخزون' : 'المخزون منخفض',
        date: new Date().toISOString(),
      };
      alerts.push(alert);
    }

    emitEvent('advanced-inventory:updated', {
      action: 'create',
      entityType: 'item',
      entityId: item.id,
      data: item,
    });
    res.json({ success: true, data: item });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/categories', async (req, res) => {
  try {
    res.json({ success: true, data: categories });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/categories', async (req, res) => {
  try {
    const category = {
      id: categories.length > 0 ? Math.max(...categories.map(c => c.id)) + 1 : 1,
      ...req.body,
      itemsCount: req.body.itemsCount || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    categories.push(category);
    emitEvent('advanced-inventory:updated', {
      action: 'create',
      entityType: 'category',
      entityId: category.id,
      data: category,
    });
    res.json({ success: true, data: category });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/suppliers', async (req, res) => {
  try {
    res.json({ success: true, data: suppliers });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/suppliers', async (req, res) => {
  try {
    const supplier = {
      id: suppliers.length > 0 ? Math.max(...suppliers.map(s => s.id)) + 1 : 1,
      ...req.body,
      rating: req.body.rating || 0,
      ordersCount: req.body.ordersCount || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    suppliers.push(supplier);
    emitEvent('advanced-inventory:updated', {
      action: 'create',
      entityType: 'supplier',
      entityId: supplier.id,
      data: supplier,
    });
    res.json({ success: true, data: supplier });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/purchases', async (req, res) => {
  try {
    const { status, supplierId } = req.query;
    let filtered = purchases;
    if (status) filtered = filtered.filter(p => p.status === status);
    if (supplierId) filtered = filtered.filter(p => p.supplierId === parseInt(supplierId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/purchases', async (req, res) => {
  try {
    const purchase = {
      id: purchases.length > 0 ? Math.max(...purchases.map(p => p.id)) + 1 : 1,
      ...req.body,
      number: req.body.number || `PUR-${Date.now()}`,
      status: req.body.status || 'pending',
      total: req.body.total || 0,
      itemsCount: req.body.itemsCount || 0,
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    purchases.push(purchase);

    // Update item quantities if purchase is completed
    if (purchase.status === 'completed' && purchase.items) {
      purchase.items.forEach(purchaseItem => {
        const item = items.find(i => i.id === purchaseItem.itemId);
        if (item) {
          item.quantity = (item.quantity || 0) + purchaseItem.quantity;
        }
      });
    }

    emitEvent('advanced-inventory:updated', {
      action: 'create',
      entityType: 'purchase',
      entityId: purchase.id,
      data: purchase,
    });
    res.json({ success: true, data: purchase });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/sales', async (req, res) => {
  try {
    const { status, customerId } = req.query;
    let filtered = sales;
    if (status) filtered = filtered.filter(s => s.status === status);
    if (customerId) filtered = filtered.filter(s => s.customerId === parseInt(customerId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/sales', async (req, res) => {
  try {
    const sale = {
      id: sales.length > 0 ? Math.max(...sales.map(s => s.id)) + 1 : 1,
      ...req.body,
      number: req.body.number || `SALE-${Date.now()}`,
      status: req.body.status || 'completed',
      total: req.body.total || 0,
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    sales.push(sale);

    // Update item quantities
    if (sale.items) {
      sale.items.forEach(saleItem => {
        const item = items.find(i => i.id === saleItem.itemId);
        if (item) {
          item.quantity = Math.max(0, (item.quantity || 0) - saleItem.quantity);

          // Check for alerts
          if (item.quantity <= item.minQuantity) {
            const alert = {
              id: alerts.length > 0 ? Math.max(...alerts.map(a => a.id)) + 1 : 1,
              itemId: item.id,
              itemName: item.name,
              level: item.quantity === 0 ? 'critical' : 'warning',
              message: item.quantity === 0 ? 'نفد المخزون' : 'المخزون منخفض',
              date: new Date().toISOString(),
            };
            alerts.push(alert);
          }
        }
      });
    }

    emitEvent('advanced-inventory:updated', {
      action: 'create',
      entityType: 'sale',
      entityId: sale.id,
      data: sale,
    });
    res.json({ success: true, data: sale });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/transfers', async (req, res) => {
  try {
    const { status } = req.query;
    let filtered = transfers;
    if (status) filtered = filtered.filter(t => t.status === status);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/transfers', async (req, res) => {
  try {
    const transfer = {
      id: transfers.length > 0 ? Math.max(...transfers.map(t => t.id)) + 1 : 1,
      ...req.body,
      number: req.body.number || `TRF-${Date.now()}`,
      status: req.body.status || 'pending',
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    transfers.push(transfer);
    emitEvent('advanced-inventory:updated', {
      action: 'create',
      entityType: 'transfer',
      entityId: transfer.id,
      data: transfer,
    });
    res.json({ success: true, data: transfer });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/adjustments', async (req, res) => {
  try {
    const { type, itemId } = req.query;
    let filtered = adjustments;
    if (type) filtered = filtered.filter(a => a.type === type);
    if (itemId) filtered = filtered.filter(a => a.itemId === parseInt(itemId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/adjustments', async (req, res) => {
  try {
    const adjustment = {
      id: adjustments.length > 0 ? Math.max(...adjustments.map(a => a.id)) + 1 : 1,
      ...req.body,
      type: req.body.type || 'correction',
      quantity: req.body.quantity || 0,
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    adjustments.push(adjustment);

    // Update item quantity
    if (adjustment.itemId) {
      const item = items.find(i => i.id === adjustment.itemId);
      if (item) {
        if (adjustment.type === 'increase') {
          item.quantity = (item.quantity || 0) + adjustment.quantity;
        } else if (adjustment.type === 'decrease') {
          item.quantity = Math.max(0, (item.quantity || 0) - adjustment.quantity);
        } else {
          item.quantity = adjustment.quantity;
        }
      }
    }

    emitEvent('advanced-inventory:updated', {
      action: 'create',
      entityType: 'adjustment',
      entityId: adjustment.id,
      data: adjustment,
    });
    res.json({ success: true, data: adjustment });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/alerts', async (req, res) => {
  try {
    const { level, itemId } = req.query;
    let filtered = alerts;
    if (level) filtered = filtered.filter(a => a.level === level);
    if (itemId) filtered = filtered.filter(a => a.itemId === parseInt(itemId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/analytics', async (req, res) => {
  try {
    const totalItems = items.length;
    const inStockItems = items.filter(i => i.quantity && i.quantity > (i.minQuantity || 0)).length;
    const lowStockItems = items.filter(
      i => i.minQuantity && i.quantity <= i.minQuantity && i.quantity > 0
    ).length;
    const outOfStockItems = items.filter(i => !i.quantity || i.quantity === 0).length;
    const totalCategories = categories.length;
    const totalSuppliers = suppliers.length;
    const totalPurchases = purchases.length;
    const totalSales = sales.length;
    const totalValue = items.reduce((sum, i) => sum + (i.quantity || 0) * (i.price || 0), 0);
    const totalPurchasesValue = purchases.reduce((sum, p) => sum + (p.total || 0), 0);
    const totalSalesValue = sales.reduce((sum, s) => sum + (s.total || 0), 0);
    const totalAlerts = alerts.length;
    const criticalAlerts = alerts.filter(a => a.level === 'critical').length;

    const analyticsData = [
      {
        id: 1,
        metric: 'إجمالي العناصر',
        value: totalItems,
        description: 'عدد العناصر الكلي',
        trend: null,
      },
      {
        id: 2,
        metric: 'العناصر المتوفرة',
        value: inStockItems,
        description: 'عدد العناصر المتوفرة',
        trend: null,
      },
      {
        id: 3,
        metric: 'العناصر منخفضة المخزون',
        value: lowStockItems,
        description: 'عدد العناصر منخفضة المخزون',
        trend: null,
      },
      {
        id: 4,
        metric: 'العناصر النافدة',
        value: outOfStockItems,
        description: 'عدد العناصر النافدة',
        trend: null,
      },
      {
        id: 5,
        metric: 'إجمالي الفئات',
        value: totalCategories,
        description: 'عدد الفئات الكلي',
        trend: null,
      },
      {
        id: 6,
        metric: 'إجمالي الموردين',
        value: totalSuppliers,
        description: 'عدد الموردين الكلي',
        trend: null,
      },
      {
        id: 7,
        metric: 'إجمالي المشتريات',
        value: totalPurchases,
        description: 'عدد المشتريات الكلي',
        trend: null,
      },
      {
        id: 8,
        metric: 'إجمالي المبيعات',
        value: totalSales,
        description: 'عدد المبيعات الكلي',
        trend: null,
      },
      {
        id: 9,
        metric: 'قيمة المخزون',
        value: `${totalValue.toLocaleString()} ريال`,
        description: 'إجمالي قيمة المخزون',
        trend: null,
      },
      {
        id: 10,
        metric: 'قيمة المشتريات',
        value: `${totalPurchasesValue.toLocaleString()} ريال`,
        description: 'إجمالي قيمة المشتريات',
        trend: null,
      },
      {
        id: 11,
        metric: 'قيمة المبيعات',
        value: `${totalSalesValue.toLocaleString()} ريال`,
        description: 'إجمالي قيمة المبيعات',
        trend: null,
      },
      {
        id: 12,
        metric: 'إجمالي التنبيهات',
        value: totalAlerts,
        description: 'عدد التنبيهات الكلي',
        trend: null,
      },
      {
        id: 13,
        metric: 'التنبيهات الحرجة',
        value: criticalAlerts,
        description: 'عدد التنبيهات الحرجة',
        trend: null,
      },
    ];

    res.json({ success: true, data: analyticsData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
