/**
 * 🧾 Advanced Invoices Management Routes
 */

const express = require('express');
const router = express.Router();

const invoices = [];
const items = [];
const templates = [];
const recurring = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/invoices', async (req, res) => {
  try {
    const { status, type, customerId } = req.query;
    let filtered = invoices;
    if (status) filtered = filtered.filter(i => i.status === status);
    if (type) filtered = filtered.filter(i => i.type === type);
    if (customerId) filtered = filtered.filter(i => i.customerId === parseInt(customerId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/invoices', async (req, res) => {
  try {
    const invoice = {
      id: invoices.length > 0 ? Math.max(...invoices.map(i => i.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'draft',
      total: req.body.total || 0,
      invoiceDate: req.body.invoiceDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    invoices.push(invoice);
    emitEvent('advanced-invoices:updated', {
      action: 'create',
      entityType: 'invoice',
      entityId: invoice.id,
      data: invoice,
    });
    res.json({ success: true, data: invoice });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/items', async (req, res) => {
  try {
    res.json({ success: true, data: items });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/items', async (req, res) => {
  try {
    const item = {
      id: items.length > 0 ? Math.max(...items.map(i => i.id)) + 1 : 1,
      ...req.body,
      price: req.body.price || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    items.push(item);
    emitEvent('advanced-invoices:updated', {
      action: 'create',
      entityType: 'item',
      entityId: item.id,
      data: item,
    });
    res.json({ success: true, data: item });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/templates', async (req, res) => {
  try {
    res.json({ success: true, data: templates });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/templates', async (req, res) => {
  try {
    const template = {
      id: templates.length > 0 ? Math.max(...templates.map(t => t.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    templates.push(template);
    emitEvent('advanced-invoices:updated', {
      action: 'create',
      entityType: 'template',
      entityId: template.id,
      data: template,
    });
    res.json({ success: true, data: template });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/recurring', async (req, res) => {
  try {
    res.json({ success: true, data: recurring });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/recurring', async (req, res) => {
  try {
    const rec = {
      id: recurring.length > 0 ? Math.max(...recurring.map(r => r.id)) + 1 : 1,
      ...req.body,
      frequency: req.body.frequency || 'monthly',
      amount: req.body.amount || 0,
      nextDate: req.body.nextDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    recurring.push(rec);
    emitEvent('advanced-invoices:updated', {
      action: 'create',
      entityType: 'recurring',
      entityId: rec.id,
      data: rec,
    });
    res.json({ success: true, data: rec });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
