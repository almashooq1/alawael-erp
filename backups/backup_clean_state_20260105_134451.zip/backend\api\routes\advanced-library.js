/**
 * 📚 Advanced Library Management Routes
 */

const express = require('express');
const router = express.Router();

const books = [];
const resources = [];
const borrowers = [];
const loans = [];
const categories = [];
const analytics = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/books', async (req, res) => {
  try {
    const { status, categoryId } = req.query;
    let filtered = books;
    if (status) filtered = filtered.filter(b => b.status === status);
    if (categoryId) filtered = filtered.filter(b => b.categoryId === parseInt(categoryId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/books', async (req, res) => {
  try {
    const book = {
      id: books.length > 0 ? Math.max(...books.map(b => b.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'available',
      availableCopies: req.body.availableCopies || req.body.totalCopies || 1,
      totalCopies: req.body.totalCopies || 1,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    books.push(book);
    emitEvent('advanced-library:updated', {
      action: 'create',
      entityType: 'book',
      entityId: book.id,
      data: book,
    });
    res.json({ success: true, data: book });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/resources', async (req, res) => {
  try {
    const { type } = req.query;
    let filtered = resources;
    if (type) filtered = filtered.filter(r => r.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/resources', async (req, res) => {
  try {
    const resource = {
      id: resources.length > 0 ? Math.max(...resources.map(r => r.id)) + 1 : 1,
      ...req.body,
      type: req.body.type || 'pdf',
      size: req.body.size || 0,
      addedDate: req.body.addedDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    resources.push(resource);
    emitEvent('advanced-library:updated', {
      action: 'create',
      entityType: 'resource',
      entityId: resource.id,
      data: resource,
    });
    res.json({ success: true, data: resource });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/borrowers', async (req, res) => {
  try {
    const { type } = req.query;
    let filtered = borrowers;
    if (type) filtered = filtered.filter(b => b.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/borrowers', async (req, res) => {
  try {
    const borrower = {
      id: borrowers.length > 0 ? Math.max(...borrowers.map(b => b.id)) + 1 : 1,
      ...req.body,
      type: req.body.type || 'patient',
      activeLoans: req.body.activeLoans || 0,
      totalLoans: req.body.totalLoans || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    borrowers.push(borrower);
    emitEvent('advanced-library:updated', {
      action: 'create',
      entityType: 'borrower',
      entityId: borrower.id,
      data: borrower,
    });
    res.json({ success: true, data: borrower });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/loans', async (req, res) => {
  try {
    const { status, borrowerId } = req.query;
    let filtered = loans;
    if (status) filtered = filtered.filter(l => l.status === status);
    if (borrowerId) filtered = filtered.filter(l => l.borrowerId === parseInt(borrowerId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/loans', async (req, res) => {
  try {
    const loan = {
      id: loans.length > 0 ? Math.max(...loans.map(l => l.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      loanDate: req.body.loanDate || new Date().toISOString(),
      dueDate: req.body.dueDate || new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    loans.push(loan);

    // Update book status
    const book = books.find(b => b.id === loan.bookId);
    if (book) {
      book.availableCopies = Math.max(0, (book.availableCopies || 0) - 1);
      if (book.availableCopies === 0) {
        book.status = 'borrowed';
      }
    }

    // Update borrower stats
    const borrower = borrowers.find(b => b.id === loan.borrowerId);
    if (borrower) {
      borrower.activeLoans = (borrower.activeLoans || 0) + 1;
      borrower.totalLoans = (borrower.totalLoans || 0) + 1;
    }

    emitEvent('advanced-library:updated', {
      action: 'create',
      entityType: 'loan',
      entityId: loan.id,
      data: loan,
    });
    res.json({ success: true, data: loan });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/categories', async (req, res) => {
  try {
    res.json({ success: true, data: categories });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/categories', async (req, res) => {
  try {
    const category = {
      id: categories.length > 0 ? Math.max(...categories.map(c => c.id)) + 1 : 1,
      ...req.body,
      booksCount: req.body.booksCount || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    categories.push(category);
    emitEvent('advanced-library:updated', {
      action: 'create',
      entityType: 'category',
      entityId: category.id,
      data: category,
    });
    res.json({ success: true, data: category });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/analytics', async (req, res) => {
  try {
    const totalBooks = books.length;
    const availableBooks = books.filter(b => b.status === 'available').length;
    const borrowedBooks = books.filter(b => b.status === 'borrowed').length;
    const totalResources = resources.length;
    const totalBorrowers = borrowers.length;
    const totalLoans = loans.length;
    const activeLoans = loans.filter(l => l.status === 'active').length;
    const overdueLoans = loans.filter(l => {
      if (!l.dueDate || l.status !== 'active') return false;
      return new Date(l.dueDate) < new Date();
    }).length;
    const totalCategories = categories.length;

    const analyticsData = [
      {
        id: 1,
        metric: 'إجمالي الكتب',
        value: totalBooks,
        description: 'عدد الكتب الكلي',
      },
      {
        id: 2,
        metric: 'الكتب المتاحة',
        value: availableBooks,
        description: 'عدد الكتب المتاحة للإعارة',
      },
      {
        id: 3,
        metric: 'الكتب المعارة',
        value: borrowedBooks,
        description: 'عدد الكتب المعارة حالياً',
      },
      {
        id: 4,
        metric: 'إجمالي الموارد',
        value: totalResources,
        description: 'عدد الموارد التعليمية الكلي',
      },
      {
        id: 5,
        metric: 'إجمالي المستعيرين',
        value: totalBorrowers,
        description: 'عدد المستعيرين الكلي',
      },
      {
        id: 6,
        metric: 'إجمالي الإعارات',
        value: totalLoans,
        description: 'عدد الإعارات الكلي',
      },
      {
        id: 7,
        metric: 'الإعارات النشطة',
        value: activeLoans,
        description: 'عدد الإعارات النشطة',
      },
      {
        id: 8,
        metric: 'الإعارات المتأخرة',
        value: overdueLoans,
        description: 'عدد الإعارات المتأخرة',
      },
      {
        id: 9,
        metric: 'إجمالي الفئات',
        value: totalCategories,
        description: 'عدد فئات الكتب الكلي',
      },
    ];

    res.json({ success: true, data: analyticsData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
module.exports.setIO = setIO;
