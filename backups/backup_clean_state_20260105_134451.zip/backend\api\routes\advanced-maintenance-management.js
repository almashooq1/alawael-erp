/**
 * 🔧 Advanced Maintenance Management Routes
 */

const express = require('express');
const router = express.Router();

const requests = [];
const schedules = [];
const workOrders = [];
const technicians = [];
const equipment = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/requests', async (req, res) => {
  try {
    const { status, priority, type } = req.query;
    let filtered = requests;

    if (status) filtered = filtered.filter(r => r.status === status);
    if (priority) filtered = filtered.filter(r => r.priority === priority);
    if (type) filtered = filtered.filter(r => r.type === type);

    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/requests', async (req, res) => {
  try {
    const request = {
      id: requests.length > 0 ? Math.max(...requests.map(r => r.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'pending',
      priority: req.body.priority || 'medium',
      requestedDate: req.body.requestedDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    requests.push(request);
    emitEvent('advanced-maintenance:updated', {
      action: 'create',
      entityType: 'request',
      entityId: request.id,
      data: request,
    });

    res.json({ success: true, data: request });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/requests/:id', async (req, res) => {
  try {
    const index = requests.findIndex(r => r.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Request not found' });
    }

    requests[index] = { ...requests[index], ...req.body, updatedAt: new Date().toISOString() };
    emitEvent('advanced-maintenance:updated', {
      action: 'update',
      entityType: 'request',
      entityId: requests[index].id,
      data: requests[index],
    });

    res.json({ success: true, data: requests[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/schedules', async (req, res) => {
  try {
    const { status, equipmentId } = req.query;
    let filtered = schedules;

    if (status) filtered = filtered.filter(s => s.status === status);
    if (equipmentId) filtered = filtered.filter(s => s.equipmentId === parseInt(equipmentId));

    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/schedules', async (req, res) => {
  try {
    const schedule = {
      id: schedules.length > 0 ? Math.max(...schedules.map(s => s.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'scheduled',
      scheduledDate: req.body.scheduledDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    schedules.push(schedule);
    emitEvent('advanced-maintenance:updated', {
      action: 'create',
      entityType: 'schedule',
      entityId: schedule.id,
      data: schedule,
    });

    res.json({ success: true, data: schedule });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/work-orders', async (req, res) => {
  try {
    const { status, technicianId } = req.query;
    let filtered = workOrders;

    if (status) filtered = filtered.filter(w => w.status === status);
    if (technicianId) filtered = filtered.filter(w => w.technicianId === parseInt(technicianId));

    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/work-orders', async (req, res) => {
  try {
    const workOrder = {
      id: workOrders.length > 0 ? Math.max(...workOrders.map(w => w.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'pending',
      cost: req.body.cost || 0,
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    workOrders.push(workOrder);
    emitEvent('advanced-maintenance:updated', {
      action: 'create',
      entityType: 'workOrder',
      entityId: workOrder.id,
      data: workOrder,
    });

    res.json({ success: true, data: workOrder });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/technicians', async (req, res) => {
  try {
    res.json({ success: true, data: technicians });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/technicians', async (req, res) => {
  try {
    const technician = {
      id: technicians.length > 0 ? Math.max(...technicians.map(t => t.id)) + 1 : 1,
      ...req.body,
      completedOrders: 0,
      activeOrders: 0,
      rating: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    technicians.push(technician);
    emitEvent('advanced-maintenance:updated', {
      action: 'create',
      entityType: 'technician',
      entityId: technician.id,
      data: technician,
    });

    res.json({ success: true, data: technician });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/equipment', async (req, res) => {
  try {
    const { status, type } = req.query;
    let filtered = equipment;

    if (status) filtered = filtered.filter(e => e.status === status);
    if (type) filtered = filtered.filter(e => e.type === type);

    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/equipment', async (req, res) => {
  try {
    const eq = {
      id: equipment.length > 0 ? Math.max(...equipment.map(e => e.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'operational',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    equipment.push(eq);
    emitEvent('advanced-maintenance:updated', {
      action: 'create',
      entityType: 'equipment',
      entityId: eq.id,
      data: eq,
    });

    res.json({ success: true, data: eq });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
