/**
 * 🔧 Advanced Maintenance Management Routes
 */

const express = require('express');
const router = express.Router();

const requests = [];
const workOrders = [];
const equipment = [];
const technicians = [];
const schedules = [];
const parts = [];
const history = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/requests', async (req, res) => {
  try {
    const { status, priority, type } = req.query;
    let filtered = requests;
    if (status) filtered = filtered.filter(r => r.status === status);
    if (priority) filtered = filtered.filter(r => r.priority === priority);
    if (type) filtered = filtered.filter(r => r.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/requests', async (req, res) => {
  try {
    const request = {
      id: requests.length > 0 ? Math.max(...requests.map(r => r.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'pending',
      priority: req.body.priority || 'medium',
      type: req.body.type || 'corrective',
      requestDate: req.body.requestDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    requests.push(request);
    emitEvent('advanced-maintenance:updated', {
      action: 'create',
      entityType: 'request',
      entityId: request.id,
      data: request,
    });
    res.json({ success: true, data: request });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/requests/:id/approve', async (req, res) => {
  try {
    const index = requests.findIndex(r => r.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Request not found' });
    }
    requests[index].status = 'approved';
    requests[index].approvedAt = new Date().toISOString();
    requests[index].approvedBy = req.body.approvedBy || 'غير محدد';

    // Create work order
    const workOrder = {
      id: workOrders.length > 0 ? Math.max(...workOrders.map(w => w.id)) + 1 : 1,
      requestId: requests[index].id,
      number: `WO-${Date.now()}`,
      equipmentId: requests[index].equipmentId,
      equipmentName: requests[index].equipmentName,
      technicianId: req.body.technicianId || null,
      technicianName: req.body.technicianName || 'غير محدد',
      status: 'pending',
      priority: requests[index].priority,
      startDate: req.body.startDate || new Date().toISOString(),
      cost: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    workOrders.push(workOrder);

    emitEvent('advanced-maintenance:updated', {
      action: 'update',
      entityType: 'request',
      entityId: requests[index].id,
      data: requests[index],
    });
    res.json({ success: true, data: requests[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/work-orders', async (req, res) => {
  try {
    const { status, priority, technicianId } = req.query;
    let filtered = workOrders;
    if (status) filtered = filtered.filter(w => w.status === status);
    if (priority) filtered = filtered.filter(w => w.priority === priority);
    if (technicianId) filtered = filtered.filter(w => w.technicianId === parseInt(technicianId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/work-orders', async (req, res) => {
  try {
    const workOrder = {
      id: workOrders.length > 0 ? Math.max(...workOrders.map(w => w.id)) + 1 : 1,
      ...req.body,
      number: req.body.number || `WO-${Date.now()}`,
      status: req.body.status || 'pending',
      priority: req.body.priority || 'medium',
      cost: req.body.cost || 0,
      startDate: req.body.startDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    workOrders.push(workOrder);
    emitEvent('advanced-maintenance:updated', {
      action: 'create',
      entityType: 'workOrder',
      entityId: workOrder.id,
      data: workOrder,
    });
    res.json({ success: true, data: workOrder });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/work-orders/:id/complete', async (req, res) => {
  try {
    const index = workOrders.findIndex(w => w.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Work order not found' });
    }
    workOrders[index].status = 'completed';
    workOrders[index].endDate = new Date().toISOString();
    workOrders[index].cost = req.body.cost || workOrders[index].cost || 0;

    // Update equipment
    if (workOrders[index].equipmentId) {
      const eq = equipment.find(e => e.id === workOrders[index].equipmentId);
      if (eq) {
        eq.status = 'operational';
        eq.lastMaintenanceDate = new Date().toISOString();
      }
    }

    // Add to history
    const historyRecord = {
      id: history.length > 0 ? Math.max(...history.map(h => h.id)) + 1 : 1,
      title: `صيانة ${workOrders[index].equipmentName || 'معدة'}`,
      type: 'maintenance',
      equipmentId: workOrders[index].equipmentId,
      equipmentName: workOrders[index].equipmentName,
      technicianId: workOrders[index].technicianId,
      technicianName: workOrders[index].technicianName,
      cost: workOrders[index].cost,
      date: new Date().toISOString(),
    };
    history.push(historyRecord);

    emitEvent('advanced-maintenance:updated', {
      action: 'update',
      entityType: 'workOrder',
      entityId: workOrders[index].id,
      data: workOrders[index],
    });
    res.json({ success: true, data: workOrders[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/equipment', async (req, res) => {
  try {
    const { status, type } = req.query;
    let filtered = equipment;
    if (status) filtered = filtered.filter(e => e.status === status);
    if (type) filtered = filtered.filter(e => e.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/equipment', async (req, res) => {
  try {
    const eq = {
      id: equipment.length > 0 ? Math.max(...equipment.map(e => e.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'operational',
      purchaseDate: req.body.purchaseDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    equipment.push(eq);
    emitEvent('advanced-maintenance:updated', {
      action: 'create',
      entityType: 'equipment',
      entityId: eq.id,
      data: eq,
    });
    res.json({ success: true, data: eq });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/technicians', async (req, res) => {
  try {
    res.json({ success: true, data: technicians });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/technicians', async (req, res) => {
  try {
    const technician = {
      id: technicians.length > 0 ? Math.max(...technicians.map(t => t.id)) + 1 : 1,
      ...req.body,
      tasksCount: req.body.tasksCount || 0,
      completionRate: req.body.completionRate || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    technicians.push(technician);
    emitEvent('advanced-maintenance:updated', {
      action: 'create',
      entityType: 'technician',
      entityId: technician.id,
      data: technician,
    });
    res.json({ success: true, data: technician });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/schedules', async (req, res) => {
  try {
    const { status, type } = req.query;
    let filtered = schedules;
    if (status) filtered = filtered.filter(s => s.status === status);
    if (type) filtered = filtered.filter(s => s.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/schedules', async (req, res) => {
  try {
    const schedule = {
      id: schedules.length > 0 ? Math.max(...schedules.map(s => s.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'scheduled',
      type: req.body.type || 'preventive',
      scheduledDate: req.body.scheduledDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    schedules.push(schedule);
    emitEvent('advanced-maintenance:updated', {
      action: 'create',
      entityType: 'schedule',
      entityId: schedule.id,
      data: schedule,
    });
    res.json({ success: true, data: schedule });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/parts', async (req, res) => {
  try {
    res.json({ success: true, data: parts });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/parts', async (req, res) => {
  try {
    const part = {
      id: parts.length > 0 ? Math.max(...parts.map(p => p.id)) + 1 : 1,
      ...req.body,
      quantity: req.body.quantity || 0,
      minQuantity: req.body.minQuantity || 0,
      price: req.body.price || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    parts.push(part);
    emitEvent('advanced-maintenance:updated', {
      action: 'create',
      entityType: 'part',
      entityId: part.id,
      data: part,
    });
    res.json({ success: true, data: part });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/history', async (req, res) => {
  try {
    const { equipmentId, technicianId, type } = req.query;
    let filtered = history;
    if (equipmentId) filtered = filtered.filter(h => h.equipmentId === parseInt(equipmentId));
    if (technicianId) filtered = filtered.filter(h => h.technicianId === parseInt(technicianId));
    if (type) filtered = filtered.filter(h => h.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/analytics', async (req, res) => {
  try {
    const totalRequests = requests.length;
    const pendingRequests = requests.filter(r => r.status === 'pending').length;
    const inProgressRequests = requests.filter(r => r.status === 'in-progress').length;
    const completedRequests = requests.filter(r => r.status === 'completed').length;
    const totalWorkOrders = workOrders.length;
    const completedWorkOrders = workOrders.filter(w => w.status === 'completed').length;
    const totalEquipment = equipment.length;
    const operationalEquipment = equipment.filter(e => e.status === 'operational').length;
    const maintenanceEquipment = equipment.filter(e => e.status === 'maintenance').length;
    const brokenEquipment = equipment.filter(e => e.status === 'broken').length;
    const totalTechnicians = technicians.length;
    const totalSchedules = schedules.length;
    const totalParts = parts.length;
    const lowStockParts = parts.filter(p => p.quantity <= p.minQuantity).length;
    const totalCost = workOrders.reduce((sum, w) => sum + (w.cost || 0), 0);

    const analyticsData = [
      {
        id: 1,
        metric: 'إجمالي الطلبات',
        value: totalRequests,
        description: 'عدد طلبات الصيانة الكلي',
        trend: null,
      },
      {
        id: 2,
        metric: 'الطلبات المعلقة',
        value: pendingRequests,
        description: 'عدد الطلبات المعلقة',
        trend: null,
      },
      {
        id: 3,
        metric: 'الطلبات قيد التنفيذ',
        value: inProgressRequests,
        description: 'عدد الطلبات قيد التنفيذ',
        trend: null,
      },
      {
        id: 4,
        metric: 'الطلبات المكتملة',
        value: completedRequests,
        description: 'عدد الطلبات المكتملة',
        trend: null,
      },
      {
        id: 5,
        metric: 'إجمالي أوامر العمل',
        value: totalWorkOrders,
        description: 'عدد أوامر العمل الكلي',
        trend: null,
      },
      {
        id: 6,
        metric: 'أوامر العمل المكتملة',
        value: completedWorkOrders,
        description: 'عدد أوامر العمل المكتملة',
        trend: null,
      },
      {
        id: 7,
        metric: 'إجمالي المعدات',
        value: totalEquipment,
        description: 'عدد المعدات الكلي',
        trend: null,
      },
      {
        id: 8,
        metric: 'المعدات التشغيلية',
        value: operationalEquipment,
        description: 'عدد المعدات التشغيلية',
        trend: null,
      },
      {
        id: 9,
        metric: 'المعدات قيد الصيانة',
        value: maintenanceEquipment,
        description: 'عدد المعدات قيد الصيانة',
        trend: null,
      },
      {
        id: 10,
        metric: 'المعدات المعطلة',
        value: brokenEquipment,
        description: 'عدد المعدات المعطلة',
        trend: null,
      },
      {
        id: 11,
        metric: 'إجمالي الفنيين',
        value: totalTechnicians,
        description: 'عدد الفنيين الكلي',
        trend: null,
      },
      {
        id: 12,
        metric: 'إجمالي الجداول',
        value: totalSchedules,
        description: 'عدد الجداول الكلي',
        trend: null,
      },
      {
        id: 13,
        metric: 'إجمالي قطع الغيار',
        value: totalParts,
        description: 'عدد قطع الغيار الكلي',
        trend: null,
      },
      {
        id: 14,
        metric: 'قطع الغيار منخفضة المخزون',
        value: lowStockParts,
        description: 'عدد قطع الغيار منخفضة المخزون',
        trend: null,
      },
      {
        id: 15,
        metric: 'إجمالي التكلفة',
        value: `${totalCost.toLocaleString()} ريال`,
        description: 'إجمالي تكلفة الصيانة',
        trend: null,
      },
    ];

    res.json({ success: true, data: analyticsData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
