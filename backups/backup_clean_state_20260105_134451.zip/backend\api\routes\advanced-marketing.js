/**
 * 📢 Advanced Marketing Management Routes
 */

const express = require('express');
const router = express.Router();

const campaigns = [];
const leads = [];
const emailTemplates = [];
const analytics = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/campaigns', async (req, res) => {
  try {
    const { status, type, channel } = req.query;
    let filtered = campaigns;
    if (status) filtered = filtered.filter(c => c.status === status);
    if (type) filtered = filtered.filter(c => c.type === type);
    if (channel) filtered = filtered.filter(c => c.channel === channel);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/campaigns', async (req, res) => {
  try {
    const campaign = {
      id: campaigns.length > 0 ? Math.max(...campaigns.map(c => c.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'draft',
      budget: req.body.budget || 0,
      startDate: req.body.startDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    campaigns.push(campaign);
    emitEvent('advanced-marketing:updated', {
      action: 'create',
      entityType: 'campaign',
      entityId: campaign.id,
      data: campaign,
    });
    res.json({ success: true, data: campaign });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/leads', async (req, res) => {
  try {
    const { status, source } = req.query;
    let filtered = leads;
    if (status) filtered = filtered.filter(l => l.status === status);
    if (source) filtered = filtered.filter(l => l.source === source);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/leads', async (req, res) => {
  try {
    const lead = {
      id: leads.length > 0 ? Math.max(...leads.map(l => l.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'new',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    leads.push(lead);
    emitEvent('advanced-marketing:updated', {
      action: 'create',
      entityType: 'lead',
      entityId: lead.id,
      data: lead,
    });
    res.json({ success: true, data: lead });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/templates', async (req, res) => {
  try {
    res.json({ success: true, data: emailTemplates });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/templates', async (req, res) => {
  try {
    const template = {
      id: emailTemplates.length > 0 ? Math.max(...emailTemplates.map(t => t.id)) + 1 : 1,
      ...req.body,
      type: req.body.type || 'general',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    emailTemplates.push(template);
    emitEvent('advanced-marketing:updated', {
      action: 'create',
      entityType: 'template',
      entityId: template.id,
      data: template,
    });
    res.json({ success: true, data: template });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/analytics', async (req, res) => {
  try {
    res.json({ success: true, data: analytics });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/analytics', async (req, res) => {
  try {
    const analytic = {
      id: analytics.length > 0 ? Math.max(...analytics.map(a => a.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    analytics.push(analytic);
    emitEvent('advanced-marketing:updated', {
      action: 'create',
      entityType: 'analytic',
      entityId: analytic.id,
      data: analytic,
    });
    res.json({ success: true, data: analytic });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
