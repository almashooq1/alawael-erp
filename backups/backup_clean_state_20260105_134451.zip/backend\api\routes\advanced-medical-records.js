/**
 * 📋 Advanced Medical Records Management Routes
 */

const express = require('express');
const router = express.Router();

const records = [];
const diagnoses = [];
const treatments = [];
const labResults = [];
const imaging = [];
const notes = [];
const history = [];
const allergies = [];
const vaccinations = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/records', async (req, res) => {
  try {
    const { status, category, patientId, providerId } = req.query;
    let filtered = records;
    if (status) filtered = filtered.filter(r => r.status === status);
    if (category) filtered = filtered.filter(r => r.category === category);
    if (patientId) filtered = filtered.filter(r => r.patientId === parseInt(patientId));
    if (providerId) filtered = filtered.filter(r => r.providerId === parseInt(providerId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/records', async (req, res) => {
  try {
    const record = {
      id: records.length > 0 ? Math.max(...records.map(r => r.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      category: req.body.category || 'general',
      recordNumber: req.body.recordNumber || `MR-${Date.now()}`,
      visitsCount: req.body.visitsCount || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    records.push(record);
    emitEvent('advanced-medical-records:updated', {
      action: 'create',
      entityType: 'record',
      entityId: record.id,
      data: record,
    });
    res.json({ success: true, data: record });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/diagnoses', async (req, res) => {
  try {
    const { patientId, severity, status } = req.query;
    let filtered = diagnoses;
    if (patientId) filtered = filtered.filter(d => d.patientId === parseInt(patientId));
    if (severity) filtered = filtered.filter(d => d.severity === severity);
    if (status) filtered = filtered.filter(d => d.status === status);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/diagnoses', async (req, res) => {
  try {
    const diagnosis = {
      id: diagnoses.length > 0 ? Math.max(...diagnoses.map(d => d.id)) + 1 : 1,
      ...req.body,
      severity: req.body.severity || 'moderate',
      status: req.body.status || 'active',
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    diagnoses.push(diagnosis);
    emitEvent('advanced-medical-records:updated', {
      action: 'create',
      entityType: 'diagnosis',
      entityId: diagnosis.id,
      data: diagnosis,
    });
    res.json({ success: true, data: diagnosis });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/treatments', async (req, res) => {
  try {
    const { patientId, status } = req.query;
    let filtered = treatments;
    if (patientId) filtered = filtered.filter(t => t.patientId === parseInt(patientId));
    if (status) filtered = filtered.filter(t => t.status === status);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/treatments', async (req, res) => {
  try {
    const treatment = {
      id: treatments.length > 0 ? Math.max(...treatments.map(t => t.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      startDate: req.body.startDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    treatments.push(treatment);
    emitEvent('advanced-medical-records:updated', {
      action: 'create',
      entityType: 'treatment',
      entityId: treatment.id,
      data: treatment,
    });
    res.json({ success: true, data: treatment });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/lab-results', async (req, res) => {
  try {
    const { patientId, abnormal } = req.query;
    let filtered = labResults;
    if (patientId) filtered = filtered.filter(l => l.patientId === parseInt(patientId));
    if (abnormal === 'true') filtered = filtered.filter(l => l.abnormal === true);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/lab-results', async (req, res) => {
  try {
    const labResult = {
      id: labResults.length > 0 ? Math.max(...labResults.map(l => l.id)) + 1 : 1,
      ...req.body,
      abnormal: req.body.abnormal || false,
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    labResults.push(labResult);
    emitEvent('advanced-medical-records:updated', {
      action: 'create',
      entityType: 'labResult',
      entityId: labResult.id,
      data: labResult,
    });
    res.json({ success: true, data: labResult });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/imaging', async (req, res) => {
  try {
    const { patientId, type } = req.query;
    let filtered = imaging;
    if (patientId) filtered = filtered.filter(i => i.patientId === parseInt(patientId));
    if (type) filtered = filtered.filter(i => i.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/imaging', async (req, res) => {
  try {
    const image = {
      id: imaging.length > 0 ? Math.max(...imaging.map(i => i.id)) + 1 : 1,
      ...req.body,
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    imaging.push(image);
    emitEvent('advanced-medical-records:updated', {
      action: 'create',
      entityType: 'imaging',
      entityId: image.id,
      data: image,
    });
    res.json({ success: true, data: image });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/notes', async (req, res) => {
  try {
    const { patientId, type, authorId } = req.query;
    let filtered = notes;
    if (patientId) filtered = filtered.filter(n => n.patientId === parseInt(patientId));
    if (type) filtered = filtered.filter(n => n.type === type);
    if (authorId) filtered = filtered.filter(n => n.authorId === parseInt(authorId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/notes', async (req, res) => {
  try {
    const note = {
      id: notes.length > 0 ? Math.max(...notes.map(n => n.id)) + 1 : 1,
      ...req.body,
      type: req.body.type || 'general',
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    notes.push(note);
    emitEvent('advanced-medical-records:updated', {
      action: 'create',
      entityType: 'note',
      entityId: note.id,
      data: note,
    });
    res.json({ success: true, data: note });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/history', async (req, res) => {
  try {
    const { patientId, type } = req.query;
    let filtered = history;
    if (patientId) filtered = filtered.filter(h => h.patientId === parseInt(patientId));
    if (type) filtered = filtered.filter(h => h.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/history', async (req, res) => {
  try {
    const historyItem = {
      id: history.length > 0 ? Math.max(...history.map(h => h.id)) + 1 : 1,
      ...req.body,
      type: req.body.type || 'general',
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    history.push(historyItem);
    emitEvent('advanced-medical-records:updated', {
      action: 'create',
      entityType: 'history',
      entityId: historyItem.id,
      data: historyItem,
    });
    res.json({ success: true, data: historyItem });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/allergies', async (req, res) => {
  try {
    const { patientId, severity } = req.query;
    let filtered = allergies;
    if (patientId) filtered = filtered.filter(a => a.patientId === parseInt(patientId));
    if (severity) filtered = filtered.filter(a => a.severity === severity);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/allergies', async (req, res) => {
  try {
    const allergy = {
      id: allergies.length > 0 ? Math.max(...allergies.map(a => a.id)) + 1 : 1,
      ...req.body,
      severity: req.body.severity || 'moderate',
      discoveredDate: req.body.discoveredDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    allergies.push(allergy);
    emitEvent('advanced-medical-records:updated', {
      action: 'create',
      entityType: 'allergy',
      entityId: allergy.id,
      data: allergy,
    });
    res.json({ success: true, data: allergy });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/vaccinations', async (req, res) => {
  try {
    const { patientId, completed } = req.query;
    let filtered = vaccinations;
    if (patientId) filtered = filtered.filter(v => v.patientId === parseInt(patientId));
    if (completed !== undefined)
      filtered = filtered.filter(v => v.completed === (completed === 'true'));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/vaccinations', async (req, res) => {
  try {
    const vaccination = {
      id: vaccinations.length > 0 ? Math.max(...vaccinations.map(v => v.id)) + 1 : 1,
      ...req.body,
      completed: req.body.completed || false,
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    vaccinations.push(vaccination);
    emitEvent('advanced-medical-records:updated', {
      action: 'create',
      entityType: 'vaccination',
      entityId: vaccination.id,
      data: vaccination,
    });
    res.json({ success: true, data: vaccination });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/analytics', async (req, res) => {
  try {
    const totalRecords = records.length;
    const activeRecords = records.filter(r => r.status === 'active').length;
    const totalDiagnoses = diagnoses.length;
    const totalTreatments = treatments.length;
    const totalLabResults = labResults.length;
    const abnormalLabResults = labResults.filter(l => l.abnormal === true).length;
    const totalImaging = imaging.length;
    const totalAllergies = allergies.length;
    const totalVaccinations = vaccinations.length;
    const completedVaccinations = vaccinations.filter(v => v.completed === true).length;

    const analyticsData = [
      {
        id: 1,
        metric: 'إجمالي الملفات الطبية',
        value: totalRecords,
        description: 'عدد الملفات الطبية الكلي',
        trend: null,
      },
      {
        id: 2,
        metric: 'الملفات النشطة',
        value: activeRecords,
        description: 'عدد الملفات الطبية النشطة',
        trend: null,
      },
      {
        id: 3,
        metric: 'إجمالي التشخيصات',
        value: totalDiagnoses,
        description: 'عدد التشخيصات الكلي',
        trend: null,
      },
      {
        id: 4,
        metric: 'إجمالي العلاجات',
        value: totalTreatments,
        description: 'عدد العلاجات الكلي',
        trend: null,
      },
      {
        id: 5,
        metric: 'إجمالي نتائج المختبر',
        value: totalLabResults,
        description: 'عدد نتائج المختبر الكلي',
        trend: null,
      },
      {
        id: 6,
        metric: 'النتائج غير الطبيعية',
        value: abnormalLabResults,
        description: 'عدد نتائج المختبر غير الطبيعية',
        trend: null,
      },
      {
        id: 7,
        metric: 'إجمالي الصور',
        value: totalImaging,
        description: 'عدد صور الأشعة والتصوير الكلي',
        trend: null,
      },
      {
        id: 8,
        metric: 'إجمالي الحساسيات',
        value: totalAllergies,
        description: 'عدد الحساسيات المسجلة',
        trend: null,
      },
      {
        id: 9,
        metric: 'إجمالي التطعيمات',
        value: totalVaccinations,
        description: 'عدد التطعيمات الكلي',
        trend: null,
      },
      {
        id: 10,
        metric: 'التطعيمات المكتملة',
        value: completedVaccinations,
        description: 'عدد التطعيمات المكتملة',
        trend: null,
      },
    ];

    res.json({ success: true, data: analyticsData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
