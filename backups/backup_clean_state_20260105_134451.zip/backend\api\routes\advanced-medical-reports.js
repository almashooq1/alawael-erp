/**
 * 📄 Advanced Medical Reports Management Routes
 */

const express = require('express');
const router = express.Router();

const reports = [];
const templates = [];
const generated = [];
const approvals = [];
const versions = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/reports', async (req, res) => {
  try {
    const { status, type, category, patientId } = req.query;
    let filtered = reports;
    if (status) filtered = filtered.filter(r => r.status === status);
    if (type) filtered = filtered.filter(r => r.type === type);
    if (category) filtered = filtered.filter(r => r.category === category);
    if (patientId) filtered = filtered.filter(r => r.patientId === parseInt(patientId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/reports', async (req, res) => {
  try {
    const report = {
      id: reports.length > 0 ? Math.max(...reports.map(r => r.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'draft',
      type: req.body.type || 'custom',
      version: req.body.version || '1.0',
      sectionsCount: req.body.sectionsCount || 0,
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    reports.push(report);
    emitEvent('advanced-medical-reports:updated', {
      action: 'create',
      entityType: 'report',
      entityId: report.id,
      data: report,
    });
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/reports/:id/submit', async (req, res) => {
  try {
    const index = reports.findIndex(r => r.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Report not found' });
    }
    reports[index].status = 'pending';
    reports[index].submittedAt = new Date().toISOString();

    // Create approval request
    const approval = {
      id: approvals.length > 0 ? Math.max(...approvals.map(a => a.id)) + 1 : 1,
      reportId: reports[index].id,
      reportTitle: reports[index].title,
      patientName: reports[index].patientName,
      status: 'pending',
      requestDate: new Date().toISOString(),
      reviewerId: req.body.reviewerId || null,
    };
    approvals.push(approval);

    emitEvent('advanced-medical-reports:updated', {
      action: 'update',
      entityType: 'report',
      entityId: reports[index].id,
      data: reports[index],
    });
    res.json({ success: true, data: reports[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/reports/:id/approve', async (req, res) => {
  try {
    const index = reports.findIndex(r => r.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Report not found' });
    }
    reports[index].status = 'approved';
    reports[index].approvedAt = new Date().toISOString();
    reports[index].approvedBy = req.body.approvedBy || 'غير محدد';

    // Update approval
    const approvalIndex = approvals.findIndex(a => a.reportId === reports[index].id);
    if (approvalIndex !== -1) {
      approvals[approvalIndex].status = 'approved';
      approvals[approvalIndex].reviewDate = new Date().toISOString();
      approvals[approvalIndex].reviewerName = req.body.approvedBy || 'غير محدد';
    }

    emitEvent('advanced-medical-reports:updated', {
      action: 'update',
      entityType: 'report',
      entityId: reports[index].id,
      data: reports[index],
    });
    res.json({ success: true, data: reports[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/reports/:id/reject', async (req, res) => {
  try {
    const index = reports.findIndex(r => r.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Report not found' });
    }
    reports[index].status = 'rejected';
    reports[index].rejectedAt = new Date().toISOString();
    reports[index].rejectionReason = req.body.reason || 'غير محدد';

    // Update approval
    const approvalIndex = approvals.findIndex(a => a.reportId === reports[index].id);
    if (approvalIndex !== -1) {
      approvals[approvalIndex].status = 'rejected';
      approvals[approvalIndex].reviewDate = new Date().toISOString();
      approvals[approvalIndex].reviewerName = req.body.rejectedBy || 'غير محدد';
      approvals[approvalIndex].comments = req.body.reason || 'غير محدد';
    }

    emitEvent('advanced-medical-reports:updated', {
      action: 'update',
      entityType: 'report',
      entityId: reports[index].id,
      data: reports[index],
    });
    res.json({ success: true, data: reports[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/reports/:id/generate', async (req, res) => {
  try {
    const report = reports.find(r => r.id === parseInt(req.params.id));
    if (!report) {
      return res.status(404).json({ success: false, error: 'Report not found' });
    }

    const generatedReport = {
      id: generated.length > 0 ? Math.max(...generated.map(g => g.id)) + 1 : 1,
      reportId: report.id,
      reportTitle: report.title,
      patientName: report.patientName,
      format: req.body.format || 'PDF',
      fileSize: req.body.fileSize || 'غير محدد',
      status: 'completed',
      generatedAt: new Date().toISOString(),
      generatedBy: req.body.generatedBy || 'غير محدد',
    };
    generated.push(generatedReport);

    emitEvent('advanced-medical-reports:updated', {
      action: 'create',
      entityType: 'generated',
      entityId: generatedReport.id,
      data: generatedReport,
    });
    res.json({ success: true, data: generatedReport });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/templates', async (req, res) => {
  try {
    const { category, type } = req.query;
    let filtered = templates;
    if (category) filtered = filtered.filter(t => t.category === category);
    if (type) filtered = filtered.filter(t => t.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/templates', async (req, res) => {
  try {
    const template = {
      id: templates.length > 0 ? Math.max(...templates.map(t => t.id)) + 1 : 1,
      ...req.body,
      category: req.body.category || 'general',
      sectionsCount: req.body.sectionsCount || 0,
      fieldsCount: req.body.fieldsCount || 0,
      lastUsed: null,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    templates.push(template);
    emitEvent('advanced-medical-reports:updated', {
      action: 'create',
      entityType: 'template',
      entityId: template.id,
      data: template,
    });
    res.json({ success: true, data: template });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/generated', async (req, res) => {
  try {
    const { reportId, format, status } = req.query;
    let filtered = generated;
    if (reportId) filtered = filtered.filter(g => g.reportId === parseInt(reportId));
    if (format) filtered = filtered.filter(g => g.format === format);
    if (status) filtered = filtered.filter(g => g.status === status);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/approvals', async (req, res) => {
  try {
    const { status, reviewerId } = req.query;
    let filtered = approvals;
    if (status) filtered = filtered.filter(a => a.status === status);
    if (reviewerId) filtered = filtered.filter(a => a.reviewerId === parseInt(reviewerId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/versions', async (req, res) => {
  try {
    const { reportId, current } = req.query;
    let filtered = versions;
    if (reportId) filtered = filtered.filter(v => v.reportId === parseInt(reportId));
    if (current === 'true') filtered = filtered.filter(v => v.current === true);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/versions', async (req, res) => {
  try {
    const version = {
      id: versions.length > 0 ? Math.max(...versions.map(v => v.id)) + 1 : 1,
      ...req.body,
      current: req.body.current || false,
      changesCount: req.body.changes?.length || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    // If this is the current version, mark others as not current
    if (version.current) {
      versions.forEach(v => {
        if (v.reportId === version.reportId) {
          v.current = false;
        }
      });
    }

    versions.push(version);
    emitEvent('advanced-medical-reports:updated', {
      action: 'create',
      entityType: 'version',
      entityId: version.id,
      data: version,
    });
    res.json({ success: true, data: version });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/analytics', async (req, res) => {
  try {
    const totalReports = reports.length;
    const draftReports = reports.filter(r => r.status === 'draft').length;
    const pendingReports = reports.filter(r => r.status === 'pending').length;
    const approvedReports = reports.filter(r => r.status === 'approved').length;
    const rejectedReports = reports.filter(r => r.status === 'rejected').length;
    const publishedReports = reports.filter(r => r.status === 'published').length;
    const totalTemplates = templates.length;
    const totalGenerated = generated.length;
    const totalApprovals = approvals.length;
    const pendingApprovals = approvals.filter(a => a.status === 'pending').length;

    const analyticsData = [
      {
        id: 1,
        metric: 'إجمالي التقارير',
        value: totalReports,
        description: 'عدد التقارير الكلي',
        trend: null,
      },
      {
        id: 2,
        metric: 'التقارير المسودة',
        value: draftReports,
        description: 'عدد التقارير المسودة',
        trend: null,
      },
      {
        id: 3,
        metric: 'التقارير قيد المراجعة',
        value: pendingReports,
        description: 'عدد التقارير قيد المراجعة',
        trend: null,
      },
      {
        id: 4,
        metric: 'التقارير الموافق عليها',
        value: approvedReports,
        description: 'عدد التقارير الموافق عليها',
        trend: null,
      },
      {
        id: 5,
        metric: 'التقارير المرفوضة',
        value: rejectedReports,
        description: 'عدد التقارير المرفوضة',
        trend: null,
      },
      {
        id: 6,
        metric: 'التقارير المنشورة',
        value: publishedReports,
        description: 'عدد التقارير المنشورة',
        trend: null,
      },
      {
        id: 7,
        metric: 'إجمالي القوالب',
        value: totalTemplates,
        description: 'عدد القوالب الكلي',
        trend: null,
      },
      {
        id: 8,
        metric: 'التقارير المولدة',
        value: totalGenerated,
        description: 'عدد التقارير المولدة',
        trend: null,
      },
      {
        id: 9,
        metric: 'إجمالي الموافقات',
        value: totalApprovals,
        description: 'عدد طلبات الموافقة الكلي',
        trend: null,
      },
      {
        id: 10,
        metric: 'الموافقات المعلقة',
        value: pendingApprovals,
        description: 'عدد الموافقات المعلقة',
        trend: null,
      },
    ];

    res.json({ success: true, data: analyticsData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
