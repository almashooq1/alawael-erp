/**
 * 💊 Advanced Medications & Treatments Management Routes
 */

const express = require('express');
const router = express.Router();

const medications = [];
const prescriptions = [];
const dosages = [];
const schedules = [];
const adherence = [];
const sideEffects = [];
const interactions = [];
const inventory = [];
const treatments = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/medications', async (req, res) => {
  try {
    const { status, category, patientId } = req.query;
    let filtered = medications;
    if (status) filtered = filtered.filter(m => m.status === status);
    if (category) filtered = filtered.filter(m => m.category === category);
    if (patientId) filtered = filtered.filter(m => m.patientId === parseInt(patientId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/medications', async (req, res) => {
  try {
    const medication = {
      id: medications.length > 0 ? Math.max(...medications.map(m => m.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      category: req.body.category || 'general',
      quantity: req.body.quantity || 0,
      expiringSoon: req.body.expiringSoon || false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    medications.push(medication);
    emitEvent('advanced-medications:updated', {
      action: 'create',
      entityType: 'medication',
      entityId: medication.id,
      data: medication,
    });
    res.json({ success: true, data: medication });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/prescriptions', async (req, res) => {
  try {
    const { status, patientId, providerId } = req.query;
    let filtered = prescriptions;
    if (status) filtered = filtered.filter(p => p.status === status);
    if (patientId) filtered = filtered.filter(p => p.patientId === parseInt(patientId));
    if (providerId) filtered = filtered.filter(p => p.providerId === parseInt(providerId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/prescriptions', async (req, res) => {
  try {
    const prescription = {
      id: prescriptions.length > 0 ? Math.max(...prescriptions.map(p => p.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'pending',
      medications: req.body.medications || [],
      medicationsCount: req.body.medications?.length || 0,
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    prescriptions.push(prescription);
    emitEvent('advanced-medications:updated', {
      action: 'create',
      entityType: 'prescription',
      entityId: prescription.id,
      data: prescription,
    });
    res.json({ success: true, data: prescription });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/prescriptions/:id/dispense', async (req, res) => {
  try {
    const index = prescriptions.findIndex(p => p.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Prescription not found' });
    }
    prescriptions[index].status = 'dispensed';
    prescriptions[index].dispensedAt = new Date().toISOString();
    emitEvent('advanced-medications:updated', {
      action: 'update',
      entityType: 'prescription',
      entityId: prescriptions[index].id,
      data: prescriptions[index],
    });
    res.json({ success: true, data: prescriptions[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/dosages', async (req, res) => {
  try {
    const { medicationId, patientId } = req.query;
    let filtered = dosages;
    if (medicationId) filtered = filtered.filter(d => d.medicationId === parseInt(medicationId));
    if (patientId) filtered = filtered.filter(d => d.patientId === parseInt(patientId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/dosages', async (req, res) => {
  try {
    const dosage = {
      id: dosages.length > 0 ? Math.max(...dosages.map(d => d.id)) + 1 : 1,
      ...req.body,
      time: req.body.time || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    dosages.push(dosage);
    emitEvent('advanced-medications:updated', {
      action: 'create',
      entityType: 'dosage',
      entityId: dosage.id,
      data: dosage,
    });
    res.json({ success: true, data: dosage });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/schedules', async (req, res) => {
  try {
    const { date, patientId } = req.query;
    let filtered = schedules;
    if (date) filtered = filtered.filter(s => s.date === date);
    if (patientId) filtered = filtered.filter(s => s.patientId === parseInt(patientId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/adherence', async (req, res) => {
  try {
    const { patientId, medicationId } = req.query;
    let filtered = adherence;
    if (patientId) filtered = filtered.filter(a => a.patientId === parseInt(patientId));
    if (medicationId) filtered = filtered.filter(a => a.medicationId === parseInt(medicationId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/adherence', async (req, res) => {
  try {
    const adherenceData = {
      id: adherence.length > 0 ? Math.max(...adherence.map(a => a.id)) + 1 : 1,
      ...req.body,
      adherenceRate: req.body.adherenceRate || 0,
      takenDoses: req.body.takenDoses || 0,
      missedDoses: req.body.missedDoses || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    adherence.push(adherenceData);
    emitEvent('advanced-medications:updated', {
      action: 'create',
      entityType: 'adherence',
      entityId: adherenceData.id,
      data: adherenceData,
    });
    res.json({ success: true, data: adherenceData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/side-effects', async (req, res) => {
  try {
    const { patientId, medicationId, severity, resolved } = req.query;
    let filtered = sideEffects;
    if (patientId) filtered = filtered.filter(s => s.patientId === parseInt(patientId));
    if (medicationId) filtered = filtered.filter(s => s.medicationId === parseInt(medicationId));
    if (severity) filtered = filtered.filter(s => s.severity === severity);
    if (resolved !== undefined)
      filtered = filtered.filter(s => s.resolved === (resolved === 'true'));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/side-effects', async (req, res) => {
  try {
    const sideEffect = {
      id: sideEffects.length > 0 ? Math.max(...sideEffects.map(s => s.id)) + 1 : 1,
      ...req.body,
      severity: req.body.severity || 'mild',
      resolved: req.body.resolved || false,
      startDate: req.body.startDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    sideEffects.push(sideEffect);
    emitEvent('advanced-medications:updated', {
      action: 'create',
      entityType: 'sideEffect',
      entityId: sideEffect.id,
      data: sideEffect,
    });
    res.json({ success: true, data: sideEffect });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/interactions', async (req, res) => {
  try {
    const { medication1, medication2, severity } = req.query;
    let filtered = interactions;
    if (medication1)
      filtered = filtered.filter(
        i => i.medication1 === medication1 || i.medication2 === medication1
      );
    if (medication2)
      filtered = filtered.filter(
        i => i.medication1 === medication2 || i.medication2 === medication2
      );
    if (severity) filtered = filtered.filter(i => i.severity === severity);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/interactions', async (req, res) => {
  try {
    const interaction = {
      id: interactions.length > 0 ? Math.max(...interactions.map(i => i.id)) + 1 : 1,
      ...req.body,
      severity: req.body.severity || 'moderate',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    interactions.push(interaction);
    emitEvent('advanced-medications:updated', {
      action: 'create',
      entityType: 'interaction',
      entityId: interaction.id,
      data: interaction,
    });
    res.json({ success: true, data: interaction });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/inventory', async (req, res) => {
  try {
    const { lowStock } = req.query;
    let filtered = inventory;
    if (lowStock === 'true') filtered = filtered.filter(i => i.lowStock === true);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/treatments', async (req, res) => {
  try {
    const { status, patientId, type } = req.query;
    let filtered = treatments;
    if (status) filtered = filtered.filter(t => t.status === status);
    if (patientId) filtered = filtered.filter(t => t.patientId === parseInt(patientId));
    if (type) filtered = filtered.filter(t => t.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/treatments', async (req, res) => {
  try {
    const treatment = {
      id: treatments.length > 0 ? Math.max(...treatments.map(t => t.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      startDate: req.body.startDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    treatments.push(treatment);
    emitEvent('advanced-medications:updated', {
      action: 'create',
      entityType: 'treatment',
      entityId: treatment.id,
      data: treatment,
    });
    res.json({ success: true, data: treatment });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/analytics', async (req, res) => {
  try {
    const totalMedications = medications.length;
    const activeMedications = medications.filter(m => m.status === 'active').length;
    const totalPrescriptions = prescriptions.length;
    const pendingPrescriptions = prescriptions.filter(p => p.status === 'pending').length;
    const dispensedPrescriptions = prescriptions.filter(p => p.status === 'dispensed').length;
    const totalSideEffects = sideEffects.length;
    const unresolvedSideEffects = sideEffects.filter(s => !s.resolved).length;
    const averageAdherence =
      adherence.length > 0
        ? Math.round(
            adherence.reduce((sum, a) => sum + (a.adherenceRate || 0), 0) / adherence.length
          )
        : 0;
    const lowStockItems = inventory.filter(i => i.lowStock === true).length;

    const analyticsData = [
      {
        id: 1,
        metric: 'إجمالي الأدوية',
        value: totalMedications,
        description: 'عدد الأدوية الكلي',
        trend: null,
      },
      {
        id: 2,
        metric: 'الأدوية النشطة',
        value: activeMedications,
        description: 'عدد الأدوية النشطة',
        trend: null,
      },
      {
        id: 3,
        metric: 'إجمالي الوصفات',
        value: totalPrescriptions,
        description: 'عدد الوصفات الطبية الكلي',
        trend: null,
      },
      {
        id: 4,
        metric: 'الوصفات المعلقة',
        value: pendingPrescriptions,
        description: 'عدد الوصفات المعلقة',
        trend: null,
      },
      {
        id: 5,
        metric: 'الوصفات المصروفة',
        value: dispensedPrescriptions,
        description: 'عدد الوصفات المصروفة',
        trend: null,
      },
      {
        id: 6,
        metric: 'الآثار الجانبية',
        value: totalSideEffects,
        description: 'عدد الآثار الجانبية المسجلة',
        trend: null,
      },
      {
        id: 7,
        metric: 'الآثار غير المحلولة',
        value: unresolvedSideEffects,
        description: 'عدد الآثار الجانبية غير المحلولة',
        trend: null,
      },
      {
        id: 8,
        metric: 'متوسط الالتزام',
        value: `${averageAdherence}%`,
        description: 'متوسط معدل الالتزام بالأدوية',
        trend: null,
      },
      {
        id: 9,
        metric: 'مخزون منخفض',
        value: lowStockItems,
        description: 'عدد الأدوية ذات المخزون المنخفض',
        trend: null,
      },
    ];

    res.json({ success: true, data: analyticsData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
