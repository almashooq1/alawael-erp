/**
 * 🤝 Advanced Partnerships Management Routes
 */

const express = require('express');
const router = express.Router();

const partnerships = [];
const partners = [];
const collaborations = [];
const projects = [];
const agreements = [];
const events = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/partnerships', async (req, res) => {
  try {
    const { status, type } = req.query;
    let filtered = partnerships;
    if (status) filtered = filtered.filter(p => p.status === status);
    if (type) filtered = filtered.filter(p => p.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/partnerships', async (req, res) => {
  try {
    const partnership = {
      id: partnerships.length > 0 ? Math.max(...partnerships.map(p => p.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'pending',
      type: req.body.type || 'strategic',
      value: req.body.value || 0,
      startDate: req.body.startDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    partnerships.push(partnership);
    emitEvent('advanced-partnerships:updated', {
      action: 'create',
      entityType: 'partnership',
      entityId: partnership.id,
      data: partnership,
    });
    res.json({ success: true, data: partnership });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/partners', async (req, res) => {
  try {
    const { status, type } = req.query;
    let filtered = partners;
    if (status) filtered = filtered.filter(p => p.status === status);
    if (type) filtered = filtered.filter(p => p.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/partners', async (req, res) => {
  try {
    const partner = {
      id: partners.length > 0 ? Math.max(...partners.map(p => p.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      type: req.body.type || 'strategic',
      partnershipsCount: req.body.partnershipsCount || 0,
      projectsCount: req.body.projectsCount || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    partners.push(partner);
    emitEvent('advanced-partnerships:updated', {
      action: 'create',
      entityType: 'partner',
      entityId: partner.id,
      data: partner,
    });
    res.json({ success: true, data: partner });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/collaborations', async (req, res) => {
  try {
    const { status, partnerId } = req.query;
    let filtered = collaborations;
    if (status) filtered = filtered.filter(c => c.status === status);
    if (partnerId) filtered = filtered.filter(c => c.partnerId === parseInt(partnerId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/collaborations', async (req, res) => {
  try {
    const collaboration = {
      id: collaborations.length > 0 ? Math.max(...collaborations.map(c => c.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      progress: req.body.progress || 0,
      startDate: req.body.startDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    collaborations.push(collaboration);
    emitEvent('advanced-partnerships:updated', {
      action: 'create',
      entityType: 'collaboration',
      entityId: collaboration.id,
      data: collaboration,
    });
    res.json({ success: true, data: collaboration });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/projects', async (req, res) => {
  try {
    const { status, partnerId } = req.query;
    let filtered = projects;
    if (status) filtered = filtered.filter(p => p.status === status);
    if (partnerId) filtered = filtered.filter(p => p.partnerId === parseInt(partnerId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/projects', async (req, res) => {
  try {
    const project = {
      id: projects.length > 0 ? Math.max(...projects.map(p => p.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      budget: req.body.budget || 0,
      progress: req.body.progress || 0,
      startDate: req.body.startDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    projects.push(project);
    emitEvent('advanced-partnerships:updated', {
      action: 'create',
      entityType: 'project',
      entityId: project.id,
      data: project,
    });
    res.json({ success: true, data: project });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/agreements', async (req, res) => {
  try {
    const { status, partnerId } = req.query;
    let filtered = agreements;
    if (status) filtered = filtered.filter(a => a.status === status);
    if (partnerId) filtered = filtered.filter(a => a.partnerId === parseInt(partnerId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/agreements', async (req, res) => {
  try {
    const agreement = {
      id: agreements.length > 0 ? Math.max(...agreements.map(a => a.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'signed',
      value: req.body.value || 0,
      signDate: req.body.signDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    agreements.push(agreement);
    emitEvent('advanced-partnerships:updated', {
      action: 'create',
      entityType: 'agreement',
      entityId: agreement.id,
      data: agreement,
    });
    res.json({ success: true, data: agreement });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/events', async (req, res) => {
  try {
    const { status, partnerId } = req.query;
    let filtered = events;
    if (status) filtered = filtered.filter(e => e.status === status);
    if (partnerId) filtered = filtered.filter(e => e.partnerId === parseInt(partnerId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/events', async (req, res) => {
  try {
    const event = {
      id: events.length > 0 ? Math.max(...events.map(e => e.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'scheduled',
      attendeesCount: req.body.attendeesCount || 0,
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    events.push(event);
    emitEvent('advanced-partnerships:updated', {
      action: 'create',
      entityType: 'event',
      entityId: event.id,
      data: event,
    });
    res.json({ success: true, data: event });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/analytics', async (req, res) => {
  try {
    const totalPartnerships = partnerships.length;
    const activePartnerships = partnerships.filter(p => p.status === 'active').length;
    const totalPartners = partners.length;
    const activePartners = partners.filter(p => p.status === 'active').length;
    const totalCollaborations = collaborations.length;
    const activeCollaborations = collaborations.filter(c => c.status === 'active').length;
    const totalProjects = projects.length;
    const activeProjects = projects.filter(p => p.status === 'active').length;
    const totalAgreements = agreements.length;
    const signedAgreements = agreements.filter(a => a.status === 'signed').length;
    const totalEvents = events.length;
    const upcomingEvents = events.filter(e => new Date(e.date) > new Date()).length;
    const totalValue = partnerships.reduce((sum, p) => sum + (p.value || 0), 0);
    const totalBudget = projects.reduce((sum, p) => sum + (p.budget || 0), 0);

    const analyticsData = [
      {
        id: 1,
        metric: 'إجمالي الشراكات',
        value: totalPartnerships,
        description: 'عدد الشراكات الكلي',
      },
      {
        id: 2,
        metric: 'الشراكات النشطة',
        value: activePartnerships,
        description: 'عدد الشراكات النشطة',
      },
      {
        id: 3,
        metric: 'إجمالي الشركاء',
        value: totalPartners,
        description: 'عدد الشركاء الكلي',
      },
      {
        id: 4,
        metric: 'الشركاء النشطين',
        value: activePartners,
        description: 'عدد الشركاء النشطين',
      },
      {
        id: 5,
        metric: 'إجمالي التعاونات',
        value: totalCollaborations,
        description: 'عدد التعاونات الكلي',
      },
      {
        id: 6,
        metric: 'التعاونات النشطة',
        value: activeCollaborations,
        description: 'عدد التعاونات النشطة',
      },
      {
        id: 7,
        metric: 'إجمالي المشاريع',
        value: totalProjects,
        description: 'عدد المشاريع الكلي',
      },
      {
        id: 8,
        metric: 'المشاريع النشطة',
        value: activeProjects,
        description: 'عدد المشاريع النشطة',
      },
      {
        id: 9,
        metric: 'إجمالي الاتفاقيات',
        value: totalAgreements,
        description: 'عدد الاتفاقيات الكلي',
      },
      {
        id: 10,
        metric: 'الاتفاقيات الموقعة',
        value: signedAgreements,
        description: 'عدد الاتفاقيات الموقعة',
      },
      {
        id: 11,
        metric: 'إجمالي الفعاليات',
        value: totalEvents,
        description: 'عدد الفعاليات الكلي',
      },
      {
        id: 12,
        metric: 'الفعاليات القادمة',
        value: upcomingEvents,
        description: 'عدد الفعاليات القادمة',
      },
      {
        id: 13,
        metric: 'إجمالي قيمة الشراكات',
        value: `${totalValue.toLocaleString('ar-SA')} ر.س`,
        description: 'إجمالي قيمة جميع الشراكات',
      },
      {
        id: 14,
        metric: 'إجمالي ميزانية المشاريع',
        value: `${totalBudget.toLocaleString('ar-SA')} ر.س`,
        description: 'إجمالي ميزانية جميع المشاريع',
      },
    ];

    res.json({ success: true, data: analyticsData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
