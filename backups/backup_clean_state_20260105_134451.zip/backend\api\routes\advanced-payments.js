/**
 * 💳 Advanced Payments Management Routes
 */

const express = require('express');
const router = express.Router();

const payments = [];
const methods = [];
const refunds = [];
const reports = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/payments', async (req, res) => {
  try {
    const { status, method, type } = req.query;
    let filtered = payments;
    if (status) filtered = filtered.filter(p => p.status === status);
    if (method) filtered = filtered.filter(p => p.method === method);
    if (type) filtered = filtered.filter(p => p.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/payments', async (req, res) => {
  try {
    const payment = {
      id: payments.length > 0 ? Math.max(...payments.map(p => p.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'pending',
      amount: req.body.amount || 0,
      paymentDate: req.body.paymentDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    payments.push(payment);
    emitEvent('advanced-payments:updated', {
      action: 'create',
      entityType: 'payment',
      entityId: payment.id,
      data: payment,
    });
    res.json({ success: true, data: payment });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/methods', async (req, res) => {
  try {
    res.json({ success: true, data: methods });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/methods', async (req, res) => {
  try {
    const method = {
      id: methods.length > 0 ? Math.max(...methods.map(m => m.id)) + 1 : 1,
      ...req.body,
      enabled: req.body.enabled !== undefined ? req.body.enabled : true,
      fee: req.body.fee || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    methods.push(method);
    emitEvent('advanced-payments:updated', {
      action: 'create',
      entityType: 'method',
      entityId: method.id,
      data: method,
    });
    res.json({ success: true, data: method });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/refunds', async (req, res) => {
  try {
    const { status, paymentId } = req.query;
    let filtered = refunds;
    if (status) filtered = filtered.filter(r => r.status === status);
    if (paymentId) filtered = filtered.filter(r => r.paymentId === parseInt(paymentId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/refunds', async (req, res) => {
  try {
    const refund = {
      id: refunds.length > 0 ? Math.max(...refunds.map(r => r.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'pending',
      amount: req.body.amount || 0,
      refundDate: req.body.refundDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    refunds.push(refund);

    // Update payment status
    const paymentIndex = payments.findIndex(p => p.id === refund.paymentId);
    if (paymentIndex !== -1) {
      payments[paymentIndex].status = 'refunded';
    }

    emitEvent('advanced-payments:updated', {
      action: 'create',
      entityType: 'refund',
      entityId: refund.id,
      data: refund,
    });
    res.json({ success: true, data: refund });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/reports', async (req, res) => {
  try {
    res.json({ success: true, data: reports });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/reports', async (req, res) => {
  try {
    const report = {
      id: reports.length > 0 ? Math.max(...reports.map(r => r.id)) + 1 : 1,
      ...req.body,
      totalPayments: req.body.totalPayments || 0,
      paymentsCount: req.body.paymentsCount || 0,
      averagePayment: req.body.averagePayment || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    reports.push(report);
    emitEvent('advanced-payments:updated', {
      action: 'create',
      entityType: 'report',
      entityId: report.id,
      data: report,
    });
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
