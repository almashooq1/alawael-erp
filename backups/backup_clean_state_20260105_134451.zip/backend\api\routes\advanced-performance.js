/**
 * 📊 Advanced Performance Management Routes
 * API routes for advanced performance management system
 */

const express = require('express');
const router = express.Router();

// Mock data storage (replace with database)
const performanceReviews = [];
const goals = [];
const kpis = [];
const developmentPlans = [];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Performance Reviews ====================

router.get('/reviews', async (req, res) => {
  try {
    const { status, period, employeeId } = req.query;
    let filtered = performanceReviews;

    if (status) {
      filtered = filtered.filter(r => r.status === status);
    }

    if (period) {
      filtered = filtered.filter(r => r.period === period);
    }

    if (employeeId) {
      filtered = filtered.filter(r => r.employeeId === parseInt(employeeId));
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.get('/reviews/:id', async (req, res) => {
  try {
    const review = performanceReviews.find(r => r.id === parseInt(req.params.id));
    if (!review) {
      return res.status(404).json({
        success: false,
        error: 'Performance review not found',
      });
    }
    res.json({
      success: true,
      data: review,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/reviews', async (req, res) => {
  try {
    const review = {
      id: performanceReviews.length > 0 ? Math.max(...performanceReviews.map(r => r.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'pending',
      overallScore: req.body.overallScore || 0,
      reviewDate: req.body.reviewDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    performanceReviews.push(review);

    emitEvent('advanced-performance:updated', {
      action: 'create',
      entityType: 'review',
      entityId: review.id,
      data: review,
    });

    res.json({
      success: true,
      data: review,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.put('/reviews/:id', async (req, res) => {
  try {
    const index = performanceReviews.findIndex(r => r.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Performance review not found',
      });
    }

    performanceReviews[index] = {
      ...performanceReviews[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    emitEvent('advanced-performance:updated', {
      action: 'update',
      entityType: 'review',
      entityId: performanceReviews[index].id,
      data: performanceReviews[index],
    });

    res.json({
      success: true,
      data: performanceReviews[index],
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Goals ====================

router.get('/goals', async (req, res) => {
  try {
    const { status, employeeId, category } = req.query;
    let filtered = goals;

    if (status) {
      filtered = filtered.filter(g => g.status === status);
    }

    if (employeeId) {
      filtered = filtered.filter(g => g.employeeId === parseInt(employeeId));
    }

    if (category) {
      filtered = filtered.filter(g => g.category === category);
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/goals', async (req, res) => {
  try {
    const goal = {
      id: goals.length > 0 ? Math.max(...goals.map(g => g.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      progress: req.body.progress || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    goals.push(goal);

    emitEvent('advanced-performance:updated', {
      action: 'create',
      entityType: 'goal',
      entityId: goal.id,
      data: goal,
    });

    res.json({
      success: true,
      data: goal,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.put('/goals/:id', async (req, res) => {
  try {
    const index = goals.findIndex(g => g.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Goal not found',
      });
    }

    goals[index] = {
      ...goals[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    emitEvent('advanced-performance:updated', {
      action: 'update',
      entityType: 'goal',
      entityId: goals[index].id,
      data: goals[index],
    });

    res.json({
      success: true,
      data: goals[index],
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== KPIs ====================

router.get('/kpis', async (req, res) => {
  try {
    res.json({
      success: true,
      data: kpis,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/kpis', async (req, res) => {
  try {
    const kpi = {
      id: kpis.length > 0 ? Math.max(...kpis.map(k => k.id)) + 1 : 1,
      ...req.body,
      currentValue: req.body.currentValue || 0,
      targetValue: req.body.targetValue || 0,
      trend: req.body.trend || 'neutral',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    kpis.push(kpi);

    emitEvent('advanced-performance:updated', {
      action: 'create',
      entityType: 'kpi',
      entityId: kpi.id,
      data: kpi,
    });

    res.json({
      success: true,
      data: kpi,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Development Plans ====================

router.get('/development-plans', async (req, res) => {
  try {
    const { status, employeeId } = req.query;
    let filtered = developmentPlans;

    if (status) {
      filtered = filtered.filter(p => p.status === status);
    }

    if (employeeId) {
      filtered = filtered.filter(p => p.employeeId === parseInt(employeeId));
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/development-plans', async (req, res) => {
  try {
    const plan = {
      id: developmentPlans.length > 0 ? Math.max(...developmentPlans.map(p => p.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    developmentPlans.push(plan);

    emitEvent('advanced-performance:updated', {
      action: 'create',
      entityType: 'developmentPlan',
      entityId: plan.id,
      data: plan,
    });

    res.json({
      success: true,
      data: plan,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.put('/development-plans/:id', async (req, res) => {
  try {
    const index = developmentPlans.findIndex(p => p.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Development plan not found',
      });
    }

    developmentPlans[index] = {
      ...developmentPlans[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    emitEvent('advanced-performance:updated', {
      action: 'update',
      entityType: 'developmentPlan',
      entityId: developmentPlans[index].id,
      data: developmentPlans[index],
    });

    res.json({
      success: true,
      data: developmentPlans[index],
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Statistics ====================

router.get('/stats', async (req, res) => {
  try {
    const totalReviews = performanceReviews.length;
    const averageScore =
      totalReviews > 0
        ? Math.round(
            performanceReviews.reduce((sum, r) => sum + (r.overallScore || 0), 0) / totalReviews
          )
        : 0;
    const activeGoals = goals.filter(g => g.status === 'active').length;
    const activePlans = developmentPlans.filter(p => p.status === 'active').length;

    res.json({
      success: true,
      data: {
        totalReviews,
        averageScore,
        activeGoals,
        activePlans,
        totalKPIs: kpis.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

module.exports = router;
module.exports.setIO = setIO;
