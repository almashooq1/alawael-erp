/**
 * Advanced Permissions Management Routes
 * API routes for advanced permissions features
 */

const express = require('express');
const router = express.Router();
const { AdvancedPermissionsManager } = require('../../shared/utils/permissions-manager');
const { requirePermission } = require('../../shared/middleware/permissions-middleware');

const advancedPermissionsManager = new AdvancedPermissionsManager();

// ========== Conditional Permissions ==========

/**
 * إضافة صلاحية مشروطة
 */
router.post(
  '/conditional-permissions',
  requirePermission('system.permissions'),
  async (req, res) => {
    try {
      advancedPermissionsManager.addConditionalPermission(
        req.body.userId,
        req.body.permissionId,
        req.body.conditions
      );
      res.json({ success: true, message: 'Conditional permission added' });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * التحقق من صلاحية مشروطة
 */
router.post('/conditional-permissions/check', async (req, res) => {
  try {
    const hasPermission = advancedPermissionsManager.checkConditionalPermission(
      req.body.userId,
      req.body.permissionId,
      req.body.context || {}
    );
    res.json({ success: true, data: { hasPermission } });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Temporary Permissions ==========

/**
 * إضافة صلاحية مؤقتة
 */
router.post('/temporary-permissions', requirePermission('system.permissions'), async (req, res) => {
  try {
    const tempPerm = advancedPermissionsManager.addTemporaryPermission(
      req.body.userId,
      req.body.permissionId,
      req.body.expiryDate,
      req.body.reason || ''
    );
    res.json({ success: true, data: tempPerm });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على الصلاحيات المؤقتة لمستخدم
 */
router.get('/temporary-permissions/:userId', async (req, res) => {
  try {
    const tempPerms = advancedPermissionsManager.temporaryPermissions.get(req.params.userId) || [];
    res.json({ success: true, data: tempPerms });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Permission Groups ==========

/**
 * إنشاء مجموعة صلاحيات
 */
router.post('/permission-groups', requirePermission('system.permissions'), async (req, res) => {
  try {
    const group = advancedPermissionsManager.createPermissionGroup(req.body);
    res.json({ success: true, data: group });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على جميع مجموعات الصلاحيات
 */
router.get('/permission-groups', async (req, res) => {
  try {
    const groups = Array.from(advancedPermissionsManager.permissionGroups.values());
    res.json({ success: true, data: groups });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تعيين مجموعة صلاحيات لدور
 */
router.post(
  '/roles/:roleId/permission-groups/:groupId',
  requirePermission('system.roles'),
  async (req, res) => {
    try {
      advancedPermissionsManager.assignPermissionGroupToRole(req.params.roleId, req.params.groupId);
      res.json({ success: true, message: 'Permission group assigned to role' });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Role Templates ==========

/**
 * إنشاء قالب دور
 */
router.post('/role-templates', requirePermission('system.roles'), async (req, res) => {
  try {
    const template = advancedPermissionsManager.createRoleTemplate(req.body);
    res.json({ success: true, data: template });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على جميع قوالب الأدوار
 */
router.get('/role-templates', async (req, res) => {
  try {
    const templates = Array.from(advancedPermissionsManager.roleTemplates.values());
    res.json({ success: true, data: templates });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * إنشاء دور من قالب
 */
router.post(
  '/role-templates/:templateId/create-role',
  requirePermission('system.roles'),
  async (req, res) => {
    try {
      const role = advancedPermissionsManager.createRoleFromTemplate(
        req.params.templateId,
        req.body
      );
      res.json({ success: true, data: role });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Permission Delegation ==========

/**
 * تفويض صلاحية
 */
router.post('/delegations', requirePermission('system.permissions'), async (req, res) => {
  try {
    const delegation = advancedPermissionsManager.delegatePermission(
      req.body.fromUserId,
      req.body.toUserId,
      req.body.permissionId,
      req.body.expiryDate || null,
      req.body.reason || ''
    );
    res.json({ success: true, data: delegation });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * إلغاء تفويض
 */
router.post(
  '/delegations/:id/revoke',
  requirePermission('system.permissions'),
  async (req, res) => {
    try {
      const delegation = advancedPermissionsManager.revokeDelegation(req.params.id);
      res.json({ success: true, data: delegation });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * الحصول على تفويضات مستخدم
 */
router.get('/delegations/user/:userId', async (req, res) => {
  try {
    const delegations = Array.from(advancedPermissionsManager.delegations.values()).filter(
      d => d.toUserId === req.params.userId || d.fromUserId === req.params.userId
    );
    res.json({ success: true, data: delegations });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Audit Log ==========

/**
 * الحصول على سجل الأنشطة
 */
router.get('/audit-log', requirePermission('system.permissions'), async (req, res) => {
  try {
    const logs = advancedPermissionsManager.getAuditLog(req.query);
    res.json({ success: true, data: logs });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Permission Analytics ==========

/**
 * الحصول على تحليلات صلاحية
 */
router.get(
  '/analytics/:permissionId',
  requirePermission('system.permissions'),
  async (req, res) => {
    try {
      const analytics = advancedPermissionsManager.getPermissionAnalytics(req.params.permissionId);
      res.json({ success: true, data: analytics });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Advanced Reports ==========

/**
 * تقرير الصلاحيات المتقدم
 */
router.get('/advanced-report', requirePermission('system.permissions'), async (req, res) => {
  try {
    const report = advancedPermissionsManager.getAdvancedPermissionsReport();
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
