/**
 * 📢 Advanced PR Management Routes
 */

const express = require('express');
const router = express.Router();

const campaigns = [];
const media = [];
const pressReleases = [];
const events = [];
const socialMedia = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/campaigns', async (req, res) => {
  try {
    const { status, type } = req.query;
    let filtered = campaigns;
    if (status) filtered = filtered.filter(c => c.status === status);
    if (type) filtered = filtered.filter(c => c.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/campaigns', async (req, res) => {
  try {
    const campaign = {
      id: campaigns.length > 0 ? Math.max(...campaigns.map(c => c.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'scheduled',
      type: req.body.type || 'awareness',
      reach: req.body.reach || 0,
      startDate: req.body.startDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    campaigns.push(campaign);
    emitEvent('advanced-pr:updated', {
      action: 'create',
      entityType: 'campaign',
      entityId: campaign.id,
      data: campaign,
    });
    res.json({ success: true, data: campaign });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/media', async (req, res) => {
  try {
    const { type } = req.query;
    let filtered = media;
    if (type) filtered = filtered.filter(m => m.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/media', async (req, res) => {
  try {
    const mediaItem = {
      id: media.length > 0 ? Math.max(...media.map(m => m.id)) + 1 : 1,
      ...req.body,
      type: req.body.type || 'image',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    media.push(mediaItem);
    emitEvent('advanced-pr:updated', {
      action: 'create',
      entityType: 'media',
      entityId: mediaItem.id,
      data: mediaItem,
    });
    res.json({ success: true, data: mediaItem });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/press-releases', async (req, res) => {
  try {
    const { date } = req.query;
    let filtered = pressReleases;
    if (date)
      filtered = filtered.filter(
        p => new Date(p.date).toDateString() === new Date(date).toDateString()
      );
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/press-releases', async (req, res) => {
  try {
    const release = {
      id: pressReleases.length > 0 ? Math.max(...pressReleases.map(p => p.id)) + 1 : 1,
      ...req.body,
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    pressReleases.push(release);
    emitEvent('advanced-pr:updated', {
      action: 'create',
      entityType: 'pressRelease',
      entityId: release.id,
      data: release,
    });
    res.json({ success: true, data: release });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/events', async (req, res) => {
  try {
    const { status, date } = req.query;
    let filtered = events;
    if (status) filtered = filtered.filter(e => e.status === status);
    if (date)
      filtered = filtered.filter(
        e => new Date(e.date).toDateString() === new Date(date).toDateString()
      );
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/events', async (req, res) => {
  try {
    const event = {
      id: events.length > 0 ? Math.max(...events.map(e => e.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'scheduled',
      attendeesCount: req.body.attendeesCount || 0,
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    events.push(event);
    emitEvent('advanced-pr:updated', {
      action: 'create',
      entityType: 'event',
      entityId: event.id,
      data: event,
    });
    res.json({ success: true, data: event });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/social-media', async (req, res) => {
  try {
    const { platform, date } = req.query;
    let filtered = socialMedia;
    if (platform) filtered = filtered.filter(s => s.platform === platform);
    if (date)
      filtered = filtered.filter(
        s => new Date(s.date).toDateString() === new Date(date).toDateString()
      );
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/social-media', async (req, res) => {
  try {
    const post = {
      id: socialMedia.length > 0 ? Math.max(...socialMedia.map(s => s.id)) + 1 : 1,
      ...req.body,
      platform: req.body.platform || 'facebook',
      likes: req.body.likes || 0,
      shares: req.body.shares || 0,
      comments: req.body.comments || 0,
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    socialMedia.push(post);
    emitEvent('advanced-pr:updated', {
      action: 'create',
      entityType: 'socialMedia',
      entityId: post.id,
      data: post,
    });
    res.json({ success: true, data: post });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/analytics', async (req, res) => {
  try {
    const totalCampaigns = campaigns.length;
    const activeCampaigns = campaigns.filter(c => c.status === 'active').length;
    const completedCampaigns = campaigns.filter(c => c.status === 'completed').length;
    const totalMedia = media.length;
    const totalPressReleases = pressReleases.length;
    const totalEvents = events.length;
    const totalSocialMedia = socialMedia.length;
    const totalReach = campaigns.reduce((sum, c) => sum + (c.reach || 0), 0);
    const totalLikes = socialMedia.reduce((sum, s) => sum + (s.likes || 0), 0);
    const totalShares = socialMedia.reduce((sum, s) => sum + (s.shares || 0), 0);

    const analyticsData = [
      {
        id: 1,
        metric: 'إجمالي الحملات',
        value: totalCampaigns,
        description: 'عدد الحملات الكلي',
      },
      {
        id: 2,
        metric: 'الحملات النشطة',
        value: activeCampaigns,
        description: 'عدد الحملات النشطة',
      },
      {
        id: 3,
        metric: 'الحملات المكتملة',
        value: completedCampaigns,
        description: 'عدد الحملات المكتملة',
      },
      {
        id: 4,
        metric: 'إجمالي الوسائط',
        value: totalMedia,
        description: 'عدد الوسائط الكلي',
      },
      {
        id: 5,
        metric: 'إجمالي البيانات الصحفية',
        value: totalPressReleases,
        description: 'عدد البيانات الصحفية الكلي',
      },
      {
        id: 6,
        metric: 'إجمالي الفعاليات',
        value: totalEvents,
        description: 'عدد الفعاليات الكلي',
      },
      {
        id: 7,
        metric: 'إجمالي منشورات التواصل',
        value: totalSocialMedia,
        description: 'عدد منشورات وسائل التواصل الكلي',
      },
      {
        id: 8,
        metric: 'إجمالي الوصول',
        value: totalReach.toLocaleString('ar-SA'),
        description: 'إجمالي الوصول لجميع الحملات',
      },
      {
        id: 9,
        metric: 'إجمالي الإعجابات',
        value: totalLikes.toLocaleString('ar-SA'),
        description: 'إجمالي الإعجابات على منشورات التواصل',
      },
      {
        id: 10,
        metric: 'إجمالي المشاركات',
        value: totalShares.toLocaleString('ar-SA'),
        description: 'إجمالي المشاركات على منشورات التواصل',
      },
    ];

    res.json({ success: true, data: analyticsData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
