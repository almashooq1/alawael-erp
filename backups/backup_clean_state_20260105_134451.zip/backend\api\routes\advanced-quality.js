/**
 * ⭐ Advanced Quality Management Routes
 */

const express = require('express');
const router = express.Router();

const standards = [];
const audits = [];
const nonConformances = [];
const improvements = [];
const metrics = [];
const certifications = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/standards', async (req, res) => {
  try {
    const { status, category } = req.query;
    let filtered = standards;
    if (status) filtered = filtered.filter(s => s.status === status);
    if (category) filtered = filtered.filter(s => s.category === category);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/standards', async (req, res) => {
  try {
    const standard = {
      id: standards.length > 0 ? Math.max(...standards.map(s => s.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      version: req.body.version || '1.0',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    standards.push(standard);
    emitEvent('advanced-quality:updated', {
      action: 'create',
      entityType: 'standard',
      entityId: standard.id,
      data: standard,
    });
    res.json({ success: true, data: standard });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/audits', async (req, res) => {
  try {
    const { status, type } = req.query;
    let filtered = audits;
    if (status) filtered = filtered.filter(a => a.status === status);
    if (type) filtered = filtered.filter(a => a.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/audits', async (req, res) => {
  try {
    const audit = {
      id: audits.length > 0 ? Math.max(...audits.map(a => a.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'pending',
      type: req.body.type || 'internal',
      auditDate: req.body.auditDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    audits.push(audit);
    emitEvent('advanced-quality:updated', {
      action: 'create',
      entityType: 'audit',
      entityId: audit.id,
      data: audit,
    });
    res.json({ success: true, data: audit });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/non-conformances', async (req, res) => {
  try {
    const { severity, status } = req.query;
    let filtered = nonConformances;
    if (severity) filtered = filtered.filter(nc => nc.severity === severity);
    if (status) filtered = filtered.filter(nc => nc.status === status);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/non-conformances', async (req, res) => {
  try {
    const nc = {
      id: nonConformances.length > 0 ? Math.max(...nonConformances.map(n => n.id)) + 1 : 1,
      ...req.body,
      severity: req.body.severity || 'medium',
      status: req.body.status || 'open',
      identifiedDate: req.body.identifiedDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    nonConformances.push(nc);
    emitEvent('advanced-quality:updated', {
      action: 'create',
      entityType: 'nonConformance',
      entityId: nc.id,
      data: nc,
    });
    res.json({ success: true, data: nc });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/improvements', async (req, res) => {
  try {
    const { status, type } = req.query;
    let filtered = improvements;
    if (status) filtered = filtered.filter(i => i.status === status);
    if (type) filtered = filtered.filter(i => i.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/improvements', async (req, res) => {
  try {
    const improvement = {
      id: improvements.length > 0 ? Math.max(...improvements.map(i => i.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'pending',
      type: req.body.type || 'process',
      progress: req.body.progress || 0,
      startDate: req.body.startDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    improvements.push(improvement);
    emitEvent('advanced-quality:updated', {
      action: 'create',
      entityType: 'improvement',
      entityId: improvement.id,
      data: improvement,
    });
    res.json({ success: true, data: improvement });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/metrics', async (req, res) => {
  try {
    res.json({ success: true, data: metrics });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/metrics', async (req, res) => {
  try {
    const metric = {
      id: metrics.length > 0 ? Math.max(...metrics.map(m => m.id)) + 1 : 1,
      ...req.body,
      value: req.body.value || 0,
      target: req.body.target || 0,
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    metrics.push(metric);
    emitEvent('advanced-quality:updated', {
      action: 'create',
      entityType: 'metric',
      entityId: metric.id,
      data: metric,
    });
    res.json({ success: true, data: metric });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/certifications', async (req, res) => {
  try {
    const { status } = req.query;
    let filtered = certifications;
    if (status) filtered = filtered.filter(c => c.status === status);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/certifications', async (req, res) => {
  try {
    const cert = {
      id: certifications.length > 0 ? Math.max(...certifications.map(c => c.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'valid',
      issueDate: req.body.issueDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    certifications.push(cert);
    emitEvent('advanced-quality:updated', {
      action: 'create',
      entityType: 'certification',
      entityId: cert.id,
      data: cert,
    });
    res.json({ success: true, data: cert });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/analytics', async (req, res) => {
  try {
    const totalStandards = standards.length;
    const activeStandards = standards.filter(s => s.status === 'active').length;
    const totalAudits = audits.length;
    const completedAudits = audits.filter(a => a.status === 'completed').length;
    const totalNonConformances = nonConformances.length;
    const openNonConformances = nonConformances.filter(nc => nc.status === 'open').length;
    const totalImprovements = improvements.length;
    const inProgressImprovements = improvements.filter(i => i.status === 'inprogress').length;
    const totalMetrics = metrics.length;
    const totalCertifications = certifications.length;
    const validCertifications = certifications.filter(c => c.status === 'valid').length;

    const analyticsData = [
      {
        id: 1,
        metric: 'إجمالي المعايير',
        value: totalStandards,
        description: 'عدد المعايير الكلي',
      },
      {
        id: 2,
        metric: 'المعايير النشطة',
        value: activeStandards,
        description: 'عدد المعايير النشطة',
      },
      {
        id: 3,
        metric: 'إجمالي التدقيقات',
        value: totalAudits,
        description: 'عدد التدقيقات الكلي',
      },
      {
        id: 4,
        metric: 'التدقيقات المكتملة',
        value: completedAudits,
        description: 'عدد التدقيقات المكتملة',
      },
      {
        id: 5,
        metric: 'إجمالي عدم المطابقة',
        value: totalNonConformances,
        description: 'عدد حالات عدم المطابقة الكلي',
      },
      {
        id: 6,
        metric: 'عدم المطابقة المفتوحة',
        value: openNonConformances,
        description: 'عدد حالات عدم المطابقة المفتوحة',
      },
      {
        id: 7,
        metric: 'إجمالي التحسينات',
        value: totalImprovements,
        description: 'عدد التحسينات الكلي',
      },
      {
        id: 8,
        metric: 'التحسينات قيد التنفيذ',
        value: inProgressImprovements,
        description: 'عدد التحسينات قيد التنفيذ',
      },
      {
        id: 9,
        metric: 'إجمالي المقاييس',
        value: totalMetrics,
        description: 'عدد المقاييس الكلي',
      },
      {
        id: 10,
        metric: 'إجمالي الشهادات',
        value: totalCertifications,
        description: 'عدد الشهادات الكلي',
      },
      {
        id: 11,
        metric: 'الشهادات الصالحة',
        value: validCertifications,
        description: 'عدد الشهادات الصالحة',
      },
    ];

    res.json({ success: true, data: analyticsData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
module.exports.setIO = setIO;
