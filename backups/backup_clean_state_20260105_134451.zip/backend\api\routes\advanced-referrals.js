/**
 * 🔄 Advanced Referrals Management Routes
 */

const express = require('express');
const router = express.Router();

const referrals = [];
const transfers = [];
const referralSources = [];
const referralDestinations = [];
const followUps = [];
const analytics = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/referrals', async (req, res) => {
  try {
    const { status, type } = req.query;
    let filtered = referrals;
    if (status) filtered = filtered.filter(r => r.status === status);
    if (type) filtered = filtered.filter(r => r.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/referrals', async (req, res) => {
  try {
    const referral = {
      id: referrals.length > 0 ? Math.max(...referrals.map(r => r.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'pending',
      type: req.body.type || 'internal',
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    referrals.push(referral);
    emitEvent('advanced-referrals:updated', {
      action: 'create',
      entityType: 'referral',
      entityId: referral.id,
      data: referral,
    });
    res.json({ success: true, data: referral });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/transfers', async (req, res) => {
  try {
    const { status } = req.query;
    let filtered = transfers;
    if (status) filtered = filtered.filter(t => t.status === status);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/transfers', async (req, res) => {
  try {
    const transfer = {
      id: transfers.length > 0 ? Math.max(...transfers.map(t => t.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'pending',
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    transfers.push(transfer);
    emitEvent('advanced-referrals:updated', {
      action: 'create',
      entityType: 'transfer',
      entityId: transfer.id,
      data: transfer,
    });
    res.json({ success: true, data: transfer });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/sources', async (req, res) => {
  try {
    const { type } = req.query;
    let filtered = referralSources;
    if (type) filtered = filtered.filter(s => s.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/sources', async (req, res) => {
  try {
    const source = {
      id: referralSources.length > 0 ? Math.max(...referralSources.map(s => s.id)) + 1 : 1,
      ...req.body,
      type: req.body.type || 'hospital',
      referralsCount: req.body.referralsCount || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    referralSources.push(source);
    emitEvent('advanced-referrals:updated', {
      action: 'create',
      entityType: 'source',
      entityId: source.id,
      data: source,
    });
    res.json({ success: true, data: source });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/destinations', async (req, res) => {
  try {
    const { type } = req.query;
    let filtered = referralDestinations;
    if (type) filtered = filtered.filter(d => d.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/destinations', async (req, res) => {
  try {
    const destination = {
      id:
        referralDestinations.length > 0 ? Math.max(...referralDestinations.map(d => d.id)) + 1 : 1,
      ...req.body,
      type: req.body.type || 'hospital',
      referralsCount: req.body.referralsCount || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    referralDestinations.push(destination);
    emitEvent('advanced-referrals:updated', {
      action: 'create',
      entityType: 'destination',
      entityId: destination.id,
      data: destination,
    });
    res.json({ success: true, data: destination });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/follow-ups', async (req, res) => {
  try {
    const { status, referralId } = req.query;
    let filtered = followUps;
    if (status) filtered = filtered.filter(f => f.status === status);
    if (referralId) filtered = filtered.filter(f => f.referralId === parseInt(referralId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/follow-ups', async (req, res) => {
  try {
    const followUp = {
      id: followUps.length > 0 ? Math.max(...followUps.map(f => f.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'pending',
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    followUps.push(followUp);
    emitEvent('advanced-referrals:updated', {
      action: 'create',
      entityType: 'followUp',
      entityId: followUp.id,
      data: followUp,
    });
    res.json({ success: true, data: followUp });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/analytics', async (req, res) => {
  try {
    const totalReferrals = referrals.length;
    const pendingReferrals = referrals.filter(r => r.status === 'pending').length;
    const approvedReferrals = referrals.filter(r => r.status === 'approved').length;
    const completedReferrals = referrals.filter(r => r.status === 'completed').length;
    const totalTransfers = transfers.length;
    const completedTransfers = transfers.filter(t => t.status === 'completed').length;
    const totalSources = referralSources.length;
    const totalDestinations = referralDestinations.length;
    const totalFollowUps = followUps.length;
    const completedFollowUps = followUps.filter(f => f.status === 'completed').length;

    const analyticsData = [
      {
        id: 1,
        metric: 'إجمالي الإحالات',
        value: totalReferrals,
        description: 'عدد الإحالات الكلي',
      },
      {
        id: 2,
        metric: 'الإحالات قيد الانتظار',
        value: pendingReferrals,
        description: 'عدد الإحالات قيد الانتظار',
      },
      {
        id: 3,
        metric: 'الإحالات الموافق عليها',
        value: approvedReferrals,
        description: 'عدد الإحالات الموافق عليها',
      },
      {
        id: 4,
        metric: 'الإحالات المكتملة',
        value: completedReferrals,
        description: 'عدد الإحالات المكتملة',
      },
      {
        id: 5,
        metric: 'إجمالي التحويلات',
        value: totalTransfers,
        description: 'عدد التحويلات الكلي',
      },
      {
        id: 6,
        metric: 'التحويلات المكتملة',
        value: completedTransfers,
        description: 'عدد التحويلات المكتملة',
      },
      {
        id: 7,
        metric: 'إجمالي المصادر',
        value: totalSources,
        description: 'عدد المصادر الكلي',
      },
      {
        id: 8,
        metric: 'إجمالي الوجهات',
        value: totalDestinations,
        description: 'عدد الوجهات الكلي',
      },
      {
        id: 9,
        metric: 'إجمالي المتابعات',
        value: totalFollowUps,
        description: 'عدد المتابعات الكلي',
      },
      {
        id: 10,
        metric: 'المتابعات المكتملة',
        value: completedFollowUps,
        description: 'عدد المتابعات المكتملة',
      },
    ];

    res.json({ success: true, data: analyticsData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
module.exports.setIO = setIO;
