/**
 * 🎯 Advanced Rehabilitation Programs Management Routes
 */

const express = require('express');
const router = express.Router();

const programs = [];
const phases = [];
const participants = [];
const progress = [];
const goals = [];
const activities = [];
const evaluations = [];
const reports = [];
const analytics = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/programs', async (req, res) => {
  try {
    const { status, category, disability, ageGroup } = req.query;
    let filtered = programs;
    if (status) filtered = filtered.filter(p => p.status === status);
    if (category) filtered = filtered.filter(p => p.category === category);
    if (disability) filtered = filtered.filter(p => p.targetDisability === disability);
    if (ageGroup) filtered = filtered.filter(p => p.ageGroup === ageGroup);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/programs', async (req, res) => {
  try {
    const program = {
      id: programs.length > 0 ? Math.max(...programs.map(p => p.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'draft',
      category: req.body.category || 'general',
      progress: req.body.progress || 0,
      phasesCount: req.body.phasesCount || 0,
      participantsCount: req.body.participantsCount || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    programs.push(program);
    emitEvent('advanced-rehabilitation-programs:updated', {
      action: 'create',
      entityType: 'program',
      entityId: program.id,
      data: program,
    });
    res.json({ success: true, data: program });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/programs/:id/start', async (req, res) => {
  try {
    const index = programs.findIndex(p => p.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Program not found' });
    }
    programs[index].status = 'active';
    programs[index].startDate = new Date().toISOString();
    emitEvent('advanced-rehabilitation-programs:updated', {
      action: 'update',
      entityType: 'program',
      entityId: programs[index].id,
      data: programs[index],
    });
    res.json({ success: true, data: programs[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/phases', async (req, res) => {
  try {
    const { programId, completed } = req.query;
    let filtered = phases;
    if (programId) filtered = filtered.filter(p => p.programId === parseInt(programId));
    if (completed !== undefined)
      filtered = filtered.filter(p => p.completed === (completed === 'true'));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/phases', async (req, res) => {
  try {
    const phase = {
      id: phases.length > 0 ? Math.max(...phases.map(p => p.id)) + 1 : 1,
      ...req.body,
      completed: req.body.completed || false,
      progress: req.body.progress || 0,
      sessionsCount: req.body.sessionsCount || 0,
      activitiesCount: req.body.activitiesCount || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    phases.push(phase);
    emitEvent('advanced-rehabilitation-programs:updated', {
      action: 'create',
      entityType: 'phase',
      entityId: phase.id,
      data: phase,
    });
    res.json({ success: true, data: phase });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/participants', async (req, res) => {
  try {
    const { programId, patientId, status } = req.query;
    let filtered = participants;
    if (programId) filtered = filtered.filter(p => p.programId === parseInt(programId));
    if (patientId) filtered = filtered.filter(p => p.patientId === parseInt(patientId));
    if (status) filtered = filtered.filter(p => p.status === status);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/participants', async (req, res) => {
  try {
    const participant = {
      id: participants.length > 0 ? Math.max(...participants.map(p => p.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      progress: req.body.progress || 0,
      completedSessions: req.body.completedSessions || 0,
      achievedGoals: req.body.achievedGoals || 0,
      startDate: req.body.startDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    participants.push(participant);
    emitEvent('advanced-rehabilitation-programs:updated', {
      action: 'create',
      entityType: 'participant',
      entityId: participant.id,
      data: participant,
    });
    res.json({ success: true, data: participant });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/progress', async (req, res) => {
  try {
    const { programId, patientId } = req.query;
    let filtered = progress;
    if (programId) filtered = filtered.filter(p => p.programId === parseInt(programId));
    if (patientId) filtered = filtered.filter(p => p.patientId === parseInt(patientId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/progress', async (req, res) => {
  try {
    const progressData = {
      id: progress.length > 0 ? Math.max(...progress.map(p => p.id)) + 1 : 1,
      ...req.body,
      overallProgress: req.body.overallProgress || 0,
      completedSessions: req.body.completedSessions || 0,
      achievedGoals: req.body.achievedGoals || 0,
      improvement: req.body.improvement || 0,
      history: req.body.history || [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    progress.push(progressData);
    emitEvent('advanced-rehabilitation-programs:updated', {
      action: 'create',
      entityType: 'progress',
      entityId: progressData.id,
      data: progressData,
    });
    res.json({ success: true, data: progressData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/goals', async (req, res) => {
  try {
    const { programId, achieved, priority } = req.query;
    let filtered = goals;
    if (programId) filtered = filtered.filter(g => g.programId === parseInt(programId));
    if (achieved !== undefined)
      filtered = filtered.filter(g => g.achieved === (achieved === 'true'));
    if (priority) filtered = filtered.filter(g => g.priority === priority);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/goals', async (req, res) => {
  try {
    const goal = {
      id: goals.length > 0 ? Math.max(...goals.map(g => g.id)) + 1 : 1,
      ...req.body,
      achieved: req.body.achieved || false,
      progress: req.body.progress || 0,
      priority: req.body.priority || 'medium',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    goals.push(goal);
    emitEvent('advanced-rehabilitation-programs:updated', {
      action: 'create',
      entityType: 'goal',
      entityId: goal.id,
      data: goal,
    });
    res.json({ success: true, data: goal });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/activities', async (req, res) => {
  try {
    const { programId, phaseId, type } = req.query;
    let filtered = activities;
    if (programId) filtered = filtered.filter(a => a.programId === parseInt(programId));
    if (phaseId) filtered = filtered.filter(a => a.phaseId === parseInt(phaseId));
    if (type) filtered = filtered.filter(a => a.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/activities', async (req, res) => {
  try {
    const activity = {
      id: activities.length > 0 ? Math.max(...activities.map(a => a.id)) + 1 : 1,
      ...req.body,
      type: req.body.type || 'general',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    activities.push(activity);
    emitEvent('advanced-rehabilitation-programs:updated', {
      action: 'create',
      entityType: 'activity',
      entityId: activity.id,
      data: activity,
    });
    res.json({ success: true, data: activity });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/evaluations', async (req, res) => {
  try {
    const { programId, patientId } = req.query;
    let filtered = evaluations;
    if (programId) filtered = filtered.filter(e => e.programId === parseInt(programId));
    if (patientId) filtered = filtered.filter(e => e.patientId === parseInt(patientId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/evaluations', async (req, res) => {
  try {
    const evaluation = {
      id: evaluations.length > 0 ? Math.max(...evaluations.map(e => e.id)) + 1 : 1,
      ...req.body,
      date: req.body.date || new Date().toISOString(),
      score: req.body.score || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    evaluations.push(evaluation);
    emitEvent('advanced-rehabilitation-programs:updated', {
      action: 'create',
      entityType: 'evaluation',
      entityId: evaluation.id,
      data: evaluation,
    });
    res.json({ success: true, data: evaluation });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/reports', async (req, res) => {
  try {
    const { programId, type } = req.query;
    let filtered = reports;
    if (programId) filtered = filtered.filter(r => r.programId === parseInt(programId));
    if (type) filtered = filtered.filter(r => r.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/reports', async (req, res) => {
  try {
    const report = {
      id: reports.length > 0 ? Math.max(...reports.map(r => r.id)) + 1 : 1,
      ...req.body,
      date: req.body.date || new Date().toISOString(),
      type: req.body.type || 'progress',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    reports.push(report);
    emitEvent('advanced-rehabilitation-programs:updated', {
      action: 'create',
      entityType: 'report',
      entityId: report.id,
      data: report,
    });
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/analytics', async (req, res) => {
  try {
    const totalPrograms = programs.length;
    const activePrograms = programs.filter(p => p.status === 'active').length;
    const completedPrograms = programs.filter(p => p.status === 'completed').length;
    const totalParticipants = participants.length;
    const activeParticipants = participants.filter(p => p.status === 'active').length;
    const averageProgress =
      progress.length > 0
        ? Math.round(
            progress.reduce((sum, p) => sum + (p.overallProgress || 0), 0) / progress.length
          )
        : 0;

    const analyticsData = [
      {
        id: 1,
        metric: 'إجمالي البرامج',
        value: totalPrograms,
        description: 'عدد البرامج التأهيلية الكلي',
        trend: null,
      },
      {
        id: 2,
        metric: 'البرامج النشطة',
        value: activePrograms,
        description: 'عدد البرامج النشطة حالياً',
        trend: null,
      },
      {
        id: 3,
        metric: 'البرامج المكتملة',
        value: completedPrograms,
        description: 'عدد البرامج المكتملة',
        trend: null,
      },
      {
        id: 4,
        metric: 'إجمالي المشاركين',
        value: totalParticipants,
        description: 'عدد المشاركين الكلي',
        trend: null,
      },
      {
        id: 5,
        metric: 'المشاركون النشطون',
        value: activeParticipants,
        description: 'عدد المشاركين النشطين',
        trend: null,
      },
      {
        id: 6,
        metric: 'متوسط التقدم',
        value: `${averageProgress}%`,
        description: 'متوسط التقدم في البرامج',
        trend: null,
      },
    ];

    res.json({ success: true, data: analyticsData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
module.exports.setIO = setIO;
