/**
 * 📊 Advanced Reports Management Routes
 */

const express = require('express');
const router = express.Router();

const reports = [];
const templates = [];
const scheduled = [];
const analytics = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/reports', async (req, res) => {
  try {
    const { status, type, category } = req.query;
    let filtered = reports;
    if (status) filtered = filtered.filter(r => r.status === status);
    if (type) filtered = filtered.filter(r => r.type === type);
    if (category) filtered = filtered.filter(r => r.category === category);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/reports', async (req, res) => {
  try {
    const report = {
      id: reports.length > 0 ? Math.max(...reports.map(r => r.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'draft',
      format: req.body.format || 'pdf',
      createdDate: req.body.createdDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    reports.push(report);
    emitEvent('advanced-reports-management:updated', {
      action: 'create',
      entityType: 'report',
      entityId: report.id,
      data: report,
    });
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/templates', async (req, res) => {
  try {
    const { type } = req.query;
    let filtered = templates;
    if (type) filtered = filtered.filter(t => t.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/templates', async (req, res) => {
  try {
    const template = {
      id: templates.length > 0 ? Math.max(...templates.map(t => t.id)) + 1 : 1,
      ...req.body,
      type: req.body.type || 'general',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    templates.push(template);
    emitEvent('advanced-reports-management:updated', {
      action: 'create',
      entityType: 'template',
      entityId: template.id,
      data: template,
    });
    res.json({ success: true, data: template });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/scheduled', async (req, res) => {
  try {
    const { status } = req.query;
    let filtered = scheduled;
    if (status) filtered = filtered.filter(s => s.status === status);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/scheduled', async (req, res) => {
  try {
    const schedule = {
      id: scheduled.length > 0 ? Math.max(...scheduled.map(s => s.id)) + 1 : 1,
      ...req.body,
      frequency: req.body.frequency || 'daily',
      status: req.body.status || 'active',
      nextRun: req.body.nextRun || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    scheduled.push(schedule);
    emitEvent('advanced-reports-management:updated', {
      action: 'create',
      entityType: 'schedule',
      entityId: schedule.id,
      data: schedule,
    });
    res.json({ success: true, data: schedule });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/analytics', async (req, res) => {
  try {
    res.json({ success: true, data: analytics });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/analytics', async (req, res) => {
  try {
    const analytic = {
      id: analytics.length > 0 ? Math.max(...analytics.map(a => a.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    analytics.push(analytic);
    emitEvent('advanced-reports-management:updated', {
      action: 'create',
      entityType: 'analytic',
      entityId: analytic.id,
      data: analytic,
    });
    res.json({ success: true, data: analytic });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
module.exports.setIO = setIO;
