/**
 * 📊 Advanced Reports Routes
 * API routes for advanced reports management system
 */

const express = require('express');
const router = express.Router();

// Mock data storage (replace with database)
const reports = [];
const templates = [];
const schedules = [];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Reports ====================

router.get('/reports', async (req, res) => {
  try {
    const { category, status } = req.query;
    let filtered = reports;

    if (category) {
      filtered = filtered.filter(r => r.category === category);
    }

    if (status) {
      filtered = filtered.filter(r => r.status === status);
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/reports', async (req, res) => {
  try {
    const report = {
      id: reports.length > 0 ? Math.max(...reports.map(r => r.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'pending',
      format: req.body.format || 'pdf',
      generatedAt: new Date().toISOString(),
      createdAt: new Date().toISOString(),
    };

    reports.push(report);

    emitEvent('reports:updated', {
      action: 'create',
      entityId: report.id,
      data: report,
    });

    res.json({
      success: true,
      data: report,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.delete('/reports/:id', async (req, res) => {
  try {
    const index = reports.findIndex(r => r.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Report not found',
      });
    }

    reports.splice(index, 1);

    emitEvent('reports:updated', {
      action: 'delete',
      entityId: parseInt(req.params.id),
    });

    res.json({
      success: true,
      message: 'Report deleted successfully',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Templates ====================

router.get('/templates', async (req, res) => {
  try {
    const { category } = req.query;
    let filtered = templates;

    if (category) {
      filtered = filtered.filter(t => t.category === category);
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/templates', async (req, res) => {
  try {
    const template = {
      id: templates.length > 0 ? Math.max(...templates.map(t => t.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
    };

    templates.push(template);

    res.json({
      success: true,
      data: template,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Schedules ====================

router.get('/schedules', async (req, res) => {
  try {
    res.json({
      success: true,
      data: schedules,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/schedules', async (req, res) => {
  try {
    const schedule = {
      id: schedules.length > 0 ? Math.max(...schedules.map(s => s.id)) + 1 : 1,
      ...req.body,
      enabled: req.body.enabled !== undefined ? req.body.enabled : true,
      createdAt: new Date().toISOString(),
    };

    schedules.push(schedule);

    res.json({
      success: true,
      data: schedule,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

module.exports = router;
module.exports.setIO = setIO;
