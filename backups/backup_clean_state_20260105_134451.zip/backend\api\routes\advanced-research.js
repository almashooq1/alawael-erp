/**
 * 🔬 Advanced Research Management Routes
 */

const express = require('express');
const router = express.Router();

const researchProjects = [];
const studies = [];
const publications = [];
const researchers = [];
const funding = [];
const collaborations = [];
const analytics = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/projects', async (req, res) => {
  try {
    const { status, category } = req.query;
    let filtered = researchProjects;
    if (status) filtered = filtered.filter(p => p.status === status);
    if (category) filtered = filtered.filter(p => p.category === category);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/projects', async (req, res) => {
  try {
    const project = {
      id: researchProjects.length > 0 ? Math.max(...researchProjects.map(p => p.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'pending',
      category: req.body.category || 'clinical',
      progress: req.body.progress || 0,
      budget: req.body.budget || 0,
      startDate: req.body.startDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    researchProjects.push(project);
    emitEvent('advanced-research:updated', {
      action: 'create',
      entityType: 'project',
      entityId: project.id,
      data: project,
    });
    res.json({ success: true, data: project });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/studies', async (req, res) => {
  try {
    const { status, type } = req.query;
    let filtered = studies;
    if (status) filtered = filtered.filter(s => s.status === status);
    if (type) filtered = filtered.filter(s => s.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/studies', async (req, res) => {
  try {
    const study = {
      id: studies.length > 0 ? Math.max(...studies.map(s => s.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      type: req.body.type || 'observational',
      sampleSize: req.body.sampleSize || 0,
      startDate: req.body.startDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    studies.push(study);
    emitEvent('advanced-research:updated', {
      action: 'create',
      entityType: 'study',
      entityId: study.id,
      data: study,
    });
    res.json({ success: true, data: study });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/publications', async (req, res) => {
  try {
    const { type, year } = req.query;
    let filtered = publications;
    if (type) filtered = filtered.filter(p => p.type === type);
    if (year)
      filtered = filtered.filter(p => new Date(p.publishDate).getFullYear() === parseInt(year));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/publications', async (req, res) => {
  try {
    const publication = {
      id: publications.length > 0 ? Math.max(...publications.map(p => p.id)) + 1 : 1,
      ...req.body,
      type: req.body.type || 'journal',
      publishDate: req.body.publishDate || new Date().toISOString(),
      impactFactor: req.body.impactFactor || null,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    publications.push(publication);
    emitEvent('advanced-research:updated', {
      action: 'create',
      entityType: 'publication',
      entityId: publication.id,
      data: publication,
    });
    res.json({ success: true, data: publication });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/researchers', async (req, res) => {
  try {
    const { specialization } = req.query;
    let filtered = researchers;
    if (specialization) filtered = filtered.filter(r => r.specialization === specialization);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/researchers', async (req, res) => {
  try {
    const researcher = {
      id: researchers.length > 0 ? Math.max(...researchers.map(r => r.id)) + 1 : 1,
      ...req.body,
      projectsCount: req.body.projectsCount || 0,
      publicationsCount: req.body.publicationsCount || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    researchers.push(researcher);
    emitEvent('advanced-research:updated', {
      action: 'create',
      entityType: 'researcher',
      entityId: researcher.id,
      data: researcher,
    });
    res.json({ success: true, data: researcher });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/funding', async (req, res) => {
  try {
    const { status, type } = req.query;
    let filtered = funding;
    if (status) filtered = filtered.filter(f => f.status === status);
    if (type) filtered = filtered.filter(f => f.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/funding', async (req, res) => {
  try {
    const fund = {
      id: funding.length > 0 ? Math.max(...funding.map(f => f.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'received',
      type: req.body.type || 'grant',
      amount: req.body.amount || 0,
      receivedDate: req.body.receivedDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    funding.push(fund);
    emitEvent('advanced-research:updated', {
      action: 'create',
      entityType: 'funding',
      entityId: fund.id,
      data: fund,
    });
    res.json({ success: true, data: fund });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/collaborations', async (req, res) => {
  try {
    const { status, type } = req.query;
    let filtered = collaborations;
    if (status) filtered = filtered.filter(c => c.status === status);
    if (type) filtered = filtered.filter(c => c.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/collaborations', async (req, res) => {
  try {
    const collaboration = {
      id: collaborations.length > 0 ? Math.max(...collaborations.map(c => c.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      type: req.body.type || 'academic',
      startDate: req.body.startDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    collaborations.push(collaboration);
    emitEvent('advanced-research:updated', {
      action: 'create',
      entityType: 'collaboration',
      entityId: collaboration.id,
      data: collaboration,
    });
    res.json({ success: true, data: collaboration });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/analytics', async (req, res) => {
  try {
    const totalProjects = researchProjects.length;
    const activeProjects = researchProjects.filter(p => p.status === 'active').length;
    const completedProjects = researchProjects.filter(p => p.status === 'completed').length;
    const totalStudies = studies.length;
    const activeStudies = studies.filter(s => s.status === 'active').length;
    const totalPublications = publications.length;
    const journalPublications = publications.filter(p => p.type === 'journal').length;
    const totalResearchers = researchers.length;
    const totalFunding = funding.reduce((sum, f) => sum + (f.amount || 0), 0);
    const totalCollaborations = collaborations.length;
    const activeCollaborations = collaborations.filter(c => c.status === 'active').length;

    const analyticsData = [
      {
        id: 1,
        metric: 'إجمالي المشاريع البحثية',
        value: totalProjects,
        description: 'عدد المشاريع البحثية الكلي',
      },
      {
        id: 2,
        metric: 'المشاريع النشطة',
        value: activeProjects,
        description: 'عدد المشاريع البحثية النشطة',
      },
      {
        id: 3,
        metric: 'المشاريع المكتملة',
        value: completedProjects,
        description: 'عدد المشاريع البحثية المكتملة',
      },
      {
        id: 4,
        metric: 'إجمالي الدراسات',
        value: totalStudies,
        description: 'عدد الدراسات الكلي',
      },
      {
        id: 5,
        metric: 'الدراسات النشطة',
        value: activeStudies,
        description: 'عدد الدراسات النشطة',
      },
      {
        id: 6,
        metric: 'إجمالي المنشورات',
        value: totalPublications,
        description: 'عدد المنشورات الكلي',
      },
      {
        id: 7,
        metric: 'منشورات المجلات',
        value: journalPublications,
        description: 'عدد منشورات المجلات',
      },
      {
        id: 8,
        metric: 'إجمالي الباحثون',
        value: totalResearchers,
        description: 'عدد الباحثون الكلي',
      },
      {
        id: 9,
        metric: 'إجمالي التمويل',
        value: `${totalFunding.toLocaleString('ar-SA')} ر.س`,
        description: 'إجمالي قيمة التمويل',
      },
      {
        id: 10,
        metric: 'إجمالي التعاونات',
        value: totalCollaborations,
        description: 'عدد التعاونات الكلي',
      },
      {
        id: 11,
        metric: 'التعاونات النشطة',
        value: activeCollaborations,
        description: 'عدد التعاونات النشطة',
      },
    ];

    res.json({ success: true, data: analyticsData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
module.exports.setIO = setIO;
