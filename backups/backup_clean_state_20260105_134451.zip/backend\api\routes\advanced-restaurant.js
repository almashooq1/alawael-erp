/**
 * 🍽️ Advanced Restaurant & Meals Management Routes
 */

const express = require('express');
const router = express.Router();

const menus = [];
const meals = [];
const orders = [];
const ingredients = [];
const suppliers = [];
const dietPlans = [];
const analytics = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/menus', async (req, res) => {
  try {
    const { status, type } = req.query;
    let filtered = menus;
    if (status) filtered = filtered.filter(m => m.status === status);
    if (type) filtered = filtered.filter(m => m.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/menus', async (req, res) => {
  try {
    const menu = {
      id: menus.length > 0 ? Math.max(...menus.map(m => m.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      type: req.body.type || 'daily',
      mealsCount: req.body.mealsCount || 0,
      price: req.body.price || 0,
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    menus.push(menu);
    emitEvent('advanced-restaurant:updated', {
      action: 'create',
      entityType: 'menu',
      entityId: menu.id,
      data: menu,
    });
    res.json({ success: true, data: menu });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/meals', async (req, res) => {
  try {
    const { category, menuId } = req.query;
    let filtered = meals;
    if (category) filtered = filtered.filter(m => m.category === category);
    if (menuId) filtered = filtered.filter(m => m.menuId === parseInt(menuId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/meals', async (req, res) => {
  try {
    const meal = {
      id: meals.length > 0 ? Math.max(...meals.map(m => m.id)) + 1 : 1,
      ...req.body,
      category: req.body.category || 'lunch',
      price: req.body.price || 0,
      calories: req.body.calories || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    meals.push(meal);
    emitEvent('advanced-restaurant:updated', {
      action: 'create',
      entityType: 'meal',
      entityId: meal.id,
      data: meal,
    });
    res.json({ success: true, data: meal });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/orders', async (req, res) => {
  try {
    const { status, customerId } = req.query;
    let filtered = orders;
    if (status) filtered = filtered.filter(o => o.status === status);
    if (customerId) filtered = filtered.filter(o => o.customerId === parseInt(customerId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/orders', async (req, res) => {
  try {
    const order = {
      id: orders.length > 0 ? Math.max(...orders.map(o => o.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'pending',
      itemsCount: req.body.itemsCount || 0,
      total: req.body.total || 0,
      orderDate: req.body.orderDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    orders.push(order);
    emitEvent('advanced-restaurant:updated', {
      action: 'create',
      entityType: 'order',
      entityId: order.id,
      data: order,
    });
    res.json({ success: true, data: order });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/ingredients', async (req, res) => {
  try {
    const { supplierId } = req.query;
    let filtered = ingredients;
    if (supplierId) filtered = filtered.filter(i => i.supplierId === parseInt(supplierId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/ingredients', async (req, res) => {
  try {
    const ingredient = {
      id: ingredients.length > 0 ? Math.max(...ingredients.map(i => i.id)) + 1 : 1,
      ...req.body,
      stock: req.body.stock || 0,
      unit: req.body.unit || 'كجم',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    ingredients.push(ingredient);
    emitEvent('advanced-restaurant:updated', {
      action: 'create',
      entityType: 'ingredient',
      entityId: ingredient.id,
      data: ingredient,
    });
    res.json({ success: true, data: ingredient });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/suppliers', async (req, res) => {
  try {
    const { status } = req.query;
    let filtered = suppliers;
    if (status) filtered = filtered.filter(s => s.status === status);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/suppliers', async (req, res) => {
  try {
    const supplier = {
      id: suppliers.length > 0 ? Math.max(...suppliers.map(s => s.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    suppliers.push(supplier);
    emitEvent('advanced-restaurant:updated', {
      action: 'create',
      entityType: 'supplier',
      entityId: supplier.id,
      data: supplier,
    });
    res.json({ success: true, data: supplier });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/diet-plans', async (req, res) => {
  try {
    const { status, type } = req.query;
    let filtered = dietPlans;
    if (status) filtered = filtered.filter(d => d.status === status);
    if (type) filtered = filtered.filter(d => d.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/diet-plans', async (req, res) => {
  try {
    const plan = {
      id: dietPlans.length > 0 ? Math.max(...dietPlans.map(d => d.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      mealsCount: req.body.mealsCount || 0,
      dailyCalories: req.body.dailyCalories || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    dietPlans.push(plan);
    emitEvent('advanced-restaurant:updated', {
      action: 'create',
      entityType: 'dietPlan',
      entityId: plan.id,
      data: plan,
    });
    res.json({ success: true, data: plan });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/analytics', async (req, res) => {
  try {
    const totalMenus = menus.length;
    const activeMenus = menus.filter(m => m.status === 'active').length;
    const totalMeals = meals.length;
    const totalOrders = orders.length;
    const completedOrders = orders.filter(o => o.status === 'completed').length;
    const totalIngredients = ingredients.length;
    const lowStockIngredients = ingredients.filter(i => i.stock < 10).length;
    const totalSuppliers = suppliers.length;
    const activeSuppliers = suppliers.filter(s => s.status === 'active').length;
    const totalDietPlans = dietPlans.length;
    const activeDietPlans = dietPlans.filter(d => d.status === 'active').length;
    const totalRevenue = orders
      .filter(o => o.status === 'completed')
      .reduce((sum, o) => sum + (o.total || 0), 0);
    const averageOrderValue = completedOrders > 0 ? (totalRevenue / completedOrders).toFixed(2) : 0;

    const analyticsData = [
      {
        id: 1,
        metric: 'إجمالي القوائم',
        value: totalMenus,
        description: 'عدد القوائم الكلي',
      },
      {
        id: 2,
        metric: 'القوائم النشطة',
        value: activeMenus,
        description: 'عدد القوائم النشطة',
      },
      {
        id: 3,
        metric: 'إجمالي الوجبات',
        value: totalMeals,
        description: 'عدد الوجبات الكلي',
      },
      {
        id: 4,
        metric: 'إجمالي الطلبات',
        value: totalOrders,
        description: 'عدد الطلبات الكلي',
      },
      {
        id: 5,
        metric: 'الطلبات المكتملة',
        value: completedOrders,
        description: 'عدد الطلبات المكتملة',
      },
      {
        id: 6,
        metric: 'إجمالي المكونات',
        value: totalIngredients,
        description: 'عدد المكونات الكلي',
      },
      {
        id: 7,
        metric: 'المكونات قليلة المخزون',
        value: lowStockIngredients,
        description: 'عدد المكونات قليلة المخزون',
      },
      {
        id: 8,
        metric: 'إجمالي الموردين',
        value: totalSuppliers,
        description: 'عدد الموردين الكلي',
      },
      {
        id: 9,
        metric: 'الموردين النشطين',
        value: activeSuppliers,
        description: 'عدد الموردين النشطين',
      },
      {
        id: 10,
        metric: 'إجمالي الخطط الغذائية',
        value: totalDietPlans,
        description: 'عدد الخطط الغذائية الكلي',
      },
      {
        id: 11,
        metric: 'الخطط الغذائية النشطة',
        value: activeDietPlans,
        description: 'عدد الخطط الغذائية النشطة',
      },
      {
        id: 12,
        metric: 'إجمالي الإيرادات',
        value: `${totalRevenue.toLocaleString()} ريال`,
        description: 'إجمالي الإيرادات من الطلبات المكتملة',
      },
      {
        id: 13,
        metric: 'متوسط قيمة الطلب',
        value: `${averageOrderValue} ريال`,
        description: 'متوسط قيمة الطلب',
      },
    ];

    res.json({ success: true, data: analyticsData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
module.exports.setIO = setIO;
