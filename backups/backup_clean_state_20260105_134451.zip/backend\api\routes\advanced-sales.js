/**
 * 💰 Advanced Sales Management Routes
 */

const express = require('express');
const router = express.Router();

const leads = [];
const opportunities = [];
const quotes = [];
const orders = [];
const invoices = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/leads', async (req, res) => {
  try {
    const { status, source } = req.query;
    let filtered = leads;
    if (status) filtered = filtered.filter(l => l.status === status);
    if (source) filtered = filtered.filter(l => l.source === source);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/leads', async (req, res) => {
  try {
    const lead = {
      id: leads.length > 0 ? Math.max(...leads.map(l => l.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'new',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    leads.push(lead);
    emitEvent('advanced-sales:updated', {
      action: 'create',
      entityType: 'lead',
      entityId: lead.id,
      data: lead,
    });
    res.json({ success: true, data: lead });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/opportunities', async (req, res) => {
  try {
    const { stage, status } = req.query;
    let filtered = opportunities;
    if (stage) filtered = filtered.filter(o => o.stage === stage);
    if (status) filtered = filtered.filter(o => o.status === status);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/opportunities', async (req, res) => {
  try {
    const opportunity = {
      id: opportunities.length > 0 ? Math.max(...opportunities.map(o => o.id)) + 1 : 1,
      ...req.body,
      stage: req.body.stage || 'prospecting',
      amount: req.body.amount || 0,
      probability: req.body.probability || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    opportunities.push(opportunity);
    emitEvent('advanced-sales:updated', {
      action: 'create',
      entityType: 'opportunity',
      entityId: opportunity.id,
      data: opportunity,
    });
    res.json({ success: true, data: opportunity });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/quotes', async (req, res) => {
  try {
    const { status } = req.query;
    let filtered = quotes;
    if (status) filtered = filtered.filter(q => q.status === status);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/quotes', async (req, res) => {
  try {
    const quote = {
      id: quotes.length > 0 ? Math.max(...quotes.map(q => q.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'draft',
      total: req.body.total || 0,
      quoteDate: req.body.quoteDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    quotes.push(quote);
    emitEvent('advanced-sales:updated', {
      action: 'create',
      entityType: 'quote',
      entityId: quote.id,
      data: quote,
    });
    res.json({ success: true, data: quote });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/orders', async (req, res) => {
  try {
    const { status } = req.query;
    let filtered = orders;
    if (status) filtered = filtered.filter(o => o.status === status);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/orders', async (req, res) => {
  try {
    const order = {
      id: orders.length > 0 ? Math.max(...orders.map(o => o.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'pending',
      total: req.body.total || 0,
      orderDate: req.body.orderDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    orders.push(order);
    emitEvent('advanced-sales:updated', {
      action: 'create',
      entityType: 'order',
      entityId: order.id,
      data: order,
    });
    res.json({ success: true, data: order });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/invoices', async (req, res) => {
  try {
    const { status } = req.query;
    let filtered = invoices;
    if (status) filtered = filtered.filter(i => i.status === status);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/invoices', async (req, res) => {
  try {
    const invoice = {
      id: invoices.length > 0 ? Math.max(...invoices.map(i => i.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'draft',
      amount: req.body.amount || 0,
      invoiceDate: req.body.invoiceDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    invoices.push(invoice);
    emitEvent('advanced-sales:updated', {
      action: 'create',
      entityType: 'invoice',
      entityId: invoice.id,
      data: invoice,
    });
    res.json({ success: true, data: invoice });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
module.exports.setIO = setIO;
