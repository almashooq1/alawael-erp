/**
 * 🔒 Advanced Security & Safety Management Routes
 */

const express = require('express');
const router = express.Router();

const incidents = [];
const risks = [];
const policies = [];
const trainings = [];
const equipment = [];
const inspections = [];
const analytics = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/incidents', async (req, res) => {
  try {
    const { status, severity, type } = req.query;
    let filtered = incidents;
    if (status) filtered = filtered.filter(i => i.status === status);
    if (severity) filtered = filtered.filter(i => i.severity === severity);
    if (type) filtered = filtered.filter(i => i.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/incidents', async (req, res) => {
  try {
    const incident = {
      id: incidents.length > 0 ? Math.max(...incidents.map(i => i.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'reported',
      severity: req.body.severity || 'medium',
      occurredAt: req.body.occurredAt || new Date().toISOString(),
      injuriesCount: req.body.injuriesCount || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    incidents.push(incident);
    emitEvent('advanced-security:updated', {
      action: 'create',
      entityType: 'incident',
      entityId: incident.id,
      data: incident,
    });
    res.json({ success: true, data: incident });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/incidents/:id/investigate', async (req, res) => {
  try {
    const index = incidents.findIndex(i => i.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Incident not found' });
    }
    incidents[index].status = 'investigating';
    incidents[index].investigatedAt = new Date().toISOString();
    incidents[index].investigator = req.body.investigator || 'غير محدد';
    emitEvent('advanced-security:updated', {
      action: 'update',
      entityType: 'incident',
      entityId: incidents[index].id,
      data: incidents[index],
    });
    res.json({ success: true, data: incidents[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/incidents/:id/resolve', async (req, res) => {
  try {
    const index = incidents.findIndex(i => i.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Incident not found' });
    }
    incidents[index].status = 'resolved';
    incidents[index].resolvedAt = new Date().toISOString();
    incidents[index].resolution = req.body.resolution || 'غير محدد';
    emitEvent('advanced-security:updated', {
      action: 'update',
      entityType: 'incident',
      entityId: incidents[index].id,
      data: incidents[index],
    });
    res.json({ success: true, data: incidents[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/risks', async (req, res) => {
  try {
    const { severity, status } = req.query;
    let filtered = risks;
    if (severity) filtered = filtered.filter(r => r.severity === severity);
    if (status) filtered = filtered.filter(r => r.status === status);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/risks', async (req, res) => {
  try {
    const risk = {
      id: risks.length > 0 ? Math.max(...risks.map(r => r.id)) + 1 : 1,
      ...req.body,
      severity: req.body.severity || 'medium',
      status: req.body.status || 'active',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    risks.push(risk);
    emitEvent('advanced-security:updated', {
      action: 'create',
      entityType: 'risk',
      entityId: risk.id,
      data: risk,
    });
    res.json({ success: true, data: risk });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/policies', async (req, res) => {
  try {
    const { status, type } = req.query;
    let filtered = policies;
    if (status) filtered = filtered.filter(p => p.status === status);
    if (type) filtered = filtered.filter(p => p.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/policies', async (req, res) => {
  try {
    const policy = {
      id: policies.length > 0 ? Math.max(...policies.map(p => p.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      version: req.body.version || '1.0',
      issueDate: req.body.issueDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    policies.push(policy);
    emitEvent('advanced-security:updated', {
      action: 'create',
      entityType: 'policy',
      entityId: policy.id,
      data: policy,
    });
    res.json({ success: true, data: policy });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/trainings', async (req, res) => {
  try {
    const { status, type } = req.query;
    let filtered = trainings;
    if (status) filtered = filtered.filter(t => t.status === status);
    if (type) filtered = filtered.filter(t => t.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/trainings', async (req, res) => {
  try {
    const training = {
      id: trainings.length > 0 ? Math.max(...trainings.map(t => t.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'scheduled',
      type: req.body.type || 'general',
      participantsCount: req.body.participantsCount || 0,
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    trainings.push(training);
    emitEvent('advanced-security:updated', {
      action: 'create',
      entityType: 'training',
      entityId: training.id,
      data: training,
    });
    res.json({ success: true, data: training });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/equipment', async (req, res) => {
  try {
    const { status, type } = req.query;
    let filtered = equipment;
    if (status) filtered = filtered.filter(e => e.status === status);
    if (type) filtered = filtered.filter(e => e.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/equipment', async (req, res) => {
  try {
    const eq = {
      id: equipment.length > 0 ? Math.max(...equipment.map(e => e.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    equipment.push(eq);
    emitEvent('advanced-security:updated', {
      action: 'create',
      entityType: 'equipment',
      entityId: eq.id,
      data: eq,
    });
    res.json({ success: true, data: eq });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/inspections', async (req, res) => {
  try {
    const { status, type } = req.query;
    let filtered = inspections;
    if (status) filtered = filtered.filter(i => i.status === status);
    if (type) filtered = filtered.filter(i => i.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/inspections', async (req, res) => {
  try {
    const inspection = {
      id: inspections.length > 0 ? Math.max(...inspections.map(i => i.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'scheduled',
      type: req.body.type || 'routine',
      inspectionDate: req.body.inspectionDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    inspections.push(inspection);
    emitEvent('advanced-security:updated', {
      action: 'create',
      entityType: 'inspection',
      entityId: inspection.id,
      data: inspection,
    });
    res.json({ success: true, data: inspection });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/analytics', async (req, res) => {
  try {
    const totalIncidents = incidents.length;
    const reportedIncidents = incidents.filter(i => i.status === 'reported').length;
    const investigatingIncidents = incidents.filter(i => i.status === 'investigating').length;
    const resolvedIncidents = incidents.filter(i => i.status === 'resolved').length;
    const totalRisks = risks.length;
    const activeRisks = risks.filter(r => r.status === 'active').length;
    const totalPolicies = policies.length;
    const activePolicies = policies.filter(p => p.status === 'active').length;
    const totalTrainings = trainings.length;
    const completedTrainings = trainings.filter(t => t.status === 'completed').length;
    const totalEquipment = equipment.length;
    const activeEquipment = equipment.filter(e => e.status === 'active').length;
    const totalInspections = inspections.length;
    const completedInspections = inspections.filter(i => i.status === 'completed').length;

    const analyticsData = [
      {
        id: 1,
        metric: 'إجمالي الحوادث',
        value: totalIncidents,
        description: 'عدد الحوادث الكلي',
      },
      {
        id: 2,
        metric: 'الحوادث المبلغ عنها',
        value: reportedIncidents,
        description: 'عدد الحوادث المبلغ عنها',
      },
      {
        id: 3,
        metric: 'الحوادث قيد التحقيق',
        value: investigatingIncidents,
        description: 'عدد الحوادث قيد التحقيق',
      },
      {
        id: 4,
        metric: 'الحوادث المحلولة',
        value: resolvedIncidents,
        description: 'عدد الحوادث المحلولة',
      },
      {
        id: 5,
        metric: 'إجمالي المخاطر',
        value: totalRisks,
        description: 'عدد المخاطر الكلي',
      },
      {
        id: 6,
        metric: 'المخاطر النشطة',
        value: activeRisks,
        description: 'عدد المخاطر النشطة',
      },
      {
        id: 7,
        metric: 'إجمالي السياسات',
        value: totalPolicies,
        description: 'عدد السياسات الكلي',
      },
      {
        id: 8,
        metric: 'السياسات النشطة',
        value: activePolicies,
        description: 'عدد السياسات النشطة',
      },
      {
        id: 9,
        metric: 'إجمالي التدريبات',
        value: totalTrainings,
        description: 'عدد التدريبات الكلي',
      },
      {
        id: 10,
        metric: 'التدريبات المكتملة',
        value: completedTrainings,
        description: 'عدد التدريبات المكتملة',
      },
      {
        id: 11,
        metric: 'إجمالي المعدات',
        value: totalEquipment,
        description: 'عدد المعدات الكلي',
      },
      {
        id: 12,
        metric: 'المعدات النشطة',
        value: activeEquipment,
        description: 'عدد المعدات النشطة',
      },
      {
        id: 13,
        metric: 'إجمالي التفتيشات',
        value: totalInspections,
        description: 'عدد التفتيشات الكلي',
      },
      {
        id: 14,
        metric: 'التفتيشات المكتملة',
        value: completedInspections,
        description: 'عدد التفتيشات المكتملة',
      },
    ];

    res.json({ success: true, data: analyticsData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
module.exports.setIO = setIO;
