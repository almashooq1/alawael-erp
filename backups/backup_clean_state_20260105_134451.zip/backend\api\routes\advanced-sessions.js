/**
 * 🎯 Advanced Sessions Management Routes
 */

const express = require('express');
const router = express.Router();

const sessions = [];
const schedules = [];
const attendance = [];
const notes = [];
const progress = [];
const goals = [];
const activities = [];
const materials = [];
const analytics = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/sessions', async (req, res) => {
  try {
    const { status, type, therapistId, patientId } = req.query;
    let filtered = sessions;
    if (status) filtered = filtered.filter(s => s.status === status);
    if (type) filtered = filtered.filter(s => s.type === type);
    if (therapistId) filtered = filtered.filter(s => s.therapistId === parseInt(therapistId));
    if (patientId) filtered = filtered.filter(s => s.patientId === parseInt(patientId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/sessions', async (req, res) => {
  try {
    const session = {
      id: sessions.length > 0 ? Math.max(...sessions.map(s => s.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'scheduled',
      type: req.body.type || 'individual',
      dateTime: req.body.dateTime || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    sessions.push(session);
    emitEvent('advanced-sessions:updated', {
      action: 'create',
      entityType: 'session',
      entityId: session.id,
      data: session,
    });
    res.json({ success: true, data: session });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/sessions/:id/start', async (req, res) => {
  try {
    const index = sessions.findIndex(s => s.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Session not found' });
    }
    sessions[index].status = 'in-progress';
    sessions[index].startTime = new Date().toISOString();
    emitEvent('advanced-sessions:updated', {
      action: 'update',
      entityType: 'session',
      entityId: sessions[index].id,
      data: sessions[index],
    });
    res.json({ success: true, data: sessions[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/sessions/:id/end', async (req, res) => {
  try {
    const index = sessions.findIndex(s => s.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Session not found' });
    }
    sessions[index].status = 'completed';
    sessions[index].endTime = new Date().toISOString();
    emitEvent('advanced-sessions:updated', {
      action: 'update',
      entityType: 'session',
      entityId: sessions[index].id,
      data: sessions[index],
    });
    res.json({ success: true, data: sessions[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/schedules', async (req, res) => {
  try {
    const { date, therapistId, patientId } = req.query;
    let filtered = schedules;
    if (date) filtered = filtered.filter(s => s.dateTime?.startsWith(date));
    if (therapistId) filtered = filtered.filter(s => s.therapistId === parseInt(therapistId));
    if (patientId) filtered = filtered.filter(s => s.patientId === parseInt(patientId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/schedules', async (req, res) => {
  try {
    const schedule = {
      id: schedules.length > 0 ? Math.max(...schedules.map(s => s.id)) + 1 : 1,
      ...req.body,
      dateTime: req.body.dateTime || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    schedules.push(schedule);
    emitEvent('advanced-sessions:updated', {
      action: 'create',
      entityType: 'schedule',
      entityId: schedule.id,
      data: schedule,
    });
    res.json({ success: true, data: schedule });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/attendance', async (req, res) => {
  try {
    const { sessionId, patientId, date } = req.query;
    let filtered = attendance;
    if (sessionId) filtered = filtered.filter(a => a.sessionId === parseInt(sessionId));
    if (patientId) filtered = filtered.filter(a => a.patientId === parseInt(patientId));
    if (date) filtered = filtered.filter(a => a.date === date);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/attendance', async (req, res) => {
  try {
    const record = {
      id: attendance.length > 0 ? Math.max(...attendance.map(a => a.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'present',
      date: req.body.date || new Date().toISOString(),
      checkInTime: req.body.checkInTime || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    attendance.push(record);
    emitEvent('advanced-sessions:updated', {
      action: 'create',
      entityType: 'attendance',
      entityId: record.id,
      data: record,
    });
    res.json({ success: true, data: record });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/notes', async (req, res) => {
  try {
    const { sessionId, therapistId, patientId } = req.query;
    let filtered = notes;
    if (sessionId) filtered = filtered.filter(n => n.sessionId === parseInt(sessionId));
    if (therapistId) filtered = filtered.filter(n => n.therapistId === parseInt(therapistId));
    if (patientId) filtered = filtered.filter(n => n.patientId === parseInt(patientId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/notes', async (req, res) => {
  try {
    const note = {
      id: notes.length > 0 ? Math.max(...notes.map(n => n.id)) + 1 : 1,
      ...req.body,
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    notes.push(note);
    emitEvent('advanced-sessions:updated', {
      action: 'create',
      entityType: 'note',
      entityId: note.id,
      data: note,
    });
    res.json({ success: true, data: note });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/progress', async (req, res) => {
  try {
    const { patientId, period } = req.query;
    let filtered = progress;
    if (patientId) filtered = filtered.filter(p => p.patientId === parseInt(patientId));
    if (period) filtered = filtered.filter(p => p.period === period);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/progress', async (req, res) => {
  try {
    const progressData = {
      id: progress.length > 0 ? Math.max(...progress.map(p => p.id)) + 1 : 1,
      ...req.body,
      completedSessions: req.body.completedSessions || 0,
      attendanceRate: req.body.attendanceRate || 0,
      improvement: req.body.improvement || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    progress.push(progressData);
    emitEvent('advanced-sessions:updated', {
      action: 'create',
      entityType: 'progress',
      entityId: progressData.id,
      data: progressData,
    });
    res.json({ success: true, data: progressData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/goals', async (req, res) => {
  try {
    const { patientId, completed, priority } = req.query;
    let filtered = goals;
    if (patientId) filtered = filtered.filter(g => g.patientId === parseInt(patientId));
    if (completed !== undefined)
      filtered = filtered.filter(g => g.completed === (completed === 'true'));
    if (priority) filtered = filtered.filter(g => g.priority === priority);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/goals', async (req, res) => {
  try {
    const goal = {
      id: goals.length > 0 ? Math.max(...goals.map(g => g.id)) + 1 : 1,
      ...req.body,
      completed: req.body.completed || false,
      progress: req.body.progress || 0,
      priority: req.body.priority || 'medium',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    goals.push(goal);
    emitEvent('advanced-sessions:updated', {
      action: 'create',
      entityType: 'goal',
      entityId: goal.id,
      data: goal,
    });
    res.json({ success: true, data: goal });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/activities', async (req, res) => {
  try {
    const { category, level } = req.query;
    let filtered = activities;
    if (category) filtered = filtered.filter(a => a.category === category);
    if (level) filtered = filtered.filter(a => a.level === level);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/activities', async (req, res) => {
  try {
    const activity = {
      id: activities.length > 0 ? Math.max(...activities.map(a => a.id)) + 1 : 1,
      ...req.body,
      category: req.body.category || 'general',
      level: req.body.level || 'beginner',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    activities.push(activity);
    emitEvent('advanced-sessions:updated', {
      action: 'create',
      entityType: 'activity',
      entityId: activity.id,
      data: activity,
    });
    res.json({ success: true, data: activity });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/materials', async (req, res) => {
  try {
    const { type, status } = req.query;
    let filtered = materials;
    if (type) filtered = filtered.filter(m => m.type === type);
    if (status) filtered = filtered.filter(m => m.status === status);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/materials', async (req, res) => {
  try {
    const material = {
      id: materials.length > 0 ? Math.max(...materials.map(m => m.id)) + 1 : 1,
      ...req.body,
      quantity: req.body.quantity || 0,
      status: req.body.status || 'available',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    materials.push(material);
    emitEvent('advanced-sessions:updated', {
      action: 'create',
      entityType: 'material',
      entityId: material.id,
      data: material,
    });
    res.json({ success: true, data: material });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/analytics', async (req, res) => {
  try {
    const totalSessions = sessions.length;
    const completedSessions = sessions.filter(s => s.status === 'completed').length;
    const inProgressSessions = sessions.filter(s => s.status === 'in-progress').length;
    const scheduledSessions = sessions.filter(s => s.status === 'scheduled').length;
    const totalAttendance = attendance.length;
    const presentAttendance = attendance.filter(a => a.status === 'present').length;
    const attendanceRate =
      totalAttendance > 0 ? Math.round((presentAttendance / totalAttendance) * 100) : 0;

    const analyticsData = [
      {
        id: 1,
        metric: 'إجمالي الجلسات',
        value: totalSessions,
        description: 'عدد الجلسات الكلي',
        trend: null,
      },
      {
        id: 2,
        metric: 'الجلسات المكتملة',
        value: completedSessions,
        description: 'عدد الجلسات المكتملة',
        trend: null,
      },
      {
        id: 3,
        metric: 'الجلسات قيد التنفيذ',
        value: inProgressSessions,
        description: 'عدد الجلسات قيد التنفيذ',
        trend: null,
      },
      {
        id: 4,
        metric: 'الجلسات المجدولة',
        value: scheduledSessions,
        description: 'عدد الجلسات المجدولة',
        trend: null,
      },
      {
        id: 5,
        metric: 'معدل الحضور',
        value: `${attendanceRate}%`,
        description: 'نسبة الحضور',
        trend: null,
      },
      {
        id: 6,
        metric: 'إجمالي الحضور',
        value: totalAttendance,
        description: 'عدد سجلات الحضور',
        trend: null,
      },
    ];

    res.json({ success: true, data: analyticsData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
module.exports.setIO = setIO;
