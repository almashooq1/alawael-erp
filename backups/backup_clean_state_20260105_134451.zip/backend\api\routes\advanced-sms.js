/**
 * 📱 Advanced SMS Management Routes
 */

const express = require('express');
const router = express.Router();

const accounts = [];
const messages = [];
const templates = [];
const campaigns = [];
const contacts = [];
const groups = [];
const autoReplies = [];
const schedules = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/accounts', async (req, res) => {
  try {
    res.json({ success: true, data: accounts });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/accounts', async (req, res) => {
  try {
    const account = {
      id: accounts.length > 0 ? Math.max(...accounts.map(a => a.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      balance: req.body.balance || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    accounts.push(account);
    emitEvent('advanced-sms:updated', {
      action: 'create',
      entityType: 'account',
      entityId: account.id,
      data: account,
    });
    res.json({ success: true, data: account });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/messages', async (req, res) => {
  try {
    const { accountId, status, type } = req.query;
    let filtered = messages;
    if (accountId) filtered = filtered.filter(m => m.accountId === parseInt(accountId));
    if (status) filtered = filtered.filter(m => m.status === status);
    if (type) filtered = filtered.filter(m => m.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/messages', async (req, res) => {
  try {
    const message = {
      id: messages.length > 0 ? Math.max(...messages.map(m => m.id)) + 1 : 1,
      ...req.body,
      type: req.body.type || 'outbound',
      status: req.body.status || 'pending',
      timestamp: req.body.timestamp || new Date().toISOString(),
      parts: req.body.parts || 1,
      cost: req.body.cost || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    messages.push(message);
    emitEvent('advanced-sms:updated', {
      action: 'create',
      entityType: 'message',
      entityId: message.id,
      data: message,
    });
    res.json({ success: true, data: message });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/templates', async (req, res) => {
  try {
    const { category } = req.query;
    let filtered = templates;
    if (category) filtered = filtered.filter(t => t.category === category);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/templates', async (req, res) => {
  try {
    const template = {
      id: templates.length > 0 ? Math.max(...templates.map(t => t.id)) + 1 : 1,
      ...req.body,
      category: req.body.category || 'general',
      length: req.body.content?.length || 0,
      parts: Math.ceil((req.body.content?.length || 0) / 160),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    templates.push(template);
    emitEvent('advanced-sms:updated', {
      action: 'create',
      entityType: 'template',
      entityId: template.id,
      data: template,
    });
    res.json({ success: true, data: template });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/campaigns', async (req, res) => {
  try {
    const { status } = req.query;
    let filtered = campaigns;
    if (status) filtered = filtered.filter(c => c.status === status);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/campaigns', async (req, res) => {
  try {
    const campaign = {
      id: campaigns.length > 0 ? Math.max(...campaigns.map(c => c.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      recipientsCount: req.body.recipientsCount || 0,
      sentCount: 0,
      deliveredCount: 0,
      failedCount: 0,
      progress: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    campaigns.push(campaign);
    emitEvent('advanced-sms:updated', {
      action: 'create',
      entityType: 'campaign',
      entityId: campaign.id,
      data: campaign,
    });
    res.json({ success: true, data: campaign });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/contacts', async (req, res) => {
  try {
    res.json({ success: true, data: contacts });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/contacts', async (req, res) => {
  try {
    const contact = {
      id: contacts.length > 0 ? Math.max(...contacts.map(c => c.id)) + 1 : 1,
      ...req.body,
      messagesCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    contacts.push(contact);
    emitEvent('advanced-sms:updated', {
      action: 'create',
      entityType: 'contact',
      entityId: contact.id,
      data: contact,
    });
    res.json({ success: true, data: contact });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/groups', async (req, res) => {
  try {
    res.json({ success: true, data: groups });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/groups', async (req, res) => {
  try {
    const group = {
      id: groups.length > 0 ? Math.max(...groups.map(g => g.id)) + 1 : 1,
      ...req.body,
      membersCount: req.body.membersCount || 0,
      messagesCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    groups.push(group);
    emitEvent('advanced-sms:updated', {
      action: 'create',
      entityType: 'group',
      entityId: group.id,
      data: group,
    });
    res.json({ success: true, data: group });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/auto-replies', async (req, res) => {
  try {
    const { enabled } = req.query;
    let filtered = autoReplies;
    if (enabled !== undefined) filtered = filtered.filter(r => r.enabled === (enabled === 'true'));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/auto-replies', async (req, res) => {
  try {
    const autoReply = {
      id: autoReplies.length > 0 ? Math.max(...autoReplies.map(r => r.id)) + 1 : 1,
      ...req.body,
      enabled: req.body.enabled !== undefined ? req.body.enabled : true,
      keywords: req.body.keywords || [],
      usageCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    autoReplies.push(autoReply);
    emitEvent('advanced-sms:updated', {
      action: 'create',
      entityType: 'autoReply',
      entityId: autoReply.id,
      data: autoReply,
    });
    res.json({ success: true, data: autoReply });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/auto-replies/:id/toggle', async (req, res) => {
  try {
    const index = autoReplies.findIndex(r => r.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Auto reply not found' });
    }
    autoReplies[index].enabled = !autoReplies[index].enabled;
    emitEvent('advanced-sms:updated', {
      action: 'update',
      entityType: 'autoReply',
      entityId: autoReplies[index].id,
      data: autoReplies[index],
    });
    res.json({ success: true, data: autoReplies[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/schedules', async (req, res) => {
  try {
    const { status } = req.query;
    let filtered = schedules;
    if (status) filtered = filtered.filter(s => s.status === status);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/schedules', async (req, res) => {
  try {
    const schedule = {
      id: schedules.length > 0 ? Math.max(...schedules.map(s => s.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'pending',
      scheduledAt: req.body.scheduledAt || new Date().toISOString(),
      recipientsCount: req.body.recipientsCount || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    schedules.push(schedule);
    emitEvent('advanced-sms:updated', {
      action: 'create',
      entityType: 'schedule',
      entityId: schedule.id,
      data: schedule,
    });
    res.json({ success: true, data: schedule });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/schedules/:id/execute', async (req, res) => {
  try {
    const index = schedules.findIndex(s => s.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Schedule not found' });
    }
    schedules[index].status = 'executed';
    schedules[index].executedAt = new Date().toISOString();
    emitEvent('advanced-sms:updated', {
      action: 'update',
      entityType: 'schedule',
      entityId: schedules[index].id,
      data: schedules[index],
    });
    res.json({ success: true, data: schedules[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/analytics', async (req, res) => {
  try {
    const totalMessages = messages.length;
    const sentMessages = messages.filter(m => m.type === 'outbound').length;
    const receivedMessages = messages.filter(m => m.type === 'inbound').length;
    const deliveredMessages = messages.filter(m => m.status === 'delivered').length;
    const failedMessages = messages.filter(m => m.status === 'failed').length;
    const totalCost = messages.reduce((sum, m) => sum + (m.cost || 0), 0);
    const activeCampaigns = campaigns.filter(c => c.status === 'active').length;

    const analyticsData = [
      {
        id: 1,
        metric: 'إجمالي الرسائل',
        value: totalMessages,
        description: 'عدد الرسائل الكلي',
        trend: null,
      },
      {
        id: 2,
        metric: 'الرسائل المرسلة',
        value: sentMessages,
        description: 'عدد الرسائل المرسلة',
        trend: null,
      },
      {
        id: 3,
        metric: 'الرسائل المستلمة',
        value: receivedMessages,
        description: 'عدد الرسائل المستلمة',
        trend: null,
      },
      {
        id: 4,
        metric: 'معدل التسليم',
        value: sentMessages > 0 ? Math.round((deliveredMessages / sentMessages) * 100) : 0,
        description: 'نسبة الرسائل المستلمة',
        trend: null,
      },
      {
        id: 5,
        metric: 'معدل الفشل',
        value: sentMessages > 0 ? Math.round((failedMessages / sentMessages) * 100) : 0,
        description: 'نسبة الرسائل الفاشلة',
        trend: null,
      },
      {
        id: 6,
        metric: 'التكلفة الإجمالية',
        value: `${totalCost.toFixed(2)} ر.س`,
        description: 'إجمالي تكلفة الرسائل',
        trend: null,
      },
      {
        id: 7,
        metric: 'الحملات النشطة',
        value: activeCampaigns,
        description: 'عدد الحملات النشطة',
        trend: null,
      },
    ];

    res.json({ success: true, data: analyticsData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
