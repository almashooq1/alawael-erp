/**
 * 🎓 Advanced Training Management Routes
 */

const express = require('express');
const router = express.Router();

const programs = [];
const courses = [];
const participants = [];
const sessions = [];
const certificates = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/programs', async (req, res) => {
  try {
    const { status, type } = req.query;
    let filtered = programs;
    if (status) filtered = filtered.filter(p => p.status === status);
    if (type) filtered = filtered.filter(p => p.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/programs', async (req, res) => {
  try {
    const program = {
      id: programs.length > 0 ? Math.max(...programs.map(p => p.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'upcoming',
      participantsCount: 0,
      startDate: req.body.startDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    programs.push(program);
    emitEvent('advanced-training-management:updated', {
      action: 'create',
      entityType: 'program',
      entityId: program.id,
      data: program,
    });
    res.json({ success: true, data: program });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/courses', async (req, res) => {
  try {
    const { status, type } = req.query;
    let filtered = courses;
    if (status) filtered = filtered.filter(c => c.status === status);
    if (type) filtered = filtered.filter(c => c.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/courses', async (req, res) => {
  try {
    const course = {
      id: courses.length > 0 ? Math.max(...courses.map(c => c.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'upcoming',
      participantsCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    courses.push(course);
    emitEvent('advanced-training-management:updated', {
      action: 'create',
      entityType: 'course',
      entityId: course.id,
      data: course,
    });
    res.json({ success: true, data: course });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/participants', async (req, res) => {
  try {
    const { courseId, status } = req.query;
    let filtered = participants;
    if (courseId) filtered = filtered.filter(p => p.courseId === parseInt(courseId));
    if (status) filtered = filtered.filter(p => p.status === status);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/participants', async (req, res) => {
  try {
    const participant = {
      id: participants.length > 0 ? Math.max(...participants.map(p => p.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'enrolled',
      progress: req.body.progress || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    participants.push(participant);
    emitEvent('advanced-training-management:updated', {
      action: 'create',
      entityType: 'participant',
      entityId: participant.id,
      data: participant,
    });
    res.json({ success: true, data: participant });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/sessions', async (req, res) => {
  try {
    const { courseId, date } = req.query;
    let filtered = sessions;
    if (courseId) filtered = filtered.filter(s => s.courseId === parseInt(courseId));
    if (date) filtered = filtered.filter(s => s.date === date);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/sessions', async (req, res) => {
  try {
    const session = {
      id: sessions.length > 0 ? Math.max(...sessions.map(s => s.id)) + 1 : 1,
      ...req.body,
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    sessions.push(session);
    emitEvent('advanced-training-management:updated', {
      action: 'create',
      entityType: 'session',
      entityId: session.id,
      data: session,
    });
    res.json({ success: true, data: session });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/certificates', async (req, res) => {
  try {
    const { participantId, courseId } = req.query;
    let filtered = certificates;
    if (participantId) filtered = filtered.filter(c => c.participantId === parseInt(participantId));
    if (courseId) filtered = filtered.filter(c => c.courseId === parseInt(courseId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/certificates', async (req, res) => {
  try {
    const certificate = {
      id: certificates.length > 0 ? Math.max(...certificates.map(c => c.id)) + 1 : 1,
      ...req.body,
      serialNumber: req.body.serialNumber || `CERT-${Date.now()}`,
      issueDate: req.body.issueDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    certificates.push(certificate);
    emitEvent('advanced-training-management:updated', {
      action: 'create',
      entityType: 'certificate',
      entityId: certificate.id,
      data: certificate,
    });
    res.json({ success: true, data: certificate });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
