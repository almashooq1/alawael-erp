/**
 * 🎓 Advanced Training Routes
 * API routes for advanced training management system
 */

const express = require('express');
const router = express.Router();

// Mock data storage (replace with database)
const courses = [];
const sessions = [];
const participants = [];
const certificates = [];
const instructors = [];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Courses ====================

router.get('/courses', async (req, res) => {
  try {
    const { status, search } = req.query;
    let filtered = courses;

    if (status) {
      filtered = filtered.filter(c => c.status === status);
    }

    if (search) {
      const query = search.toLowerCase();
      filtered = filtered.filter(
        c =>
          c.title.toLowerCase().includes(query) ||
          (c.description && c.description.toLowerCase().includes(query))
      );
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/courses', async (req, res) => {
  try {
    const course = {
      id: courses.length > 0 ? Math.max(...courses.map(c => c.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      participantsCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    courses.push(course);

    emitEvent('training:course:updated', {
      action: 'create',
      entityId: course.id,
      data: course,
    });

    res.json({
      success: true,
      data: course,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.delete('/courses/:id', async (req, res) => {
  try {
    const index = courses.findIndex(c => c.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Course not found',
      });
    }

    courses.splice(index, 1);

    emitEvent('training:course:updated', {
      action: 'delete',
      entityId: parseInt(req.params.id),
    });

    res.json({
      success: true,
      message: 'Course deleted successfully',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Sessions ====================

router.get('/sessions', async (req, res) => {
  try {
    const { courseId, date } = req.query;
    let filtered = sessions;

    if (courseId) {
      filtered = filtered.filter(s => s.courseId === parseInt(courseId));
    }

    if (date) {
      filtered = filtered.filter(s => s.date === date);
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/sessions', async (req, res) => {
  try {
    const session = {
      id: sessions.length > 0 ? Math.max(...sessions.map(s => s.id)) + 1 : 1,
      ...req.body,
      participantsCount: 0,
      createdAt: new Date().toISOString(),
    };

    sessions.push(session);

    emitEvent('training:session:updated', {
      action: 'create',
      entityId: session.id,
      data: session,
    });

    res.json({
      success: true,
      data: session,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Participants ====================

router.get('/participants', async (req, res) => {
  try {
    const { courseId, status } = req.query;
    let filtered = participants;

    if (courseId) {
      filtered = filtered.filter(p => p.courseId === parseInt(courseId));
    }

    if (status) {
      filtered = filtered.filter(p => p.status === status);
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/participants', async (req, res) => {
  try {
    const participant = {
      id: participants.length > 0 ? Math.max(...participants.map(p => p.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'registered',
      createdAt: new Date().toISOString(),
    };

    participants.push(participant);

    // Update course participants count
    if (participant.courseId) {
      const course = courses.find(c => c.id === participant.courseId);
      if (course) {
        course.participantsCount = (course.participantsCount || 0) + 1;
      }
    }

    res.json({
      success: true,
      data: participant,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Certificates ====================

router.get('/certificates', async (req, res) => {
  try {
    const { courseId, participantId } = req.query;
    let filtered = certificates;

    if (courseId) {
      filtered = filtered.filter(c => c.courseId === parseInt(courseId));
    }

    if (participantId) {
      filtered = filtered.filter(c => c.participantId === parseInt(participantId));
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/certificates', async (req, res) => {
  try {
    const certificate = {
      id: certificates.length > 0 ? Math.max(...certificates.map(c => c.id)) + 1 : 1,
      ...req.body,
      issueDate: new Date().toISOString(),
    };

    certificates.push(certificate);

    res.json({
      success: true,
      data: certificate,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Instructors ====================

router.get('/instructors', async (req, res) => {
  try {
    res.json({
      success: true,
      data: instructors,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/instructors', async (req, res) => {
  try {
    const instructor = {
      id: instructors.length > 0 ? Math.max(...instructors.map(i => i.id)) + 1 : 1,
      ...req.body,
      coursesCount: 0,
      createdAt: new Date().toISOString(),
    };

    instructors.push(instructor);

    res.json({
      success: true,
      data: instructor,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

module.exports = { router, setIO };
