const express = require('express');
const router = express.Router();
const StudentTransportAssignment = require('../models/StudentTransportAssignment');
// Student Transport Assignment Endpoints
// Get all assignments (with optional filters)
router.get('/transport-assignments', async (req, res) => {
  try {
    const where = {};
    const { studentId, busId, routeId, driverId, status } = req.query;
    if (studentId) where.studentId = studentId;
    if (busId) where.busId = busId;
    if (routeId) where.routeId = routeId;
    if (driverId) where.driverId = driverId;
    if (status) where.status = status;
    const assignments = await StudentTransportAssignment.findAll({ where });
    res.json({ success: true, data: assignments });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Create new assignment
const Notification = require('../models/Notification');
const Parent = require('../models/Parent');
const User = require('../models/User');
router.post('/transport-assignments', async (req, res) => {
  try {
    const assignment = await StudentTransportAssignment.create(req.body);
    emitEvent('advanced-transportation:updated', {
      action: 'create',
      entityType: 'student-transport-assignment',
      entityId: assignment.id,
      data: assignment,
    });
    // Notify parent, driver, and admin
    try {
      // Notify parent (if studentId is available and parent exists)
      if (assignment.studentId) {
        // Find parent by studentId (assuming Parent.getStudents returns students for a parent, so we reverse lookup)
        // This is a placeholder; adapt to your actual parent-student relationship
        // You may need to query the student and get parentId/email
      }
      // Notify driver
      if (assignment.driverId) {
        await Notification.send({
          title: 'تم تعيين رحلة نقل جديدة',
          message: `تم تعيينك كسائق لطالب جديد (معرف الطالب: ${assignment.studentId}) على الحافلة ${assignment.busId}.`,
          recipientId: assignment.driverId,
          type: 'info',
          priority: 'normal',
          channel: 'in_app',
        });
      }
      // Notify admin (broadcast to all admins, or a specific adminId if available)
      // Example: send to admin with id 1
      await Notification.send({
        title: 'تم إنشاء تعيين نقل طالب',
        message: `تم تعيين نقل جديد للطالب ${assignment.studentId} على الحافلة ${assignment.busId}.`,
        recipientId: 1,
        type: 'info',
        priority: 'normal',
        channel: 'in_app',
      });
    } catch (notifyErr) {
      // Log notification errors but do not block main response
      console.error('Notification error:', notifyErr);
    }
    res.json({ success: true, data: assignment });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Update assignment
router.put('/transport-assignments/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const [updated] = await StudentTransportAssignment.update(req.body, { where: { id } });
    if (!updated) return res.status(404).json({ success: false, error: 'Assignment not found' });
    const assignment = await StudentTransportAssignment.findByPk(id);
    emitEvent('advanced-transportation:updated', {
      action: 'update',
      entityType: 'student-transport-assignment',
      entityId: assignment.id,
      data: assignment,
    });
    // Notify driver and admin about update
    try {
      if (assignment.driverId) {
        await Notification.send({
          title: 'تم تحديث تعيين النقل',
          message: `تم تحديث تفاصيل النقل للطالب ${assignment.studentId} على الحافلة ${assignment.busId}.`,
          recipientId: assignment.driverId,
          type: 'info',
          priority: 'normal',
          channel: 'in_app',
        });
      }
      await Notification.send({
        title: 'تم تحديث تعيين نقل طالب',
        message: `تم تحديث تعيين النقل للطالب ${assignment.studentId} على الحافلة ${assignment.busId}.`,
        recipientId: 1,
        type: 'info',
        priority: 'normal',
        channel: 'in_app',
      });
    } catch (notifyErr) {
      console.error('Notification error:', notifyErr);
    }
    res.json({ success: true, data: assignment });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Delete assignment
router.delete('/transport-assignments/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const assignment = await StudentTransportAssignment.findByPk(id);
    const deleted = await StudentTransportAssignment.destroy({ where: { id } });
    if (!deleted) return res.status(404).json({ success: false, error: 'Assignment not found' });
    emitEvent('advanced-transportation:updated', {
      action: 'delete',
      entityType: 'student-transport-assignment',
      entityId: id,
    });
    // Notify driver and admin about deletion
    try {
      if (assignment && assignment.driverId) {
        await Notification.send({
          title: 'تم حذف تعيين النقل',
          message: `تم حذف تعيين النقل للطالب ${assignment.studentId} من الحافلة ${assignment.busId}.`,
          recipientId: assignment.driverId,
          type: 'warning',
          priority: 'normal',
          channel: 'in_app',
        });
      }
      await Notification.send({
        title: 'تم حذف تعيين نقل طالب',
        message: `تم حذف تعيين النقل للطالب ${assignment ? assignment.studentId : ''} من الحافلة ${assignment ? assignment.busId : ''}.`,
        recipientId: 1,
        type: 'warning',
        priority: 'normal',
        channel: 'in_app',
      });
    } catch (notifyErr) {
      console.error('Notification error:', notifyErr);
    }
    res.json({ success: true, data: { id } });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});
/**
 * 🚌 Advanced Transportation Management Routes
 */

const Vehicle = require('../models/Vehicle');
const Driver = require('../models/Driver');
const RouteModel = require('../models/Route');
const { recommendTransportAssignment } = require('../transport/recommendation');

// توصية ذكية لأفضل وسيلة نقل
router.post('/transport/recommend', async (req, res) => {
  try {
    const { student } = req.body;
    // جلب جميع الحافلات والمسارات والسائقين الفعّالين
    const [buses, routes, drivers] = await Promise.all([
      Vehicle.findAll(),
      RouteModel.findAll(),
      Driver.findAll(),
    ]);
    // إضافة عدد الطلاب المخصصين لكل حافلة
    const assignments = await require('../models/StudentTransportAssignment').findAll();
    const busAssignedCount = {};
    assignments.forEach(a => {
      busAssignedCount[a.busId] = (busAssignedCount[a.busId] || 0) + 1;
    });
    const busesWithCount = buses.map(b => ({
      ...b.dataValues,
      assignedCount: busAssignedCount[b.id] || 0,
    }));
    // استدعاء خوارزمية التوصية
    const result = await recommendTransportAssignment({
      student,
      buses: busesWithCount,
      routes: routes.map(r => r.dataValues),
      drivers: drivers.map(d => d.dataValues),
    });
    res.json({ success: true, recommendation: result });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});
// let trips = [];
// let schedules = [];
// let maintenance = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// Sequelize-based Vehicle endpoints
router.get('/vehicles', async (req, res) => {
  try {
    const { status, type } = req.query;
    const where = {};
    if (status) where.status = status;
    if (type) where.type = type;
    const vehicles = await Vehicle.findAll({ where });
    res.json({ success: true, data: vehicles });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/vehicles', async (req, res) => {
  try {
    const vehicle = await Vehicle.create(req.body);
    emitEvent('advanced-transportation:updated', {
      action: 'create',
      entityType: 'vehicle',
      entityId: vehicle.id,
      data: vehicle,
    });
    res.json({ success: true, data: vehicle });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/routes', async (req, res) => {
  try {
    const { status } = req.query;
    const where = {};
    if (status) where.status = status;
    const routes = await RouteModel.findAll({ where });
    res.json({ success: true, data: routes });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/routes', async (req, res) => {
  try {
    const route = await RouteModel.create(req.body);
    emitEvent('advanced-transportation:updated', {
      action: 'create',
      entityType: 'route',
      entityId: route.id,
      data: route,
    });
    res.json({ success: true, data: route });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/trips', async (req, res) => {
  try {
    const { status, vehicleId, driverId } = req.query;
    let filtered = trips;
    if (status) filtered = filtered.filter(t => t.status === status);
    if (vehicleId) filtered = filtered.filter(t => t.vehicleId === parseInt(vehicleId));
    if (driverId) filtered = filtered.filter(t => t.driverId === parseInt(driverId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/trips', async (req, res) => {
  try {
    const trip = {
      id: trips.length > 0 ? Math.max(...trips.map(t => t.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'scheduled',
      passengersCount: req.body.passengersCount || 0,
      scheduledTime: req.body.scheduledTime || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    trips.push(trip);
    emitEvent('advanced-transportation:updated', {
      action: 'create',
      entityType: 'trip',
      entityId: trip.id,
      data: trip,
    });
    res.json({ success: true, data: trip });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/drivers', async (req, res) => {
  try {
    const { status } = req.query;
    const where = {};
    if (status) where.status = status;
    const drivers = await Driver.findAll({ where });
    res.json({ success: true, data: drivers });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/drivers', async (req, res) => {
  try {
    const driver = await Driver.create(req.body);
    emitEvent('advanced-transportation:updated', {
      action: 'create',
      entityType: 'driver',
      entityId: driver.id,
      data: driver,
    });
    res.json({ success: true, data: driver });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/schedules', async (req, res) => {
  try {
    const { status, day } = req.query;
    let filtered = schedules;
    if (status) filtered = filtered.filter(s => s.status === status);
    if (day) filtered = filtered.filter(s => s.day === day);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/schedules', async (req, res) => {
  try {
    const schedule = {
      id: schedules.length > 0 ? Math.max(...schedules.map(s => s.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    schedules.push(schedule);
    emitEvent('advanced-transportation:updated', {
      action: 'create',
      entityType: 'schedule',
      entityId: schedule.id,
      data: schedule,
    });
    res.json({ success: true, data: schedule });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/maintenance', async (req, res) => {
  try {
    const { status, vehicleId } = req.query;
    let filtered = maintenance;
    if (status) filtered = filtered.filter(m => m.status === status);
    if (vehicleId) filtered = filtered.filter(m => m.vehicleId === parseInt(vehicleId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/maintenance', async (req, res) => {
  try {
    const maint = {
      id: maintenance.length > 0 ? Math.max(...maintenance.map(m => m.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'pending',
      cost: req.body.cost || 0,
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    maintenance.push(maint);
    emitEvent('advanced-transportation:updated', {
      action: 'create',
      entityType: 'maintenance',
      entityId: maint.id,
      data: maint,
    });
    res.json({ success: true, data: maint });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/analytics', async (req, res) => {
  try {
    const totalVehicles = vehicles.length;
    const activeVehicles = vehicles.filter(v => v.status === 'active').length;
    const totalRoutes = routes.length;
    const activeRoutes = routes.filter(r => r.status === 'active').length;
    const totalTrips = trips.length;
    const completedTrips = trips.filter(t => t.status === 'completed').length;
    const totalDrivers = drivers.length;
    const activeDrivers = drivers.filter(d => d.status === 'active').length;
    const totalSchedules = schedules.length;
    const activeSchedules = schedules.filter(s => s.status === 'active').length;
    const totalMaintenance = maintenance.length;
    const pendingMaintenance = maintenance.filter(m => m.status === 'pending').length;
    const totalPassengers = trips.reduce((sum, t) => sum + (t.passengersCount || 0), 0);
    const totalMaintenanceCost = maintenance.reduce((sum, m) => sum + (m.cost || 0), 0);

    const analyticsData = [
      {
        id: 1,
        metric: 'إجمالي المركبات',
        value: totalVehicles,
        description: 'عدد المركبات الكلي',
      },
      {
        id: 2,
        metric: 'المركبات النشطة',
        value: activeVehicles,
        description: 'عدد المركبات النشطة',
      },
      {
        id: 3,
        metric: 'إجمالي المسارات',
        value: totalRoutes,
        description: 'عدد المسارات الكلي',
      },
      {
        id: 4,
        metric: 'المسارات النشطة',
        value: activeRoutes,
        description: 'عدد المسارات النشطة',
      },
      {
        id: 5,
        metric: 'إجمالي الرحلات',
        value: totalTrips,
        description: 'عدد الرحلات الكلي',
      },
      {
        id: 6,
        metric: 'الرحلات المكتملة',
        value: completedTrips,
        description: 'عدد الرحلات المكتملة',
      },
      {
        id: 7,
        metric: 'إجمالي السائقين',
        value: totalDrivers,
        description: 'عدد السائقين الكلي',
      },
      {
        id: 8,
        metric: 'السائقين النشطين',
        value: activeDrivers,
        description: 'عدد السائقين النشطين',
      },
      {
        id: 9,
        metric: 'إجمالي الجداول',
        value: totalSchedules,
        description: 'عدد الجداول الكلي',
      },
      {
        id: 10,
        metric: 'الجداول النشطة',
        value: activeSchedules,
        description: 'عدد الجداول النشطة',
      },
      {
        id: 11,
        metric: 'إجمالي الصيانة',
        value: totalMaintenance,
        description: 'عدد سجلات الصيانة الكلي',
      },
      {
        id: 12,
        metric: 'الصيانة قيد الانتظار',
        value: pendingMaintenance,
        description: 'عدد سجلات الصيانة قيد الانتظار',
      },
      {
        id: 13,
        metric: 'إجمالي الركاب',
        value: totalPassengers,
        description: 'عدد الركاب الكلي',
      },
      {
        id: 14,
        metric: 'إجمالي تكلفة الصيانة',
        value: `${totalMaintenanceCost.toLocaleString()} ريال`,
        description: 'إجمالي تكلفة الصيانة',
      },
    ];

    res.json({ success: true, data: analyticsData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
