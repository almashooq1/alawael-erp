/**
 * 🤝 Advanced Vendors Management Routes
 */

const express = require('express');
const router = express.Router();

const vendors = [];
const products = [];
const orders = [];
const evaluations = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/vendors', async (req, res) => {
  try {
    const { status, category } = req.query;
    let filtered = vendors;

    if (status) filtered = filtered.filter(v => v.status === status);
    if (category) filtered = filtered.filter(v => v.category === category);

    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/vendors', async (req, res) => {
  try {
    const vendor = {
      id: vendors.length > 0 ? Math.max(...vendors.map(v => v.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      rating: req.body.rating || 0,
      ordersCount: 0,
      totalValue: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    vendors.push(vendor);
    emitEvent('advanced-vendors:updated', {
      action: 'create',
      entityType: 'vendor',
      entityId: vendor.id,
      data: vendor,
    });

    res.json({ success: true, data: vendor });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/products', async (req, res) => {
  try {
    const { vendorId, category } = req.query;
    let filtered = products;

    if (vendorId) filtered = filtered.filter(p => p.vendorId === parseInt(vendorId));
    if (category) filtered = filtered.filter(p => p.category === category);

    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/products', async (req, res) => {
  try {
    const product = {
      id: products.length > 0 ? Math.max(...products.map(p => p.id)) + 1 : 1,
      ...req.body,
      price: req.body.price || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    products.push(product);
    emitEvent('advanced-vendors:updated', {
      action: 'create',
      entityType: 'product',
      entityId: product.id,
      data: product,
    });

    res.json({ success: true, data: product });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/orders', async (req, res) => {
  try {
    const { status, vendorId } = req.query;
    let filtered = orders;

    if (status) filtered = filtered.filter(o => o.status === status);
    if (vendorId) filtered = filtered.filter(o => o.vendorId === parseInt(vendorId));

    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/orders', async (req, res) => {
  try {
    const order = {
      id: orders.length > 0 ? Math.max(...orders.map(o => o.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'pending',
      total: req.body.total || 0,
      orderDate: req.body.orderDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    orders.push(order);
    emitEvent('advanced-vendors:updated', {
      action: 'create',
      entityType: 'order',
      entityId: order.id,
      data: order,
    });

    res.json({ success: true, data: order });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/evaluations', async (req, res) => {
  try {
    const { vendorId } = req.query;
    let filtered = evaluations;

    if (vendorId) filtered = filtered.filter(e => e.vendorId === parseInt(vendorId));

    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/evaluations', async (req, res) => {
  try {
    const evaluation = {
      id: evaluations.length > 0 ? Math.max(...evaluations.map(e => e.id)) + 1 : 1,
      ...req.body,
      rating: req.body.rating || 0,
      evaluationDate: req.body.evaluationDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    evaluations.push(evaluation);
    emitEvent('advanced-vendors:updated', {
      action: 'create',
      entityType: 'evaluation',
      entityId: evaluation.id,
      data: evaluation,
    });

    res.json({ success: true, data: evaluation });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
module.exports.setIO = setIO;
