/**
 * 🤝 Advanced Volunteers Management Routes
 */

const express = require('express');
const router = express.Router();

const volunteers = [];
const programs = [];
const activities = [];
const hours = [];
const certificates = [];
const evaluations = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/volunteers', async (req, res) => {
  try {
    const { status, category } = req.query;
    let filtered = volunteers;
    if (status) filtered = filtered.filter(v => v.status === status);
    if (category) filtered = filtered.filter(v => v.category === category);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/volunteers', async (req, res) => {
  try {
    const volunteer = {
      id: volunteers.length > 0 ? Math.max(...volunteers.map(v => v.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'pending',
      category: req.body.category || 'social',
      totalHours: req.body.totalHours || 0,
      activitiesCount: req.body.activitiesCount || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    volunteers.push(volunteer);
    emitEvent('advanced-volunteers:updated', {
      action: 'create',
      entityType: 'volunteer',
      entityId: volunteer.id,
      data: volunteer,
    });
    res.json({ success: true, data: volunteer });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/programs', async (req, res) => {
  try {
    const { status, category } = req.query;
    let filtered = programs;
    if (status) filtered = filtered.filter(p => p.status === status);
    if (category) filtered = filtered.filter(p => p.category === category);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/programs', async (req, res) => {
  try {
    const program = {
      id: programs.length > 0 ? Math.max(...programs.map(p => p.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'ongoing',
      category: req.body.category || 'social',
      volunteersCount: req.body.volunteersCount || 0,
      startDate: req.body.startDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    programs.push(program);
    emitEvent('advanced-volunteers:updated', {
      action: 'create',
      entityType: 'program',
      entityId: program.id,
      data: program,
    });
    res.json({ success: true, data: program });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/activities', async (req, res) => {
  try {
    const { status, programId } = req.query;
    let filtered = activities;
    if (status) filtered = filtered.filter(a => a.status === status);
    if (programId) filtered = filtered.filter(a => a.programId === parseInt(programId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/activities', async (req, res) => {
  try {
    const activity = {
      id: activities.length > 0 ? Math.max(...activities.map(a => a.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'scheduled',
      volunteersCount: req.body.volunteersCount || 0,
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    activities.push(activity);
    emitEvent('advanced-volunteers:updated', {
      action: 'create',
      entityType: 'activity',
      entityId: activity.id,
      data: activity,
    });
    res.json({ success: true, data: activity });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/hours', async (req, res) => {
  try {
    const { volunteerId, activityId } = req.query;
    let filtered = hours;
    if (volunteerId) filtered = filtered.filter(h => h.volunteerId === parseInt(volunteerId));
    if (activityId) filtered = filtered.filter(h => h.activityId === parseInt(activityId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/hours', async (req, res) => {
  try {
    const hour = {
      id: hours.length > 0 ? Math.max(...hours.map(h => h.id)) + 1 : 1,
      ...req.body,
      hours: req.body.hours || 0,
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    hours.push(hour);

    // Update volunteer total hours
    const volunteer = volunteers.find(v => v.id === hour.volunteerId);
    if (volunteer) {
      volunteer.totalHours = (volunteer.totalHours || 0) + hour.hours;
    }

    emitEvent('advanced-volunteers:updated', {
      action: 'create',
      entityType: 'hour',
      entityId: hour.id,
      data: hour,
    });
    res.json({ success: true, data: hour });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/certificates', async (req, res) => {
  try {
    const { status, volunteerId } = req.query;
    let filtered = certificates;
    if (status) filtered = filtered.filter(c => c.status === status);
    if (volunteerId) filtered = filtered.filter(c => c.volunteerId === parseInt(volunteerId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/certificates', async (req, res) => {
  try {
    const cert = {
      id: certificates.length > 0 ? Math.max(...certificates.map(c => c.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'issued',
      totalHours: req.body.totalHours || 0,
      issueDate: req.body.issueDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    certificates.push(cert);
    emitEvent('advanced-volunteers:updated', {
      action: 'create',
      entityType: 'certificate',
      entityId: cert.id,
      data: cert,
    });
    res.json({ success: true, data: cert });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/evaluations', async (req, res) => {
  try {
    const { volunteerId, activityId } = req.query;
    let filtered = evaluations;
    if (volunteerId) filtered = filtered.filter(e => e.volunteerId === parseInt(volunteerId));
    if (activityId) filtered = filtered.filter(e => e.activityId === parseInt(activityId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/evaluations', async (req, res) => {
  try {
    const evaluation = {
      id: evaluations.length > 0 ? Math.max(...evaluations.map(e => e.id)) + 1 : 1,
      ...req.body,
      rating: req.body.rating || 0,
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    evaluations.push(evaluation);
    emitEvent('advanced-volunteers:updated', {
      action: 'create',
      entityType: 'evaluation',
      entityId: evaluation.id,
      data: evaluation,
    });
    res.json({ success: true, data: evaluation });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/analytics', async (req, res) => {
  try {
    const totalVolunteers = volunteers.length;
    const activeVolunteers = volunteers.filter(v => v.status === 'active').length;
    const totalPrograms = programs.length;
    const ongoingPrograms = programs.filter(p => p.status === 'ongoing').length;
    const totalActivities = activities.length;
    const completedActivities = activities.filter(a => a.status === 'completed').length;
    const totalHours = hours.reduce((sum, h) => sum + (h.hours || 0), 0);
    const totalCertificates = certificates.length;
    const issuedCertificates = certificates.filter(c => c.status === 'issued').length;
    const totalEvaluations = evaluations.length;
    const averageRating =
      evaluations.length > 0
        ? (evaluations.reduce((sum, e) => sum + (e.rating || 0), 0) / evaluations.length).toFixed(1)
        : 0;

    const analyticsData = [
      {
        id: 1,
        metric: 'إجمالي المتطوعين',
        value: totalVolunteers,
        description: 'عدد المتطوعين الكلي',
      },
      {
        id: 2,
        metric: 'المتطوعين النشطين',
        value: activeVolunteers,
        description: 'عدد المتطوعين النشطين',
      },
      {
        id: 3,
        metric: 'إجمالي البرامج',
        value: totalPrograms,
        description: 'عدد البرامج الكلي',
      },
      {
        id: 4,
        metric: 'البرامج الجارية',
        value: ongoingPrograms,
        description: 'عدد البرامج الجارية',
      },
      {
        id: 5,
        metric: 'إجمالي الأنشطة',
        value: totalActivities,
        description: 'عدد الأنشطة الكلي',
      },
      {
        id: 6,
        metric: 'الأنشطة المكتملة',
        value: completedActivities,
        description: 'عدد الأنشطة المكتملة',
      },
      {
        id: 7,
        metric: 'إجمالي الساعات',
        value: `${totalHours} ساعة`,
        description: 'إجمالي ساعات التطوع',
      },
      {
        id: 8,
        metric: 'إجمالي الشهادات',
        value: totalCertificates,
        description: 'عدد الشهادات الكلي',
      },
      {
        id: 9,
        metric: 'الشهادات الصادرة',
        value: issuedCertificates,
        description: 'عدد الشهادات الصادرة',
      },
      {
        id: 10,
        metric: 'إجمالي التقييمات',
        value: totalEvaluations,
        description: 'عدد التقييمات الكلي',
      },
      {
        id: 11,
        metric: 'متوسط التقييم',
        value: `${averageRating}/5`,
        description: 'متوسط تقييم المتطوعين',
      },
    ];

    res.json({ success: true, data: analyticsData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
