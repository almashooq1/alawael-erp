/**
 * 💬 Advanced WhatsApp Management Routes
 */

const express = require('express');
const router = express.Router();

const connections = [];
const messages = [];
const templates = [];
const campaigns = [];
const contacts = [];
const groups = [];
const bots = [];
const autoReplies = [];
const schedules = [];
const interactiveTemplates = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/connections', async (req, res) => {
  try {
    const { status } = req.query;
    let filtered = connections;
    if (status) filtered = filtered.filter(c => c.status === status);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/connections', async (req, res) => {
  try {
    const connection = {
      id: connections.length > 0 ? Math.max(...connections.map(c => c.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'disconnected',
      messagesSent: 0,
      messagesReceived: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    connections.push(connection);
    emitEvent('advanced-whatsapp:updated', {
      action: 'create',
      entityType: 'connection',
      entityId: connection.id,
      data: connection,
    });
    res.json({ success: true, data: connection });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/connections/:id/connect', async (req, res) => {
  try {
    const index = connections.findIndex(c => c.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Connection not found' });
    }
    connections[index].status = 'connected';
    connections[index].connectedAt = new Date().toISOString();
    connections[index].lastActivity = new Date().toISOString();
    emitEvent('advanced-whatsapp:updated', {
      action: 'update',
      entityType: 'connection',
      entityId: connections[index].id,
      data: connections[index],
    });
    res.json({ success: true, data: connections[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/connections/:id/disconnect', async (req, res) => {
  try {
    const index = connections.findIndex(c => c.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Connection not found' });
    }
    connections[index].status = 'disconnected';
    emitEvent('advanced-whatsapp:updated', {
      action: 'update',
      entityType: 'connection',
      entityId: connections[index].id,
      data: connections[index],
    });
    res.json({ success: true, data: connections[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/messages', async (req, res) => {
  try {
    const { type, status, connectionId } = req.query;
    let filtered = messages;
    if (type) filtered = filtered.filter(m => m.type === type);
    if (status) filtered = filtered.filter(m => m.status === status);
    if (connectionId) filtered = filtered.filter(m => m.connectionId === parseInt(connectionId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/messages', async (req, res) => {
  try {
    const message = {
      id: messages.length > 0 ? Math.max(...messages.map(m => m.id)) + 1 : 1,
      ...req.body,
      type: req.body.type || 'sent',
      status: req.body.status || 'pending',
      timestamp: req.body.timestamp || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    messages.push(message);

    // Update connection stats
    const connectionIndex = connections.findIndex(c => c.id === message.connectionId);
    if (connectionIndex !== -1) {
      if (message.type === 'sent') {
        connections[connectionIndex].messagesSent++;
      } else {
        connections[connectionIndex].messagesReceived++;
      }
      connections[connectionIndex].lastActivity = new Date().toISOString();
    }

    emitEvent('advanced-whatsapp:updated', {
      action: 'create',
      entityType: 'message',
      entityId: message.id,
      data: message,
    });
    res.json({ success: true, data: message });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/templates', async (req, res) => {
  try {
    const { category, approved } = req.query;
    let filtered = templates;
    if (category) filtered = filtered.filter(t => t.category === category);
    if (approved !== undefined)
      filtered = filtered.filter(t => t.approved === (approved === 'true'));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/templates', async (req, res) => {
  try {
    const template = {
      id: templates.length > 0 ? Math.max(...templates.map(t => t.id)) + 1 : 1,
      ...req.body,
      approved: req.body.approved !== undefined ? req.body.approved : false,
      language: req.body.language || 'ar',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    templates.push(template);
    emitEvent('advanced-whatsapp:updated', {
      action: 'create',
      entityType: 'template',
      entityId: template.id,
      data: template,
    });
    res.json({ success: true, data: template });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/campaigns', async (req, res) => {
  try {
    const { status } = req.query;
    let filtered = campaigns;
    if (status) filtered = filtered.filter(c => c.status === status);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/campaigns', async (req, res) => {
  try {
    const campaign = {
      id: campaigns.length > 0 ? Math.max(...campaigns.map(c => c.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      recipientsCount: req.body.recipientsCount || 0,
      sentCount: 0,
      deliveredCount: 0,
      readCount: 0,
      progress: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    campaigns.push(campaign);
    emitEvent('advanced-whatsapp:updated', {
      action: 'create',
      entityType: 'campaign',
      entityId: campaign.id,
      data: campaign,
    });
    res.json({ success: true, data: campaign });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/contacts', async (req, res) => {
  try {
    res.json({ success: true, data: contacts });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/contacts', async (req, res) => {
  try {
    const contact = {
      id: contacts.length > 0 ? Math.max(...contacts.map(c => c.id)) + 1 : 1,
      ...req.body,
      messagesCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    contacts.push(contact);
    emitEvent('advanced-whatsapp:updated', {
      action: 'create',
      entityType: 'contact',
      entityId: contact.id,
      data: contact,
    });
    res.json({ success: true, data: contact });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/groups', async (req, res) => {
  try {
    res.json({ success: true, data: groups });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/groups', async (req, res) => {
  try {
    const group = {
      id: groups.length > 0 ? Math.max(...groups.map(g => g.id)) + 1 : 1,
      ...req.body,
      membersCount: req.body.membersCount || 0,
      messagesCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    groups.push(group);
    emitEvent('advanced-whatsapp:updated', {
      action: 'create',
      entityType: 'group',
      entityId: group.id,
      data: group,
    });
    res.json({ success: true, data: group });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/bots', async (req, res) => {
  try {
    const { enabled } = req.query;
    let filtered = bots;
    if (enabled !== undefined) filtered = filtered.filter(b => b.enabled === (enabled === 'true'));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/bots', async (req, res) => {
  try {
    const bot = {
      id: bots.length > 0 ? Math.max(...bots.map(b => b.id)) + 1 : 1,
      ...req.body,
      enabled: req.body.enabled !== undefined ? req.body.enabled : true,
      type: req.body.type || 'smart',
      aiEnabled: req.body.aiEnabled !== undefined ? req.body.aiEnabled : true,
      processedMessages: 0,
      successRate: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    bots.push(bot);
    emitEvent('advanced-whatsapp:updated', {
      action: 'create',
      entityType: 'bot',
      entityId: bot.id,
      data: bot,
    });
    res.json({ success: true, data: bot });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/bots/:id/toggle', async (req, res) => {
  try {
    const index = bots.findIndex(b => b.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Bot not found' });
    }
    bots[index].enabled = !bots[index].enabled;
    emitEvent('advanced-whatsapp:updated', {
      action: 'update',
      entityType: 'bot',
      entityId: bots[index].id,
      data: bots[index],
    });
    res.json({ success: true, data: bots[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/auto-replies', async (req, res) => {
  try {
    const { enabled, priority } = req.query;
    let filtered = autoReplies;
    if (enabled !== undefined) filtered = filtered.filter(r => r.enabled === (enabled === 'true'));
    if (priority) filtered = filtered.filter(r => r.priority === priority);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/auto-replies', async (req, res) => {
  try {
    const autoReply = {
      id: autoReplies.length > 0 ? Math.max(...autoReplies.map(r => r.id)) + 1 : 1,
      ...req.body,
      enabled: req.body.enabled !== undefined ? req.body.enabled : true,
      priority: req.body.priority || 'medium',
      keywords: req.body.keywords || [],
      usageCount: 0,
      successRate: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    autoReplies.push(autoReply);
    emitEvent('advanced-whatsapp:updated', {
      action: 'create',
      entityType: 'autoReply',
      entityId: autoReply.id,
      data: autoReply,
    });
    res.json({ success: true, data: autoReply });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/auto-replies/:id/toggle', async (req, res) => {
  try {
    const index = autoReplies.findIndex(r => r.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Auto reply not found' });
    }
    autoReplies[index].enabled = !autoReplies[index].enabled;
    emitEvent('advanced-whatsapp:updated', {
      action: 'update',
      entityType: 'autoReply',
      entityId: autoReplies[index].id,
      data: autoReplies[index],
    });
    res.json({ success: true, data: autoReplies[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/schedules', async (req, res) => {
  try {
    const { status } = req.query;
    let filtered = schedules;
    if (status) filtered = filtered.filter(s => s.status === status);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/schedules', async (req, res) => {
  try {
    const schedule = {
      id: schedules.length > 0 ? Math.max(...schedules.map(s => s.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'pending',
      scheduledAt: req.body.scheduledAt || new Date().toISOString(),
      recurrence: req.body.recurrence || 'once',
      recipientsCount: req.body.recipientsCount || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    schedules.push(schedule);
    emitEvent('advanced-whatsapp:updated', {
      action: 'create',
      entityType: 'schedule',
      entityId: schedule.id,
      data: schedule,
    });
    res.json({ success: true, data: schedule });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/schedules/:id/execute', async (req, res) => {
  try {
    const index = schedules.findIndex(s => s.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Schedule not found' });
    }
    schedules[index].status = 'executed';
    schedules[index].executedAt = new Date().toISOString();
    emitEvent('advanced-whatsapp:updated', {
      action: 'update',
      entityType: 'schedule',
      entityId: schedules[index].id,
      data: schedules[index],
    });
    res.json({ success: true, data: schedules[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/interactive-templates', async (req, res) => {
  try {
    const { approved, type } = req.query;
    let filtered = interactiveTemplates;
    if (approved !== undefined)
      filtered = filtered.filter(t => t.approved === (approved === 'true'));
    if (type) filtered = filtered.filter(t => t.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/interactive-templates', async (req, res) => {
  try {
    const template = {
      id:
        interactiveTemplates.length > 0 ? Math.max(...interactiveTemplates.map(t => t.id)) + 1 : 1,
      ...req.body,
      approved: req.body.approved !== undefined ? req.body.approved : false,
      type: req.body.type || 'button',
      buttons: req.body.buttons || [],
      usageCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    interactiveTemplates.push(template);
    emitEvent('advanced-whatsapp:updated', {
      action: 'create',
      entityType: 'interactiveTemplate',
      entityId: template.id,
      data: template,
    });
    res.json({ success: true, data: template });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/analytics', async (req, res) => {
  try {
    // Calculate analytics
    const totalMessages = messages.length;
    const sentMessages = messages.filter(m => m.type === 'sent').length;
    const receivedMessages = messages.filter(m => m.type === 'received').length;
    const deliveredMessages = messages.filter(m => m.status === 'delivered').length;
    const readMessages = messages.filter(m => m.status === 'read').length;
    const activeConnections = connections.filter(c => c.status === 'connected').length;

    const analyticsData = [
      {
        id: 1,
        metric: 'إجمالي الرسائل',
        value: totalMessages,
        description: 'عدد الرسائل الكلي',
        trend: null,
      },
      {
        id: 2,
        metric: 'الرسائل المرسلة',
        value: sentMessages,
        description: 'عدد الرسائل المرسلة',
        trend: null,
      },
      {
        id: 3,
        metric: 'الرسائل المستلمة',
        value: receivedMessages,
        description: 'عدد الرسائل المستلمة',
        trend: null,
      },
      {
        id: 4,
        metric: 'معدل التسليم',
        value: totalMessages > 0 ? Math.round((deliveredMessages / totalMessages) * 100) : 0,
        description: 'نسبة الرسائل المستلمة',
        trend: null,
      },
      {
        id: 5,
        metric: 'معدل القراءة',
        value: deliveredMessages > 0 ? Math.round((readMessages / deliveredMessages) * 100) : 0,
        description: 'نسبة الرسائل المقروءة',
        trend: null,
      },
      {
        id: 6,
        metric: 'الاتصالات النشطة',
        value: activeConnections,
        description: 'عدد الاتصالات المتصلة',
        trend: null,
      },
    ];

    res.json({ success: true, data: analyticsData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
