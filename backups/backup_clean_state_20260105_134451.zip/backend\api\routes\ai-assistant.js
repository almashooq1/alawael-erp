/**
 * AI Assistant Routes
 * مسارات المساعد الذكي
 */

const express = require('express');
const router = express.Router();
const aiAssistant = require('../../shared/utils/ai-assistant');
const { authenticateToken } = require('../middleware/auth-middleware');

// Analyze data
router.post('/analyze', authenticateToken, (req, res) => {
  try {
    const { data, type } = req.body;

    if (!data) {
      return res.status(400).json({
        success: false,
        error: 'Data is required',
      });
    }

    const insights = aiAssistant.analyze(data, type || 'general');

    res.json({
      success: true,
      data: {
        insights,
        count: insights.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Generate recommendations
router.post('/recommendations', authenticateToken, (req, res) => {
  try {
    const { data } = req.body;

    if (!data) {
      return res.status(400).json({
        success: false,
        error: 'Data is required',
      });
    }

    const recommendations = aiAssistant.generateRecommendations(data);

    res.json({
      success: true,
      data: {
        recommendations,
        count: recommendations.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Predict trends
router.post('/predict', authenticateToken, (req, res) => {
  try {
    const { data, period } = req.body;

    if (!data) {
      return res.status(400).json({
        success: false,
        error: 'Data is required',
      });
    }

    const predictions = aiAssistant.predictTrends(data, period || 'month');

    res.json({
      success: true,
      data: predictions,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Auto optimize
router.post('/optimize', authenticateToken, (req, res) => {
  try {
    const { data } = req.body;

    if (!data) {
      return res.status(400).json({
        success: false,
        error: 'Data is required',
      });
    }

    const optimizations = aiAssistant.autoOptimize(data);

    res.json({
      success: true,
      data: {
        optimizations,
        count: optimizations.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get suggestions
router.get('/suggestions', authenticateToken, (req, res) => {
  try {
    const limit = req.query.limit ? parseInt(req.query.limit) : 10;
    const suggestions = aiAssistant.getSuggestions(limit);

    res.json({
      success: true,
      data: {
        suggestions,
        count: suggestions.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Learn from context
router.post('/learn', authenticateToken, (req, res) => {
  try {
    const { context } = req.body;

    if (!context) {
      return res.status(400).json({
        success: false,
        error: 'Context is required',
      });
    }

    aiAssistant.learn(context);

    res.json({
      success: true,
      message: 'Context learned successfully',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

module.exports = router;
