/**
 * 📊 Advanced Analytics Routes
 * API routes for reports, dashboards, metrics, and insights
 */

const express = require('express');
const router = express.Router();

// Mock data storage
const reports = [];
const dashboards = [];
const metrics = [];
const insights = [];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Reports ====================

router.get('/reports', async (req, res) => {
  try {
    res.json({ success: true, data: reports });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/reports/:id', async (req, res) => {
  try {
    const report = reports.find(r => r.id === parseInt(req.params.id));
    if (!report) {
      return res.status(404).json({ success: false, error: 'Report not found' });
    }
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/reports', async (req, res) => {
  try {
    const report = {
      id: reports.length > 0 ? Math.max(...reports.map(r => r.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    reports.push(report);

    emitEvent('analytics:update', {
      action: 'create',
      entityType: 'report',
      entityId: report.id,
      data: report,
    });

    res.status(201).json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/reports/:id', async (req, res) => {
  try {
    const index = reports.findIndex(r => r.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Report not found' });
    }

    reports[index] = {
      ...reports[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    emitEvent('analytics:update', {
      action: 'update',
      entityType: 'report',
      entityId: reports[index].id,
      data: reports[index],
    });

    res.json({ success: true, data: reports[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.delete('/reports/:id', async (req, res) => {
  try {
    const index = reports.findIndex(r => r.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Report not found' });
    }

    const deletedReport = reports[index];
    reports.splice(index, 1);

    emitEvent('analytics:update', {
      action: 'delete',
      entityType: 'report',
      entityId: deletedReport.id,
    });

    res.json({ success: true, message: 'Report deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Dashboards ====================

router.get('/dashboards', async (req, res) => {
  try {
    res.json({ success: true, data: dashboards });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/dashboards', async (req, res) => {
  try {
    const dashboard = {
      id: dashboards.length > 0 ? Math.max(...dashboards.map(d => d.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    dashboards.push(dashboard);

    emitEvent('analytics:update', {
      action: 'create',
      entityType: 'dashboard',
      entityId: dashboard.id,
      data: dashboard,
    });

    res.status(201).json({ success: true, data: dashboard });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Metrics ====================

router.get('/metrics', async (req, res) => {
  try {
    res.json({ success: true, data: metrics });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/metrics', async (req, res) => {
  try {
    const metric = {
      id: metrics.length > 0 ? Math.max(...metrics.map(m => m.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    metrics.push(metric);

    emitEvent('analytics:update', {
      action: 'create',
      entityType: 'metric',
      entityId: metric.id,
      data: metric,
    });

    res.status(201).json({ success: true, data: metric });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Insights ====================

router.get('/insights', async (req, res) => {
  try {
    res.json({ success: true, data: insights });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/insights', async (req, res) => {
  try {
    const insight = {
      id: insights.length > 0 ? Math.max(...insights.map(i => i.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    insights.push(insight);

    emitEvent('analytics:update', {
      action: 'create',
      entityType: 'insight',
      entityId: insight.id,
      data: insight,
    });

    res.status(201).json({ success: true, data: insight });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
