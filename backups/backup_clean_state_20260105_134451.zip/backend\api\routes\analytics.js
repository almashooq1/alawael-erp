/**
 * Analytics Routes
 * مسارات التحليلات
 */

const express = require('express');
const router = express.Router();
const analyticsDashboard = require('../../shared/utils/analytics-dashboard');
const { authenticateToken, optionalAuth } = require('../middleware/auth-middleware');

// Initialize analytics
analyticsDashboard.init();

// Get dashboard data (requires auth)
router.get('/dashboard', authenticateToken, async (req, res) => {
  try {
    const data = await analyticsDashboard.getDashboardData();
    res.json({
      success: true,
      data,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get user analytics (requires auth)
router.get('/users', authenticateToken, async (req, res) => {
  try {
    const period = req.query.period || 'month';
    const data = await analyticsDashboard.getUserAnalytics(period);
    res.json({
      success: true,
      data,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get session analytics (requires auth)
router.get('/sessions', authenticateToken, async (req, res) => {
  try {
    const period = req.query.period || 'month';
    const data = await analyticsDashboard.getSessionAnalytics(period);
    res.json({
      success: true,
      data,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get performance metrics (optional auth)
router.get('/performance', optionalAuth, async (req, res) => {
  try {
    const data = await analyticsDashboard.getPerformanceMetrics();
    res.json({
      success: true,
      data,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get insights (requires auth)
router.get('/insights', authenticateToken, async (req, res) => {
  try {
    const dashboardData = await analyticsDashboard.getDashboardData();
    const insights = analyticsDashboard.generateInsights(dashboardData);
    res.json({
      success: true,
      data: insights,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Add metric (requires auth)
router.post('/metrics', authenticateToken, (req, res) => {
  try {
    const { type, data } = req.body;
    analyticsDashboard.addMetric(type, data);
    res.json({
      success: true,
      message: 'Metric added successfully',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

module.exports = router;
