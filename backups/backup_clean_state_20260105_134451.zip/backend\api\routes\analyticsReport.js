// نقطة نهاية لإرسال تقرير Analytics عبر البريد وSlack
const express = require('express');
const router = express.Router();
const { sendMail } = require('../../shared/utils/email-sender');
const { notifySlack } = require('../../shared/utils/slack-notifier');

// POST /api/analytics/send-report
router.post('/send-report', async (req, res) => {
  try {
    const { to, subject, text, slack, analyticsData } = req.body;
    // إرسال عبر البريد
    if (to) {
      await sendMail({ to, subject: subject || 'Analytics Report', text });
    }
    // إرسال عبر Slack
    if (slack) {
      await notifySlack('Analytics Report', '-', '-', text || JSON.stringify(analyticsData));
    }
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
