/**
 * 🐾 Animal-Assisted Therapy Routes
 * API routes for animal-assisted therapy sessions, animals, handlers, and progress
 */

const express = require('express');
const router = express.Router();

// Mock data storage
const sessions = [];
const animals = [];
const handlers = [];
const progress = [];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Sessions ====================

router.get('/sessions', async (req, res) => {
  try {
    res.json({ success: true, data: sessions });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/sessions', async (req, res) => {
  try {
    const session = {
      id: sessions.length > 0 ? Math.max(...sessions.map(s => s.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    sessions.push(session);

    emitEvent('animalAssistedTherapy:update', {
      action: 'create',
      entityType: 'session',
      entityId: session.id,
      data: session,
    });

    res.status(201).json({ success: true, data: session });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/sessions/:id', async (req, res) => {
  try {
    const index = sessions.findIndex(s => s.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Session not found' });
    }

    sessions[index] = {
      ...sessions[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    emitEvent('animalAssistedTherapy:update', {
      action: 'update',
      entityType: 'session',
      entityId: sessions[index].id,
      data: sessions[index],
    });

    res.json({ success: true, data: sessions[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.delete('/sessions/:id', async (req, res) => {
  try {
    const index = sessions.findIndex(s => s.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Session not found' });
    }

    const deletedSession = sessions[index];
    sessions.splice(index, 1);

    emitEvent('animalAssistedTherapy:update', {
      action: 'delete',
      entityType: 'session',
      entityId: deletedSession.id,
    });

    res.json({ success: true, message: 'Session deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Animals ====================

router.get('/animals', async (req, res) => {
  try {
    res.json({ success: true, data: animals });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/animals', async (req, res) => {
  try {
    const animal = {
      id: animals.length > 0 ? Math.max(...animals.map(a => a.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    animals.push(animal);

    emitEvent('animalAssistedTherapy:update', {
      action: 'create',
      entityType: 'animal',
      entityId: animal.id,
      data: animal,
    });

    res.status(201).json({ success: true, data: animal });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Handlers ====================

router.get('/handlers', async (req, res) => {
  try {
    res.json({ success: true, data: handlers });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/handlers', async (req, res) => {
  try {
    const handler = {
      id: handlers.length > 0 ? Math.max(...handlers.map(h => h.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    handlers.push(handler);

    emitEvent('animalAssistedTherapy:update', {
      action: 'create',
      entityType: 'handler',
      entityId: handler.id,
      data: handler,
    });

    res.status(201).json({ success: true, data: handler });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Progress ====================

router.get('/progress', async (req, res) => {
  try {
    res.json({ success: true, data: progress });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/progress', async (req, res) => {
  try {
    const prog = {
      id: progress.length > 0 ? Math.max(...progress.map(p => p.id)) + 1 : 1,
      ...req.body,
      date: new Date().toISOString(),
    };
    progress.push(prog);

    emitEvent('animalAssistedTherapy:update', {
      action: 'create',
      entityType: 'progress',
      entityId: prog.id,
      data: prog,
    });

    res.status(201).json({ success: true, data: prog });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
