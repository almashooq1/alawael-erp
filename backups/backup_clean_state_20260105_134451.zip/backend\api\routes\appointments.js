/**
 * 📅 Appointments Management Routes
 * مسارات إدارة المواعيد
 */

const express = require('express');
const router = express.Router();
const authenticateToken = require('../middleware/authenticateToken');
const logger = require('../../shared/logging/logger');

// Real-time event emitter (if available)
let io = null;
try {
  const realtimeModule = require('../realtime');
  io = realtimeModule.io;
} catch (error) {
  // Real-time not available
}

/**
 * Emit real-time event
 */
function emitEvent(eventType, entityType, data) {
  if (io) {
    io.emit('appointments:update', {
      action: eventType,
      entityType: entityType,
      entityId: data.id,
      data: data,
    });
  }
}

// Apply authentication to all routes
router.use(authenticateToken);

// In-memory storage for appointments (in production, use database)
const appointmentsStore = [];
const timeSlotsStore = [
  { id: 1, time: '08:00', available: true },
  { id: 2, time: '09:00', available: true },
  { id: 3, time: '10:00', available: true },
  { id: 4, time: '11:00', available: true },
  { id: 5, time: '12:00', available: true },
  { id: 6, time: '13:00', available: true },
  { id: 7, time: '14:00', available: true },
  { id: 8, time: '15:00', available: true },
  { id: 9, time: '16:00', available: true },
];

/**
 * Appointments Routes
 */
router.get('/', async (req, res) => {
  try {
    res.json(appointmentsStore);
  } catch (error) {
    logger.error('Error fetching appointments:', error);
    res.status(500).json({ error: 'خطأ في جلب المواعيد' });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const appointment = appointmentsStore.find(a => a.id === parseInt(req.params.id));
    if (!appointment) {
      return res.status(404).json({ error: 'الموعد غير موجود' });
    }
    res.json(appointment);
  } catch (error) {
    logger.error('Error fetching appointment:', error);
    res.status(500).json({ error: 'خطأ في جلب الموعد' });
  }
});

router.post('/', async (req, res) => {
  try {
    const appointment = {
      id: Date.now(),
      ...req.body,
      createdAt: new Date(),
    };
    appointmentsStore.push(appointment);
    emitEvent('create', 'appointment', appointment);
    logger.info('Appointment created', { id: appointment.id });
    res.status(201).json(appointment);
  } catch (error) {
    logger.error('Error creating appointment:', error);
    res.status(400).json({ error: 'خطأ في إضافة الموعد' });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const index = appointmentsStore.findIndex(a => a.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ error: 'الموعد غير موجود' });
    }
    appointmentsStore[index] = { ...appointmentsStore[index], ...req.body };
    emitEvent('update', 'appointment', appointmentsStore[index]);
    logger.info('Appointment updated', { id: req.params.id });
    res.json(appointmentsStore[index]);
  } catch (error) {
    logger.error('Error updating appointment:', error);
    res.status(400).json({ error: 'خطأ في تحديث الموعد' });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    const index = appointmentsStore.findIndex(a => a.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ error: 'الموعد غير موجود' });
    }
    appointmentsStore.splice(index, 1);
    emitEvent('delete', 'appointment', { id: req.params.id });
    logger.info('Appointment deleted', { id: req.params.id });
    res.json({ message: 'تم حذف الموعد بنجاح' });
  } catch (error) {
    logger.error('Error deleting appointment:', error);
    res.status(400).json({ error: 'خطأ في حذف الموعد' });
  }
});

/**
 * Time Slots Routes
 */
router.get('/time-slots', async (req, res) => {
  try {
    res.json(timeSlotsStore);
  } catch (error) {
    logger.error('Error fetching time slots:', error);
    res.status(500).json({ error: 'خطأ في جلب الأوقات المتاحة' });
  }
});

router.get('/time-slots/:id', async (req, res) => {
  try {
    const slot = timeSlotsStore.find(s => s.id === parseInt(req.params.id));
    if (!slot) {
      return res.status(404).json({ error: 'الوقت غير موجود' });
    }
    res.json(slot);
  } catch (error) {
    logger.error('Error fetching time slot:', error);
    res.status(500).json({ error: 'خطأ في جلب الوقت' });
  }
});

router.post('/time-slots', async (req, res) => {
  try {
    const slot = {
      id: Date.now(),
      ...req.body,
    };
    timeSlotsStore.push(slot);
    res.status(201).json(slot);
  } catch (error) {
    logger.error('Error creating time slot:', error);
    res.status(400).json({ error: 'خطأ في إضافة الوقت' });
  }
});

router.put('/time-slots/:id', async (req, res) => {
  try {
    const index = timeSlotsStore.findIndex(s => s.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ error: 'الوقت غير موجود' });
    }
    timeSlotsStore[index] = { ...timeSlotsStore[index], ...req.body };
    res.json(timeSlotsStore[index]);
  } catch (error) {
    logger.error('Error updating time slot:', error);
    res.status(400).json({ error: 'خطأ في تحديث الوقت' });
  }
});

router.delete('/time-slots/:id', async (req, res) => {
  try {
    const index = timeSlotsStore.findIndex(s => s.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ error: 'الوقت غير موجود' });
    }
    timeSlotsStore.splice(index, 1);
    res.json({ message: 'تم حذف الوقت بنجاح' });
  } catch (error) {
    logger.error('Error deleting time slot:', error);
    res.status(400).json({ error: 'خطأ في حذف الوقت' });
  }
});

module.exports = router;
