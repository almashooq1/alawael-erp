/**
 * 💧 Aquatic Therapy Routes
 * API routes for aquatic therapy sessions, exercises, pools, and progress
 */

const express = require('express');
const router = express.Router();

// Mock data storage
const sessions = [];
const exercises = [];
const pools = [];
const progress = [];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Sessions ====================

router.get('/sessions', async (req, res) => {
  try {
    res.json({ success: true, data: sessions });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/sessions', async (req, res) => {
  try {
    const session = {
      id: sessions.length > 0 ? Math.max(...sessions.map(s => s.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    sessions.push(session);

    emitEvent('aquaticTherapy:update', {
      action: 'create',
      entityType: 'session',
      entityId: session.id,
      data: session,
    });

    res.status(201).json({ success: true, data: session });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/sessions/:id', async (req, res) => {
  try {
    const index = sessions.findIndex(s => s.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Session not found' });
    }

    sessions[index] = {
      ...sessions[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    emitEvent('aquaticTherapy:update', {
      action: 'update',
      entityType: 'session',
      entityId: sessions[index].id,
      data: sessions[index],
    });

    res.json({ success: true, data: sessions[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.delete('/sessions/:id', async (req, res) => {
  try {
    const index = sessions.findIndex(s => s.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Session not found' });
    }

    const deletedSession = sessions[index];
    sessions.splice(index, 1);

    emitEvent('aquaticTherapy:update', {
      action: 'delete',
      entityType: 'session',
      entityId: deletedSession.id,
    });

    res.json({ success: true, message: 'Session deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Exercises ====================

router.get('/exercises', async (req, res) => {
  try {
    res.json({ success: true, data: exercises });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/exercises', async (req, res) => {
  try {
    const exercise = {
      id: exercises.length > 0 ? Math.max(...exercises.map(e => e.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    exercises.push(exercise);

    emitEvent('aquaticTherapy:update', {
      action: 'create',
      entityType: 'exercise',
      entityId: exercise.id,
      data: exercise,
    });

    res.status(201).json({ success: true, data: exercise });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Pools ====================

router.get('/pools', async (req, res) => {
  try {
    res.json({ success: true, data: pools });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/pools', async (req, res) => {
  try {
    const pool = {
      id: pools.length > 0 ? Math.max(...pools.map(p => p.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    pools.push(pool);

    emitEvent('aquaticTherapy:update', {
      action: 'create',
      entityType: 'pool',
      entityId: pool.id,
      data: pool,
    });

    res.status(201).json({ success: true, data: pool });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Progress ====================

router.get('/progress', async (req, res) => {
  try {
    res.json({ success: true, data: progress });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/progress', async (req, res) => {
  try {
    const prog = {
      id: progress.length > 0 ? Math.max(...progress.map(p => p.id)) + 1 : 1,
      ...req.body,
      date: new Date().toISOString(),
    };
    progress.push(prog);

    emitEvent('aquaticTherapy:update', {
      action: 'create',
      entityType: 'progress',
      entityId: prog.id,
      data: prog,
    });

    res.status(201).json({ success: true, data: prog });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
