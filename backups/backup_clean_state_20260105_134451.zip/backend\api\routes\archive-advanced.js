/**
 * Archive Advanced Routes
 * API routes for advanced archive features
 */

const express = require('express');
const router = express.Router();
const SmartArchiveManager = require('../../shared/utils/smart-archive-manager');
const ArchiveAutoArchiver = require('../../shared/utils/archive-auto-archiver');
const ArchiveBackupManager = require('../../shared/utils/archive-backup-manager');
const ArchiveAnalyticsManager = require('../../shared/utils/archive-analytics-manager');
const ArchiveIntegrationManager = require('../../shared/utils/archive-integration-manager');
const ArchiveDocumentProcessor = require('../../shared/utils/archive-document-processor');
const ArchiveCloudIntegration = require('../../shared/utils/archive-cloud-integration');
const ArchiveNotificationsManager = require('../../shared/utils/archive-notifications-manager');
const { requirePermission } = require('../../shared/middleware/permissions-middleware');

const archiveManager = new SmartArchiveManager();
const autoArchiver = new ArchiveAutoArchiver(archiveManager);
const backupManager = new ArchiveBackupManager(archiveManager);
const analyticsManager = new ArchiveAnalyticsManager(archiveManager);
const integrationManager = new ArchiveIntegrationManager(archiveManager);
const documentProcessor = new ArchiveDocumentProcessor(archiveManager);
const cloudIntegration = new ArchiveCloudIntegration(archiveManager);
const notificationsManager = new ArchiveNotificationsManager();

// ========== Auto Archive ==========

/**
 * إضافة قاعدة أرشفة تلقائية
 */
router.post('/auto-archive/rules', requirePermission('archive.archive'), async (req, res) => {
  try {
    const rule = autoArchiver.addAutoArchiveRule(req.body);
    res.json({ success: true, data: rule });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على قواعد الأرشفة التلقائية
 */
router.get('/auto-archive/rules', requirePermission('archive.view'), async (req, res) => {
  try {
    const rules = autoArchiver.getRules(req.query);
    res.json({ success: true, data: rules });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تنفيذ قاعدة أرشفة
 */
router.post(
  '/auto-archive/rules/:id/execute',
  requirePermission('archive.archive'),
  async (req, res) => {
    try {
      const result = await autoArchiver.executeRule(req.params.id);
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * تنفيذ جميع القواعد المستحقة
 */
router.post('/auto-archive/execute-all', requirePermission('archive.archive'), async (req, res) => {
  try {
    const results = await autoArchiver.executeDueRules();
    res.json({ success: true, data: results });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تقرير الأرشفة التلقائية
 */
router.get('/auto-archive/report', requirePermission('archive.view'), async (req, res) => {
  try {
    const report = autoArchiver.getAutoArchiveReport();
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Backup ==========

/**
 * إنشاء نسخة احتياطية
 */
router.post('/backup', requirePermission('archive.edit'), async (req, res) => {
  try {
    const backup = backupManager.createBackup(req.body.metadata || {});
    res.json({ success: true, data: backup });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على النسخ الاحتياطية
 */
router.get('/backup', requirePermission('archive.view'), async (req, res) => {
  try {
    const backups = backupManager.getBackups(req.query);
    res.json({ success: true, data: backups });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * استعادة نسخة احتياطية
 */
router.post('/backup/:id/restore', requirePermission('archive.edit'), async (req, res) => {
  try {
    const result = backupManager.restoreBackup(req.params.id);
    res.json({ success: true, data: result });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تصدير نسخة احتياطية
 */
router.get('/backup/:id/export', requirePermission('archive.view'), async (req, res) => {
  try {
    const backupJson = backupManager.exportBackup(req.params.id);
    res.setHeader('Content-Type', 'application/json');
    res.setHeader(
      'Content-Disposition',
      `attachment; filename="archive-backup-${req.params.id}.json"`
    );
    res.send(backupJson);
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * إحصائيات النسخ الاحتياطية
 */
router.get('/backup/stats', requirePermission('archive.view'), async (req, res) => {
  try {
    const stats = backupManager.getBackupStats();
    res.json({ success: true, data: stats });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Analytics ==========

/**
 * تسجيل عرض وثيقة
 */
router.post('/analytics/view/:documentId', async (req, res) => {
  try {
    const userId = req.user?.id || req.user?.userId || 'anonymous';
    analyticsManager.recordView(req.params.documentId, userId);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تسجيل تحميل وثيقة
 */
router.post('/analytics/download/:documentId', async (req, res) => {
  try {
    const userId = req.user?.id || req.user?.userId || 'anonymous';
    analyticsManager.recordDownload(req.params.documentId, userId);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على إحصائيات وثيقة
 */
router.get(
  '/analytics/documents/:documentId',
  requirePermission('archive.view'),
  async (req, res) => {
    try {
      const stats = analyticsManager.getDocumentStats(req.params.documentId);
      res.json({ success: true, data: stats });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * الحصول على أكثر الوثائق مشاهدة
 */
router.get('/analytics/most-viewed', requirePermission('archive.view'), async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 10;
    const documents = analyticsManager.getMostViewedDocuments(limit);
    res.json({ success: true, data: documents });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على أكثر الوثائق تحميلاً
 */
router.get('/analytics/most-downloaded', requirePermission('archive.view'), async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 10;
    const documents = analyticsManager.getMostDownloadedDocuments(limit);
    res.json({ success: true, data: documents });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تقرير التحليلات الشامل
 */
router.get('/analytics/report', requirePermission('archive.view'), async (req, res) => {
  try {
    const report = analyticsManager.getAnalyticsReport(
      req.query.startDate || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
      req.query.endDate || new Date().toISOString()
    );
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Integration ==========

/**
 * تسجيل تكامل
 */
router.post('/integration', requirePermission('archive.edit'), async (req, res) => {
  try {
    const integration = integrationManager.registerIntegration(req.body);
    res.json({ success: true, data: integration });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على التكاملات
 */
router.get('/integration', requirePermission('archive.view'), async (req, res) => {
  try {
    const integrations = integrationManager.getIntegrations(req.query);
    res.json({ success: true, data: integrations });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * مزامنة مع نظام خارجي
 */
router.post('/integration/:id/sync', requirePermission('archive.edit'), async (req, res) => {
  try {
    const result = await integrationManager.syncWithExternal(req.params.id);
    res.json({ success: true, data: result });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تصدير وثائق لنظام خارجي
 */
router.post('/integration/:id/export', requirePermission('archive.view'), async (req, res) => {
  try {
    const result = await integrationManager.exportToExternal(
      req.params.id,
      req.body.documentIds || []
    );
    res.json({ success: true, data: result });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تقرير التكامل
 */
router.get('/integration/report', requirePermission('archive.view'), async (req, res) => {
  try {
    const report = integrationManager.getIntegrationReport();
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Document Processing ==========

/**
 * معالجة وثيقة
 */
router.post(
  '/processing/process/:documentId',
  requirePermission('archive.edit'),
  async (req, res) => {
    try {
      const result = await documentProcessor.processDocument(req.params.documentId, req.body);
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * الحصول على نتائج المعالجة
 */
router.get('/processing/:documentId', requirePermission('archive.view'), async (req, res) => {
  try {
    const results = documentProcessor.getProcessingResults(req.params.documentId);
    res.json({ success: true, data: results });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Cloud Integration ==========

/**
 * تسجيل مزود سحابي
 */
router.post('/cloud/providers', requirePermission('archive.edit'), async (req, res) => {
  try {
    const provider = cloudIntegration.registerCloudProvider(req.body);
    res.json({ success: true, data: provider });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * رفع وثيقة إلى السحابة
 */
router.post(
  '/cloud/upload/:providerId/:documentId',
  requirePermission('archive.edit'),
  async (req, res) => {
    try {
      const result = await cloudIntegration.uploadToCloud(
        req.params.providerId,
        req.params.documentId
      );
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * مزامنة مع السحابة
 */
router.post('/cloud/sync/:providerId', requirePermission('archive.edit'), async (req, res) => {
  try {
    const result = await cloudIntegration.syncWithCloud(req.params.providerId);
    res.json({ success: true, data: result });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تقرير التكامل السحابي
 */
router.get('/cloud/report', requirePermission('archive.view'), async (req, res) => {
  try {
    const report = cloudIntegration.getCloudReport();
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Notifications ==========

/**
 * الحصول على إشعارات مستخدم
 */
router.get('/notifications/:userId', async (req, res) => {
  try {
    const notifications = notificationsManager.getUserNotifications(req.params.userId, req.query);
    res.json({ success: true, data: notifications });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تحديد إشعار كمقروء
 */
router.post('/notifications/:id/read', async (req, res) => {
  try {
    const notification = notificationsManager.markAsRead(req.params.id);
    res.json({ success: true, data: notification });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * إحصائيات الإشعارات
 */
router.get('/notifications/:userId/stats', async (req, res) => {
  try {
    const stats = notificationsManager.getNotificationsStats(req.params.userId);
    res.json({ success: true, data: stats });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
