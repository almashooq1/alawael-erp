/**
 * 📦 Asset Management Routes
 * API routes for assets, maintenance, depreciation, and categories
 */

const express = require('express');
const router = express.Router();

// Mock data storage
const assets = [];
const maintenance = [];
const depreciation = [];
const categories = [
  { id: 1, name: 'أجهزة', code: 'equipment' },
  { id: 2, name: 'معدات', code: 'tools' },
  { id: 3, name: 'مباني', code: 'buildings' },
];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Assets ====================

router.get('/assets', async (req, res) => {
  try {
    res.json({ success: true, data: assets });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/assets/:id', async (req, res) => {
  try {
    const asset = assets.find(a => a.id === parseInt(req.params.id));
    if (!asset) {
      return res.status(404).json({ success: false, error: 'Asset not found' });
    }
    res.json({ success: true, data: asset });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/assets', async (req, res) => {
  try {
    const asset = {
      id: assets.length > 0 ? Math.max(...assets.map(a => a.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    assets.push(asset);

    emitEvent('assets:update', {
      action: 'create',
      entityType: 'asset',
      entityId: asset.id,
      data: asset,
    });

    res.status(201).json({ success: true, data: asset });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/assets/:id', async (req, res) => {
  try {
    const index = assets.findIndex(a => a.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Asset not found' });
    }

    assets[index] = {
      ...assets[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    emitEvent('assets:update', {
      action: 'update',
      entityType: 'asset',
      entityId: assets[index].id,
      data: assets[index],
    });

    res.json({ success: true, data: assets[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.delete('/assets/:id', async (req, res) => {
  try {
    const index = assets.findIndex(a => a.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Asset not found' });
    }

    const deletedAsset = assets[index];
    assets.splice(index, 1);

    emitEvent('assets:update', {
      action: 'delete',
      entityType: 'asset',
      entityId: deletedAsset.id,
    });

    res.json({ success: true, message: 'Asset deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Maintenance ====================

router.get('/maintenance', async (req, res) => {
  try {
    res.json({ success: true, data: maintenance });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/maintenance', async (req, res) => {
  try {
    const maintenanceRecord = {
      id: maintenance.length > 0 ? Math.max(...maintenance.map(m => m.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    maintenance.push(maintenanceRecord);

    emitEvent('assets:update', {
      action: 'create',
      entityType: 'maintenance',
      entityId: maintenanceRecord.id,
      data: maintenanceRecord,
    });

    res.status(201).json({ success: true, data: maintenanceRecord });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Depreciation ====================

router.get('/depreciation', async (req, res) => {
  try {
    res.json({ success: true, data: depreciation });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/depreciation', async (req, res) => {
  try {
    const depreciationRecord = {
      id: depreciation.length > 0 ? Math.max(...depreciation.map(d => d.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    depreciation.push(depreciationRecord);

    emitEvent('assets:update', {
      action: 'create',
      entityType: 'depreciation',
      entityId: depreciationRecord.id,
      data: depreciationRecord,
    });

    res.status(201).json({ success: true, data: depreciationRecord });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Categories ====================

router.get('/categories', async (req, res) => {
  try {
    res.json({ success: true, data: categories });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/categories', async (req, res) => {
  try {
    const category = {
      id: categories.length > 0 ? Math.max(...categories.map(c => c.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    categories.push(category);

    emitEvent('assets:update', {
      action: 'create',
      entityType: 'category',
      entityId: category.id,
      data: category,
    });

    res.status(201).json({ success: true, data: category });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
