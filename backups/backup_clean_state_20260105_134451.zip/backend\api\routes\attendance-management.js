/**
 * Attendance Management Routes
 * Routes for attendance and leave management
 */

const express = require('express');
const router = express.Router();

const AttendanceManager = require('../../shared/utils/attendance-manager');
const attendanceManager = new AttendanceManager();

// Employee Management
router.post('/employees', async (req, res) => {
  try {
    const employee = attendanceManager.addEmployee(req.body);
    res.json({ success: true, data: employee });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/employees', async (req, res) => {
  try {
    const employees = Array.from(attendanceManager.employees.values());
    res.json({ success: true, data: employees });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/employees/:id', async (req, res) => {
  try {
    const employee = attendanceManager.employees.get(req.params.id);
    if (!employee) {
      return res.status(404).json({ success: false, error: 'Employee not found' });
    }
    res.json({ success: true, data: employee });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Check In/Out
router.post('/check-in', async (req, res) => {
  try {
    const record = attendanceManager.checkIn(req.body.employeeId, req.body);
    res.json({ success: true, data: record });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/check-out', async (req, res) => {
  try {
    const record = attendanceManager.checkOut(req.body.employeeId, req.body);
    res.json({ success: true, data: record });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// QR Code Check In
router.post('/check-in/qr', async (req, res) => {
  try {
    const { qrCode, location } = req.body;
    const employee = Array.from(attendanceManager.employees.values()).find(
      emp => emp.qrCode === qrCode
    );

    if (!employee) {
      return res.status(404).json({ success: false, error: 'Invalid QR Code' });
    }

    const record = attendanceManager.checkIn(employee.id, {
      method: 'qr_code',
      location,
    });
    res.json({ success: true, data: record });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Biometric Check In
router.post('/check-in/biometric', async (req, res) => {
  try {
    const { biometricId, location } = req.body;
    const employee = Array.from(attendanceManager.employees.values()).find(
      emp => emp.biometricId === biometricId
    );

    if (!employee) {
      return res.status(404).json({ success: false, error: 'Biometric ID not found' });
    }

    const record = attendanceManager.checkIn(employee.id, {
      method: 'biometric',
      location,
    });
    res.json({ success: true, data: record });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Shifts Management
router.post('/shifts', async (req, res) => {
  try {
    const shift = attendanceManager.createShift(req.body);
    res.json({ success: true, data: shift });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/shifts', async (req, res) => {
  try {
    const shifts = Array.from(attendanceManager.shifts.values());
    res.json({ success: true, data: shifts });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Leave Management
router.post('/leave/request', async (req, res) => {
  try {
    const leaveRequest = attendanceManager.requestLeave(req.body.employeeId, req.body);
    res.json({ success: true, data: leaveRequest });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/leave/:id/approve', async (req, res) => {
  try {
    const leaveRequest = attendanceManager.approveLeave(req.params.id, req.body.approverId);
    res.json({ success: true, data: leaveRequest });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/leave/requests', async (req, res) => {
  try {
    const requests = Array.from(attendanceManager.leaveRequests.values());
    let filtered = requests;

    if (req.query.employeeId) {
      filtered = filtered.filter(r => r.employeeId === req.query.employeeId);
    }

    if (req.query.status) {
      filtered = filtered.filter(r => r.status === req.query.status);
    }

    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Schedule Management
router.post('/schedules', async (req, res) => {
  try {
    const schedule = attendanceManager.createSchedule(req.body.employeeId, req.body);
    res.json({ success: true, data: schedule });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Attendance Records
router.get('/records', async (req, res) => {
  try {
    const records = attendanceManager.getAttendanceRecords(req.query);
    res.json({ success: true, data: records });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/records/employee/:id', async (req, res) => {
  try {
    const records = attendanceManager.getAttendanceRecords({
      employeeId: req.params.id,
      ...req.query,
    });
    res.json({ success: true, data: records });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Reports
router.get('/report', async (req, res) => {
  try {
    const report = attendanceManager.getAttendanceReport(
      req.query.startDate ||
        new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      req.query.endDate || new Date().toISOString().split('T')[0],
      req.query
    );
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
