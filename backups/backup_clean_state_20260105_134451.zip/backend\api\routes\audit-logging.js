/**
 * 📋 Audit & Logging Routes
 * API routes for audit logs, system logs, error logs, and access logs
 */

const express = require('express');
const router = express.Router();

// Mock data storage
const auditLogs = [];
const systemLogs = [];
const errorLogs = [];
const accessLogs = [];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Audit Logs ====================

router.get('/audit-logs', async (req, res) => {
  try {
    res.json({ success: true, data: auditLogs });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/audit-logs/:id', async (req, res) => {
  try {
    const log = auditLogs.find(l => l.id === parseInt(req.params.id));
    if (!log) {
      return res.status(404).json({ success: false, error: 'Audit log not found' });
    }
    res.json({ success: true, data: log });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/audit-logs', async (req, res) => {
  try {
    const log = {
      id: auditLogs.length > 0 ? Math.max(...auditLogs.map(l => l.id)) + 1 : 1,
      ...req.body,
      timestamp: new Date().toISOString(),
    };
    auditLogs.push(log);

    emitEvent('audit:update', {
      action: 'create',
      entityType: 'log',
      entityId: log.id,
      data: log,
    });

    res.status(201).json({ success: true, data: log });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== System Logs ====================

router.get('/system-logs', async (req, res) => {
  try {
    res.json({ success: true, data: systemLogs });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/system-logs', async (req, res) => {
  try {
    const log = {
      id: systemLogs.length > 0 ? Math.max(...systemLogs.map(l => l.id)) + 1 : 1,
      ...req.body,
      timestamp: new Date().toISOString(),
    };
    systemLogs.push(log);

    emitEvent('audit:update', {
      action: 'create',
      entityType: 'systemLog',
      entityId: log.id,
      data: log,
    });

    res.status(201).json({ success: true, data: log });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Error Logs ====================

router.get('/error-logs', async (req, res) => {
  try {
    res.json({ success: true, data: errorLogs });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/error-logs', async (req, res) => {
  try {
    const log = {
      id: errorLogs.length > 0 ? Math.max(...errorLogs.map(l => l.id)) + 1 : 1,
      ...req.body,
      timestamp: new Date().toISOString(),
    };
    errorLogs.push(log);

    emitEvent('audit:update', {
      action: 'create',
      entityType: 'errorLog',
      entityId: log.id,
      data: log,
    });

    res.status(201).json({ success: true, data: log });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Access Logs ====================

router.get('/access-logs', async (req, res) => {
  try {
    res.json({ success: true, data: accessLogs });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/access-logs', async (req, res) => {
  try {
    const log = {
      id: accessLogs.length > 0 ? Math.max(...accessLogs.map(l => l.id)) + 1 : 1,
      ...req.body,
      timestamp: new Date().toISOString(),
    };
    accessLogs.push(log);

    emitEvent('audit:update', {
      action: 'create',
      entityType: 'accessLog',
      entityId: log.id,
      data: log,
    });

    res.status(201).json({ success: true, data: log });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
