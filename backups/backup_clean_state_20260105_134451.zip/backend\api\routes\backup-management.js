/**
 * 💾 Backup Management Routes
 * API routes for backups, schedules, restores, and storage
 */

const express = require('express');
const router = express.Router();

// Mock data storage
const backups = [];
const schedules = [];
const restores = [];
const storage = [];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Backups ====================

router.get('/backups', async (req, res) => {
  try {
    res.json({ success: true, data: backups });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/backups/:id', async (req, res) => {
  try {
    const backup = backups.find(b => b.id === parseInt(req.params.id));
    if (!backup) {
      return res.status(404).json({ success: false, error: 'Backup not found' });
    }
    res.json({ success: true, data: backup });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/backups', async (req, res) => {
  try {
    const backup = {
      id: backups.length > 0 ? Math.max(...backups.map(b => b.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    backups.push(backup);

    emitEvent('backup:update', {
      action: 'create',
      entityType: 'backup',
      entityId: backup.id,
      data: backup,
    });

    res.status(201).json({ success: true, data: backup });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/backups/:id', async (req, res) => {
  try {
    const index = backups.findIndex(b => b.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Backup not found' });
    }

    backups[index] = {
      ...backups[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    emitEvent('backup:update', {
      action: 'update',
      entityType: 'backup',
      entityId: backups[index].id,
      data: backups[index],
    });

    res.json({ success: true, data: backups[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.delete('/backups/:id', async (req, res) => {
  try {
    const index = backups.findIndex(b => b.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Backup not found' });
    }

    const deletedBackup = backups[index];
    backups.splice(index, 1);

    emitEvent('backup:update', {
      action: 'delete',
      entityType: 'backup',
      entityId: deletedBackup.id,
    });

    res.json({ success: true, message: 'Backup deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Schedules ====================

router.get('/schedules', async (req, res) => {
  try {
    res.json({ success: true, data: schedules });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/schedules', async (req, res) => {
  try {
    const schedule = {
      id: schedules.length > 0 ? Math.max(...schedules.map(s => s.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    schedules.push(schedule);

    emitEvent('backup:update', {
      action: 'create',
      entityType: 'schedule',
      entityId: schedule.id,
      data: schedule,
    });

    res.status(201).json({ success: true, data: schedule });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Restores ====================

router.get('/restores', async (req, res) => {
  try {
    res.json({ success: true, data: restores });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/restores', async (req, res) => {
  try {
    const restore = {
      id: restores.length > 0 ? Math.max(...restores.map(r => r.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    restores.push(restore);

    emitEvent('backup:update', {
      action: 'create',
      entityType: 'restore',
      entityId: restore.id,
      data: restore,
    });

    res.status(201).json({ success: true, data: restore });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Storage ====================

router.get('/storage', async (req, res) => {
  try {
    res.json({ success: true, data: storage });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/storage', async (req, res) => {
  try {
    const storageItem = {
      id: storage.length > 0 ? Math.max(...storage.map(s => s.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    storage.push(storageItem);

    emitEvent('backup:update', {
      action: 'create',
      entityType: 'storage',
      entityId: storageItem.id,
      data: storageItem,
    });

    res.status(201).json({ success: true, data: storageItem });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
