/**
 * 🧘 Behavioral Therapy Routes
 * API routes for behavioral therapy sessions, interventions, plans, and progress
 */

const express = require('express');
const router = express.Router();

// Mock data storage
const sessions = [];
const interventions = [];
const plans = [];
const progress = [];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Sessions ====================

router.get('/sessions', async (req, res) => {
  try {
    res.json({ success: true, data: sessions });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/sessions', async (req, res) => {
  try {
    const session = {
      id: sessions.length > 0 ? Math.max(...sessions.map(s => s.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    sessions.push(session);

    emitEvent('behavioralTherapy:update', {
      action: 'create',
      entityType: 'session',
      entityId: session.id,
      data: session,
    });

    res.status(201).json({ success: true, data: session });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/sessions/:id', async (req, res) => {
  try {
    const index = sessions.findIndex(s => s.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Session not found' });
    }

    sessions[index] = {
      ...sessions[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    emitEvent('behavioralTherapy:update', {
      action: 'update',
      entityType: 'session',
      entityId: sessions[index].id,
      data: sessions[index],
    });

    res.json({ success: true, data: sessions[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.delete('/sessions/:id', async (req, res) => {
  try {
    const index = sessions.findIndex(s => s.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Session not found' });
    }

    const deletedSession = sessions[index];
    sessions.splice(index, 1);

    emitEvent('behavioralTherapy:update', {
      action: 'delete',
      entityType: 'session',
      entityId: deletedSession.id,
    });

    res.json({ success: true, message: 'Session deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Interventions ====================

router.get('/interventions', async (req, res) => {
  try {
    res.json({ success: true, data: interventions });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/interventions', async (req, res) => {
  try {
    const intervention = {
      id: interventions.length > 0 ? Math.max(...interventions.map(i => i.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    interventions.push(intervention);

    emitEvent('behavioralTherapy:update', {
      action: 'create',
      entityType: 'intervention',
      entityId: intervention.id,
      data: intervention,
    });

    res.status(201).json({ success: true, data: intervention });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Plans ====================

router.get('/plans', async (req, res) => {
  try {
    res.json({ success: true, data: plans });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/plans', async (req, res) => {
  try {
    const plan = {
      id: plans.length > 0 ? Math.max(...plans.map(p => p.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    plans.push(plan);

    emitEvent('behavioralTherapy:update', {
      action: 'create',
      entityType: 'plan',
      entityId: plan.id,
      data: plan,
    });

    res.status(201).json({ success: true, data: plan });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Progress ====================

router.get('/progress', async (req, res) => {
  try {
    res.json({ success: true, data: progress });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/progress', async (req, res) => {
  try {
    const prog = {
      id: progress.length > 0 ? Math.max(...progress.map(p => p.id)) + 1 : 1,
      ...req.body,
      date: new Date().toISOString(),
    };
    progress.push(prog);

    emitEvent('behavioralTherapy:update', {
      action: 'create',
      entityType: 'progress',
      entityId: prog.id,
      data: prog,
    });

    res.status(201).json({ success: true, data: prog });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
