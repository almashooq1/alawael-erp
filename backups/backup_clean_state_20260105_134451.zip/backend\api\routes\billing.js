/**
 * 💰 Billing & Invoicing Routes
 * API routes for billing, invoices, payments, and subscriptions
 */

const express = require('express');
const router = express.Router();

// Mock data storage (replace with database)
const invoices = [];
const payments = [];
const subscriptions = [];
const paymentMethods = [
  { id: 1, name: 'نقدي', code: 'cash', status: 'active' },
  { id: 2, name: 'بطاقة ائتمانية', code: 'card', status: 'active' },
  { id: 3, name: 'تحويل بنكي', code: 'bank_transfer', status: 'active' },
];

// Get Socket.IO instance for real-time events
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

/**
 * Emit real-time event
 */
function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Invoices ====================

/**
 * GET /api/billing/invoices
 * Get all invoices
 */
router.get('/invoices', async (req, res) => {
  try {
    res.json({
      success: true,
      data: invoices,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * GET /api/billing/invoices/:id
 * Get invoice by ID
 */
router.get('/invoices/:id', async (req, res) => {
  try {
    const invoice = invoices.find(i => i.id === parseInt(req.params.id));
    if (!invoice) {
      return res.status(404).json({
        success: false,
        error: 'Invoice not found',
      });
    }
    res.json({
      success: true,
      data: invoice,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * POST /api/billing/invoices
 * Create new invoice
 */
router.post('/invoices', async (req, res) => {
  try {
    const invoice = {
      id: invoices.length > 0 ? Math.max(...invoices.map(i => i.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    invoices.push(invoice);

    // Emit real-time event
    emitEvent('billing:update', {
      action: 'create',
      entityType: 'invoice',
      entityId: invoice.id,
      data: invoice,
    });

    res.status(201).json({
      success: true,
      data: invoice,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * PUT /api/billing/invoices/:id
 * Update invoice
 */
router.put('/invoices/:id', async (req, res) => {
  try {
    const index = invoices.findIndex(i => i.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Invoice not found',
      });
    }

    invoices[index] = {
      ...invoices[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    // Emit real-time event
    emitEvent('billing:update', {
      action: 'update',
      entityType: 'invoice',
      entityId: invoices[index].id,
      data: invoices[index],
    });

    res.json({
      success: true,
      data: invoices[index],
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * DELETE /api/billing/invoices/:id
 * Delete invoice
 */
router.delete('/invoices/:id', async (req, res) => {
  try {
    const index = invoices.findIndex(i => i.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Invoice not found',
      });
    }

    const deletedInvoice = invoices[index];
    invoices.splice(index, 1);

    // Emit real-time event
    emitEvent('billing:update', {
      action: 'delete',
      entityType: 'invoice',
      entityId: deletedInvoice.id,
    });

    res.json({
      success: true,
      message: 'Invoice deleted successfully',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Payments ====================

/**
 * GET /api/billing/payments
 * Get all payments
 */
router.get('/payments', async (req, res) => {
  try {
    res.json({
      success: true,
      data: payments,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * GET /api/billing/payments/:id
 * Get payment by ID
 */
router.get('/payments/:id', async (req, res) => {
  try {
    const payment = payments.find(p => p.id === parseInt(req.params.id));
    if (!payment) {
      return res.status(404).json({
        success: false,
        error: 'Payment not found',
      });
    }
    res.json({
      success: true,
      data: payment,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * POST /api/billing/payments
 * Create new payment
 */
router.post('/payments', async (req, res) => {
  try {
    const payment = {
      id: payments.length > 0 ? Math.max(...payments.map(p => p.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    payments.push(payment);

    // Emit real-time event
    emitEvent('billing:update', {
      action: 'create',
      entityType: 'payment',
      entityId: payment.id,
      data: payment,
    });

    res.status(201).json({
      success: true,
      data: payment,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * PUT /api/billing/payments/:id
 * Update payment
 */
router.put('/payments/:id', async (req, res) => {
  try {
    const index = payments.findIndex(p => p.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Payment not found',
      });
    }

    payments[index] = {
      ...payments[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    // Emit real-time event
    emitEvent('billing:update', {
      action: 'update',
      entityType: 'payment',
      entityId: payments[index].id,
      data: payments[index],
    });

    res.json({
      success: true,
      data: payments[index],
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * DELETE /api/billing/payments/:id
 * Delete payment
 */
router.delete('/payments/:id', async (req, res) => {
  try {
    const index = payments.findIndex(p => p.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Payment not found',
      });
    }

    const deletedPayment = payments[index];
    payments.splice(index, 1);

    // Emit real-time event
    emitEvent('billing:update', {
      action: 'delete',
      entityType: 'payment',
      entityId: deletedPayment.id,
    });

    res.json({
      success: true,
      message: 'Payment deleted successfully',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Subscriptions ====================

/**
 * GET /api/billing/subscriptions
 * Get all subscriptions
 */
router.get('/subscriptions', async (req, res) => {
  try {
    res.json({
      success: true,
      data: subscriptions,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * GET /api/billing/subscriptions/:id
 * Get subscription by ID
 */
router.get('/subscriptions/:id', async (req, res) => {
  try {
    const subscription = subscriptions.find(s => s.id === parseInt(req.params.id));
    if (!subscription) {
      return res.status(404).json({
        success: false,
        error: 'Subscription not found',
      });
    }
    res.json({
      success: true,
      data: subscription,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * POST /api/billing/subscriptions
 * Create new subscription
 */
router.post('/subscriptions', async (req, res) => {
  try {
    const subscription = {
      id: subscriptions.length > 0 ? Math.max(...subscriptions.map(s => s.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    subscriptions.push(subscription);

    // Emit real-time event
    emitEvent('billing:update', {
      action: 'create',
      entityType: 'subscription',
      entityId: subscription.id,
      data: subscription,
    });

    res.status(201).json({
      success: true,
      data: subscription,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * PUT /api/billing/subscriptions/:id
 * Update subscription
 */
router.put('/subscriptions/:id', async (req, res) => {
  try {
    const index = subscriptions.findIndex(s => s.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Subscription not found',
      });
    }

    subscriptions[index] = {
      ...subscriptions[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    // Emit real-time event
    emitEvent('billing:update', {
      action: 'update',
      entityType: 'subscription',
      entityId: subscriptions[index].id,
      data: subscriptions[index],
    });

    res.json({
      success: true,
      data: subscriptions[index],
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * DELETE /api/billing/subscriptions/:id
 * Delete subscription
 */
router.delete('/subscriptions/:id', async (req, res) => {
  try {
    const index = subscriptions.findIndex(s => s.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Subscription not found',
      });
    }

    const deletedSubscription = subscriptions[index];
    subscriptions.splice(index, 1);

    // Emit real-time event
    emitEvent('billing:update', {
      action: 'delete',
      entityType: 'subscription',
      entityId: deletedSubscription.id,
    });

    res.json({
      success: true,
      message: 'Subscription deleted successfully',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Payment Methods ====================

/**
 * GET /api/billing/payment-methods
 * Get all payment methods
 */
router.get('/payment-methods', async (req, res) => {
  try {
    res.json({
      success: true,
      data: paymentMethods,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * GET /api/billing/payment-methods/:id
 * Get payment method by ID
 */
router.get('/payment-methods/:id', async (req, res) => {
  try {
    const method = paymentMethods.find(m => m.id === parseInt(req.params.id));
    if (!method) {
      return res.status(404).json({
        success: false,
        error: 'Payment method not found',
      });
    }
    res.json({
      success: true,
      data: method,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * POST /api/billing/payment-methods
 * Create new payment method
 */
router.post('/payment-methods', async (req, res) => {
  try {
    const method = {
      id: paymentMethods.length > 0 ? Math.max(...paymentMethods.map(m => m.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    paymentMethods.push(method);

    // Emit real-time event
    emitEvent('billing:update', {
      action: 'create',
      entityType: 'paymentMethod',
      entityId: method.id,
      data: method,
    });

    res.status(201).json({
      success: true,
      data: method,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * PUT /api/billing/payment-methods/:id
 * Update payment method
 */
router.put('/payment-methods/:id', async (req, res) => {
  try {
    const index = paymentMethods.findIndex(m => m.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Payment method not found',
      });
    }

    paymentMethods[index] = {
      ...paymentMethods[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    // Emit real-time event
    emitEvent('billing:update', {
      action: 'update',
      entityType: 'paymentMethod',
      entityId: paymentMethods[index].id,
      data: paymentMethods[index],
    });

    res.json({
      success: true,
      data: paymentMethods[index],
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * DELETE /api/billing/payment-methods/:id
 * Delete payment method
 */
router.delete('/payment-methods/:id', async (req, res) => {
  try {
    const index = paymentMethods.findIndex(m => m.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Payment method not found',
      });
    }

    const deletedMethod = paymentMethods[index];
    paymentMethods.splice(index, 1);

    // Emit real-time event
    emitEvent('billing:update', {
      action: 'delete',
      entityType: 'paymentMethod',
      entityId: deletedMethod.id,
    });

    res.json({
      success: true,
      message: 'Payment method deleted successfully',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

module.exports = { router, setIO };
