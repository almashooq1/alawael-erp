/**
 * 💰 Budget & Finance Management Routes
 * مسارات إدارة الميزانية والمالية
 */

const express = require('express');
const router = express.Router();

// Model stubs
let Budget, Expense, Revenue;
try {
  Budget = require('../models/Budget');
} catch {
  Budget = {
    find: () => Promise.resolve([]),
    findById: () => Promise.resolve(null),
    create: () => Promise.resolve({}),
    save: () => Promise.resolve({}),
  };
}
try {
  Expense = require('../models/Expense');
} catch {
  Expense = {
    find: () => Promise.resolve([]),
    findById: () => Promise.resolve(null),
    create: () => Promise.resolve({}),
    save: () => Promise.resolve({}),
  };
}
try {
  Revenue = require('../models/Revenue');
} catch {
  Revenue = {
    find: () => Promise.resolve([]),
    findById: () => Promise.resolve(null),
    create: () => Promise.resolve({}),
    save: () => Promise.resolve({}),
  };
}

const authenticateToken = require('../middleware/authenticateToken');
const logger = require('../../shared/logging/logger');

// Real-time event emitter (if available)
let io = null;
try {
  const realtimeModule = require('../realtime');
  io = realtimeModule.io;
} catch (error) {
  // Real-time not available
}

/**
 * Emit real-time event
 */
function emitEvent(eventType, entityType, data) {
  if (io) {
    io.emit('budget:update', {
      action: eventType,
      entityType: entityType,
      entityId: data.id,
      data: data,
    });
  }
}

// Apply authentication to all routes
router.use(authenticateToken);

/**
 * Budgets Routes
 */
router.get('/budgets', async (req, res) => {
  try {
    const budgets = await Budget.findAll({
      order: [
        ['year', 'DESC'],
        ['createdAt', 'DESC'],
      ],
    });
    res.json(budgets);
  } catch (error) {
    logger.error('Error fetching budgets:', error);
    res.status(500).json({ error: 'خطأ في جلب الميزانيات' });
  }
});

router.get('/budgets/:id', async (req, res) => {
  try {
    const budget = await Budget.findByPk(req.params.id);
    if (!budget) {
      return res.status(404).json({ error: 'الميزانية غير موجودة' });
    }
    res.json(budget);
  } catch (error) {
    logger.error('Error fetching budget:', error);
    res.status(500).json({ error: 'خطأ في جلب الميزانية' });
  }
});

router.post('/budgets', async (req, res) => {
  try {
    const budget = await Budget.create(req.body);
    emitEvent('create', 'budget', budget);
    logger.info('Budget created', { id: budget.id, name: budget.name });
    res.status(201).json(budget);
  } catch (error) {
    logger.error('Error creating budget:', error);
    res.status(400).json({ error: 'خطأ في إضافة الميزانية' });
  }
});

router.put('/budgets/:id', async (req, res) => {
  try {
    const [updated] = await Budget.update(req.body, {
      where: { id: req.params.id },
    });
    if (updated) {
      const budget = await Budget.findByPk(req.params.id);
      emitEvent('update', 'budget', budget);
      logger.info('Budget updated', { id: budget.id });
      res.json(budget);
    } else {
      res.status(404).json({ error: 'الميزانية غير موجودة' });
    }
  } catch (error) {
    logger.error('Error updating budget:', error);
    res.status(400).json({ error: 'خطأ في تحديث الميزانية' });
  }
});

router.delete('/budgets/:id', async (req, res) => {
  try {
    const deleted = await Budget.destroy({
      where: { id: req.params.id },
    });
    if (deleted) {
      // Also delete related expenses
      await Expense.destroy({ where: { budgetId: req.params.id } });
      emitEvent('delete', 'budget', { id: req.params.id });
      logger.info('Budget deleted', { id: req.params.id });
      res.json({ message: 'تم حذف الميزانية بنجاح' });
    } else {
      res.status(404).json({ error: 'الميزانية غير موجودة' });
    }
  } catch (error) {
    logger.error('Error deleting budget:', error);
    res.status(400).json({ error: 'خطأ في حذف الميزانية' });
  }
});

/**
 * Expenses Routes
 */
router.get('/expenses', async (req, res) => {
  try {
    const expenses = await Expense.findAll({
      order: [['date', 'DESC']],
      limit: 100,
    });
    res.json(expenses);
  } catch (error) {
    logger.error('Error fetching expenses:', error);
    res.status(500).json({ error: 'خطأ في جلب المصروفات' });
  }
});

router.get('/expenses/:id', async (req, res) => {
  try {
    const expense = await Expense.findByPk(req.params.id);
    if (!expense) {
      return res.status(404).json({ error: 'المصروف غير موجود' });
    }
    res.json(expense);
  } catch (error) {
    logger.error('Error fetching expense:', error);
    res.status(500).json({ error: 'خطأ في جلب المصروف' });
  }
});

router.post('/expenses', async (req, res) => {
  try {
    const expense = await Expense.create(req.body);
    emitEvent('create', 'expense', expense);
    logger.info('Expense created', { id: expense.id, amount: expense.amount });
    res.status(201).json(expense);
  } catch (error) {
    logger.error('Error creating expense:', error);
    res.status(400).json({ error: 'خطأ في إضافة المصروف' });
  }
});

router.put('/expenses/:id', async (req, res) => {
  try {
    const [updated] = await Expense.update(req.body, {
      where: { id: req.params.id },
    });
    if (updated) {
      const expense = await Expense.findByPk(req.params.id);
      emitEvent('update', 'expense', expense);
      logger.info('Expense updated', { id: expense.id });
      res.json(expense);
    } else {
      res.status(404).json({ error: 'المصروف غير موجود' });
    }
  } catch (error) {
    logger.error('Error updating expense:', error);
    res.status(400).json({ error: 'خطأ في تحديث المصروف' });
  }
});

router.delete('/expenses/:id', async (req, res) => {
  try {
    const deleted = await Expense.destroy({
      where: { id: req.params.id },
    });
    if (deleted) {
      emitEvent('delete', 'expense', { id: req.params.id });
      logger.info('Expense deleted', { id: req.params.id });
      res.json({ message: 'تم حذف المصروف بنجاح' });
    } else {
      res.status(404).json({ error: 'المصروف غير موجود' });
    }
  } catch (error) {
    logger.error('Error deleting expense:', error);
    res.status(400).json({ error: 'خطأ في حذف المصروف' });
  }
});

/**
 * Revenues Routes
 */
router.get('/revenues', async (req, res) => {
  try {
    const revenues = await Revenue.findAll({
      order: [['date', 'DESC']],
      limit: 100,
    });
    res.json(revenues);
  } catch (error) {
    logger.error('Error fetching revenues:', error);
    res.status(500).json({ error: 'خطأ في جلب الإيرادات' });
  }
});

router.get('/revenues/:id', async (req, res) => {
  try {
    const revenue = await Revenue.findByPk(req.params.id);
    if (!revenue) {
      return res.status(404).json({ error: 'الإيراد غير موجود' });
    }
    res.json(revenue);
  } catch (error) {
    logger.error('Error fetching revenue:', error);
    res.status(500).json({ error: 'خطأ في جلب الإيراد' });
  }
});

router.post('/revenues', async (req, res) => {
  try {
    const revenue = await Revenue.create(req.body);
    emitEvent('create', 'revenue', revenue);
    logger.info('Revenue created', { id: revenue.id, amount: revenue.amount });
    res.status(201).json(revenue);
  } catch (error) {
    logger.error('Error creating revenue:', error);
    res.status(400).json({ error: 'خطأ في إضافة الإيراد' });
  }
});

router.put('/revenues/:id', async (req, res) => {
  try {
    const [updated] = await Revenue.update(req.body, {
      where: { id: req.params.id },
    });
    if (updated) {
      const revenue = await Revenue.findByPk(req.params.id);
      emitEvent('update', 'revenue', revenue);
      logger.info('Revenue updated', { id: revenue.id });
      res.json(revenue);
    } else {
      res.status(404).json({ error: 'الإيراد غير موجود' });
    }
  } catch (error) {
    logger.error('Error updating revenue:', error);
    res.status(400).json({ error: 'خطأ في تحديث الإيراد' });
  }
});

router.delete('/revenues/:id', async (req, res) => {
  try {
    const deleted = await Revenue.destroy({
      where: { id: req.params.id },
    });
    if (deleted) {
      emitEvent('delete', 'revenue', { id: req.params.id });
      logger.info('Revenue deleted', { id: req.params.id });
      res.json({ message: 'تم حذف الإيراد بنجاح' });
    } else {
      res.status(404).json({ error: 'الإيراد غير موجود' });
    }
  } catch (error) {
    logger.error('Error deleting revenue:', error);
    res.status(400).json({ error: 'خطأ في حذف الإيراد' });
  }
});

module.exports = router;
