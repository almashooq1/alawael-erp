/**
 * 🇸🇦 API Routes for Camera Surveillance System
 * مسارات API لنظام مراقبة الكاميرات
 */

const express = require('express');
const router = express.Router();
const CameraSurveillanceManager = require('../../shared/utils/camera-surveillance-manager');
const CameraSurveillanceAnalytics = require('../../shared/utils/camera-surveillance-analytics');
const CameraSurveillanceSecurity = require('../../shared/utils/camera-surveillance-security');
const CameraSurveillanceAlerts = require('../../shared/utils/camera-surveillance-alerts');
const CameraSurveillanceReports = require('../../shared/utils/camera-surveillance-reports');
const CameraSurveillanceAI = require('../../shared/utils/camera-surveillance-ai');
const CameraSurveillanceNotifications = require('../../shared/utils/camera-surveillance-notifications');
const CameraSurveillanceBackup = require('../../shared/utils/camera-surveillance-backup');
const CameraSurveillanceIntegration = require('../../shared/utils/camera-surveillance-integration');
const CameraSurveillancePerformance = require('../../shared/utils/camera-surveillance-performance');
const CameraSurveillanceMonitoring = require('../../shared/utils/camera-surveillance-monitoring');
const CameraSurveillanceRealtime = require('../../shared/utils/camera-surveillance-realtime');
const CameraSurveillanceExport = require('../../shared/utils/camera-surveillance-export');
const { requirePermission } = require('../../shared/middleware/permissions-middleware');

const cameraManager = new CameraSurveillanceManager();
const analytics = new CameraSurveillanceAnalytics(cameraManager);
const security = new CameraSurveillanceSecurity(cameraManager);
const alerts = new CameraSurveillanceAlerts(cameraManager);
const reports = new CameraSurveillanceReports(cameraManager, analytics, security);
const ai = new CameraSurveillanceAI(cameraManager, analytics, alerts);
const notifications = new CameraSurveillanceNotifications(cameraManager, alerts, ai);
const backup = new CameraSurveillanceBackup(cameraManager);
const integration = new CameraSurveillanceIntegration(cameraManager);
const performance = new CameraSurveillancePerformance(cameraManager);
const monitoring = new CameraSurveillanceMonitoring(cameraManager, performance);
const realtime = new CameraSurveillanceRealtime(cameraManager);
const exportManager = new CameraSurveillanceExport(cameraManager);

// ========== Branches ==========

router.post('/branches', requirePermission('surveillance.branches.edit'), async (req, res) => {
  try {
    const branch = cameraManager.addBranch(req.body);
    res.json({ success: true, data: branch });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/branches', requirePermission('surveillance.branches.view'), async (req, res) => {
  try {
    const branches = cameraManager.getBranches(req.query);
    res.json({ success: true, data: branches });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get(
  '/branches/:branchId',
  requirePermission('surveillance.branches.view'),
  async (req, res) => {
    try {
      const branch = cameraManager.branches.get(req.params.branchId);
      if (branch) {
        res.json({ success: true, data: branch });
      } else {
        res.status(404).json({ success: false, error: 'Branch not found' });
      }
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Cameras ==========

router.post('/cameras', requirePermission('surveillance.cameras.edit'), async (req, res) => {
  try {
    const camera = cameraManager.addCamera(req.body);
    res.json({ success: true, data: camera });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/cameras', requirePermission('surveillance.cameras.view'), async (req, res) => {
  try {
    const cameras = cameraManager.getCameras(req.query);
    res.json({ success: true, data: cameras });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get(
  '/cameras/:cameraId',
  requirePermission('surveillance.cameras.view'),
  async (req, res) => {
    try {
      const camera = cameraManager.cameras.get(req.params.cameraId);
      if (camera) {
        res.json({ success: true, data: camera });
      } else {
        res.status(404).json({ success: false, error: 'Camera not found' });
      }
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.put(
  '/cameras/:cameraId/status',
  requirePermission('surveillance.cameras.edit'),
  async (req, res) => {
    try {
      const success = cameraManager.updateCameraStatus(req.params.cameraId, req.body.status);
      res.json({ success });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.post(
  '/cameras/:cameraId/recording',
  requirePermission('surveillance.cameras.edit'),
  async (req, res) => {
    try {
      const result = cameraManager.toggleRecording(req.params.cameraId, req.body.isRecording);
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Recordings ==========

router.get('/recordings', requirePermission('surveillance.recordings.view'), async (req, res) => {
  try {
    const recordings = cameraManager.getRecordings(req.query);
    res.json({ success: true, data: recordings });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get(
  '/recordings/:recordingId',
  requirePermission('surveillance.recordings.view'),
  async (req, res) => {
    try {
      const recording = cameraManager.recordings.get(req.params.recordingId);
      if (recording) {
        res.json({ success: true, data: recording });
      } else {
        res.status(404).json({ success: false, error: 'Recording not found' });
      }
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Events ==========

router.post('/events', requirePermission('surveillance.events.edit'), async (req, res) => {
  try {
    const event = cameraManager.logEvent(req.body);
    res.json({ success: true, data: event });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/events', requirePermission('surveillance.events.view'), async (req, res) => {
  try {
    const events = cameraManager.getEvents(req.query);
    res.json({ success: true, data: events });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post(
  '/events/:eventId/acknowledge',
  requirePermission('surveillance.events.edit'),
  async (req, res) => {
    try {
      const success = cameraManager.acknowledgeEvent(req.params.eventId, req.body.acknowledgedBy);
      res.json({ success });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Statistics ==========

router.get('/statistics', requirePermission('surveillance.statistics.view'), async (req, res) => {
  try {
    const statistics = cameraManager.getStatistics(req.query.branchId);
    res.json({ success: true, data: statistics });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Analytics ==========

router.get(
  '/analytics/camera-usage',
  requirePermission('surveillance.analytics.view'),
  async (req, res) => {
    try {
      const startDate = req.query.startDate || new Date(new Date().setDate(1)).toISOString();
      const endDate = req.query.endDate || new Date().toISOString();
      const analysis = analytics.analyzeCameraUsage(req.query.branchId, startDate, endDate);
      res.json({ success: true, data: analysis });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/analytics/events',
  requirePermission('surveillance.analytics.view'),
  async (req, res) => {
    try {
      const startDate = req.query.startDate || new Date(new Date().setDate(1)).toISOString();
      const endDate = req.query.endDate || new Date().toISOString();
      const analysis = analytics.analyzeEvents(req.query.branchId, startDate, endDate);
      res.json({ success: true, data: analysis });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/analytics/performance',
  requirePermission('surveillance.analytics.view'),
  async (req, res) => {
    try {
      const startDate = req.query.startDate || new Date(new Date().setDate(1)).toISOString();
      const endDate = req.query.endDate || new Date().toISOString();
      const analysis = analytics.analyzePerformance(req.query.branchId, startDate, endDate);
      res.json({ success: true, data: analysis });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Security ==========

router.post(
  '/security/access-log',
  requirePermission('surveillance.security.edit'),
  async (req, res) => {
    try {
      const log = security.logAccess(req.body);
      res.json({ success: true, data: log });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/security/access-logs',
  requirePermission('surveillance.security.view'),
  async (req, res) => {
    try {
      const logs = security.getAccessLogs(req.query);
      res.json({ success: true, data: logs });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.post(
  '/security/check',
  requirePermission('surveillance.security.view'),
  async (req, res) => {
    try {
      const check = security.performSecurityCheck(req.query.branchId);
      res.json({ success: true, data: check });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/security/alerts',
  requirePermission('surveillance.security.view'),
  async (req, res) => {
    try {
      const alerts = security.getAlerts(req.query);
      res.json({ success: true, data: alerts });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.post(
  '/security/alerts/:alertId/acknowledge',
  requirePermission('surveillance.security.edit'),
  async (req, res) => {
    try {
      const success = security.acknowledgeAlert(req.params.alertId, req.body.acknowledgedBy);
      res.json({ success });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.post(
  '/security/alerts/:alertId/resolve',
  requirePermission('surveillance.security.edit'),
  async (req, res) => {
    try {
      const success = security.resolveAlert(req.params.alertId);
      res.json({ success });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Smart Alerts ==========

router.post('/alerts/check', requirePermission('surveillance.alerts.edit'), async (req, res) => {
  try {
    const newAlerts = alerts.checkCamerasAndAlert();
    res.json({ success: true, data: newAlerts, count: newAlerts.length });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/alerts', requirePermission('surveillance.alerts.view'), async (req, res) => {
  try {
    const alertsList = alerts.getAlerts(req.query);
    res.json({ success: true, data: alertsList });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post(
  '/alerts/:alertId/acknowledge',
  requirePermission('surveillance.alerts.edit'),
  async (req, res) => {
    try {
      const success = alerts.acknowledgeAlert(req.params.alertId, req.body.acknowledgedBy);
      res.json({ success });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.post(
  '/alerts/:alertId/resolve',
  requirePermission('surveillance.alerts.edit'),
  async (req, res) => {
    try {
      const success = alerts.resolveAlert(req.params.alertId);
      res.json({ success });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/alerts/statistics',
  requirePermission('surveillance.alerts.view'),
  async (req, res) => {
    try {
      const statistics = alerts.getAlertStatistics(req.query.branchId);
      res.json({ success: true, data: statistics });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Reports ==========

router.get(
  '/reports/comprehensive',
  requirePermission('surveillance.reports.view'),
  async (req, res) => {
    try {
      const startDate = req.query.startDate || new Date(new Date().setDate(1)).toISOString();
      const endDate = req.query.endDate || new Date().toISOString();
      const report = reports.generateComprehensiveReport(req.query.branchId, startDate, endDate);
      res.json({ success: true, data: report });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get('/reports/cameras', requirePermission('surveillance.reports.view'), async (req, res) => {
  try {
    const report = reports.generateCameraReport(req.query.branchId);
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/reports/events', requirePermission('surveillance.reports.view'), async (req, res) => {
  try {
    const startDate = req.query.startDate || new Date(new Date().setDate(1)).toISOString();
    const endDate = req.query.endDate || new Date().toISOString();
    const report = reports.generateEventsReport(req.query.branchId, startDate, endDate);
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get(
  '/reports/recordings',
  requirePermission('surveillance.reports.view'),
  async (req, res) => {
    try {
      const startDate = req.query.startDate || new Date(new Date().setDate(1)).toISOString();
      const endDate = req.query.endDate || new Date().toISOString();
      const report = reports.generateRecordingsReport(req.query.branchId, startDate, endDate);
      res.json({ success: true, data: report });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/reports/security',
  requirePermission('surveillance.reports.view'),
  async (req, res) => {
    try {
      const startDate = req.query.startDate || new Date(new Date().setDate(1)).toISOString();
      const endDate = req.query.endDate || new Date().toISOString();
      const report = reports.generateSecurityReport(req.query.branchId, startDate, endDate);
      res.json({ success: true, data: report });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Notifications ==========

router.post(
  '/notifications/check',
  requirePermission('surveillance.notifications.edit'),
  async (req, res) => {
    try {
      const newNotifications = await notifications.checkAndNotify();
      res.json({ success: true, data: newNotifications, count: newNotifications.length });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/notifications',
  requirePermission('surveillance.notifications.view'),
  async (req, res) => {
    try {
      const notificationsList = notifications.getNotifications(req.query);
      res.json({ success: true, data: notificationsList });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.post(
  '/notifications/:notificationId/read',
  requirePermission('surveillance.notifications.edit'),
  async (req, res) => {
    try {
      const success = notifications.markAsRead(req.params.notificationId);
      res.json({ success });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.delete(
  '/notifications/:notificationId',
  requirePermission('surveillance.notifications.edit'),
  async (req, res) => {
    try {
      const success = notifications.deleteNotification(req.params.notificationId);
      res.json({ success });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/notifications/statistics',
  requirePermission('surveillance.notifications.view'),
  async (req, res) => {
    try {
      const statistics = notifications.getStatistics(req.query.branchId);
      res.json({ success: true, data: statistics });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Backup ==========

router.post('/backup', requirePermission('surveillance.backup.edit'), async (req, res) => {
  try {
    const backupData = backup.createBackup(req.body);
    res.json({ success: true, data: backupData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/backup', requirePermission('surveillance.backup.view'), async (req, res) => {
  try {
    const backups = backup.getBackups(req.query);
    res.json({ success: true, data: backups });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post(
  '/backup/:backupId/restore',
  requirePermission('surveillance.backup.edit'),
  async (req, res) => {
    try {
      const result = backup.restoreBackup(req.params.backupId, req.body);
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.delete(
  '/backup/:backupId',
  requirePermission('surveillance.backup.edit'),
  async (req, res) => {
    try {
      const success = backup.deleteBackup(req.params.backupId);
      res.json({ success });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.post('/backup/clean', requirePermission('surveillance.backup.edit'), async (req, res) => {
  try {
    const deleted = backup.cleanOldBackups();
    res.json({ success: true, deleted });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get(
  '/backup/statistics',
  requirePermission('surveillance.backup.view'),
  async (req, res) => {
    try {
      const statistics = backup.getStatistics();
      res.json({ success: true, data: statistics });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Integration ==========

router.get(
  '/integration/status',
  requirePermission('surveillance.integration.view'),
  async (req, res) => {
    try {
      const status = integration.getIntegrationStatus();
      res.json({ success: true, data: status });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.post(
  '/integration/sync/all',
  requirePermission('surveillance.integration.edit'),
  async (req, res) => {
    try {
      const results = await integration.syncAll();
      res.json({ success: true, data: results });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.post(
  '/integration/sync/attendance',
  requirePermission('surveillance.integration.edit'),
  async (req, res) => {
    try {
      const result = await integration.syncWithAttendance();
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.post(
  '/integration/sync/security',
  requirePermission('surveillance.integration.edit'),
  async (req, res) => {
    try {
      const result = await integration.syncWithSecurity();
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.post(
  '/integration/sync/hr',
  requirePermission('surveillance.integration.edit'),
  async (req, res) => {
    try {
      const result = await integration.syncWithHR();
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.post(
  '/integration/sync/facilities',
  requirePermission('surveillance.integration.edit'),
  async (req, res) => {
    try {
      const result = await integration.syncWithFacilities();
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.post(
  '/integration/:integrationId/toggle',
  requirePermission('surveillance.integration.edit'),
  async (req, res) => {
    try {
      const success = integration.toggleIntegration(req.params.integrationId, req.body.enabled);
      res.json({ success });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Performance & Monitoring ==========

router.get(
  '/performance/analysis',
  requirePermission('surveillance.performance.view'),
  async (req, res) => {
    try {
      const analysis = performance.analyzePerformance();
      res.json({ success: true, data: analysis });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/performance/metrics',
  requirePermission('surveillance.performance.view'),
  async (req, res) => {
    try {
      const metrics = performance.getMetrics();
      res.json({ success: true, data: metrics });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.post(
  '/performance/reset',
  requirePermission('surveillance.performance.edit'),
  async (req, res) => {
    try {
      performance.resetMetrics();
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.post(
  '/monitoring/health-check',
  requirePermission('surveillance.monitoring.view'),
  async (req, res) => {
    try {
      const health = monitoring.performHealthCheck();
      res.json({ success: true, data: health });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/monitoring/health-history',
  requirePermission('surveillance.monitoring.view'),
  async (req, res) => {
    try {
      const limit = parseInt(req.query.limit) || 10;
      const history = monitoring.getHealthCheckHistory(limit);
      res.json({ success: true, data: history });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/monitoring/statistics',
  requirePermission('surveillance.monitoring.view'),
  async (req, res) => {
    try {
      const statistics = monitoring.getMonitoringStatistics();
      res.json({ success: true, data: statistics });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Realtime ==========

router.get(
  '/realtime/connections',
  requirePermission('surveillance.realtime.view'),
  async (req, res) => {
    try {
      const connections = realtime.getActiveConnections(req.query.cameraId);
      res.json({ success: true, data: connections });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/realtime/events',
  requirePermission('surveillance.realtime.view'),
  async (req, res) => {
    try {
      const limit = parseInt(req.query.limit) || 50;
      const events = realtime.getRealtimeEvents(limit);
      res.json({ success: true, data: events });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/realtime/statistics',
  requirePermission('surveillance.realtime.view'),
  async (req, res) => {
    try {
      const statistics = realtime.getConnectionStatistics();
      res.json({ success: true, data: statistics });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Export/Import ==========

router.get('/export/json', requirePermission('surveillance.export.view'), async (req, res) => {
  try {
    const jsonData = exportManager.exportToJSON(req.query);
    res.setHeader('Content-Type', 'application/json');
    res.setHeader(
      'Content-Disposition',
      `attachment; filename="camera-surveillance-${Date.now()}.json"`
    );
    res.send(jsonData);
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/export/csv/:type', requirePermission('surveillance.export.view'), async (req, res) => {
  try {
    const csvData = exportManager.exportToCSV(req.params.type, req.query);
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader(
      'Content-Disposition',
      `attachment; filename="camera-surveillance-${req.params.type}-${Date.now()}.csv"`
    );
    res.send(csvData);
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/import/json', requirePermission('surveillance.import.edit'), async (req, res) => {
  try {
    const result = exportManager.importFromJSON(req.body);
    res.json({ success: true, data: result });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
