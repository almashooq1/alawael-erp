/**
 * 🇸🇦 API Routes لسنترال الاتصالات
 * Central Communications API Routes
 */

const express = require('express');
const router = express.Router();
const CentralCommunicationsManager = require('../../shared/utils/central-communications-manager');
const CentralCommunicationsAnalytics = require('../../shared/utils/central-communications-analytics');
const CentralCommunicationsReports = require('../../shared/utils/central-communications-reports');
const CentralCommunicationsIVR = require('../../shared/utils/central-communications-ivr');
const CentralCommunicationsQueue = require('../../shared/utils/central-communications-queue');
const CentralCommunicationsRecording = require('../../shared/utils/central-communications-recording');
const CentralCommunicationsNotifications = require('../../shared/utils/central-communications-notifications');
const CentralCommunicationsIntegration = require('../../shared/utils/central-communications-integration');
const CentralCommunicationsBackup = require('../../shared/utils/central-communications-backup');
const CentralCommunicationsPerformance = require('../../shared/utils/central-communications-performance');
const CentralCommunicationsSecurity = require('../../shared/utils/central-communications-security');
const CentralCommunicationsExport = require('../../shared/utils/central-communications-export');
const { requirePermission } = require('../../shared/middleware/permissions-middleware');

const centralManager = new CentralCommunicationsManager();
const analytics = new CentralCommunicationsAnalytics(centralManager);
const reports = new CentralCommunicationsReports(centralManager, analytics);
const ivr = new CentralCommunicationsIVR(centralManager);
const queue = new CentralCommunicationsQueue(centralManager);
const recording = new CentralCommunicationsRecording(centralManager);
const notifications = new CentralCommunicationsNotifications(centralManager);
const integration = new CentralCommunicationsIntegration(centralManager);
const backup = new CentralCommunicationsBackup(centralManager);
const performance = new CentralCommunicationsPerformance(centralManager);
const security = new CentralCommunicationsSecurity(centralManager);
const exportManager = new CentralCommunicationsExport(centralManager);

// ========== Central Number ==========

router.get(
  '/central-number',
  requirePermission('communications.central.view'),
  async (req, res) => {
    try {
      const centralNumber = centralManager.getCentralNumber();
      res.json({ success: true, data: centralNumber });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.put(
  '/central-number',
  requirePermission('communications.central.edit'),
  async (req, res) => {
    try {
      const centralNumber = centralManager.updateCentralNumber(req.body);
      res.json({ success: true, data: centralNumber });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Branches ==========

router.get('/branches', requirePermission('communications.branches.view'), async (req, res) => {
  try {
    const branches = centralManager.getBranches();
    res.json({ success: true, data: branches });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/branches/:id', requirePermission('communications.branches.view'), async (req, res) => {
  try {
    const branch = centralManager.getBranch(req.params.id);
    if (!branch) {
      return res.status(404).json({ success: false, error: 'الفرع غير موجود' });
    }
    res.json({ success: true, data: branch });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/branches', requirePermission('communications.branches.edit'), async (req, res) => {
  try {
    const branch = centralManager.addBranch(req.body);
    res.json({ success: true, data: branch });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/branches/:id', requirePermission('communications.branches.edit'), async (req, res) => {
  try {
    const branch = centralManager.updateBranch(req.params.id, req.body);
    res.json({ success: true, data: branch });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.delete(
  '/branches/:id',
  requirePermission('communications.branches.delete'),
  async (req, res) => {
    try {
      const deleted = centralManager.deleteBranch(req.params.id);
      res.json({ success: deleted });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Calls ==========

router.get('/calls', requirePermission('communications.calls.view'), async (req, res) => {
  try {
    const calls = centralManager.getCalls(req.query);
    res.json({ success: true, data: calls });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/calls', requirePermission('communications.calls.edit'), async (req, res) => {
  try {
    const call = centralManager.addCall(req.body);
    res.json({ success: true, data: call });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put(
  '/calls/:id/status',
  requirePermission('communications.calls.edit'),
  async (req, res) => {
    try {
      const call = centralManager.updateCallStatus(
        req.params.id,
        req.body.status,
        req.body.duration
      );
      if (!call) {
        return res.status(404).json({ success: false, error: 'المكالمة غير موجودة' });
      }
      res.json({ success: true, data: call });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.post(
  '/calls/:id/route',
  requirePermission('communications.calls.edit'),
  async (req, res) => {
    try {
      const call = centralManager.routeCall(req.params.id, req.body.extension);
      res.json({ success: true, data: call });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Extensions ==========

router.get('/extensions', requirePermission('communications.extensions.view'), async (req, res) => {
  try {
    const extensions = Array.from(centralManager.extensions.values());
    res.json({ success: true, data: extensions });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Routing Rules ==========

router.get('/routing-rules', requirePermission('communications.routing.view'), async (req, res) => {
  try {
    const rules = centralManager.getRoutingRules();
    res.json({ success: true, data: rules });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post(
  '/routing-rules',
  requirePermission('communications.routing.edit'),
  async (req, res) => {
    try {
      const rule = centralManager.addRoutingRule(req.body);
      res.json({ success: true, data: rule });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Operators ==========

router.get('/operators', requirePermission('communications.operators.view'), async (req, res) => {
  try {
    const operators = centralManager.getOperators(req.query);
    res.json({ success: true, data: operators });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/operators', requirePermission('communications.operators.edit'), async (req, res) => {
  try {
    const operator = centralManager.addOperator(req.body);
    res.json({ success: true, data: operator });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Statistics ==========

router.get('/statistics', requirePermission('communications.statistics.view'), async (req, res) => {
  try {
    const statistics = centralManager.getStatistics(req.query);
    res.json({ success: true, data: statistics });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Analytics ==========

router.get(
  '/analytics/branches',
  requirePermission('communications.analytics.view'),
  async (req, res) => {
    try {
      const analysis = analytics.analyzeCallsByBranch(req.query.dateFrom, req.query.dateTo);
      res.json({ success: true, data: analysis });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/analytics/time',
  requirePermission('communications.analytics.view'),
  async (req, res) => {
    try {
      const analysis = analytics.analyzeCallsByTime(req.query.dateFrom, req.query.dateTo);
      res.json({ success: true, data: analysis });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/analytics/operators',
  requirePermission('communications.analytics.view'),
  async (req, res) => {
    try {
      const analysis = analytics.analyzeOperatorsPerformance(req.query.dateFrom, req.query.dateTo);
      res.json({ success: true, data: analysis });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/analytics/trends',
  requirePermission('communications.analytics.view'),
  async (req, res) => {
    try {
      const days = parseInt(req.query.days) || 30;
      const trends = analytics.analyzeCallTrends(days);
      res.json({ success: true, data: trends });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/analytics/distribution',
  requirePermission('communications.analytics.view'),
  async (req, res) => {
    try {
      const distribution = analytics.analyzeCallDistribution(req.query.dateFrom, req.query.dateTo);
      res.json({ success: true, data: distribution });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Reports ==========

router.get(
  '/reports/comprehensive',
  requirePermission('communications.reports.view'),
  async (req, res) => {
    try {
      const report = reports.generateComprehensiveReport(req.query.dateFrom, req.query.dateTo);
      res.json({ success: true, data: report });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/reports/branches',
  requirePermission('communications.reports.view'),
  async (req, res) => {
    try {
      const report = reports.generateBranchesReport(req.query.dateFrom, req.query.dateTo);
      res.json({ success: true, data: report });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/reports/operators',
  requirePermission('communications.reports.view'),
  async (req, res) => {
    try {
      const report = reports.generateOperatorsReport(req.query.dateFrom, req.query.dateTo);
      res.json({ success: true, data: report });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get('/reports/daily', requirePermission('communications.reports.view'), async (req, res) => {
  try {
    const report = reports.generateDailyReport(req.query.date);
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== IVR ==========

router.get('/ivr/menus', requirePermission('communications.ivr.view'), async (req, res) => {
  try {
    const menus = ivr.getMenus();
    res.json({ success: true, data: menus });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/ivr/menus', requirePermission('communications.ivr.edit'), async (req, res) => {
  try {
    const menu = ivr.addMenu(req.body);
    res.json({ success: true, data: menu });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/ivr/route', requirePermission('communications.ivr.edit'), async (req, res) => {
  try {
    const result = ivr.routeCall(req.body.callId, req.body.menuId, req.body.selection);
    res.json({ success: true, data: result });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Queue ==========

router.get('/queues', requirePermission('communications.queue.view'), async (req, res) => {
  try {
    const queues = Array.from(queue.queues.values());
    res.json({ success: true, data: queues });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/queues', requirePermission('communications.queue.edit'), async (req, res) => {
  try {
    const queueData = queue.addQueue(req.body);
    res.json({ success: true, data: queueData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post(
  '/queues/:id/members',
  requirePermission('communications.queue.edit'),
  async (req, res) => {
    try {
      const member = queue.addQueueMember(req.params.id, req.body.operatorId);
      res.json({ success: true, data: member });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.post(
  '/queues/:id/calls',
  requirePermission('communications.queue.edit'),
  async (req, res) => {
    try {
      const result = queue.addCallToQueue(req.body.callId, req.params.id);
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/queues/:id/statistics',
  requirePermission('communications.queue.view'),
  async (req, res) => {
    try {
      const statistics = queue.getQueueStatistics(req.params.id);
      res.json({ success: true, data: statistics });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Recording ==========

router.post(
  '/recordings/start',
  requirePermission('communications.recording.edit'),
  async (req, res) => {
    try {
      const result = recording.startRecording(req.body.callId);
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.post(
  '/recordings/stop',
  requirePermission('communications.recording.edit'),
  async (req, res) => {
    try {
      const result = recording.stopRecording(req.body.callId);
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get('/recordings', requirePermission('communications.recording.view'), async (req, res) => {
  try {
    const recordings = recording.getRecordings(req.query);
    res.json({ success: true, data: recordings });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.delete(
  '/recordings/:id',
  requirePermission('communications.recording.delete'),
  async (req, res) => {
    try {
      const deleted = recording.deleteRecording(req.params.id);
      res.json({ success: deleted });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/recordings/statistics',
  requirePermission('communications.recording.view'),
  async (req, res) => {
    try {
      const statistics = recording.getStatistics(req.query);
      res.json({ success: true, data: statistics });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Notifications ==========

router.get(
  '/notifications',
  requirePermission('communications.notifications.view'),
  async (req, res) => {
    try {
      const notificationsList = notifications.getNotifications(req.query);
      res.json({ success: true, data: notificationsList });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.put(
  '/notifications/:id/read',
  requirePermission('communications.notifications.edit'),
  async (req, res) => {
    try {
      const marked = notifications.markAsRead(req.params.id);
      res.json({ success: marked });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.delete(
  '/notifications/:id',
  requirePermission('communications.notifications.delete'),
  async (req, res) => {
    try {
      const deleted = notifications.deleteNotification(req.params.id);
      res.json({ success: deleted });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/notifications/unread-count',
  requirePermission('communications.notifications.view'),
  async (req, res) => {
    try {
      const count = notifications.getUnreadCount();
      res.json({ success: true, data: { count } });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Performance ==========

router.get(
  '/performance/analysis',
  requirePermission('communications.performance.view'),
  async (req, res) => {
    try {
      const analysis = performance.analyzePerformance();
      res.json({ success: true, data: analysis });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/performance/metrics',
  requirePermission('communications.performance.view'),
  async (req, res) => {
    try {
      const metrics = performance.getMetrics();
      res.json({ success: true, data: metrics });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.post(
  '/performance/reset',
  requirePermission('communications.performance.edit'),
  async (req, res) => {
    try {
      performance.resetMetrics();
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Security ==========

router.get(
  '/security/access-logs',
  requirePermission('communications.security.view'),
  async (req, res) => {
    try {
      const logs = security.getAccessLogs(req.query);
      res.json({ success: true, data: logs });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/security/alerts',
  requirePermission('communications.security.view'),
  async (req, res) => {
    try {
      const alerts = security.getSecurityAlerts(req.query);
      res.json({ success: true, data: alerts });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.put(
  '/security/alerts/:id/acknowledge',
  requirePermission('communications.security.edit'),
  async (req, res) => {
    try {
      const acknowledged = security.acknowledgeAlert(req.params.id);
      res.json({ success: acknowledged });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.post(
  '/security/block-number',
  requirePermission('communications.security.edit'),
  async (req, res) => {
    try {
      const blocked = security.blockNumber(req.body.number);
      res.json({ success: blocked });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.post(
  '/security/unblock-number',
  requirePermission('communications.security.edit'),
  async (req, res) => {
    try {
      const unblocked = security.unblockNumber(req.body.number);
      res.json({ success: unblocked });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Export/Import ==========

router.get('/export/json', requirePermission('communications.export.view'), async (req, res) => {
  try {
    const jsonData = exportManager.exportToJSON(req.query);
    res.setHeader('Content-Type', 'application/json');
    res.setHeader(
      'Content-Disposition',
      `attachment; filename="central-communications-${Date.now()}.json"`
    );
    res.send(jsonData);
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get(
  '/export/csv/:type',
  requirePermission('communications.export.view'),
  async (req, res) => {
    try {
      const csvData = exportManager.exportToCSV(req.params.type, req.query);
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader(
        'Content-Disposition',
        `attachment; filename="central-communications-${req.params.type}-${Date.now()}.csv"`
      );
      res.send(csvData);
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.post('/import/json', requirePermission('communications.import.edit'), async (req, res) => {
  try {
    const result = exportManager.importFromJSON(req.body);
    res.json({ success: true, data: result });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
