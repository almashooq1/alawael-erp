/**
 * 🏆 Advanced Certifications & Accreditations Routes
 * API routes for certifications, accreditations, licenses, and renewals
 */

const express = require('express');
const router = express.Router();

// Mock data storage
const certifications = [];
const accreditations = [];
const licenses = [];
const renewals = [];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Certifications ====================

router.get('/certifications', async (req, res) => {
  try {
    res.json({ success: true, data: certifications });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/certifications/:id', async (req, res) => {
  try {
    const cert = certifications.find(c => c.id === parseInt(req.params.id));
    if (!cert) {
      return res.status(404).json({ success: false, error: 'Certification not found' });
    }
    res.json({ success: true, data: cert });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/certifications', async (req, res) => {
  try {
    const cert = {
      id: certifications.length > 0 ? Math.max(...certifications.map(c => c.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    certifications.push(cert);

    emitEvent('certifications:update', {
      action: 'create',
      entityType: 'certification',
      entityId: cert.id,
      data: cert,
    });

    res.status(201).json({ success: true, data: cert });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/certifications/:id', async (req, res) => {
  try {
    const index = certifications.findIndex(c => c.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Certification not found' });
    }

    certifications[index] = {
      ...certifications[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    emitEvent('certifications:update', {
      action: 'update',
      entityType: 'certification',
      entityId: certifications[index].id,
      data: certifications[index],
    });

    res.json({ success: true, data: certifications[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.delete('/certifications/:id', async (req, res) => {
  try {
    const index = certifications.findIndex(c => c.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Certification not found' });
    }

    const deletedCert = certifications[index];
    certifications.splice(index, 1);

    emitEvent('certifications:update', {
      action: 'delete',
      entityType: 'certification',
      entityId: deletedCert.id,
    });

    res.json({ success: true, message: 'Certification deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Accreditations ====================

router.get('/accreditations', async (req, res) => {
  try {
    res.json({ success: true, data: accreditations });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/accreditations', async (req, res) => {
  try {
    const acc = {
      id: accreditations.length > 0 ? Math.max(...accreditations.map(a => a.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    accreditations.push(acc);

    emitEvent('certifications:update', {
      action: 'create',
      entityType: 'accreditation',
      entityId: acc.id,
      data: acc,
    });

    res.status(201).json({ success: true, data: acc });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Licenses ====================

router.get('/licenses', async (req, res) => {
  try {
    res.json({ success: true, data: licenses });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/licenses', async (req, res) => {
  try {
    const license = {
      id: licenses.length > 0 ? Math.max(...licenses.map(l => l.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    licenses.push(license);

    emitEvent('certifications:update', {
      action: 'create',
      entityType: 'license',
      entityId: license.id,
      data: license,
    });

    res.status(201).json({ success: true, data: license });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Renewals ====================

router.get('/renewals', async (req, res) => {
  try {
    res.json({ success: true, data: renewals });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/renewals', async (req, res) => {
  try {
    const renewal = {
      id: renewals.length > 0 ? Math.max(...renewals.map(r => r.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    renewals.push(renewal);

    emitEvent('certifications:update', {
      action: 'create',
      entityType: 'renewal',
      entityId: renewal.id,
      data: renewal,
    });

    res.status(201).json({ success: true, data: renewal });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
