/**
 * 🏆 Certifications Management Routes
 * مسارات إدارة الشهادات والاعتمادات
 */

const express = require('express');
const router = express.Router();

const mockStub = {
  find: async () => [],
  findById: async () => null,
  findOne: async () => null,
  create: async () => ({}),
  updateOne: async () => ({ modifiedCount: 0 }),
  deleteOne: async () => ({ deletedCount: 0 }),
  countDocuments: async () => 0,
  aggregate: () => ({
    sort: () => ({ limit: () => ({ skip: () => ({ toArray: async () => [] }) }) }),
  }),
};

const Certification = (() => {
  try {
    return require('../models/Certification');
  } catch (e) {
    return mockStub;
  }
})();
const Accreditation = (() => {
  try {
    return require('../models/Accreditation');
  } catch (e) {
    return mockStub;
  }
})();
const License = (() => {
  try {
    return require('../models/License');
  } catch (e) {
    return mockStub;
  }
})();

const authenticateToken = require('../middleware/authenticateToken');
const logger = require('../../shared/logging/logger');

// Real-time event emitter (if available)
let io = null;
try {
  const realtimeModule = require('../realtime');
  io = realtimeModule.io;
} catch (error) {
  // Real-time not available
}

/**
 * Emit real-time event
 */
function emitEvent(eventType, entityType, data) {
  if (io) {
    io.emit('certifications:update', {
      action: eventType,
      entityType: entityType,
      entityId: data.id,
      data: data,
    });
  }
}

// Apply authentication to all routes
router.use(authenticateToken);

/**
 * Certifications Routes
 */
router.get('/', async (req, res) => {
  try {
    const certifications = await Certification.findAll({
      order: [['createdAt', 'DESC']],
    });
    res.json(certifications);
  } catch (error) {
    logger.error('Error fetching certifications:', error);
    res.status(500).json({ error: 'خطأ في جلب الشهادات' });
  }
});

router.post('/', async (req, res) => {
  try {
    const certification = await Certification.create(req.body);
    emitEvent('create', 'certification', certification);
    logger.info('Certification created', { id: certification.id, name: certification.name });
    res.status(201).json(certification);
  } catch (error) {
    logger.error('Error creating certification:', error);
    res.status(400).json({ error: 'خطأ في إضافة الشهادة' });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const [updated] = await Certification.update(req.body, {
      where: { id: req.params.id },
    });
    if (updated) {
      const certification = await Certification.findByPk(req.params.id);
      emitEvent('update', 'certification', certification);
      logger.info('Certification updated', { id: certification.id });
      res.json(certification);
    } else {
      res.status(404).json({ error: 'الشهادة غير موجودة' });
    }
  } catch (error) {
    logger.error('Error updating certification:', error);
    res.status(400).json({ error: 'خطأ في تحديث الشهادة' });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    const deleted = await Certification.destroy({
      where: { id: req.params.id },
    });
    if (deleted) {
      emitEvent('delete', 'certification', { id: req.params.id });
      logger.info('Certification deleted', { id: req.params.id });
      res.json({ message: 'تم حذف الشهادة بنجاح' });
    } else {
      res.status(404).json({ error: 'الشهادة غير موجودة' });
    }
  } catch (error) {
    logger.error('Error deleting certification:', error);
    res.status(400).json({ error: 'خطأ في حذف الشهادة' });
  }
});

/**
 * Accreditations Routes
 */
router.get('/accreditations', async (req, res) => {
  try {
    const accreditations = await Accreditation.findAll({
      order: [['createdAt', 'DESC']],
    });
    res.json(accreditations);
  } catch (error) {
    logger.error('Error fetching accreditations:', error);
    res.status(500).json({ error: 'خطأ في جلب الاعتمادات' });
  }
});

router.post('/accreditations', async (req, res) => {
  try {
    const accreditation = await Accreditation.create(req.body);
    emitEvent('create', 'accreditation', accreditation);
    logger.info('Accreditation created', { id: accreditation.id, name: accreditation.name });
    res.status(201).json(accreditation);
  } catch (error) {
    logger.error('Error creating accreditation:', error);
    res.status(400).json({ error: 'خطأ في إضافة الاعتماد' });
  }
});

/**
 * Licenses Routes
 */
router.get('/licenses', async (req, res) => {
  try {
    const licenses = await License.findAll({
      order: [['createdAt', 'DESC']],
    });
    res.json(licenses);
  } catch (error) {
    logger.error('Error fetching licenses:', error);
    res.status(500).json({ error: 'خطأ في جلب التراخيص' });
  }
});

router.post('/licenses', async (req, res) => {
  try {
    const license = await License.create(req.body);
    emitEvent('create', 'license', license);
    logger.info('License created', { id: license.id, name: license.name });
    res.status(201).json(license);
  } catch (error) {
    logger.error('Error creating license:', error);
    res.status(400).json({ error: 'خطأ في إضافة الترخيص' });
  }
});

module.exports = router;
