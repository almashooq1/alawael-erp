/**
 * 📝 Advanced Complaints & Suggestions Routes
 * API routes for complaints, suggestions, tickets, and resolutions
 */

const express = require('express');
const router = express.Router();

// Mock data storage
const complaints = [];
const suggestions = [];
const tickets = [];
const resolutions = [];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Complaints ====================

router.get('/complaints', async (req, res) => {
  try {
    res.json({ success: true, data: complaints });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/complaints/:id', async (req, res) => {
  try {
    const complaint = complaints.find(c => c.id === parseInt(req.params.id));
    if (!complaint) {
      return res.status(404).json({ success: false, error: 'Complaint not found' });
    }
    res.json({ success: true, data: complaint });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/complaints', async (req, res) => {
  try {
    const complaint = {
      id: complaints.length > 0 ? Math.max(...complaints.map(c => c.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    complaints.push(complaint);

    emitEvent('complaints:update', {
      action: 'create',
      entityType: 'complaint',
      entityId: complaint.id,
      data: complaint,
    });

    res.status(201).json({ success: true, data: complaint });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/complaints/:id', async (req, res) => {
  try {
    const index = complaints.findIndex(c => c.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Complaint not found' });
    }

    complaints[index] = {
      ...complaints[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    emitEvent('complaints:update', {
      action: 'update',
      entityType: 'complaint',
      entityId: complaints[index].id,
      data: complaints[index],
    });

    res.json({ success: true, data: complaints[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.delete('/complaints/:id', async (req, res) => {
  try {
    const index = complaints.findIndex(c => c.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Complaint not found' });
    }

    const deletedComplaint = complaints[index];
    complaints.splice(index, 1);

    emitEvent('complaints:update', {
      action: 'delete',
      entityType: 'complaint',
      entityId: deletedComplaint.id,
    });

    res.json({ success: true, message: 'Complaint deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Suggestions ====================

router.get('/suggestions', async (req, res) => {
  try {
    res.json({ success: true, data: suggestions });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/suggestions', async (req, res) => {
  try {
    const suggestion = {
      id: suggestions.length > 0 ? Math.max(...suggestions.map(s => s.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    suggestions.push(suggestion);

    emitEvent('complaints:update', {
      action: 'create',
      entityType: 'suggestion',
      entityId: suggestion.id,
      data: suggestion,
    });

    res.status(201).json({ success: true, data: suggestion });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Tickets ====================

router.get('/tickets', async (req, res) => {
  try {
    res.json({ success: true, data: tickets });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/tickets', async (req, res) => {
  try {
    const ticket = {
      id: tickets.length > 0 ? Math.max(...tickets.map(t => t.id)) + 1 : 1,
      ticketNumber: `TKT-${Date.now()}`,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    tickets.push(ticket);

    emitEvent('complaints:update', {
      action: 'create',
      entityType: 'ticket',
      entityId: ticket.id,
      data: ticket,
    });

    res.status(201).json({ success: true, data: ticket });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Resolutions ====================

router.get('/resolutions', async (req, res) => {
  try {
    res.json({ success: true, data: resolutions });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/resolutions', async (req, res) => {
  try {
    const resolution = {
      id: resolutions.length > 0 ? Math.max(...resolutions.map(r => r.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    resolutions.push(resolution);

    emitEvent('complaints:update', {
      action: 'create',
      entityType: 'resolution',
      entityId: resolution.id,
      data: resolution,
    });

    res.status(201).json({ success: true, data: resolution });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
