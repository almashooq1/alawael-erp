/**
 * 💬 Complaints & Suggestions Management Routes
 * مسارات إدارة الشكاوى والاقتراحات
 */

const express = require('express');
const router = express.Router();
const Complaint = require('../models/Complaint');
const Suggestion = require('../models/Suggestion');
const authenticateToken = require('../middleware/authenticateToken');
const logger = require('../../shared/logging/logger');

// Real-time event emitter (if available)
let io = null;
try {
  const realtimeModule = require('../realtime');
  io = realtimeModule.io;
} catch (error) {
  // Real-time not available
}

/**
 * Emit real-time event
 */
function emitEvent(eventType, entityType, data) {
  if (io) {
    io.emit('complaintsSuggestions:update', {
      action: eventType,
      entityType: entityType,
      entityId: data.id,
      data: data,
    });
  }
}

// Apply authentication to all routes
router.use(authenticateToken);

/**
 * Complaints Routes
 */
router.get('/complaints', async (req, res) => {
  try {
    const complaints = await Complaint.findAll({
      order: [['createdAt', 'DESC']],
      limit: 100,
    });
    res.json(complaints);
  } catch (error) {
    logger.error('Error fetching complaints:', error);
    res.status(500).json({ error: 'خطأ في جلب الشكاوى' });
  }
});

router.post('/complaints', async (req, res) => {
  try {
    const complaint = await Complaint.create(req.body);
    emitEvent('create', 'complaint', complaint);
    logger.info('Complaint created', { id: complaint.id });
    res.status(201).json(complaint);
  } catch (error) {
    logger.error('Error creating complaint:', error);
    res.status(400).json({ error: 'خطأ في إضافة الشكوى' });
  }
});

/**
 * Suggestions Routes
 */
router.get('/suggestions', async (req, res) => {
  try {
    const suggestions = await Suggestion.findAll({
      order: [['createdAt', 'DESC']],
      limit: 100,
    });
    res.json(suggestions);
  } catch (error) {
    logger.error('Error fetching suggestions:', error);
    res.status(500).json({ error: 'خطأ في جلب الاقتراحات' });
  }
});

router.post('/suggestions', async (req, res) => {
  try {
    const suggestion = await Suggestion.create(req.body);
    emitEvent('create', 'suggestion', suggestion);
    logger.info('Suggestion created', { id: suggestion.id });
    res.status(201).json(suggestion);
  } catch (error) {
    logger.error('Error creating suggestion:', error);
    res.status(400).json({ error: 'خطأ في إضافة الاقتراح' });
  }
});

module.exports = router;
