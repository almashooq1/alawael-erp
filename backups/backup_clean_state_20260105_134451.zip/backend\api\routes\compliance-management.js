/**
 * ✅ Compliance Management Routes
 * API routes for compliance management system
 */

const express = require('express');
const router = express.Router();

// Mock data storage (replace with database)
const requirements = [];
const audits = [];
const certifications = [];
const violations = [];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Requirements ====================

router.get('/requirements', async (req, res) => {
  try {
    const { standard, status } = req.query;
    let filtered = requirements;

    if (standard) {
      filtered = filtered.filter(r => r.standard === standard);
    }

    if (status) {
      filtered = filtered.filter(r => r.status === status);
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.get('/requirements/:id', async (req, res) => {
  try {
    const requirement = requirements.find(r => r.id === parseInt(req.params.id));
    if (!requirement) {
      return res.status(404).json({
        success: false,
        error: 'Requirement not found',
      });
    }
    res.json({
      success: true,
      data: requirement,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/requirements', async (req, res) => {
  try {
    const requirement = {
      id: requirements.length > 0 ? Math.max(...requirements.map(r => r.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'pending',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    requirements.push(requirement);

    emitEvent('compliance:requirement:updated', {
      action: 'create',
      entityId: requirement.id,
      data: requirement,
    });

    res.json({
      success: true,
      data: requirement,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.put('/requirements/:id', async (req, res) => {
  try {
    const index = requirements.findIndex(r => r.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Requirement not found',
      });
    }

    requirements[index] = {
      ...requirements[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    emitEvent('compliance:requirement:updated', {
      action: 'update',
      entityId: requirements[index].id,
      data: requirements[index],
    });

    res.json({
      success: true,
      data: requirements[index],
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.delete('/requirements/:id', async (req, res) => {
  try {
    const index = requirements.findIndex(r => r.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Requirement not found',
      });
    }

    requirements.splice(index, 1);

    emitEvent('compliance:requirement:updated', {
      action: 'delete',
      entityId: parseInt(req.params.id),
    });

    res.json({
      success: true,
      message: 'Requirement deleted successfully',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Audits ====================

router.get('/audits', async (req, res) => {
  try {
    res.json({
      success: true,
      data: audits,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/audits', async (req, res) => {
  try {
    const audit = {
      id: audits.length > 0 ? Math.max(...audits.map(a => a.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
    };

    audits.push(audit);

    emitEvent('compliance:audit:updated', {
      action: 'create',
      entityId: audit.id,
      data: audit,
    });

    res.json({
      success: true,
      data: audit,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Certifications ====================

router.get('/certifications', async (req, res) => {
  try {
    res.json({
      success: true,
      data: certifications,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/certifications', async (req, res) => {
  try {
    const certification = {
      id: certifications.length > 0 ? Math.max(...certifications.map(c => c.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
    };

    certifications.push(certification);

    res.json({
      success: true,
      data: certification,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Violations ====================

router.get('/violations', async (req, res) => {
  try {
    const { severity, standard } = req.query;
    let filtered = violations;

    if (severity) {
      filtered = filtered.filter(v => v.severity === severity);
    }

    if (standard) {
      filtered = filtered.filter(v => v.standard === standard);
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/violations', async (req, res) => {
  try {
    const violation = {
      id: violations.length > 0 ? Math.max(...violations.map(v => v.id)) + 1 : 1,
      ...req.body,
      discoveredDate: req.body.discoveredDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
    };

    violations.push(violation);

    emitEvent('compliance:violation:updated', {
      action: 'create',
      entityId: violation.id,
      data: violation,
    });

    res.json({
      success: true,
      data: violation,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

module.exports = { router, setIO };
