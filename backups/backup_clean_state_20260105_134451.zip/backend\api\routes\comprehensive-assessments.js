/**
 * 📊 Comprehensive Assessments & Tests Management Routes
 */

const express = require('express');
const router = express.Router();

// أنواع المقاييس والاختبارات الشاملة
const assessments = [
  {
    id: 1,
    name: 'مقياس وكسلر للذكاء',
    category: 'cognitive',
    type: 'standardized',
    targetDisability: 'intellectual',
    questionsCount: 15,
    duration: '60-90 دقيقة',
    ageRange: '6-90 سنة',
    description: 'مقياس شامل لتقييم القدرات المعرفية والذكاء العام',
    status: 'active',
  },
  {
    id: 2,
    name: 'مقياس CARS للتوحد',
    category: 'behavioral',
    type: 'standardized',
    targetDisability: 'autism',
    questionsCount: 15,
    duration: '30-45 دقيقة',
    ageRange: 'جميع الأعمار',
    description: 'مقياس لتشخيص اضطراب طيف التوحد',
    status: 'active',
  },
  {
    id: 3,
    name: 'مقياس كونرز لفرط الحركة',
    category: 'behavioral',
    type: 'standardized',
    targetDisability: 'adhd',
    questionsCount: 18,
    duration: '20-30 دقيقة',
    ageRange: '6-18 سنة',
    description: 'مقياس لتقييم اضطراب فرط الحركة وتشتت الانتباه',
    status: 'active',
  },
  {
    id: 4,
    name: 'مقياس فاينلاند للسلوك التكيفي',
    category: 'adaptive',
    type: 'standardized',
    targetDisability: 'intellectual',
    questionsCount: 20,
    duration: '45-60 دقيقة',
    ageRange: '0-90 سنة',
    description: 'مقياس لتقييم المهارات التكيفية اليومية',
    status: 'active',
  },
  {
    id: 5,
    name: 'مقياس المهارات الحركية',
    category: 'motor',
    type: 'performance',
    targetDisability: 'physical',
    questionsCount: 12,
    duration: '30-45 دقيقة',
    ageRange: 'جميع الأعمار',
    description: 'تقييم المهارات الحركية الدقيقة والكلية',
    status: 'active',
  },
  {
    id: 6,
    name: 'مقياس التواصل اللغوي',
    category: 'communication',
    type: 'standardized',
    targetDisability: 'multiple',
    questionsCount: 16,
    duration: '40-50 دقيقة',
    ageRange: 'جميع الأعمار',
    description: 'تقييم مهارات التواصل واللغة',
    status: 'active',
  },
  {
    id: 7,
    name: 'مقياس المهارات الاجتماعية',
    category: 'social',
    type: 'observation',
    targetDisability: 'autism',
    questionsCount: 14,
    duration: '35-45 دقيقة',
    ageRange: 'جميع الأعمار',
    description: 'تقييم المهارات الاجتماعية والتفاعل',
    status: 'active',
  },
  {
    id: 8,
    name: 'مقياس الذاكرة والانتباه',
    category: 'cognitive',
    type: 'standardized',
    targetDisability: 'adhd',
    questionsCount: 10,
    duration: '25-35 دقيقة',
    ageRange: '6-18 سنة',
    description: 'تقييم الذاكرة والانتباه والتركيز',
    status: 'active',
  },
  {
    id: 9,
    name: 'مقياس المهارات الحسية',
    category: 'adaptive',
    type: 'performance',
    targetDisability: 'multiple',
    questionsCount: 8,
    duration: '20-30 دقيقة',
    ageRange: 'جميع الأعمار',
    description: 'تقييم المعالجة الحسية والاستجابة',
    status: 'active',
  },
  {
    id: 10,
    name: 'مقياس التكامل الحسي',
    category: 'adaptive',
    type: 'observation',
    targetDisability: 'autism',
    questionsCount: 12,
    duration: '30-40 دقيقة',
    ageRange: 'جميع الأعمار',
    description: 'تقييم التكامل الحسي والاستجابة للمحفزات',
    status: 'active',
  },
  {
    id: 11,
    name: 'مقياس بيب للتنمية',
    category: 'cognitive',
    type: 'standardized',
    targetDisability: 'multiple',
    questionsCount: 178,
    duration: '45-60 دقيقة',
    ageRange: '0-3 سنوات',
    description: 'مقياس شامل لتقييم التنمية في مرحلة الطفولة المبكرة',
    status: 'active',
  },
  {
    id: 12,
    name: 'مقياس ستانفورد بينيه للذكاء',
    category: 'cognitive',
    type: 'standardized',
    targetDisability: 'intellectual',
    questionsCount: 10,
    duration: '45-90 دقيقة',
    ageRange: '2-85 سنة',
    description: 'مقياس ذكاء شامل ومتعدد الأبعاد',
    status: 'active',
  },
  {
    id: 13,
    name: 'مقياس المهارات الحياتية اليومية',
    category: 'adaptive',
    type: 'performance',
    targetDisability: 'multiple',
    questionsCount: 15,
    duration: '30-45 دقيقة',
    ageRange: 'جميع الأعمار',
    description: 'تقييم المهارات الحياتية الأساسية والاستقلالية',
    status: 'active',
  },
  {
    id: 14,
    name: 'مقياس المهارات البصرية',
    category: 'cognitive',
    type: 'performance',
    targetDisability: 'visual',
    questionsCount: 10,
    duration: '25-35 دقيقة',
    ageRange: 'جميع الأعمار',
    description: 'تقييم المهارات البصرية والإدراك البصري',
    status: 'active',
  },
  {
    id: 15,
    name: 'مقياس المهارات السمعية',
    category: 'communication',
    type: 'performance',
    targetDisability: 'hearing',
    questionsCount: 12,
    duration: '30-40 دقيقة',
    ageRange: 'جميع الأعمار',
    description: 'تقييم المهارات السمعية والإدراك السمعي',
    status: 'active',
  },
  {
    id: 16,
    name: 'مقياس المهارات الأكاديمية',
    category: 'cognitive',
    type: 'standardized',
    targetDisability: 'intellectual',
    questionsCount: 20,
    duration: '40-50 دقيقة',
    ageRange: '6-18 سنة',
    description: 'تقييم المهارات الأكاديمية الأساسية (قراءة، كتابة، حساب)',
    status: 'active',
  },
  {
    id: 17,
    name: 'مقياس السلوك التكيفي للأطفال',
    category: 'adaptive',
    type: 'standardized',
    targetDisability: 'intellectual',
    questionsCount: 18,
    duration: '35-45 دقيقة',
    ageRange: '3-18 سنة',
    description: 'تقييم السلوك التكيفي والمهارات اليومية للأطفال',
    status: 'active',
  },
  {
    id: 18,
    name: 'مقياس المهارات التنفيذية',
    category: 'cognitive',
    type: 'standardized',
    targetDisability: 'adhd',
    questionsCount: 16,
    duration: '30-40 دقيقة',
    ageRange: '6-18 سنة',
    description: 'تقييم المهارات التنفيذية (التخطيط، التنظيم، التحكم)',
    status: 'active',
  },
  {
    id: 19,
    name: 'مقياس القلق والاكتئاب',
    category: 'behavioral',
    type: 'standardized',
    targetDisability: 'multiple',
    questionsCount: 14,
    duration: '20-30 دقيقة',
    ageRange: '8-18 سنة',
    description: 'تقييم أعراض القلق والاكتئاب',
    status: 'active',
  },
  {
    id: 20,
    name: 'مقياس المهارات اللعب',
    category: 'social',
    type: 'observation',
    targetDisability: 'autism',
    questionsCount: 10,
    duration: '25-35 دقيقة',
    ageRange: '2-12 سنة',
    description: 'تقييم مهارات اللعب والتفاعل الاجتماعي',
    status: 'active',
  },
  {
    id: 21,
    name: 'مقياس المهارات الحركية الدقيقة',
    category: 'motor',
    type: 'performance',
    targetDisability: 'physical',
    questionsCount: 8,
    duration: '20-30 دقيقة',
    ageRange: 'جميع الأعمار',
    description: 'تقييم المهارات الحركية الدقيقة (اليد، الأصابع)',
    status: 'active',
  },
  {
    id: 22,
    name: 'مقياس المهارات الحركية الكلية',
    category: 'motor',
    type: 'performance',
    targetDisability: 'physical',
    questionsCount: 10,
    duration: '25-35 دقيقة',
    ageRange: 'جميع الأعمار',
    description: 'تقييم المهارات الحركية الكلية (المشي، الجري، التوازن)',
    status: 'active',
  },
  {
    id: 23,
    name: 'مقياس اللغة الاستقبالية',
    category: 'communication',
    type: 'standardized',
    targetDisability: 'multiple',
    questionsCount: 12,
    duration: '30-40 دقيقة',
    ageRange: 'جميع الأعمار',
    description: 'تقييم فهم اللغة والاستجابة للكلام',
    status: 'active',
  },
  {
    id: 24,
    name: 'مقياس اللغة التعبيرية',
    category: 'communication',
    type: 'standardized',
    targetDisability: 'multiple',
    questionsCount: 14,
    duration: '35-45 دقيقة',
    ageRange: 'جميع الأعمار',
    description: 'تقييم القدرة على التعبير اللغوي والتواصل',
    status: 'active',
  },
  {
    id: 25,
    name: 'مقياس التفاعل الاجتماعي',
    category: 'social',
    type: 'observation',
    targetDisability: 'autism',
    questionsCount: 16,
    duration: '40-50 دقيقة',
    ageRange: 'جميع الأعمار',
    description: 'تقييم التفاعل الاجتماعي ومهارات التواصل الاجتماعي',
    status: 'active',
  },
  {
    id: 26,
    name: 'مقياس النطق والكلام',
    category: 'communication',
    type: 'standardized',
    targetDisability: 'multiple',
    questionsCount: 12,
    duration: '30-40 دقيقة',
    ageRange: 'جميع الأعمار',
    description: 'تقييم مهارات النطق والكلام والوضوح',
    status: 'active',
  },
  {
    id: 27,
    name: 'مقياس اضطرابات النطق',
    category: 'communication',
    type: 'standardized',
    targetDisability: 'multiple',
    questionsCount: 14,
    duration: '35-45 دقيقة',
    ageRange: 'جميع الأعمار',
    description: 'تقييم اضطرابات النطق والصوت',
    status: 'active',
  },
  {
    id: 28,
    name: 'مقياس الطلاقة اللغوية',
    category: 'communication',
    type: 'performance',
    targetDisability: 'multiple',
    questionsCount: 10,
    duration: '25-35 دقيقة',
    ageRange: 'جميع الأعمار',
    description: 'تقييم الطلاقة اللغوية وسرعة الكلام',
    status: 'active',
  },
  {
    id: 29,
    name: 'مقياس المهارات المهنية',
    category: 'adaptive',
    type: 'performance',
    targetDisability: 'multiple',
    questionsCount: 15,
    duration: '40-50 دقيقة',
    ageRange: '16-65 سنة',
    description: 'تقييم المهارات المهنية والاستعداد للعمل',
    status: 'active',
  },
  {
    id: 30,
    name: 'مقياس الاستعداد المهني',
    category: 'adaptive',
    type: 'standardized',
    targetDisability: 'intellectual',
    questionsCount: 18,
    duration: '45-55 دقيقة',
    ageRange: '16-65 سنة',
    description: 'تقييم الاستعداد المهني والمهارات العملية',
    status: 'active',
  },
  {
    id: 31,
    name: 'مقياس المهارات الحرفية',
    category: 'motor',
    type: 'performance',
    targetDisability: 'physical',
    questionsCount: 12,
    duration: '30-40 دقيقة',
    ageRange: 'جميع الأعمار',
    description: 'تقييم المهارات الحرفية واليدوية',
    status: 'active',
  },
  {
    id: 32,
    name: 'مقياس الصحة النفسية',
    category: 'behavioral',
    type: 'standardized',
    targetDisability: 'multiple',
    questionsCount: 20,
    duration: '40-50 دقيقة',
    ageRange: 'جميع الأعمار',
    description: 'تقييم الصحة النفسية العامة',
    status: 'active',
  },
  {
    id: 33,
    name: 'مقياس الضغط النفسي',
    category: 'behavioral',
    type: 'standardized',
    targetDisability: 'multiple',
    questionsCount: 14,
    duration: '25-35 دقيقة',
    ageRange: 'جميع الأعمار',
    description: 'تقييم مستوى الضغط النفسي والتوتر',
    status: 'active',
  },
  {
    id: 34,
    name: 'مقياس احترام الذات',
    category: 'behavioral',
    type: 'standardized',
    targetDisability: 'multiple',
    questionsCount: 10,
    duration: '20-30 دقيقة',
    ageRange: 'جميع الأعمار',
    description: 'تقييم مستوى احترام الذات والثقة بالنفس',
    status: 'active',
  },
  {
    id: 35,
    name: 'مقياس التغذية والصحة',
    category: 'adaptive',
    type: 'observation',
    targetDisability: 'multiple',
    questionsCount: 12,
    duration: '30-40 دقيقة',
    ageRange: 'جميع الأعمار',
    description: 'تقييم العادات الغذائية والصحية',
    status: 'active',
  },
  {
    id: 36,
    name: 'مقياس النوم والراحة',
    category: 'adaptive',
    type: 'observation',
    targetDisability: 'multiple',
    questionsCount: 10,
    duration: '20-30 دقيقة',
    ageRange: 'جميع الأعمار',
    description: 'تقييم أنماط النوم والراحة',
    status: 'active',
  },
  {
    id: 37,
    name: 'مقياس الاستقلالية',
    category: 'adaptive',
    type: 'performance',
    targetDisability: 'multiple',
    questionsCount: 16,
    duration: '40-50 دقيقة',
    ageRange: 'جميع الأعمار',
    description: 'تقييم مستوى الاستقلالية في الحياة اليومية',
    status: 'active',
  },
  {
    id: 38,
    name: 'مقياس الاعتماد على الذات',
    category: 'adaptive',
    type: 'performance',
    targetDisability: 'physical',
    questionsCount: 14,
    duration: '35-45 دقيقة',
    ageRange: 'جميع الأعمار',
    description: 'تقييم القدرة على الاعتماد على الذات',
    status: 'active',
  },
  {
    id: 39,
    name: 'مقياس المهارات المالية',
    category: 'adaptive',
    type: 'performance',
    targetDisability: 'intellectual',
    questionsCount: 12,
    duration: '30-40 دقيقة',
    ageRange: '16-65 سنة',
    description: 'تقييم المهارات المالية وإدارة المال',
    status: 'active',
  },
  {
    id: 40,
    name: 'مقياس المهارات المنزلية',
    category: 'adaptive',
    type: 'performance',
    targetDisability: 'multiple',
    questionsCount: 15,
    duration: '35-45 دقيقة',
    ageRange: 'جميع الأعمار',
    description: 'تقييم المهارات المنزلية والاعتناء بالذات',
    status: 'active',
  },
  {
    id: 41,
    name: 'مقياس الإبداع والابتكار',
    category: 'cognitive',
    type: 'performance',
    targetDisability: 'multiple',
    questionsCount: 12,
    duration: '30-40 دقيقة',
    ageRange: 'جميع الأعمار',
    description: 'تقييم القدرات الإبداعية والابتكارية',
    status: 'active',
  },
  {
    id: 42,
    name: 'مقياس حل المشكلات',
    category: 'cognitive',
    type: 'standardized',
    targetDisability: 'multiple',
    questionsCount: 14,
    duration: '35-45 دقيقة',
    ageRange: 'جميع الأعمار',
    description: 'تقييم مهارات حل المشكلات والتفكير النقدي',
    status: 'active',
  },
  {
    id: 43,
    name: 'مقياس الذاكرة طويلة المدى',
    category: 'cognitive',
    type: 'standardized',
    targetDisability: 'intellectual',
    questionsCount: 10,
    duration: '25-35 دقيقة',
    ageRange: 'جميع الأعمار',
    description: 'تقييم الذاكرة طويلة المدى والاستدعاء',
    status: 'active',
  },
  {
    id: 44,
    name: 'مقياس الذاكرة قصيرة المدى',
    category: 'cognitive',
    type: 'standardized',
    targetDisability: 'intellectual',
    questionsCount: 10,
    duration: '25-35 دقيقة',
    ageRange: 'جميع الأعمار',
    description: 'تقييم الذاكرة قصيرة المدى والعاملة',
    status: 'active',
  },
  {
    id: 45,
    name: 'مقياس التوجه المكاني',
    category: 'cognitive',
    type: 'performance',
    targetDisability: 'visual',
    questionsCount: 8,
    duration: '20-30 دقيقة',
    ageRange: 'جميع الأعمار',
    description: 'تقييم التوجه المكاني والتنقل',
    status: 'active',
  },
  {
    id: 46,
    name: 'مقياس المهارات الرياضية',
    category: 'cognitive',
    type: 'standardized',
    targetDisability: 'intellectual',
    questionsCount: 16,
    duration: '40-50 دقيقة',
    ageRange: '6-18 سنة',
    description: 'تقييم المهارات الرياضية والحسابية',
    status: 'active',
  },
  {
    id: 47,
    name: 'مقياس القراءة والفهم',
    category: 'cognitive',
    type: 'standardized',
    targetDisability: 'intellectual',
    questionsCount: 14,
    duration: '35-45 دقيقة',
    ageRange: '6-18 سنة',
    description: 'تقييم مهارات القراءة والفهم القرائي',
    status: 'active',
  },
  {
    id: 48,
    name: 'مقياس الكتابة والتعبير',
    category: 'cognitive',
    type: 'performance',
    targetDisability: 'intellectual',
    questionsCount: 12,
    duration: '30-40 دقيقة',
    ageRange: '6-18 سنة',
    description: 'تقييم مهارات الكتابة والتعبير الكتابي',
    status: 'active',
  },
  {
    id: 49,
    name: 'مقياس المهارات العاطفية',
    category: 'social',
    type: 'standardized',
    targetDisability: 'autism',
    questionsCount: 14,
    duration: '35-45 دقيقة',
    ageRange: 'جميع الأعمار',
    description: 'تقييم الذكاء العاطفي والمهارات العاطفية',
    status: 'active',
  },
  {
    id: 50,
    name: 'مقياس التعاطف والتفهم',
    category: 'social',
    type: 'observation',
    targetDisability: 'autism',
    questionsCount: 12,
    duration: '30-40 دقيقة',
    ageRange: 'جميع الأعمار',
    description: 'تقييم القدرة على التعاطف وفهم مشاعر الآخرين',
    status: 'active',
  },
];

const tests = [];
const categories = [
  {
    id: 1,
    name: 'إدراكي',
    description: 'مقاييس واختبارات القدرات المعرفية والذكاء',
    assessmentsCount: 13,
  },
  {
    id: 2,
    name: 'سلوكي',
    description: 'مقاييس واختبارات السلوك والاضطرابات النفسية',
    assessmentsCount: 6,
  },
  { id: 3, name: 'حركي', description: 'مقاييس واختبارات المهارات الحركية', assessmentsCount: 4 },
  { id: 4, name: 'تواصلي', description: 'مقاييس واختبارات التواصل واللغة', assessmentsCount: 6 },
  {
    id: 5,
    name: 'اجتماعي',
    description: 'مقاييس واختبارات المهارات الاجتماعية',
    assessmentsCount: 4,
  },
  {
    id: 6,
    name: 'تكيفي',
    description: 'مقاييس واختبارات المهارات التكيفية والحياتية',
    assessmentsCount: 12,
  },
];
const results = [];
const scales = [
  {
    id: 1,
    name: 'مقياس وكسلر للذكاء',
    standard: 'معياري',
    type: 'ذكاء',
    ageRange: '6-90 سنة',
    reliability: '0.95',
  },
  {
    id: 2,
    name: 'مقياس CARS',
    standard: 'معياري',
    type: 'توحد',
    ageRange: 'جميع الأعمار',
    reliability: '0.92',
  },
  {
    id: 3,
    name: 'مقياس كونرز',
    standard: 'معياري',
    type: 'فرط حركة',
    ageRange: '6-18 سنة',
    reliability: '0.89',
  },
  {
    id: 4,
    name: 'مقياس فاينلاند',
    standard: 'معياري',
    type: 'تكيفي',
    ageRange: '0-90 سنة',
    reliability: '0.91',
  },
  {
    id: 5,
    name: 'مقياس بيب',
    standard: 'معياري',
    type: 'تنمية',
    ageRange: '0-3 سنوات',
    reliability: '0.93',
  },
  {
    id: 6,
    name: 'مقياس ستانفورد بينيه',
    standard: 'معياري',
    type: 'ذكاء',
    ageRange: '2-85 سنة',
    reliability: '0.94',
  },
  {
    id: 7,
    name: 'مقياس فينلاند للسلوك التكيفي',
    standard: 'معياري',
    type: 'تكيفي',
    ageRange: '0-90 سنة',
    reliability: '0.91',
  },
  {
    id: 8,
    name: 'مقياس جيليام للتوحد',
    standard: 'معياري',
    type: 'توحد',
    ageRange: '3-22 سنة',
    reliability: '0.90',
  },
  {
    id: 9,
    name: 'مقياس التوحد للأطفال',
    standard: 'معياري',
    type: 'توحد',
    ageRange: '18 شهر - 5 سنوات',
    reliability: '0.88',
  },
  {
    id: 10,
    name: 'مقياس فينلاند للسلوك التكيفي - الإصدار الثالث',
    standard: 'معياري',
    type: 'تكيفي',
    ageRange: '0-90 سنة',
    reliability: '0.92',
  },
];
const templates = [];
const reports = [];
const progress = [];
const recommendations = [];
const treatmentPlans = [];
const aiInsights = [];

let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

router.get('/assessments', async (req, res) => {
  try {
    const { category, type, status, disability } = req.query;
    let filtered = assessments;
    if (category) filtered = filtered.filter(a => a.category === category);
    if (type) filtered = filtered.filter(a => a.type === type);
    if (status) filtered = filtered.filter(a => a.status === status);
    if (disability) filtered = filtered.filter(a => a.targetDisability === disability);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/assessments', async (req, res) => {
  try {
    const assessment = {
      id: assessments.length > 0 ? Math.max(...assessments.map(a => a.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      questionsCount: req.body.questionsCount || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    assessments.push(assessment);
    emitEvent('comprehensive-assessments:updated', {
      action: 'create',
      entityType: 'assessment',
      entityId: assessment.id,
      data: assessment,
    });
    res.json({ success: true, data: assessment });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/tests', async (req, res) => {
  try {
    const { category, type } = req.query;
    let filtered = tests;
    if (category) filtered = filtered.filter(t => t.category === category);
    if (type) filtered = filtered.filter(t => t.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/tests', async (req, res) => {
  try {
    const test = {
      id: tests.length > 0 ? Math.max(...tests.map(t => t.id)) + 1 : 1,
      ...req.body,
      questionsCount: req.body.questionsCount || 0,
      maxScore: req.body.maxScore || 100,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    tests.push(test);
    emitEvent('comprehensive-assessments:updated', {
      action: 'create',
      entityType: 'test',
      entityId: test.id,
      data: test,
    });
    res.json({ success: true, data: test });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/categories', async (req, res) => {
  try {
    res.json({ success: true, data: categories });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/results', async (req, res) => {
  try {
    const { patientId, assessmentId } = req.query;
    let filtered = results;
    if (patientId) filtered = filtered.filter(r => r.patientId === parseInt(patientId));
    if (assessmentId) filtered = filtered.filter(r => r.assessmentId === parseInt(assessmentId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/results', async (req, res) => {
  try {
    const result = {
      id: results.length > 0 ? Math.max(...results.map(r => r.id)) + 1 : 1,
      ...req.body,
      date: req.body.date || new Date().toISOString(),
      score: req.body.score || 0,
      maxScore: req.body.maxScore || 100,
      percentage: req.body.percentage || 0,
      level: req.body.level || 'average',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    results.push(result);
    emitEvent('comprehensive-assessments:updated', {
      action: 'create',
      entityType: 'result',
      entityId: result.id,
      data: result,
    });
    res.json({ success: true, data: result });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/scales', async (req, res) => {
  try {
    res.json({ success: true, data: scales });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/scales', async (req, res) => {
  try {
    const scale = {
      id: scales.length > 0 ? Math.max(...scales.map(s => s.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    scales.push(scale);
    emitEvent('comprehensive-assessments:updated', {
      action: 'create',
      entityType: 'scale',
      entityId: scale.id,
      data: scale,
    });
    res.json({ success: true, data: scale });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/templates', async (req, res) => {
  try {
    res.json({ success: true, data: templates });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/templates', async (req, res) => {
  try {
    const template = {
      id: templates.length > 0 ? Math.max(...templates.map(t => t.id)) + 1 : 1,
      ...req.body,
      type: req.body.type || 'general',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    templates.push(template);
    emitEvent('comprehensive-assessments:updated', {
      action: 'create',
      entityType: 'template',
      entityId: template.id,
      data: template,
    });
    res.json({ success: true, data: template });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/reports', async (req, res) => {
  try {
    const { patientId, type } = req.query;
    let filtered = reports;
    if (patientId) filtered = filtered.filter(r => r.patientId === parseInt(patientId));
    if (type) filtered = filtered.filter(r => r.type === type);
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/reports', async (req, res) => {
  try {
    const report = {
      id: reports.length > 0 ? Math.max(...reports.map(r => r.id)) + 1 : 1,
      ...req.body,
      date: req.body.date || new Date().toISOString(),
      type: req.body.type || 'assessment',
      size: req.body.size || 'غير محدد',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    reports.push(report);
    emitEvent('comprehensive-assessments:updated', {
      action: 'create',
      entityType: 'report',
      entityId: report.id,
      data: report,
    });
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/progress', async (req, res) => {
  try {
    const { patientId, assessmentId } = req.query;
    let filtered = progress;
    if (patientId) filtered = filtered.filter(p => p.patientId === parseInt(patientId));
    if (assessmentId) filtered = filtered.filter(p => p.assessmentId === parseInt(assessmentId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/progress', async (req, res) => {
  try {
    const progressData = {
      id: progress.length > 0 ? Math.max(...progress.map(p => p.id)) + 1 : 1,
      ...req.body,
      history: req.body.history || [],
      overallChange: req.body.overallChange || 0,
      evaluationsCount: req.body.evaluationsCount || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    progress.push(progressData);
    emitEvent('comprehensive-assessments:updated', {
      action: 'create',
      entityType: 'progress',
      entityId: progressData.id,
      data: progressData,
    });
    res.json({ success: true, data: progressData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/recommendations', async (req, res) => {
  try {
    const { priority, category, patientId } = req.query;
    let filtered = recommendations;
    if (priority) filtered = filtered.filter(r => r.priority === priority);
    if (category) filtered = filtered.filter(r => r.category === category);
    if (patientId) filtered = filtered.filter(r => r.patientId === parseInt(patientId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/recommendations', async (req, res) => {
  try {
    const recommendation = {
      id: recommendations.length > 0 ? Math.max(...recommendations.map(r => r.id)) + 1 : 1,
      ...req.body,
      priority: req.body.priority || 'medium',
      actions: req.body.actions || [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    recommendations.push(recommendation);
    emitEvent('comprehensive-assessments:updated', {
      action: 'create',
      entityType: 'recommendation',
      entityId: recommendation.id,
      data: recommendation,
    });
    res.json({ success: true, data: recommendation });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/treatment-plans', async (req, res) => {
  try {
    const { status, patientId } = req.query;
    let filtered = treatmentPlans;
    if (status) filtered = filtered.filter(t => t.status === status);
    if (patientId) filtered = filtered.filter(t => t.patientId === parseInt(patientId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/treatment-plans', async (req, res) => {
  try {
    const treatmentPlan = {
      id: treatmentPlans.length > 0 ? Math.max(...treatmentPlans.map(t => t.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      progress: req.body.progress || 0,
      goals: req.body.goals || [],
      startDate: req.body.startDate || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    treatmentPlans.push(treatmentPlan);
    emitEvent('comprehensive-assessments:updated', {
      action: 'create',
      entityType: 'treatmentPlan',
      entityId: treatmentPlan.id,
      data: treatmentPlan,
    });
    res.json({ success: true, data: treatmentPlan });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/ai-insights', async (req, res) => {
  try {
    const { type, patientId } = req.query;
    let filtered = aiInsights;
    if (type) filtered = filtered.filter(i => i.type === type);
    if (patientId) filtered = filtered.filter(i => i.patientId === parseInt(patientId));
    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/ai-insights', async (req, res) => {
  try {
    const insight = {
      id: aiInsights.length > 0 ? Math.max(...aiInsights.map(i => i.id)) + 1 : 1,
      ...req.body,
      type: req.body.type || 'info',
      confidence: req.body.confidence || 0,
      data: req.body.data || {},
      recommendations: req.body.recommendations || [],
      date: req.body.date || new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    aiInsights.push(insight);
    emitEvent('comprehensive-assessments:updated', {
      action: 'create',
      entityType: 'aiInsight',
      entityId: insight.id,
      data: insight,
    });
    res.json({ success: true, data: insight });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/analytics', async (req, res) => {
  try {
    const totalAssessments = assessments.length;
    const totalTests = tests.length;
    const totalResults = results.length;
    const averageScore =
      results.length > 0
        ? results.reduce((sum, r) => sum + (r.percentage || 0), 0) / results.length
        : 0;
    const activeAssessments = assessments.filter(a => a.status === 'active').length;
    const completedResults = results.length;

    const analyticsData = [
      {
        id: 1,
        metric: 'إجمالي المقاييس',
        value: totalAssessments,
        description: 'عدد المقاييس المتاحة',
        trend: null,
      },
      {
        id: 2,
        metric: 'إجمالي الاختبارات',
        value: totalTests,
        description: 'عدد الاختبارات المتاحة',
        trend: null,
      },
      {
        id: 3,
        metric: 'النتائج المكتملة',
        value: completedResults,
        description: 'عدد التقييمات المكتملة',
        trend: null,
      },
      {
        id: 4,
        metric: 'المتوسط العام',
        value: `${Math.round(averageScore)}%`,
        description: 'متوسط النتائج',
        trend: null,
      },
      {
        id: 5,
        metric: 'المقاييس النشطة',
        value: activeAssessments,
        description: 'عدد المقاييس النشطة',
        trend: null,
      },
      {
        id: 6,
        metric: 'التصنيفات',
        value: categories.length,
        description: 'عدد التصنيفات المتاحة',
        trend: null,
      },
      {
        id: 7,
        metric: 'المقاييس المعيارية',
        value: scales.length,
        description: 'عدد المقاييس المعيارية',
        trend: null,
      },
      {
        id: 8,
        metric: 'التغطية الشاملة',
        value: '100%',
        description: 'تغطية جميع أنواع الإعاقات',
        trend: null,
      },
    ];

    res.json({ success: true, data: analyticsData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
