/**
 * 📚 Comprehensive Student File Routes
 * API routes for comprehensive intelligent integrated student file system
 */

const express = require('express');
const router = express.Router();

// Mock data storage (replace with database)
const students = [];
const studentFiles = new Map(); // Store complete file data for each student

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Students ====================

router.get('/students', async (req, res) => {
  try {
    const { search, status, disabilityType } = req.query;
    let filtered = students;

    if (search) {
      filtered = filtered.filter(
        s =>
          s.name.toLowerCase().includes(search.toLowerCase()) ||
          (s.studentNumber && s.studentNumber.includes(search))
      );
    }

    if (status) {
      filtered = filtered.filter(s => s.status === status);
    }

    if (disabilityType) {
      filtered = filtered.filter(s => s.disabilityType === disabilityType);
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.get('/students/:id', async (req, res) => {
  try {
    const student = students.find(s => s.id === parseInt(req.params.id));
    if (!student) {
      return res.status(404).json({
        success: false,
        error: 'Student not found',
      });
    }

    // Get complete file data
    const fileData = studentFiles.get(student.id) || student;

    res.json({
      success: true,
      data: fileData,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/students', async (req, res) => {
  try {
    const student = {
      id: students.length > 0 ? Math.max(...students.map(s => s.id)) + 1 : 1,
      ...req.body,
      enrollmentDate: req.body.enrollmentDate || new Date().toISOString(),
      status: req.body.status || 'active',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    students.push(student);

    // Initialize file data
    studentFiles.set(student.id, {
      ...student,
      diagnoses: [],
      medications: [],
      allergies: [],
      assessments: [],
      treatmentPlans: [],
      sessions: [],
      progress: [],
      documents: [],
      reports: [],
      guardians: [],
      messages: [],
      milestones: [],
      recentActivity: [],
    });

    emitEvent('student:file:updated', {
      action: 'create',
      studentId: student.id,
      data: student,
    });

    res.json({
      success: true,
      data: student,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.put('/students/:id', async (req, res) => {
  try {
    const index = students.findIndex(s => s.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Student not found',
      });
    }

    students[index] = {
      ...students[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    // Update file data
    const fileData = studentFiles.get(students[index].id);
    if (fileData) {
      studentFiles.set(students[index].id, {
        ...fileData,
        ...req.body,
        updatedAt: new Date().toISOString(),
      });
    }

    emitEvent('student:file:updated', {
      action: 'update',
      studentId: students[index].id,
      data: students[index],
    });

    res.json({
      success: true,
      data: students[index],
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.delete('/students/:id', async (req, res) => {
  try {
    const index = students.findIndex(s => s.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Student not found',
      });
    }

    students.splice(index, 1);
    studentFiles.delete(parseInt(req.params.id));

    emitEvent('student:file:updated', {
      action: 'delete',
      studentId: parseInt(req.params.id),
    });

    res.json({
      success: true,
      message: 'Student deleted successfully',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Student File Sections ====================

// Medical Records
router.get('/students/:id/medical', async (req, res) => {
  try {
    const fileData = studentFiles.get(parseInt(req.params.id));
    if (!fileData) {
      return res.status(404).json({
        success: false,
        error: 'Student file not found',
      });
    }

    res.json({
      success: true,
      data: {
        diagnoses: fileData.diagnoses || [],
        medications: fileData.medications || [],
        allergies: fileData.allergies || [],
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/students/:id/medical/diagnoses', async (req, res) => {
  try {
    const fileData = studentFiles.get(parseInt(req.params.id));
    if (!fileData) {
      return res.status(404).json({
        success: false,
        error: 'Student file not found',
      });
    }

    const diagnosis = {
      id: Date.now(),
      ...req.body,
      date: req.body.date || new Date().toISOString(),
    };

    fileData.diagnoses = fileData.diagnoses || [];
    fileData.diagnoses.push(diagnosis);
    studentFiles.set(parseInt(req.params.id), fileData);

    emitEvent('student:file:updated', {
      action: 'update',
      studentId: parseInt(req.params.id),
      section: 'medical',
      data: diagnosis,
    });

    res.json({
      success: true,
      data: diagnosis,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Assessments
router.get('/students/:id/assessments', async (req, res) => {
  try {
    const fileData = studentFiles.get(parseInt(req.params.id));
    if (!fileData) {
      return res.status(404).json({
        success: false,
        error: 'Student file not found',
      });
    }

    res.json({
      success: true,
      data: fileData.assessments || [],
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/students/:id/assessments', async (req, res) => {
  try {
    const fileData = studentFiles.get(parseInt(req.params.id));
    if (!fileData) {
      return res.status(404).json({
        success: false,
        error: 'Student file not found',
      });
    }

    const assessment = {
      id: Date.now(),
      ...req.body,
      date: req.body.date || new Date().toISOString(),
    };

    fileData.assessments = fileData.assessments || [];
    fileData.assessments.push(assessment);
    studentFiles.set(parseInt(req.params.id), fileData);

    emitEvent('student:file:updated', {
      action: 'update',
      studentId: parseInt(req.params.id),
      section: 'assessments',
      data: assessment,
    });

    res.json({
      success: true,
      data: assessment,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Treatment Plans
router.get('/students/:id/treatment-plans', async (req, res) => {
  try {
    const fileData = studentFiles.get(parseInt(req.params.id));
    if (!fileData) {
      return res.status(404).json({
        success: false,
        error: 'Student file not found',
      });
    }

    res.json({
      success: true,
      data: fileData.treatmentPlans || [],
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/students/:id/treatment-plans', async (req, res) => {
  try {
    const fileData = studentFiles.get(parseInt(req.params.id));
    if (!fileData) {
      return res.status(404).json({
        success: false,
        error: 'Student file not found',
      });
    }

    const plan = {
      id: Date.now(),
      ...req.body,
      status: req.body.status || 'active',
      startDate: req.body.startDate || new Date().toISOString(),
    };

    fileData.treatmentPlans = fileData.treatmentPlans || [];
    fileData.treatmentPlans.push(plan);
    studentFiles.set(parseInt(req.params.id), fileData);

    emitEvent('student:file:updated', {
      action: 'update',
      studentId: parseInt(req.params.id),
      section: 'treatment',
      data: plan,
    });

    res.json({
      success: true,
      data: plan,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Progress
router.get('/students/:id/progress', async (req, res) => {
  try {
    const fileData = studentFiles.get(parseInt(req.params.id));
    if (!fileData) {
      return res.status(404).json({
        success: false,
        error: 'Student file not found',
      });
    }

    res.json({
      success: true,
      data: {
        progress: fileData.progress || [],
        milestones: fileData.milestones || [],
        progressRate: this.calculateProgressRate(fileData),
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/students/:id/progress', async (req, res) => {
  try {
    const fileData = studentFiles.get(parseInt(req.params.id));
    if (!fileData) {
      return res.status(404).json({
        success: false,
        error: 'Student file not found',
      });
    }

    const progressEntry = {
      id: Date.now(),
      ...req.body,
      date: req.body.date || new Date().toISOString(),
    };

    fileData.progress = fileData.progress || [];
    fileData.progress.push(progressEntry);

    // Update progress rate
    fileData.progressRate = this.calculateProgressRate(fileData);

    studentFiles.set(parseInt(req.params.id), fileData);

    emitEvent('student:file:updated', {
      action: 'update',
      studentId: parseInt(req.params.id),
      section: 'progress',
      data: progressEntry,
    });

    res.json({
      success: true,
      data: progressEntry,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Documents
router.get('/students/:id/documents', async (req, res) => {
  try {
    const fileData = studentFiles.get(parseInt(req.params.id));
    if (!fileData) {
      return res.status(404).json({
        success: false,
        error: 'Student file not found',
      });
    }

    res.json({
      success: true,
      data: fileData.documents || [],
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/students/:id/documents', async (req, res) => {
  try {
    const fileData = studentFiles.get(parseInt(req.params.id));
    if (!fileData) {
      return res.status(404).json({
        success: false,
        error: 'Student file not found',
      });
    }

    const document = {
      id: Date.now(),
      ...req.body,
      uploadDate: new Date().toISOString(),
    };

    fileData.documents = fileData.documents || [];
    fileData.documents.push(document);
    studentFiles.set(parseInt(req.params.id), fileData);

    emitEvent('student:file:updated', {
      action: 'update',
      studentId: parseInt(req.params.id),
      section: 'documents',
      data: document,
    });

    res.json({
      success: true,
      data: document,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// AI Insights
router.get('/students/:id/ai-insights', async (req, res) => {
  try {
    const fileData = studentFiles.get(parseInt(req.params.id));
    if (!fileData) {
      return res.status(404).json({
        success: false,
        error: 'Student file not found',
      });
    }

    // Generate AI insights
    const insights = generateAIInsights(fileData);
    const predictions = generatePredictions(fileData);

    res.json({
      success: true,
      data: {
        insights,
        predictions,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Export Student File
router.get('/students/:id/export', async (req, res) => {
  try {
    const fileData = studentFiles.get(parseInt(req.params.id));
    if (!fileData) {
      return res.status(404).json({
        success: false,
        error: 'Student file not found',
      });
    }

    // TODO: Generate PDF export
    // For now, return JSON
    res.json({
      success: true,
      data: fileData,
      message: 'Export functionality - PDF generation coming soon',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Helper Functions ====================

function calculateProgressRate(fileData) {
  if (!fileData.progress || fileData.progress.length === 0) {
    return 0;
  }

  // Simple calculation based on completed milestones
  const totalMilestones = fileData.milestones?.length || 1;
  const completedMilestones = fileData.milestones?.filter(m => m.achieved).length || 0;

  return Math.round((completedMilestones / totalMilestones) * 100);
}

function generateAIInsights(fileData) {
  const insights = [];

  // Analyze progress
  if (fileData.progress && fileData.progress.length > 0) {
    const recentProgress = fileData.progress.slice(-3);
    const avgProgress =
      recentProgress.reduce((sum, p) => sum + (p.value || 0), 0) / recentProgress.length;

    if (avgProgress > 70) {
      insights.push({
        type: 'progress',
        title: 'تقدم ممتاز',
        description: 'الطالب يظهر تقدماً ممتازاً في الآونة الأخيرة',
        priority: 'low',
      });
    } else if (avgProgress < 40) {
      insights.push({
        type: 'progress',
        title: 'يحتاج إلى دعم إضافي',
        description: 'التقدم بطيء، يُنصح بمراجعة الخطة العلاجية',
        priority: 'high',
        recommendations: ['مراجعة الخطة العلاجية', 'زيادة عدد الجلسات', 'تعديل الأهداف'],
      });
    }
  }

  // Analyze attendance
  if (fileData.sessions && fileData.sessions.length > 0) {
    const totalSessions = fileData.sessions.length;
    const completedSessions = fileData.sessions.filter(s => s.status === 'completed').length;
    const attendanceRate = (completedSessions / totalSessions) * 100;

    if (attendanceRate < 70) {
      insights.push({
        type: 'attendance',
        title: 'معدل الحضور منخفض',
        description: `معدل الحضور: ${attendanceRate.toFixed(1)}%`,
        priority: 'medium',
        recommendations: ['التواصل مع أولياء الأمور', 'مراجعة جدول الجلسات'],
      });
    }
  }

  return insights;
}

function generatePredictions(fileData) {
  const predictions = [];

  // Predict next milestone
  if (fileData.milestones && fileData.milestones.length > 0) {
    const nextMilestone = fileData.milestones.find(m => !m.achieved);
    if (nextMilestone) {
      predictions.push({
        action: 'next_milestone',
        description: `الهدف التالي: ${nextMilestone.title}`,
        probability: 0.7,
      });
    }
  }

  // Predict treatment plan completion
  if (fileData.treatmentPlans && fileData.treatmentPlans.length > 0) {
    const activePlans = fileData.treatmentPlans.filter(p => p.status === 'active');
    if (activePlans.length > 0) {
      predictions.push({
        action: 'plan_review',
        description: 'مراجعة الخطة العلاجية قريباً',
        probability: 0.6,
      });
    }
  }

  return predictions;
}

module.exports = { router, setIO };
