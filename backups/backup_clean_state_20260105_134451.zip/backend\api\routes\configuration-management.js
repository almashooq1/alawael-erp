/**
 * ⚙️ Configuration Management Routes
 * API routes for configurations, settings, environments, and secrets
 */

const express = require('express');
const router = express.Router();

// Mock data storage
const configurations = [];
const settings = [];
const environments = [];
const secrets = [];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Configurations ====================

router.get('/configurations', async (req, res) => {
  try {
    res.json({ success: true, data: configurations });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/configurations/:id', async (req, res) => {
  try {
    const config = configurations.find(c => c.id === parseInt(req.params.id));
    if (!config) {
      return res.status(404).json({ success: false, error: 'Configuration not found' });
    }
    res.json({ success: true, data: config });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/configurations', async (req, res) => {
  try {
    const config = {
      id: configurations.length > 0 ? Math.max(...configurations.map(c => c.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    configurations.push(config);

    emitEvent('configuration:update', {
      action: 'create',
      entityType: 'configuration',
      entityId: config.id,
      data: config,
    });

    res.status(201).json({ success: true, data: config });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/configurations/:id', async (req, res) => {
  try {
    const index = configurations.findIndex(c => c.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Configuration not found' });
    }

    configurations[index] = {
      ...configurations[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    emitEvent('configuration:update', {
      action: 'update',
      entityType: 'configuration',
      entityId: configurations[index].id,
      data: configurations[index],
    });

    res.json({ success: true, data: configurations[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.delete('/configurations/:id', async (req, res) => {
  try {
    const index = configurations.findIndex(c => c.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Configuration not found' });
    }

    const deletedConfig = configurations[index];
    configurations.splice(index, 1);

    emitEvent('configuration:update', {
      action: 'delete',
      entityType: 'configuration',
      entityId: deletedConfig.id,
    });

    res.json({ success: true, message: 'Configuration deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Settings ====================

router.get('/settings', async (req, res) => {
  try {
    res.json({ success: true, data: settings });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/settings', async (req, res) => {
  try {
    const setting = {
      id: settings.length > 0 ? Math.max(...settings.map(s => s.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    settings.push(setting);

    emitEvent('configuration:update', {
      action: 'create',
      entityType: 'setting',
      entityId: setting.id,
      data: setting,
    });

    res.status(201).json({ success: true, data: setting });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Environments ====================

router.get('/environments', async (req, res) => {
  try {
    res.json({ success: true, data: environments });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/environments', async (req, res) => {
  try {
    const environment = {
      id: environments.length > 0 ? Math.max(...environments.map(e => e.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    environments.push(environment);

    emitEvent('configuration:update', {
      action: 'create',
      entityType: 'environment',
      entityId: environment.id,
      data: environment,
    });

    res.status(201).json({ success: true, data: environment });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Secrets ====================

router.get('/secrets', async (req, res) => {
  try {
    res.json({ success: true, data: secrets });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/secrets', async (req, res) => {
  try {
    const secret = {
      id: secrets.length > 0 ? Math.max(...secrets.map(s => s.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    secrets.push(secret);

    emitEvent('configuration:update', {
      action: 'create',
      entityType: 'secret',
      entityId: secret.id,
      data: secret,
    });

    res.status(201).json({ success: true, data: secret });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.delete('/secrets/:id', async (req, res) => {
  try {
    const index = secrets.findIndex(s => s.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Secret not found' });
    }

    const deletedSecret = secrets[index];
    secrets.splice(index, 1);

    emitEvent('configuration:update', {
      action: 'delete',
      entityType: 'secret',
      entityId: deletedSecret.id,
    });

    res.json({ success: true, message: 'Secret deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
