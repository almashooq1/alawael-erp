/**
 * 📝 Content Management Routes
 * API routes for content management system
 */

const express = require('express');
const router = express.Router();

// Mock data storage (replace with database)
const content = [];
const templates = [];
const media = [];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Content ====================

router.get('/content', async (req, res) => {
  try {
    const { status, type, search } = req.query;
    let filtered = content;

    if (status) {
      filtered = filtered.filter(c => c.status === status);
    }

    if (type) {
      filtered = filtered.filter(c => c.type === type);
    }

    if (search) {
      const query = search.toLowerCase();
      filtered = filtered.filter(
        c =>
          c.title.toLowerCase().includes(query) ||
          (c.content && c.content.toLowerCase().includes(query)) ||
          (c.tags && c.tags.some(tag => tag.toLowerCase().includes(query)))
      );
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.get('/content/:id', async (req, res) => {
  try {
    const item = content.find(c => c.id === parseInt(req.params.id));
    if (!item) {
      return res.status(404).json({
        success: false,
        error: 'Content not found',
      });
    }

    // Increment views
    item.views = (item.views || 0) + 1;

    res.json({
      success: true,
      data: item,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/content', async (req, res) => {
  try {
    const item = {
      id: content.length > 0 ? Math.max(...content.map(c => c.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'draft',
      views: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    content.push(item);

    emitEvent('content:updated', {
      action: 'create',
      entityId: item.id,
      data: item,
    });

    res.json({
      success: true,
      data: item,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.put('/content/:id', async (req, res) => {
  try {
    const index = content.findIndex(c => c.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Content not found',
      });
    }

    content[index] = {
      ...content[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    emitEvent('content:updated', {
      action: 'update',
      entityId: content[index].id,
      data: content[index],
    });

    res.json({
      success: true,
      data: content[index],
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.delete('/content/:id', async (req, res) => {
  try {
    const index = content.findIndex(c => c.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Content not found',
      });
    }

    content.splice(index, 1);

    emitEvent('content:updated', {
      action: 'delete',
      entityId: parseInt(req.params.id),
    });

    res.json({
      success: true,
      message: 'Content deleted successfully',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/content/:id/publish', async (req, res) => {
  try {
    const item = content.find(c => c.id === parseInt(req.params.id));
    if (!item) {
      return res.status(404).json({
        success: false,
        error: 'Content not found',
      });
    }

    item.status = 'published';
    item.publishedAt = new Date().toISOString();
    item.updatedAt = new Date().toISOString();

    emitEvent('content:published', {
      entityId: item.id,
      data: item,
    });

    emitEvent('content:updated', {
      action: 'update',
      entityId: item.id,
      data: item,
    });

    res.json({
      success: true,
      data: item,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Templates ====================

router.get('/templates', async (req, res) => {
  try {
    res.json({
      success: true,
      data: templates,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/templates', async (req, res) => {
  try {
    const template = {
      id: templates.length > 0 ? Math.max(...templates.map(t => t.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
    };

    templates.push(template);

    res.json({
      success: true,
      data: template,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Media ====================

router.get('/media', async (req, res) => {
  try {
    res.json({
      success: true,
      data: media,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/media', async (req, res) => {
  try {
    const mediaItem = {
      id: media.length > 0 ? Math.max(...media.map(m => m.id)) + 1 : 1,
      ...req.body,
      uploadedAt: new Date().toISOString(),
    };

    media.push(mediaItem);

    res.json({
      success: true,
      data: mediaItem,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.delete('/media/:id', async (req, res) => {
  try {
    const index = media.findIndex(m => m.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Media not found',
      });
    }

    media.splice(index, 1);

    res.json({
      success: true,
      message: 'Media deleted successfully',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

module.exports = { router, setIO };
