/**
 * 🎓 Continuous Training Management Routes
 * مسارات إدارة التدريب المستمر
 */

const express = require('express');
const router = express.Router();
const TrainingProgram = require('../models/TrainingProgram');
const TrainingSession = require('../models/TrainingSession');
const authenticateToken = require('../middleware/authenticateToken');
const logger = require('../../shared/logging/logger');

// Real-time event emitter (if available)
let io = null;
try {
  const realtimeModule = require('../realtime');
  io = realtimeModule.io;
} catch (error) {
  // Real-time not available
}

/**
 * Emit real-time event
 */
function emitEvent(eventType, entityType, data) {
  if (io) {
    io.emit('continuousTraining:update', {
      action: eventType,
      entityType: entityType,
      entityId: data.id,
      data: data,
    });
  }
}

// Apply authentication to all routes
router.use(authenticateToken);

/**
 * Training Programs Routes
 */
router.get('/programs', async (req, res) => {
  try {
    const programs = await TrainingProgram.findAll({
      order: [['createdAt', 'DESC']],
    });
    res.json(programs);
  } catch (error) {
    logger.error('Error fetching training programs:', error);
    res.status(500).json({ error: 'خطأ في جلب البرامج التدريبية' });
  }
});

router.post('/programs', async (req, res) => {
  try {
    const program = await TrainingProgram.create(req.body);
    emitEvent('create', 'program', program);
    logger.info('Training program created', { id: program.id, name: program.name });
    res.status(201).json(program);
  } catch (error) {
    logger.error('Error creating training program:', error);
    res.status(400).json({ error: 'خطأ في إضافة البرنامج التدريبي' });
  }
});

/**
 * Training Sessions Routes
 */
router.get('/sessions', async (req, res) => {
  try {
    const sessions = await TrainingSession.findAll({
      order: [['date', 'DESC']],
      limit: 100,
    });
    res.json(sessions);
  } catch (error) {
    logger.error('Error fetching training sessions:', error);
    res.status(500).json({ error: 'خطأ في جلب الجلسات التدريبية' });
  }
});

router.post('/sessions', async (req, res) => {
  try {
    const session = await TrainingSession.create(req.body);
    emitEvent('create', 'session', session);
    logger.info('Training session created', { id: session.id, programId: session.programId });
    res.status(201).json(session);
  } catch (error) {
    logger.error('Error creating training session:', error);
    res.status(400).json({ error: 'خطأ في إضافة الجلسة التدريبية' });
  }
});

module.exports = router;
