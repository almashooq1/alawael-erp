/**
 * 📊 Custom Reports Routes
 * API routes for custom reports, builders, schedules, and exports
 */

const express = require('express');
const router = express.Router();

// Mock data storage
const reports = [];
const builders = [];
const schedules = [];
const reportExports = [];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Reports ====================

router.get('/reports', async (req, res) => {
  try {
    res.json({ success: true, data: reports });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/reports/:id', async (req, res) => {
  try {
    const report = reports.find(r => r.id === parseInt(req.params.id));
    if (!report) {
      return res.status(404).json({ success: false, error: 'Report not found' });
    }
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/reports', async (req, res) => {
  try {
    const report = {
      id: reports.length > 0 ? Math.max(...reports.map(r => r.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    reports.push(report);

    emitEvent('customReports:update', {
      action: 'create',
      entityType: 'report',
      entityId: report.id,
      data: report,
    });

    res.status(201).json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/reports/:id', async (req, res) => {
  try {
    const index = reports.findIndex(r => r.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Report not found' });
    }

    reports[index] = {
      ...reports[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    emitEvent('customReports:update', {
      action: 'update',
      entityType: 'report',
      entityId: reports[index].id,
      data: reports[index],
    });

    res.json({ success: true, data: reports[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.delete('/reports/:id', async (req, res) => {
  try {
    const index = reports.findIndex(r => r.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Report not found' });
    }

    const deletedReport = reports[index];
    reports.splice(index, 1);

    emitEvent('customReports:update', {
      action: 'delete',
      entityType: 'report',
      entityId: deletedReport.id,
    });

    res.json({ success: true, message: 'Report deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Builders ====================

router.get('/builders', async (req, res) => {
  try {
    res.json({ success: true, data: builders });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/builders', async (req, res) => {
  try {
    const builder = {
      id: builders.length > 0 ? Math.max(...builders.map(b => b.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    builders.push(builder);

    emitEvent('customReports:update', {
      action: 'create',
      entityType: 'builder',
      entityId: builder.id,
      data: builder,
    });

    res.status(201).json({ success: true, data: builder });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Schedules ====================

router.get('/schedules', async (req, res) => {
  try {
    res.json({ success: true, data: schedules });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/schedules', async (req, res) => {
  try {
    const schedule = {
      id: schedules.length > 0 ? Math.max(...schedules.map(s => s.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    schedules.push(schedule);

    emitEvent('customReports:update', {
      action: 'create',
      entityType: 'schedule',
      entityId: schedule.id,
      data: schedule,
    });

    res.status(201).json({ success: true, data: schedule });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Exports ====================

router.get('/exports', async (req, res) => {
  try {
    res.json({ success: true, data: exports });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/exports', async (req, res) => {
  try {
    const exportItem = {
      id: reportExports.length > 0 ? Math.max(...reportExports.map(e => e.id)) + 1 : 1,
      ...req.body,
      exportedAt: new Date().toISOString(),
    };
    reportExports.push(exportItem);

    emitEvent('customReports:update', {
      action: 'create',
      entityType: 'export',
      entityId: exportItem.id,
      data: exportItem,
    });

    res.status(201).json({ success: true, data: exportItem });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
