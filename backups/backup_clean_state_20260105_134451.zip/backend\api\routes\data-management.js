/**
 * 💾 Big Data Management Routes
 * API routes for datasets, processes, analytics, and storage
 */

const express = require('express');
const router = express.Router();

// Mock data storage
const datasets = [];
const processes = [];
const storage = [];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Datasets ====================

router.get('/datasets', async (req, res) => {
  try {
    res.json({ success: true, data: datasets });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/datasets/:id', async (req, res) => {
  try {
    const dataset = datasets.find(d => d.id === parseInt(req.params.id));
    if (!dataset) {
      return res.status(404).json({ success: false, error: 'Dataset not found' });
    }
    res.json({ success: true, data: dataset });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/datasets', async (req, res) => {
  try {
    const dataset = {
      id: datasets.length > 0 ? Math.max(...datasets.map(d => d.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    datasets.push(dataset);

    emitEvent('dataManagement:update', {
      action: 'create',
      entityType: 'dataset',
      entityId: dataset.id,
      data: dataset,
    });

    res.status(201).json({ success: true, data: dataset });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/datasets/:id', async (req, res) => {
  try {
    const index = datasets.findIndex(d => d.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Dataset not found' });
    }

    datasets[index] = {
      ...datasets[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    emitEvent('dataManagement:update', {
      action: 'update',
      entityType: 'dataset',
      entityId: datasets[index].id,
      data: datasets[index],
    });

    res.json({ success: true, data: datasets[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.delete('/datasets/:id', async (req, res) => {
  try {
    const index = datasets.findIndex(d => d.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Dataset not found' });
    }

    const deletedDataset = datasets[index];
    datasets.splice(index, 1);

    emitEvent('dataManagement:update', {
      action: 'delete',
      entityType: 'dataset',
      entityId: deletedDataset.id,
    });

    res.json({ success: true, message: 'Dataset deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Processes ====================

router.get('/processes', async (req, res) => {
  try {
    res.json({ success: true, data: processes });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/processes', async (req, res) => {
  try {
    const process = {
      id: processes.length > 0 ? Math.max(...processes.map(p => p.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    processes.push(process);

    emitEvent('dataManagement:update', {
      action: 'create',
      entityType: 'process',
      entityId: process.id,
      data: process,
    });

    res.status(201).json({ success: true, data: process });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Analytics ====================

router.get('/analytics', async (req, res) => {
  try {
    res.json({ success: true, data: analytics });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/analytics', async (req, res) => {
  try {
    const analytic = {
      id: analytics.length > 0 ? Math.max(...analytics.map(a => a.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    analytics.push(analytic);

    emitEvent('dataManagement:update', {
      action: 'create',
      entityType: 'analytic',
      entityId: analytic.id,
      data: analytic,
    });

    res.status(201).json({ success: true, data: analytic });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Storage ====================

router.get('/storage', async (req, res) => {
  try {
    res.json({ success: true, data: storage });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/storage', async (req, res) => {
  try {
    const storageItem = {
      id: storage.length > 0 ? Math.max(...storage.map(s => s.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    storage.push(storageItem);

    emitEvent('dataManagement:update', {
      action: 'create',
      entityType: 'storage',
      entityId: storageItem.id,
      data: storageItem,
    });

    res.status(201).json({ success: true, data: storageItem });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
