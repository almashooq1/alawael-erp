/**
 * 💾 Digital Assets Routes
 * API routes for digital assets management system
 */

const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  },
});

const upload = multer({
  storage: storage,
  limits: { fileSize: 100 * 1024 * 1024 }, // 100MB limit
});

// Mock data storage (replace with database)
const assets = [];
const folders = [];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Assets ====================

router.get('/assets', async (req, res) => {
  try {
    const { folderId, type, search } = req.query;
    let filtered = assets;

    if (folderId) {
      filtered = filtered.filter(a => a.folderId === parseInt(folderId));
    }

    if (type) {
      filtered = filtered.filter(a => a.type === type);
    }

    if (search) {
      const query = search.toLowerCase();
      filtered = filtered.filter(
        a =>
          a.name.toLowerCase().includes(query) ||
          (a.description && a.description.toLowerCase().includes(query)) ||
          (a.tags && a.tags.some(tag => tag.toLowerCase().includes(query)))
      );
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.get('/assets/:id', async (req, res) => {
  try {
    const asset = assets.find(a => a.id === parseInt(req.params.id));
    if (!asset) {
      return res.status(404).json({
        success: false,
        error: 'Asset not found',
      });
    }
    res.json({
      success: true,
      data: asset,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/assets/upload', upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        error: 'No file uploaded',
      });
    }

    const asset = {
      id: assets.length > 0 ? Math.max(...assets.map(a => a.id)) + 1 : 1,
      name: req.file.originalname,
      type: getFileType(req.file.mimetype),
      size: req.file.size,
      url: `/uploads/${req.file.filename}`,
      folderId: req.body.folderId ? parseInt(req.body.folderId) : null,
      uploadedAt: new Date().toISOString(),
    };

    assets.push(asset);

    emitEvent('assets:uploaded', {
      entityId: asset.id,
      data: asset,
    });

    emitEvent('assets:updated', {
      action: 'create',
      entityId: asset.id,
      data: asset,
    });

    res.json({
      success: true,
      data: asset,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.delete('/assets/:id', async (req, res) => {
  try {
    const index = assets.findIndex(a => a.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Asset not found',
      });
    }

    assets.splice(index, 1);

    emitEvent('assets:updated', {
      action: 'delete',
      entityId: parseInt(req.params.id),
    });

    res.json({
      success: true,
      message: 'Asset deleted successfully',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Folders ====================

router.get('/folders', async (req, res) => {
  try {
    res.json({
      success: true,
      data: folders,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/folders', async (req, res) => {
  try {
    const folder = {
      id: folders.length > 0 ? Math.max(...folders.map(f => f.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
    };

    folders.push(folder);

    res.json({
      success: true,
      data: folder,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Helper Functions ====================

function getFileType(mimeType) {
  if (mimeType.startsWith('image/')) return 'image';
  if (mimeType.startsWith('video/')) return 'video';
  if (mimeType.startsWith('audio/')) return 'audio';
  if (mimeType.includes('pdf')) return 'pdf';
  if (mimeType.includes('word') || mimeType.includes('document')) return 'document';
  return 'file';
}

module.exports = { router, setIO };
