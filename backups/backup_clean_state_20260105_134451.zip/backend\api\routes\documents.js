/**
 * 📄 Documents Management Routes
 * مسارات إدارة المستندات
 */

const express = require('express');
const router = express.Router();

const Document = (() => {
  try {
    return require('../models/Document');
  } catch (e) {
    return {
      find: async () => [],
      findById: async () => null,
      findOne: async () => null,
      create: async () => ({}),
      updateOne: async () => ({ modifiedCount: 0 }),
      deleteOne: async () => ({ deletedCount: 0 }),
      countDocuments: async () => 0,
      aggregate: () => ({
        sort: () => ({ limit: () => ({ skip: () => ({ toArray: async () => [] }) }) }),
      }),
    };
  }
})();

const authenticateToken = require('../middleware/authenticateToken');
const logger = require('../../shared/logging/logger');

// Real-time event emitter (if available)
let io = null;
try {
  const realtimeModule = require('../realtime');
  io = realtimeModule.io;
} catch (error) {
  // Real-time not available
}

/**
 * Emit real-time event
 */
function emitEvent(eventType, entityType, data) {
  if (io) {
    io.emit('documents:update', {
      action: eventType,
      entityType: entityType,
      entityId: data.id,
      data: data,
    });
  }
}

// Apply authentication to all routes
router.use(authenticateToken);

/**
 * Documents Routes
 */
router.get('/', async (req, res) => {
  try {
    const documents = await Document.findAll({
      order: [['date', 'DESC']],
    });
    res.json(documents);
  } catch (error) {
    logger.error('Error fetching documents:', error);
    res.status(500).json({ error: 'خطأ في جلب المستندات' });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const document = await Document.findByPk(req.params.id);
    if (!document) {
      return res.status(404).json({ error: 'المستند غير موجود' });
    }
    res.json(document);
  } catch (error) {
    logger.error('Error fetching document:', error);
    res.status(500).json({ error: 'خطأ في جلب المستند' });
  }
});

router.post('/', async (req, res) => {
  try {
    const document = await Document.create(req.body);
    emitEvent('create', 'document', document);
    logger.info('Document created', { id: document.id, name: document.name });
    res.status(201).json(document);
  } catch (error) {
    logger.error('Error creating document:', error);
    res.status(400).json({ error: 'خطأ في رفع المستند' });
  }
});

router.post('/upload', async (req, res) => {
  try {
    // In production, handle actual file upload using multer or similar
    const document = await Document.create(req.body);
    emitEvent('create', 'document', document);
    logger.info('Document uploaded', { id: document.id, name: document.name });
    res.status(201).json(document);
  } catch (error) {
    logger.error('Error uploading document:', error);
    res.status(400).json({ error: 'خطأ في رفع المستند' });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const [updated] = await Document.update(req.body, {
      where: { id: req.params.id },
    });
    if (updated) {
      const document = await Document.findByPk(req.params.id);
      emitEvent('update', 'document', document);
      logger.info('Document updated', { id: document.id });
      res.json(document);
    } else {
      res.status(404).json({ error: 'المستند غير موجود' });
    }
  } catch (error) {
    logger.error('Error updating document:', error);
    res.status(400).json({ error: 'خطأ في تحديث المستند' });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    const deleted = await Document.destroy({
      where: { id: req.params.id },
    });
    if (deleted) {
      emitEvent('delete', 'document', { id: req.params.id });
      logger.info('Document deleted', { id: req.params.id });
      res.json({ message: 'تم حذف المستند بنجاح' });
    } else {
      res.status(404).json({ error: 'المستند غير موجود' });
    }
  } catch (error) {
    logger.error('Error deleting document:', error);
    res.status(400).json({ error: 'خطأ في حذف المستند' });
  }
});

module.exports = router;
