/**
 * 🚨 Emergency Management Routes
 * مسارات إدارة الطوارئ
 */

const express = require('express');
const router = express.Router();

// Model stubs
let Emergency, EmergencyPlan, EmergencyContact;
try {
  Emergency = require('../models/Emergency');
} catch {
  Emergency = {
    find: () => Promise.resolve([]),
    findById: () => Promise.resolve(null),
    create: () => Promise.resolve({}),
    save: () => Promise.resolve({}),
  };
}
try {
  EmergencyPlan = require('../models/EmergencyPlan');
} catch {
  EmergencyPlan = {
    find: () => Promise.resolve([]),
    findById: () => Promise.resolve(null),
    create: () => Promise.resolve({}),
    save: () => Promise.resolve({}),
  };
}
try {
  EmergencyContact = require('../models/EmergencyContact');
} catch {
  EmergencyContact = {
    find: () => Promise.resolve([]),
    findById: () => Promise.resolve(null),
    create: () => Promise.resolve({}),
    save: () => Promise.resolve({}),
  };
}

const authenticateToken = require('../middleware/authenticateToken');
const logger = require('../../shared/logging/logger');

// Real-time event emitter (if available)
let io = null;
try {
  const realtimeModule = require('../realtime');
  io = realtimeModule.io;
} catch (error) {
  // Real-time not available
}

/**
 * Emit real-time event
 */
function emitEvent(eventType, entityType, data) {
  if (io) {
    io.emit('emergency:update', {
      action: eventType,
      entityType: entityType,
      entityId: data.id,
      data: data,
    });
  }
}

// Apply authentication to all routes
router.use(authenticateToken);

/**
 * Emergencies Routes
 */
router.get('/emergencies', async (req, res) => {
  try {
    const emergencies = await Emergency.findAll({
      order: [['createdAt', 'DESC']],
      limit: 100,
    });
    res.json(emergencies);
  } catch (error) {
    logger.error('Error fetching emergencies:', error);
    res.status(500).json({ error: 'خطأ في جلب الطوارئ' });
  }
});

router.get('/emergencies/:id', async (req, res) => {
  try {
    const emergency = await Emergency.findByPk(req.params.id);
    if (!emergency) {
      return res.status(404).json({ error: 'الطارئ غير موجود' });
    }
    res.json(emergency);
  } catch (error) {
    logger.error('Error fetching emergency:', error);
    res.status(500).json({ error: 'خطأ في جلب الطارئ' });
  }
});

router.post('/emergencies', async (req, res) => {
  try {
    const emergency = await Emergency.create(req.body);
    emitEvent('create', 'emergency', emergency);
    logger.info('Emergency reported', { id: emergency.id, type: emergency.type });
    res.status(201).json(emergency);
  } catch (error) {
    logger.error('Error creating emergency:', error);
    res.status(400).json({ error: 'خطأ في الإبلاغ عن الطارئ' });
  }
});

router.put('/emergencies/:id', async (req, res) => {
  try {
    const [updated] = await Emergency.update(req.body, {
      where: { id: req.params.id },
    });
    if (updated) {
      const emergency = await Emergency.findByPk(req.params.id);
      emitEvent('update', 'emergency', emergency);
      logger.info('Emergency updated', { id: emergency.id });
      res.json(emergency);
    } else {
      res.status(404).json({ error: 'الطارئ غير موجود' });
    }
  } catch (error) {
    logger.error('Error updating emergency:', error);
    res.status(400).json({ error: 'خطأ في تحديث الطارئ' });
  }
});

router.delete('/emergencies/:id', async (req, res) => {
  try {
    const deleted = await Emergency.destroy({
      where: { id: req.params.id },
    });
    if (deleted) {
      emitEvent('delete', 'emergency', { id: req.params.id });
      logger.info('Emergency deleted', { id: req.params.id });
      res.json({ message: 'تم حذف الطارئ بنجاح' });
    } else {
      res.status(404).json({ error: 'الطارئ غير موجود' });
    }
  } catch (error) {
    logger.error('Error deleting emergency:', error);
    res.status(400).json({ error: 'خطأ في حذف الطارئ' });
  }
});

/**
 * Emergency Plans Routes
 */
router.get('/plans', async (req, res) => {
  try {
    const plans = await EmergencyPlan.findAll({
      order: [['createdAt', 'DESC']],
    });
    res.json(plans);
  } catch (error) {
    logger.error('Error fetching emergency plans:', error);
    res.status(500).json({ error: 'خطأ في جلب خطط الطوارئ' });
  }
});

router.post('/plans', async (req, res) => {
  try {
    const plan = await EmergencyPlan.create(req.body);
    emitEvent('create', 'plan', plan);
    logger.info('Emergency plan created', { id: plan.id, name: plan.name });
    res.status(201).json(plan);
  } catch (error) {
    logger.error('Error creating emergency plan:', error);
    res.status(400).json({ error: 'خطأ في إضافة خطة الطوارئ' });
  }
});

router.put('/plans/:id', async (req, res) => {
  try {
    const [updated] = await EmergencyPlan.update(req.body, {
      where: { id: req.params.id },
    });
    if (updated) {
      const plan = await EmergencyPlan.findByPk(req.params.id);
      emitEvent('update', 'plan', plan);
      logger.info('Emergency plan updated', { id: plan.id });
      res.json(plan);
    } else {
      res.status(404).json({ error: 'خطة الطوارئ غير موجودة' });
    }
  } catch (error) {
    logger.error('Error updating emergency plan:', error);
    res.status(400).json({ error: 'خطأ في تحديث خطة الطوارئ' });
  }
});

router.delete('/plans/:id', async (req, res) => {
  try {
    const deleted = await EmergencyPlan.destroy({
      where: { id: req.params.id },
    });
    if (deleted) {
      emitEvent('delete', 'plan', { id: req.params.id });
      logger.info('Emergency plan deleted', { id: req.params.id });
      res.json({ message: 'تم حذف خطة الطوارئ بنجاح' });
    } else {
      res.status(404).json({ error: 'خطة الطوارئ غير موجودة' });
    }
  } catch (error) {
    logger.error('Error deleting emergency plan:', error);
    res.status(400).json({ error: 'خطأ في حذف خطة الطوارئ' });
  }
});

/**
 * Emergency Contacts Routes
 */
router.get('/contacts', async (req, res) => {
  try {
    const contacts = await EmergencyContact.findAll({
      order: [['name', 'ASC']],
    });
    res.json(contacts);
  } catch (error) {
    logger.error('Error fetching emergency contacts:', error);
    res.status(500).json({ error: 'خطأ في جلب جهات الاتصال' });
  }
});

router.post('/contacts', async (req, res) => {
  try {
    const contact = await EmergencyContact.create(req.body);
    emitEvent('create', 'contact', contact);
    logger.info('Emergency contact created', { id: contact.id, name: contact.name });
    res.status(201).json(contact);
  } catch (error) {
    logger.error('Error creating emergency contact:', error);
    res.status(400).json({ error: 'خطأ في إضافة جهة الاتصال' });
  }
});

router.put('/contacts/:id', async (req, res) => {
  try {
    const [updated] = await EmergencyContact.update(req.body, {
      where: { id: req.params.id },
    });
    if (updated) {
      const contact = await EmergencyContact.findByPk(req.params.id);
      emitEvent('update', 'contact', contact);
      logger.info('Emergency contact updated', { id: contact.id });
      res.json(contact);
    } else {
      res.status(404).json({ error: 'جهة الاتصال غير موجودة' });
    }
  } catch (error) {
    logger.error('Error updating emergency contact:', error);
    res.status(400).json({ error: 'خطأ في تحديث جهة الاتصال' });
  }
});

router.delete('/contacts/:id', async (req, res) => {
  try {
    const deleted = await EmergencyContact.destroy({
      where: { id: req.params.id },
    });
    if (deleted) {
      emitEvent('delete', 'contact', { id: req.params.id });
      logger.info('Emergency contact deleted', { id: req.params.id });
      res.json({ message: 'تم حذف جهة الاتصال بنجاح' });
    } else {
      res.status(404).json({ error: 'جهة الاتصال غير موجودة' });
    }
  } catch (error) {
    logger.error('Error deleting emergency contact:', error);
    res.status(400).json({ error: 'خطأ في حذف جهة الاتصال' });
  }
});

module.exports = router;
