/**
 * 💼 Employment Management Routes
 * مسارات إدارة التوظيف
 */

const express = require('express');
const router = express.Router();
const EmploymentOpportunity = require('../models/EmploymentOpportunity');
const authenticateToken = require('../middleware/authenticateToken');
const logger = require('../../shared/logging/logger');

// Real-time event emitter (if available)
let io = null;
try {
  const realtimeModule = require('../realtime');
  io = realtimeModule.io;
} catch (error) {
  // Real-time not available
}

/**
 * Emit real-time event
 */
function emitEvent(eventType, entityType, data) {
  if (io) {
    io.emit('employment:update', {
      action: eventType,
      entityType: entityType,
      entityId: data.id,
      data: data,
    });
  }
}

// Apply authentication to all routes
router.use(authenticateToken);

/**
 * Employment Opportunities Routes
 */
router.get('/opportunities', async (req, res) => {
  try {
    const opportunities = await EmploymentOpportunity.findAll({
      order: [['createdAt', 'DESC']],
    });
    res.json(opportunities);
  } catch (error) {
    logger.error('Error fetching employment opportunities:', error);
    res.status(500).json({ error: 'خطأ في جلب فرص العمل' });
  }
});

router.post('/opportunities', async (req, res) => {
  try {
    const opportunity = await EmploymentOpportunity.create(req.body);
    emitEvent('create', 'opportunity', opportunity);
    logger.info('Employment opportunity created', { id: opportunity.id, title: opportunity.title });
    res.status(201).json(opportunity);
  } catch (error) {
    logger.error('Error creating employment opportunity:', error);
    res.status(400).json({ error: 'خطأ في إضافة فرصة العمل' });
  }
});

module.exports = router;
