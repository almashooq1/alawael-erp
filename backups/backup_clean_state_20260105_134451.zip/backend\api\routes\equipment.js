/**
 * 🛠️ Equipment Management Routes
 * مسارات إدارة المعدات والأجهزة
 */

const express = require('express');
const router = express.Router();
let Equipment;
try {
  Equipment = require('../models/Equipment');
} catch (e) {
  Equipment = {
    findById: async id => ({ id }),
    create: async data => ({ id: Date.now(), ...data }),
    find: async () => [],
    findByIdAndUpdate: async (id, data) => ({ id, ...data }),
  };
}
let Maintenance;
try {
  Maintenance = require('../models/Maintenance');
} catch (e) {
  Maintenance = {
    findById: async id => ({ id }),
    create: async data => ({ id: Date.now(), ...data }),
    find: async () => [],
    findByIdAndUpdate: async (id, data) => ({ id, ...data }),
  };
}
const authenticateToken = require('../middleware/authenticateToken');
const logger = require('../../shared/logging/logger');

// Real-time event emitter (if available)
let io = null;
try {
  const realtimeModule = require('../realtime');
  io = realtimeModule.io;
} catch (error) {
  // Real-time not available
}

/**
 * Emit real-time event
 */
function emitEvent(eventType, entityType, data) {
  if (io) {
    io.emit('equipment:update', {
      action: eventType,
      entityType: entityType,
      entityId: data.id,
      data: data,
    });
  }
}

// Apply authentication to all routes
router.use(authenticateToken);

/**
 * Equipment Routes
 */
router.get('/', async (req, res) => {
  try {
    const equipment = await Equipment.findAll({
      order: [['createdAt', 'DESC']],
    });
    res.json(equipment);
  } catch (error) {
    logger.error('Error fetching equipment:', error);
    res.status(500).json({ error: 'خطأ في جلب المعدات' });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const equipment = await Equipment.findByPk(req.params.id);
    if (!equipment) {
      return res.status(404).json({ error: 'المعدات غير موجودة' });
    }
    res.json(equipment);
  } catch (error) {
    logger.error('Error fetching equipment:', error);
    res.status(500).json({ error: 'خطأ في جلب المعدات' });
  }
});

router.post('/', async (req, res) => {
  try {
    const equipment = await Equipment.create(req.body);
    emitEvent('create', 'equipment', equipment);
    logger.info('Equipment created', { id: equipment.id, name: equipment.name });
    res.status(201).json(equipment);
  } catch (error) {
    logger.error('Error creating equipment:', error);
    res.status(400).json({ error: 'خطأ في إضافة المعدات' });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const [updated] = await Equipment.update(req.body, {
      where: { id: req.params.id },
    });
    if (updated) {
      const equipment = await Equipment.findByPk(req.params.id);
      emitEvent('update', 'equipment', equipment);
      logger.info('Equipment updated', { id: equipment.id });
      res.json(equipment);
    } else {
      res.status(404).json({ error: 'المعدات غير موجودة' });
    }
  } catch (error) {
    logger.error('Error updating equipment:', error);
    res.status(400).json({ error: 'خطأ في تحديث المعدات' });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    const deleted = await Equipment.destroy({
      where: { id: req.params.id },
    });
    if (deleted) {
      // Also delete related maintenance records
      await Maintenance.destroy({
        where: { equipmentId: req.params.id },
      });
      emitEvent('delete', 'equipment', { id: req.params.id });
      logger.info('Equipment deleted', { id: req.params.id });
      res.json({ message: 'تم حذف المعدات بنجاح' });
    } else {
      res.status(404).json({ error: 'المعدات غير موجودة' });
    }
  } catch (error) {
    logger.error('Error deleting equipment:', error);
    res.status(400).json({ error: 'خطأ في حذف المعدات' });
  }
});

/**
 * Maintenance Routes
 */
router.get('/maintenance', async (req, res) => {
  try {
    const maintenance = await Maintenance.findAll({
      order: [['date', 'DESC']],
    });
    res.json(maintenance);
  } catch (error) {
    logger.error('Error fetching maintenance records:', error);
    res.status(500).json({ error: 'خطأ في جلب سجلات الصيانة' });
  }
});

router.post('/maintenance', async (req, res) => {
  try {
    const maintenance = await Maintenance.create(req.body);
    emitEvent('create', 'maintenance', maintenance);

    // Update equipment status if maintenance is in progress
    if (maintenance.status === 'قيد التنفيذ') {
      await Equipment.update(
        { status: 'صيانة', lastMaintenanceDate: maintenance.date },
        { where: { id: maintenance.equipmentId } }
      );
    } else if (maintenance.status === 'مكتمل') {
      await Equipment.update(
        { status: 'متاح', lastMaintenanceDate: maintenance.date },
        { where: { id: maintenance.equipmentId } }
      );
    }

    logger.info('Maintenance record created', { id: maintenance.id });
    res.status(201).json(maintenance);
  } catch (error) {
    logger.error('Error creating maintenance record:', error);
    res.status(400).json({ error: 'خطأ في إضافة سجل الصيانة' });
  }
});

router.put('/maintenance/:id', async (req, res) => {
  try {
    const [updated] = await Maintenance.update(req.body, {
      where: { id: req.params.id },
    });
    if (updated) {
      const maintenance = await Maintenance.findByPk(req.params.id);
      emitEvent('update', 'maintenance', maintenance);
      logger.info('Maintenance record updated', { id: maintenance.id });
      res.json(maintenance);
    } else {
      res.status(404).json({ error: 'سجل الصيانة غير موجود' });
    }
  } catch (error) {
    logger.error('Error updating maintenance record:', error);
    res.status(400).json({ error: 'خطأ في تحديث سجل الصيانة' });
  }
});

module.exports = router;
