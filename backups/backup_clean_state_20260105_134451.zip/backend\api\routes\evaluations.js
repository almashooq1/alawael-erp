/**
 * 📝 Evaluations Management Routes
 * مسارات إدارة التقييمات والاستبيانات
 */

const express = require('express');
const router = express.Router();

const mockStub = {
  find: async () => [],
  findById: async () => null,
  findOne: async () => null,
  create: async () => ({}),
  updateOne: async () => ({ modifiedCount: 0 }),
  deleteOne: async () => ({ deletedCount: 0 }),
  countDocuments: async () => 0,
  aggregate: () => ({
    sort: () => ({ limit: () => ({ skip: () => ({ toArray: async () => [] }) }) }),
  }),
};

const Evaluation = (() => {
  try {
    return require('../models/Evaluation');
  } catch (e) {
    return mockStub;
  }
})();
const Survey = (() => {
  try {
    return require('../models/Survey');
  } catch (e) {
    return mockStub;
  }
})();
const Question = (() => {
  try {
    return require('../models/Question');
  } catch (e) {
    return mockStub;
  }
})();
const Response = (() => {
  try {
    return require('../models/Response');
  } catch (e) {
    return mockStub;
  }
})();

const authenticateToken = require('../middleware/authenticateToken');
const logger = require('../../shared/logging/logger');

// Real-time event emitter (if available)
let io = null;
try {
  const realtimeModule = require('../realtime');
  io = realtimeModule.io;
} catch (error) {
  // Real-time not available
}

/**
 * Emit real-time event
 */
function emitEvent(eventType, entityType, data) {
  if (io) {
    io.emit('evaluations:update', {
      action: eventType,
      entityType: entityType,
      entityId: data.id,
      data: data,
    });
  }
}

// Apply authentication to all routes
router.use(authenticateToken);

/**
 * Evaluations Routes
 */
router.get('/', async (req, res) => {
  try {
    const evaluations = await Evaluation.findAll({
      order: [['date', 'DESC']],
    });
    res.json(evaluations);
  } catch (error) {
    logger.error('Error fetching evaluations:', error);
    res.status(500).json({ error: 'خطأ في جلب التقييمات' });
  }
});

router.post('/', async (req, res) => {
  try {
    const evaluation = await Evaluation.create(req.body);
    emitEvent('create', 'evaluation', evaluation);
    logger.info('Evaluation created', { id: evaluation.id, title: evaluation.title });
    res.status(201).json(evaluation);
  } catch (error) {
    logger.error('Error creating evaluation:', error);
    res.status(400).json({ error: 'خطأ في إضافة التقييم' });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const [updated] = await Evaluation.update(req.body, {
      where: { id: req.params.id },
    });
    if (updated) {
      const evaluation = await Evaluation.findByPk(req.params.id);
      emitEvent('update', 'evaluation', evaluation);
      logger.info('Evaluation updated', { id: evaluation.id });
      res.json(evaluation);
    } else {
      res.status(404).json({ error: 'التقييم غير موجود' });
    }
  } catch (error) {
    logger.error('Error updating evaluation:', error);
    res.status(400).json({ error: 'خطأ في تحديث التقييم' });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    const deleted = await Evaluation.destroy({
      where: { id: req.params.id },
    });
    if (deleted) {
      emitEvent('delete', 'evaluation', { id: req.params.id });
      logger.info('Evaluation deleted', { id: req.params.id });
      res.json({ message: 'تم حذف التقييم بنجاح' });
    } else {
      res.status(404).json({ error: 'التقييم غير موجود' });
    }
  } catch (error) {
    logger.error('Error deleting evaluation:', error);
    res.status(400).json({ error: 'خطأ في حذف التقييم' });
  }
});

/**
 * Surveys Routes
 */
router.get('/surveys', async (req, res) => {
  try {
    const surveys = await Survey.findAll({
      order: [['createdAt', 'DESC']],
    });
    res.json(surveys);
  } catch (error) {
    logger.error('Error fetching surveys:', error);
    res.status(500).json({ error: 'خطأ في جلب الاستبيانات' });
  }
});

router.post('/surveys', async (req, res) => {
  try {
    const survey = await Survey.create(req.body);
    emitEvent('create', 'survey', survey);
    logger.info('Survey created', { id: survey.id, title: survey.title });
    res.status(201).json(survey);
  } catch (error) {
    logger.error('Error creating survey:', error);
    res.status(400).json({ error: 'خطأ في إضافة الاستبيان' });
  }
});

/**
 * Questions Routes
 */
router.get('/questions', async (req, res) => {
  try {
    const questions = await Question.findAll({
      order: [['order', 'ASC']],
    });
    res.json(questions);
  } catch (error) {
    logger.error('Error fetching questions:', error);
    res.status(500).json({ error: 'خطأ في جلب الأسئلة' });
  }
});

router.post('/questions', async (req, res) => {
  try {
    const question = await Question.create(req.body);
    emitEvent('create', 'question', question);
    logger.info('Question created', { id: question.id, text: question.text });
    res.status(201).json(question);
  } catch (error) {
    logger.error('Error creating question:', error);
    res.status(400).json({ error: 'خطأ في إضافة السؤال' });
  }
});

/**
 * Responses Routes
 */
router.get('/responses', async (req, res) => {
  try {
    const responses = await Response.findAll({
      order: [['createdAt', 'DESC']],
    });
    res.json(responses);
  } catch (error) {
    logger.error('Error fetching responses:', error);
    res.status(500).json({ error: 'خطأ في جلب الإجابات' });
  }
});

router.post('/responses', async (req, res) => {
  try {
    const response = await Response.create(req.body);
    emitEvent('create', 'response', response);
    logger.info('Response created', { id: response.id, questionId: response.questionId });
    res.status(201).json(response);
  } catch (error) {
    logger.error('Error creating response:', error);
    res.status(400).json({ error: 'خطأ في إضافة الإجابة' });
  }
});

module.exports = router;
