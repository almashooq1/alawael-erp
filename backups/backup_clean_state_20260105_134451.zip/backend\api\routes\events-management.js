/**
 * 📅 Events Management Routes
 * API routes for events management system
 */

const express = require('express');
const router = express.Router();

// Mock data storage (replace with database)
const events = [];
const categories = [];
const registrations = [];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Events ====================

router.get('/events', async (req, res) => {
  try {
    const { categoryId, status, search, startDate, endDate } = req.query;
    let filtered = events;

    if (categoryId) {
      filtered = filtered.filter(e => e.categoryId === parseInt(categoryId));
    }

    if (status) {
      filtered = filtered.filter(e => e.status === status);
    }

    if (search) {
      const query = search.toLowerCase();
      filtered = filtered.filter(
        e =>
          e.title.toLowerCase().includes(query) ||
          (e.description && e.description.toLowerCase().includes(query)) ||
          (e.location && e.location.toLowerCase().includes(query))
      );
    }

    if (startDate) {
      filtered = filtered.filter(e => new Date(e.startDate) >= new Date(startDate));
    }

    if (endDate) {
      filtered = filtered.filter(e => new Date(e.endDate) <= new Date(endDate));
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.get('/events/:id', async (req, res) => {
  try {
    const event = events.find(e => e.id === parseInt(req.params.id));
    if (!event) {
      return res.status(404).json({
        success: false,
        error: 'Event not found',
      });
    }
    res.json({
      success: true,
      data: event,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/events', async (req, res) => {
  try {
    const event = {
      id: events.length > 0 ? Math.max(...events.map(e => e.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'upcoming',
      currentParticipants: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    events.push(event);

    emitEvent('events:updated', {
      action: 'create',
      entityId: event.id,
      data: event,
    });

    res.json({
      success: true,
      data: event,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.put('/events/:id', async (req, res) => {
  try {
    const index = events.findIndex(e => e.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Event not found',
      });
    }

    events[index] = {
      ...events[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    emitEvent('events:updated', {
      action: 'update',
      entityId: events[index].id,
      data: events[index],
    });

    res.json({
      success: true,
      data: events[index],
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.delete('/events/:id', async (req, res) => {
  try {
    const index = events.findIndex(e => e.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Event not found',
      });
    }

    events.splice(index, 1);

    emitEvent('events:updated', {
      action: 'delete',
      entityId: parseInt(req.params.id),
    });

    res.json({
      success: true,
      message: 'Event deleted successfully',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Categories ====================

router.get('/categories', async (req, res) => {
  try {
    res.json({
      success: true,
      data: categories,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/categories', async (req, res) => {
  try {
    const category = {
      id: categories.length > 0 ? Math.max(...categories.map(c => c.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
    };

    categories.push(category);

    res.json({
      success: true,
      data: category,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Registrations ====================

router.get('/registrations', async (req, res) => {
  try {
    const { eventId, status } = req.query;
    let filtered = registrations;

    if (eventId) {
      filtered = filtered.filter(r => r.eventId === parseInt(eventId));
    }

    if (status) {
      filtered = filtered.filter(r => r.status === status);
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/registrations', async (req, res) => {
  try {
    const registration = {
      id: registrations.length > 0 ? Math.max(...registrations.map(r => r.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'pending',
      registeredAt: new Date().toISOString(),
    };

    registrations.push(registration);

    // Update event participants count
    const event = events.find(e => e.id === registration.eventId);
    if (event) {
      event.currentParticipants = (event.currentParticipants || 0) + 1;
    }

    emitEvent('events:registration:updated', {
      action: 'create',
      entityId: registration.id,
      data: registration,
    });

    emitEvent('events:updated', {
      action: 'update',
      entityId: event?.id,
      data: event,
    });

    res.json({
      success: true,
      data: registration,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.put('/registrations/:id/approve', async (req, res) => {
  try {
    const registration = registrations.find(r => r.id === parseInt(req.params.id));
    if (!registration) {
      return res.status(404).json({
        success: false,
        error: 'Registration not found',
      });
    }

    registration.status = 'approved';
    registration.approvedAt = new Date().toISOString();

    emitEvent('events:registration:updated', {
      action: 'update',
      entityId: registration.id,
      data: registration,
    });

    res.json({
      success: true,
      data: registration,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.put('/registrations/:id/reject', async (req, res) => {
  try {
    const registration = registrations.find(r => r.id === parseInt(req.params.id));
    if (!registration) {
      return res.status(404).json({
        success: false,
        error: 'Registration not found',
      });
    }

    registration.status = 'rejected';
    registration.rejectedAt = new Date().toISOString();

    // Update event participants count
    const event = events.find(e => e.id === registration.eventId);
    if (event && registration.status === 'approved') {
      event.currentParticipants = Math.max(0, (event.currentParticipants || 0) - 1);
    }

    emitEvent('events:registration:updated', {
      action: 'update',
      entityId: registration.id,
      data: registration,
    });

    res.json({
      success: true,
      data: registration,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

module.exports = { router, setIO };
