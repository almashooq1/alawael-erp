/**
 * 🎉 Events Management Routes
 * مسارات إدارة الفعاليات
 */

const express = require('express');
const router = express.Router();

const mockStub = {
  find: async () => [],
  findById: async () => null,
  findOne: async () => null,
  create: async () => ({}),
  updateOne: async () => ({ modifiedCount: 0 }),
  deleteOne: async () => ({ deletedCount: 0 }),
  countDocuments: async () => 0,
  aggregate: () => ({
    sort: () => ({ limit: () => ({ skip: () => ({ toArray: async () => [] }) }) }),
  }),
};

const Event = (() => {
  try {
    return require('../models/Event');
  } catch (e) {
    return mockStub;
  }
})();
const EventParticipant = (() => {
  try {
    return require('../models/EventParticipant');
  } catch (e) {
    return mockStub;
  }
})();

const authenticateToken = require('../middleware/authenticateToken');
const logger = require('../../shared/logging/logger');

// Real-time event emitter (if available)
let io = null;
try {
  const realtimeModule = require('../realtime');
  io = realtimeModule.io;
} catch (error) {
  // Real-time not available
}

/**
 * Emit real-time event
 */
function emitEvent(eventType, entityType, data) {
  if (io) {
    io.emit('events:update', {
      action: eventType,
      entityType: entityType,
      entityId: data.id,
      data: data,
    });
  }
}

// Apply authentication to all routes
router.use(authenticateToken);

/**
 * Events Routes
 */
router.get('/', async (req, res) => {
  try {
    const events = await Event.findAll({
      order: [['date', 'DESC']],
      limit: 100,
    });
    res.json(events);
  } catch (error) {
    logger.error('Error fetching events:', error);
    res.status(500).json({ error: 'خطأ في جلب الفعاليات' });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const event = await Event.findByPk(req.params.id);
    if (!event) {
      return res.status(404).json({ error: 'الفعالية غير موجودة' });
    }
    res.json(event);
  } catch (error) {
    logger.error('Error fetching event:', error);
    res.status(500).json({ error: 'خطأ في جلب الفعالية' });
  }
});

router.post('/', async (req, res) => {
  try {
    const event = await Event.create(req.body);
    emitEvent('create', 'event', event);
    logger.info('Event created', { id: event.id, title: event.title });
    res.status(201).json(event);
  } catch (error) {
    logger.error('Error creating event:', error);
    res.status(400).json({ error: 'خطأ في إضافة الفعالية' });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const [updated] = await Event.update(req.body, {
      where: { id: req.params.id },
    });
    if (updated) {
      const event = await Event.findByPk(req.params.id);
      emitEvent('update', 'event', event);
      logger.info('Event updated', { id: event.id });
      res.json(event);
    } else {
      res.status(404).json({ error: 'الفعالية غير موجودة' });
    }
  } catch (error) {
    logger.error('Error updating event:', error);
    res.status(400).json({ error: 'خطأ في تحديث الفعالية' });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    const deleted = await Event.destroy({
      where: { id: req.params.id },
    });
    if (deleted) {
      // Also delete related participants
      await EventParticipant.destroy({ where: { eventId: req.params.id } });
      emitEvent('delete', 'event', { id: req.params.id });
      logger.info('Event deleted', { id: req.params.id });
      res.json({ message: 'تم حذف الفعالية بنجاح' });
    } else {
      res.status(404).json({ error: 'الفعالية غير موجودة' });
    }
  } catch (error) {
    logger.error('Error deleting event:', error);
    res.status(400).json({ error: 'خطأ في حذف الفعالية' });
  }
});

/**
 * Event Participants Routes
 */
router.get('/participants', async (req, res) => {
  try {
    const participants = await EventParticipant.findAll({
      order: [['createdAt', 'DESC']],
    });
    res.json(participants);
  } catch (error) {
    logger.error('Error fetching participants:', error);
    res.status(500).json({ error: 'خطأ في جلب المشاركين' });
  }
});

router.post('/participants', async (req, res) => {
  try {
    const participant = await EventParticipant.create(req.body);
    emitEvent('create', 'participant', participant);
    logger.info('Event participant added', { id: participant.id, eventId: participant.eventId });
    res.status(201).json(participant);
  } catch (error) {
    logger.error('Error creating participant:', error);
    res.status(400).json({ error: 'خطأ في إضافة المشارك' });
  }
});

router.delete('/participants/:id', async (req, res) => {
  try {
    const deleted = await EventParticipant.destroy({
      where: { id: req.params.id },
    });
    if (deleted) {
      emitEvent('delete', 'participant', { id: req.params.id });
      logger.info('Event participant deleted', { id: req.params.id });
      res.json({ message: 'تم حذف المشارك بنجاح' });
    } else {
      res.status(404).json({ error: 'المشارك غير موجود' });
    }
  } catch (error) {
    logger.error('Error deleting participant:', error);
    res.status(400).json({ error: 'خطأ في حذف المشارك' });
  }
});

module.exports = router;
