/**
 * 🏢 Facilities Management Routes
 * مسارات إدارة المرافق
 */

const express = require('express');
const router = express.Router();

// Model stubs
let Facility, Booking, FacilityMaintenance;
try {
  Facility = require('../models/Facility');
} catch {
  Facility = {
    find: () => Promise.resolve([]),
    findById: () => Promise.resolve(null),
    create: () => Promise.resolve({}),
    save: () => Promise.resolve({}),
  };
}
try {
  Booking = require('../models/Booking');
} catch {
  Booking = {
    find: () => Promise.resolve([]),
    findById: () => Promise.resolve(null),
    create: () => Promise.resolve({}),
    save: () => Promise.resolve({}),
  };
}
try {
  FacilityMaintenance = require('../models/FacilityMaintenance');
} catch {
  FacilityMaintenance = {
    find: () => Promise.resolve([]),
    findById: () => Promise.resolve(null),
    create: () => Promise.resolve({}),
    save: () => Promise.resolve({}),
  };
}

const authenticateToken = require('../middleware/authenticateToken');
const logger = require('../../shared/logging/logger');

// Real-time event emitter (if available)
let io = null;
try {
  const realtimeModule = require('../realtime');
  io = realtimeModule.io;
} catch (error) {
  // Real-time not available
}

/**
 * Emit real-time event
 */
function emitEvent(eventType, entityType, data) {
  if (io) {
    io.emit('facilities:update', {
      action: eventType,
      entityType: entityType,
      entityId: data.id,
      data: data,
    });
  }
}

// Apply authentication to all routes
router.use(authenticateToken);

/**
 * Facilities Routes
 */
router.get('/', async (req, res) => {
  try {
    const facilities = await Facility.findAll({
      order: [['createdAt', 'DESC']],
    });
    res.json(facilities);
  } catch (error) {
    logger.error('Error fetching facilities:', error);
    res.status(500).json({ error: 'خطأ في جلب المرافق' });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const facility = await Facility.findByPk(req.params.id);
    if (!facility) {
      return res.status(404).json({ error: 'المرفق غير موجود' });
    }
    res.json(facility);
  } catch (error) {
    logger.error('Error fetching facility:', error);
    res.status(500).json({ error: 'خطأ في جلب المرفق' });
  }
});

router.post('/', async (req, res) => {
  try {
    const facility = await Facility.create(req.body);
    emitEvent('create', 'facility', facility);
    logger.info('Facility created', { id: facility.id, name: facility.name });
    res.status(201).json(facility);
  } catch (error) {
    logger.error('Error creating facility:', error);
    res.status(400).json({ error: 'خطأ في إضافة المرفق' });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const [updated] = await Facility.update(req.body, {
      where: { id: req.params.id },
    });
    if (updated) {
      const facility = await Facility.findByPk(req.params.id);
      emitEvent('update', 'facility', facility);
      logger.info('Facility updated', { id: facility.id });
      res.json(facility);
    } else {
      res.status(404).json({ error: 'المرفق غير موجود' });
    }
  } catch (error) {
    logger.error('Error updating facility:', error);
    res.status(400).json({ error: 'خطأ في تحديث المرفق' });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    const deleted = await Facility.destroy({
      where: { id: req.params.id },
    });
    if (deleted) {
      // Also delete related bookings and maintenance
      await Booking.destroy({ where: { facilityId: req.params.id } });
      await FacilityMaintenance.destroy({ where: { facilityId: req.params.id } });
      emitEvent('delete', 'facility', { id: req.params.id });
      logger.info('Facility deleted', { id: req.params.id });
      res.json({ message: 'تم حذف المرفق بنجاح' });
    } else {
      res.status(404).json({ error: 'المرفق غير موجود' });
    }
  } catch (error) {
    logger.error('Error deleting facility:', error);
    res.status(400).json({ error: 'خطأ في حذف المرفق' });
  }
});

/**
 * Bookings Routes
 */
router.get('/bookings', async (req, res) => {
  try {
    const bookings = await Booking.findAll({
      order: [['date', 'DESC']],
      limit: 100,
    });
    res.json(bookings);
  } catch (error) {
    logger.error('Error fetching bookings:', error);
    res.status(500).json({ error: 'خطأ في جلب الحجوزات' });
  }
});

router.get('/bookings/:id', async (req, res) => {
  try {
    const booking = await Booking.findByPk(req.params.id);
    if (!booking) {
      return res.status(404).json({ error: 'الحجز غير موجود' });
    }
    res.json(booking);
  } catch (error) {
    logger.error('Error fetching booking:', error);
    res.status(500).json({ error: 'خطأ في جلب الحجز' });
  }
});

router.post('/bookings', async (req, res) => {
  try {
    const booking = await Booking.create(req.body);
    emitEvent('create', 'booking', booking);

    // Update facility status if booking is confirmed
    if (booking.status === 'مؤكد') {
      await Facility.update({ status: 'محجوز' }, { where: { id: booking.facilityId } });
    }

    logger.info('Booking created', { id: booking.id, facilityId: booking.facilityId });
    res.status(201).json(booking);
  } catch (error) {
    logger.error('Error creating booking:', error);
    res.status(400).json({ error: 'خطأ في إضافة الحجز' });
  }
});

router.put('/bookings/:id', async (req, res) => {
  try {
    const [updated] = await Booking.update(req.body, {
      where: { id: req.params.id },
    });
    if (updated) {
      const booking = await Booking.findByPk(req.params.id);
      emitEvent('update', 'booking', booking);

      // Update facility status based on booking status
      if (booking.status === 'مؤكد') {
        await Facility.update({ status: 'محجوز' }, { where: { id: booking.facilityId } });
      } else if (booking.status === 'ملغي') {
        await Facility.update({ status: 'متاح' }, { where: { id: booking.facilityId } });
      }

      logger.info('Booking updated', { id: booking.id });
      res.json(booking);
    } else {
      res.status(404).json({ error: 'الحجز غير موجود' });
    }
  } catch (error) {
    logger.error('Error updating booking:', error);
    res.status(400).json({ error: 'خطأ في تحديث الحجز' });
  }
});

router.delete('/bookings/:id', async (req, res) => {
  try {
    const booking = await Booking.findByPk(req.params.id);
    const deleted = await Booking.destroy({
      where: { id: req.params.id },
    });
    if (deleted) {
      // Update facility status back to available
      if (booking) {
        await Facility.update({ status: 'متاح' }, { where: { id: booking.facilityId } });
      }
      emitEvent('delete', 'booking', { id: req.params.id });
      logger.info('Booking deleted', { id: req.params.id });
      res.json({ message: 'تم حذف الحجز بنجاح' });
    } else {
      res.status(404).json({ error: 'الحجز غير موجود' });
    }
  } catch (error) {
    logger.error('Error deleting booking:', error);
    res.status(400).json({ error: 'خطأ في حذف الحجز' });
  }
});

/**
 * Maintenance Routes
 */
router.get('/maintenance', async (req, res) => {
  try {
    const maintenance = await FacilityMaintenance.findAll({
      order: [['date', 'DESC']],
    });
    res.json(maintenance);
  } catch (error) {
    logger.error('Error fetching maintenance:', error);
    res.status(500).json({ error: 'خطأ في جلب طلبات الصيانة' });
  }
});

router.post('/maintenance', async (req, res) => {
  try {
    const maintenance = await FacilityMaintenance.create(req.body);
    emitEvent('create', 'maintenance', maintenance);

    // Update facility status to maintenance
    await Facility.update({ status: 'صيانة' }, { where: { id: maintenance.facilityId } });

    logger.info('Maintenance request created', { id: maintenance.id });
    res.status(201).json(maintenance);
  } catch (error) {
    logger.error('Error creating maintenance:', error);
    res.status(400).json({ error: 'خطأ في إضافة طلب الصيانة' });
  }
});

router.put('/maintenance/:id', async (req, res) => {
  try {
    const [updated] = await FacilityMaintenance.update(req.body, {
      where: { id: req.params.id },
    });
    if (updated) {
      const maintenance = await FacilityMaintenance.findByPk(req.params.id);
      emitEvent('update', 'maintenance', maintenance);

      // Update facility status if maintenance is completed
      if (maintenance.status === 'مكتمل') {
        await Facility.update({ status: 'متاح' }, { where: { id: maintenance.facilityId } });
      }

      logger.info('Maintenance updated', { id: maintenance.id });
      res.json(maintenance);
    } else {
      res.status(404).json({ error: 'طلب الصيانة غير موجود' });
    }
  } catch (error) {
    logger.error('Error updating maintenance:', error);
    res.status(400).json({ error: 'خطأ في تحديث طلب الصيانة' });
  }
});

router.delete('/maintenance/:id', async (req, res) => {
  try {
    const deleted = await FacilityMaintenance.destroy({
      where: { id: req.params.id },
    });
    if (deleted) {
      emitEvent('delete', 'maintenance', { id: req.params.id });
      logger.info('Maintenance deleted', { id: req.params.id });
      res.json({ message: 'تم حذف طلب الصيانة بنجاح' });
    } else {
      res.status(404).json({ error: 'طلب الصيانة غير موجود' });
    }
  } catch (error) {
    logger.error('Error deleting maintenance:', error);
    res.status(400).json({ error: 'خطأ في حذف طلب الصيانة' });
  }
});

module.exports = router;
