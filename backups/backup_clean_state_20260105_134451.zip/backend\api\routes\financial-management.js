/**
 * 💰 Financial Management Routes
 * API routes for integrated financial and accounting system
 */

const express = require('express');
const router = express.Router();
const FinancialManager = require('../../shared/utils/financial-manager');

const financialManager = new FinancialManager();

// ==================== Invoices ====================

/**
 * POST /api/financial/invoices
 * Create a new invoice
 */
router.post('/invoices', async (req, res) => {
  try {
    const invoice = financialManager.createInvoice(req.body);
    res.json({
      success: true,
      data: invoice,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * GET /api/financial/invoices
 * Get all invoices
 */
router.get('/invoices', async (req, res) => {
  try {
    const invoices = financialManager.getAllInvoices(req.query);
    res.json({
      success: true,
      data: invoices,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * GET /api/financial/invoices/:id
 * Get invoice by ID
 */
router.get('/invoices/:id', async (req, res) => {
  try {
    const invoice = financialManager.getInvoice(req.params.id);
    if (!invoice) {
      return res.status(404).json({
        success: false,
        error: 'Invoice not found',
      });
    }
    res.json({
      success: true,
      data: invoice,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * PUT /api/financial/invoices/:id
 * Update invoice
 */
router.put('/invoices/:id', async (req, res) => {
  try {
    const invoice = financialManager.updateInvoice(req.params.id, req.body);
    res.json({
      success: true,
      data: invoice,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Payments ====================

/**
 * POST /api/financial/payments
 * Record a payment
 */
router.post('/payments', async (req, res) => {
  try {
    const payment = financialManager.recordPayment(req.body);
    res.json({
      success: true,
      data: payment,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * GET /api/financial/payments
 * Get all payments
 */
router.get('/payments', async (req, res) => {
  try {
    const payments = financialManager.getPayments(req.query);
    res.json({
      success: true,
      data: payments,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * POST /api/financial/payments/mada
 * Process Mada payment
 */
router.post('/payments/mada', async (req, res) => {
  try {
    const result = await financialManager.processMadaPayment(
      req.body.invoiceId,
      req.body.amount,
      req.body.cardData
    );
    res.json(result);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * POST /api/financial/payments/sadad
 * Process Sadad payment
 */
router.post('/payments/sadad', async (req, res) => {
  try {
    const result = await financialManager.processSadadPayment(
      req.body.invoiceId,
      req.body.amount,
      req.body.billerId,
      req.body.subscriberId
    );
    res.json(result);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Budgets ====================

/**
 * POST /api/financial/budgets
 * Create a budget
 */
router.post('/budgets', async (req, res) => {
  try {
    const budget = financialManager.createBudget(req.body);
    res.json({
      success: true,
      data: budget,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * GET /api/financial/budgets
 * Get all budgets
 */
router.get('/budgets', async (req, res) => {
  try {
    const budgets = Array.from(financialManager.budgets.values());
    res.json({
      success: true,
      data: budgets,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Expenses ====================

/**
 * POST /api/financial/expenses
 * Record an expense
 */
router.post('/expenses', async (req, res) => {
  try {
    const expense = financialManager.recordExpense(req.body);
    res.json({
      success: true,
      data: expense,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Reports ====================

/**
 * GET /api/financial/reports
 * Get financial report
 */
router.get('/reports', async (req, res) => {
  try {
    const report = financialManager.getFinancialReport(
      req.query.startDate || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
      req.query.endDate || new Date().toISOString()
    );
    res.json({
      success: true,
      data: report,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * GET /api/financial/reports/vat
 * Get VAT report
 */
router.get('/reports/vat', async (req, res) => {
  try {
    const report = financialManager.getVATReport(
      req.query.startDate || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
      req.query.endDate || new Date().toISOString()
    );
    res.json({
      success: true,
      data: report,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

module.exports = router;
