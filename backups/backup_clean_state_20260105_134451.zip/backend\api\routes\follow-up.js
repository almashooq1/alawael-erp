/**
 * 📞 Follow-up Management Routes
 * مسارات إدارة المتابعة
 */

const express = require('express');
const router = express.Router();
const FollowUp = require('../models/FollowUp');
const authenticateToken = require('../middleware/authenticateToken');
const logger = require('../../shared/logging/logger');

// Real-time event emitter (if available)
let io = null;
try {
  const realtimeModule = require('../realtime');
  io = realtimeModule.io;
} catch (error) {
  // Real-time not available
}

/**
 * Emit real-time event
 */
function emitEvent(eventType, entityType, data) {
  if (io) {
    io.emit('followUp:update', {
      action: eventType,
      entityType: entityType,
      entityId: data.id,
      data: data,
    });
  }
}

// Apply authentication to all routes
router.use(authenticateToken);

/**
 * Follow-up Routes
 */
router.get('/', async (req, res) => {
  try {
    const followUps = await FollowUp.findAll({
      order: [['scheduledDate', 'DESC']],
      limit: 100,
    });
    res.json(followUps);
  } catch (error) {
    logger.error('Error fetching follow-ups:', error);
    res.status(500).json({ error: 'خطأ في جلب المتابعات' });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const followUp = await FollowUp.findByPk(req.params.id);
    if (!followUp) {
      return res.status(404).json({ error: 'المتابعة غير موجودة' });
    }
    res.json(followUp);
  } catch (error) {
    logger.error('Error fetching follow-up:', error);
    res.status(500).json({ error: 'خطأ في جلب المتابعة' });
  }
});

router.post('/', async (req, res) => {
  try {
    const followUp = await FollowUp.create(req.body);
    emitEvent('create', 'followUp', followUp);
    logger.info('Follow-up created', { id: followUp.id, patientId: followUp.patientId });
    res.status(201).json(followUp);
  } catch (error) {
    logger.error('Error creating follow-up:', error);
    res.status(400).json({ error: 'خطأ في إضافة المتابعة' });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const [updated] = await FollowUp.update(req.body, {
      where: { id: req.params.id },
    });
    if (updated) {
      const followUp = await FollowUp.findByPk(req.params.id);
      emitEvent('update', 'followUp', followUp);
      logger.info('Follow-up updated', { id: followUp.id });
      res.json(followUp);
    } else {
      res.status(404).json({ error: 'المتابعة غير موجودة' });
    }
  } catch (error) {
    logger.error('Error updating follow-up:', error);
    res.status(400).json({ error: 'خطأ في تحديث المتابعة' });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    const deleted = await FollowUp.destroy({
      where: { id: req.params.id },
    });
    if (deleted) {
      emitEvent('delete', 'followUp', { id: req.params.id });
      logger.info('Follow-up deleted', { id: req.params.id });
      res.json({ message: 'تم حذف المتابعة بنجاح' });
    } else {
      res.status(404).json({ error: 'المتابعة غير موجودة' });
    }
  } catch (error) {
    logger.error('Error deleting follow-up:', error);
    res.status(400).json({ error: 'خطأ في حذف المتابعة' });
  }
});

module.exports = router;
