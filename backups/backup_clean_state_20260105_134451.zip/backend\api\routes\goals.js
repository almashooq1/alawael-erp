/**
 * 🎯 Goals Management Routes
 * مسارات إدارة الأهداف العلاجية
 */

const express = require('express');
const router = express.Router();

const mockStub = {
  find: async () => [],
  findById: async () => null,
  findOne: async () => null,
  create: async () => ({}),
  updateOne: async () => ({ modifiedCount: 0 }),
  deleteOne: async () => ({ deletedCount: 0 }),
  countDocuments: async () => 0,
  aggregate: () => ({
    sort: () => ({ limit: () => ({ skip: () => ({ toArray: async () => [] }) }) }),
  }),
};

const Goal = (() => {
  try {
    return require('../models/Goal');
  } catch (e) {
    return mockStub;
  }
})();
const GoalEvaluation = (() => {
  try {
    return require('../models/GoalEvaluation');
  } catch (e) {
    return mockStub;
  }
})();

const authenticateToken = require('../middleware/authenticateToken');
const logger = require('../../shared/logging/logger');

// Real-time event emitter (if available)
let io = null;
try {
  const realtimeModule = require('../realtime');
  io = realtimeModule.io;
} catch (error) {
  // Real-time not available
}

/**
 * Emit real-time event
 */
function emitEvent(eventType, entityType, data) {
  if (io) {
    io.emit('goals:update', {
      action: eventType,
      entityType: entityType,
      entityId: data.id,
      data: data,
    });
  }
}

// Apply authentication to all routes
router.use(authenticateToken);

/**
 * Goals Routes
 */
router.get('/', async (req, res) => {
  try {
    const goals = await Goal.findAll({
      order: [['createdAt', 'DESC']],
      limit: 100,
    });
    res.json(goals);
  } catch (error) {
    logger.error('Error fetching goals:', error);
    res.status(500).json({ error: 'خطأ في جلب الأهداف' });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const goal = await Goal.findByPk(req.params.id);
    if (!goal) {
      return res.status(404).json({ error: 'الهدف غير موجود' });
    }
    res.json(goal);
  } catch (error) {
    logger.error('Error fetching goal:', error);
    res.status(500).json({ error: 'خطأ في جلب الهدف' });
  }
});

router.post('/', async (req, res) => {
  try {
    const goal = await Goal.create(req.body);
    emitEvent('create', 'goal', goal);
    logger.info('Goal created', { id: goal.id, title: goal.title });
    res.status(201).json(goal);
  } catch (error) {
    logger.error('Error creating goal:', error);
    res.status(400).json({ error: 'خطأ في إضافة الهدف' });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const [updated] = await Goal.update(req.body, {
      where: { id: req.params.id },
    });
    if (updated) {
      const goal = await Goal.findByPk(req.params.id);
      emitEvent('update', 'goal', goal);
      logger.info('Goal updated', { id: goal.id });
      res.json(goal);
    } else {
      res.status(404).json({ error: 'الهدف غير موجود' });
    }
  } catch (error) {
    logger.error('Error updating goal:', error);
    res.status(400).json({ error: 'خطأ في تحديث الهدف' });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    const deleted = await Goal.destroy({
      where: { id: req.params.id },
    });
    if (deleted) {
      // Also delete related evaluations
      await GoalEvaluation.destroy({ where: { goalId: req.params.id } });
      emitEvent('delete', 'goal', { id: req.params.id });
      logger.info('Goal deleted', { id: req.params.id });
      res.json({ message: 'تم حذف الهدف بنجاح' });
    } else {
      res.status(404).json({ error: 'الهدف غير موجود' });
    }
  } catch (error) {
    logger.error('Error deleting goal:', error);
    res.status(400).json({ error: 'خطأ في حذف الهدف' });
  }
});

/**
 * Goal Evaluations Routes
 */
router.get('/evaluations', async (req, res) => {
  try {
    const evaluations = await GoalEvaluation.findAll({
      order: [['createdAt', 'DESC']],
    });
    res.json(evaluations);
  } catch (error) {
    logger.error('Error fetching goal evaluations:', error);
    res.status(500).json({ error: 'خطأ في جلب تقييمات الأهداف' });
  }
});

router.post('/evaluations', async (req, res) => {
  try {
    const evaluation = await GoalEvaluation.create(req.body);
    emitEvent('create', 'evaluation', evaluation);
    logger.info('Goal evaluation created', { id: evaluation.id, goalId: evaluation.goalId });
    res.status(201).json(evaluation);
  } catch (error) {
    logger.error('Error creating goal evaluation:', error);
    res.status(400).json({ error: 'خطأ في إضافة تقييم الهدف' });
  }
});

module.exports = router;
