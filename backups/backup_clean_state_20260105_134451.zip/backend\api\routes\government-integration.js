/**
 * 🏛️ Government Integration Routes
 * API routes for Saudi government integration
 */

const express = require('express');
const router = express.Router();
const GovernmentIntegrationManager = require('../../shared/utils/government-integration-manager');

const govIntegration = new GovernmentIntegrationManager();

// ==================== MOH Integration ====================

/**
 * POST /api/government/moh/reports
 * Send medical report to MOH
 */
router.post('/moh/reports', async (req, res) => {
  try {
    const result = await govIntegration.sendMedicalReportToMOH(req.body);
    res.json(result);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * POST /api/government/moh/verify-license
 * Verify medical license
 */
router.post('/moh/verify-license', async (req, res) => {
  try {
    const result = await govIntegration.verifyMedicalLicense(
      req.body.licenseNumber,
      req.body.practitionerId
    );
    res.json(result);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== MOCD Integration ====================

/**
 * POST /api/government/mocd/reports
 * Send activity report to MOCD
 */
router.post('/mocd/reports', async (req, res) => {
  try {
    const result = await govIntegration.sendActivityReportToMOCD(req.body);
    res.json(result);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * POST /api/government/mocd/register
 * Register center with MOCD
 */
router.post('/mocd/register', async (req, res) => {
  try {
    const result = await govIntegration.registerCenterWithMOCD(req.body);
    res.json(result);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== SCFHS Integration ====================

/**
 * POST /api/government/scfhs/verify-license
 * Verify SCFHS license
 */
router.post('/scfhs/verify-license', async (req, res) => {
  try {
    const result = await govIntegration.verifySCFHSLicense(
      req.body.licenseNumber,
      req.body.therapistId
    );
    res.json(result);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * POST /api/government/scfhs/training-hours
 * Track training hours
 */
router.post('/scfhs/training-hours', async (req, res) => {
  try {
    const result = await govIntegration.trackTrainingHours(
      req.body.therapistId,
      req.body.hours,
      req.body.trainingData
    );
    res.json(result);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Absher Integration ====================

/**
 * POST /api/government/absher/verify
 * Verify identity with Absher
 */
router.post('/absher/verify', async (req, res) => {
  try {
    const result = await govIntegration.verifyIdentityWithAbsher(
      req.body.nationalId,
      req.body.fullName
    );
    res.json(result);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * GET /api/government/absher/data
 * Get data from Absher
 */
router.get('/absher/data', async (req, res) => {
  try {
    const result = await govIntegration.getAbsherData(req.query.nationalId);
    res.json(result);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Saber Integration ====================

/**
 * POST /api/government/saber/verify
 * Verify certificate with Saber
 */
router.post('/saber/verify', async (req, res) => {
  try {
    const result = await govIntegration.verifyCertificateWithSaber(
      req.body.certificateNumber,
      req.body.certificateType
    );
    res.json(result);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * POST /api/government/saber/issue
 * Issue document with Saber
 */
router.post('/saber/issue', async (req, res) => {
  try {
    const result = await govIntegration.issueDocumentWithSaber(req.body);
    res.json(result);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Fatoorah Integration ====================

/**
 * POST /api/government/fatoorah/invoice
 * Issue Fatoorah invoice
 */
router.post('/fatoorah/invoice', async (req, res) => {
  try {
    const result = await govIntegration.issueFatoorahInvoice(req.body);
    res.json(result);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Insurance Integration ====================

/**
 * POST /api/government/insurance/verify
 * Verify insurance coverage
 */
router.post('/insurance/verify', async (req, res) => {
  try {
    const result = await govIntegration.verifyInsuranceCoverage(
      req.body.patientId,
      req.body.insuranceNumber
    );
    res.json(result);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * POST /api/government/insurance/claim
 * Submit insurance claim
 */
router.post('/insurance/claim', async (req, res) => {
  try {
    const result = await govIntegration.submitInsuranceClaim(req.body);
    res.json(result);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Automated Reports ====================

/**
 * POST /api/government/automated-reports
 * Send automated reports
 */
router.post('/automated-reports', async (req, res) => {
  try {
    const result = await govIntegration.sendAutomatedReports(
      req.body.reportType || 'monthly',
      req.body.period
    );
    res.json(result);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Status ====================

/**
 * GET /api/government/status
 * Get integration status
 */
router.get('/status', async (req, res) => {
  try {
    const status = govIntegration.getIntegrationStatus();
    res.json({
      success: true,
      data: status,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

module.exports = router;
