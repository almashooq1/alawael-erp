/**
 * 👥 Group Sessions Management Routes
 * مسارات إدارة الجلسات الجماعية
 */

const express = require('express');
const router = express.Router();
const Group = require('../models/Group');
const GroupSession = require('../models/GroupSession');
const authenticateToken = require('../middleware/authenticateToken');
const logger = require('../../shared/logging/logger');

// Real-time event emitter (if available)
let io = null;
try {
  const realtimeModule = require('../realtime');
  io = realtimeModule.io;
} catch (error) {
  // Real-time not available
}

/**
 * Emit real-time event
 */
function emitEvent(eventType, entityType, data) {
  if (io) {
    io.emit('groupSessions:update', {
      action: eventType,
      entityType: entityType,
      entityId: data.id,
      data: data,
    });
  }
}

// Apply authentication to all routes
router.use(authenticateToken);

/**
 * Groups Routes
 */
router.get('/groups', async (req, res) => {
  try {
    const groups = await Group.findAll({
      order: [['name', 'ASC']],
    });
    res.json(groups);
  } catch (error) {
    logger.error('Error fetching groups:', error);
    res.status(500).json({ error: 'خطأ في جلب المجموعات' });
  }
});

router.post('/groups', async (req, res) => {
  try {
    const group = await Group.create(req.body);
    emitEvent('create', 'group', group);
    logger.info('Group created', { id: group.id, name: group.name });
    res.status(201).json(group);
  } catch (error) {
    logger.error('Error creating group:', error);
    res.status(400).json({ error: 'خطأ في إضافة المجموعة' });
  }
});

/**
 * Group Sessions Routes
 */
router.get('/sessions', async (req, res) => {
  try {
    const sessions = await GroupSession.findAll({
      order: [['date', 'DESC']],
      limit: 100,
    });
    res.json(sessions);
  } catch (error) {
    logger.error('Error fetching group sessions:', error);
    res.status(500).json({ error: 'خطأ في جلب الجلسات الجماعية' });
  }
});

router.post('/sessions', async (req, res) => {
  try {
    const session = await GroupSession.create(req.body);
    emitEvent('create', 'session', session);
    logger.info('Group session created', { id: session.id, groupId: session.groupId });
    res.status(201).json(session);
  } catch (error) {
    logger.error('Error creating group session:', error);
    res.status(400).json({ error: 'خطأ في إضافة الجلسة الجماعية' });
  }
});

router.put('/sessions/:id', async (req, res) => {
  try {
    const [updated] = await GroupSession.update(req.body, {
      where: { id: req.params.id },
    });
    if (updated) {
      const session = await GroupSession.findByPk(req.params.id);
      emitEvent('update', 'session', session);
      logger.info('Group session updated', { id: session.id });
      res.json(session);
    } else {
      res.status(404).json({ error: 'الجلسة الجماعية غير موجودة' });
    }
  } catch (error) {
    logger.error('Error updating group session:', error);
    res.status(400).json({ error: 'خطأ في تحديث الجلسة الجماعية' });
  }
});

router.delete('/sessions/:id', async (req, res) => {
  try {
    const deleted = await GroupSession.destroy({
      where: { id: req.params.id },
    });
    if (deleted) {
      emitEvent('delete', 'session', { id: req.params.id });
      logger.info('Group session deleted', { id: req.params.id });
      res.json({ message: 'تم حذف الجلسة الجماعية بنجاح' });
    } else {
      res.status(404).json({ error: 'الجلسة الجماعية غير موجودة' });
    }
  } catch (error) {
    logger.error('Error deleting group session:', error);
    res.status(400).json({ error: 'خطأ في حذف الجلسة الجماعية' });
  }
});

module.exports = router;
