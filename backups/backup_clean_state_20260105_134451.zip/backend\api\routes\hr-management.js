/**
 * 👥 API Routes for HR Management
 * مسارات API لإدارة الموارد البشرية
 */

const express = require('express');
const router = express.Router();
let HREmployeeManager, HRPayrollManager, HRLeaveManager, HRPerformanceManager, HRRecruitmentManager;
let HRAnalyticsManager,
  HRReportsManager,
  HRNotificationsManager,
  HRIntegrationManager,
  HRBackupManager;
let HRSearchEngine, HRExportImportManager, HRArchiveManager, HRPerformanceOptimizer;
let HRSaudiGOSIManager, HRSaudiTaxManager, HRSaudiLaborLawManager, HRSaudiHijriCalendar;

try {
  HREmployeeManager = require('../../shared/utils/hr-employee-manager');
} catch (e) {
  HREmployeeManager = class {};
}
try {
  HRPayrollManager = require('../../shared/utils/hr-payroll-manager');
} catch (e) {
  HRPayrollManager = class {};
}
try {
  HRLeaveManager = require('../../shared/utils/hr-leave-manager');
} catch (e) {
  HRLeaveManager = class {};
}
try {
  HRPerformanceManager = require('../../shared/utils/hr-performance-manager');
} catch (e) {
  HRPerformanceManager = class {};
}
try {
  HRRecruitmentManager = require('../../shared/utils/hr-recruitment-manager');
} catch (e) {
  HRRecruitmentManager = class {};
}
try {
  HRAnalyticsManager = require('../../shared/utils/hr-analytics-manager');
} catch (e) {
  HRAnalyticsManager = class {};
}
try {
  HRReportsManager = require('../../shared/utils/hr-reports-manager');
} catch (e) {
  HRReportsManager = class {};
}
try {
  HRNotificationsManager = require('../../shared/utils/hr-notifications-manager');
} catch (e) {
  HRNotificationsManager = class {};
}
try {
  HRIntegrationManager = require('../../shared/utils/hr-integration-manager');
} catch (e) {
  HRIntegrationManager = class {};
}
try {
  HRBackupManager = require('../../shared/utils/hr-backup-manager');
} catch (e) {
  HRBackupManager = class {};
}
try {
  HRSearchEngine = require('../../shared/utils/hr-search-engine');
} catch (e) {
  HRSearchEngine = class {};
}
try {
  HRExportImportManager = require('../../shared/utils/hr-export-import-manager');
} catch (e) {
  HRExportImportManager = class {};
}
try {
  HRArchiveManager = require('../../shared/utils/hr-archive-manager');
} catch (e) {
  HRArchiveManager = class {};
}
try {
  HRPerformanceOptimizer = require('../../shared/utils/hr-performance-optimizer');
} catch (e) {
  HRPerformanceOptimizer = class {};
}
try {
  HRSaudiGOSIManager = require('../../shared/utils/hr-saudi-gosi-manager');
} catch (e) {
  HRSaudiGOSIManager = class {};
}
try {
  HRSaudiTaxManager = require('../../shared/utils/hr-saudi-tax-manager');
} catch (e) {
  HRSaudiTaxManager = class {};
}
try {
  HRSaudiLaborLawManager = require('../../shared/utils/hr-saudi-labor-law-manager');
} catch (e) {
  HRSaudiLaborLawManager = class {};
}
try {
  HRSaudiHijriCalendar = require('../../shared/utils/hr-saudi-hijri-calendar');
} catch (e) {
  HRSaudiHijriCalendar = class {};
}
const HRSaudiHolidaysManager = require('../../shared/utils/hr-saudi-holidays-manager');
const HRSaudiVisaResidencyManager = require('../../shared/utils/hr-saudi-visa-residency-manager');
const HRSaudiHealthInsuranceManager = require('../../shared/utils/hr-saudi-health-insurance-manager');
const HRSaudiRamadanManager = require('../../shared/utils/hr-saudi-ramadan-manager');
const HRSaudiGovernmentIntegration = require('../../shared/utils/hr-saudi-government-integration');
const HRSaudiNotificationsManager = require('../../shared/utils/hr-saudi-notifications-manager');
const HRSaudiReportsManager = require('../../shared/utils/hr-saudi-reports-manager');
const HRSaudiAnalyticsManager = require('../../shared/utils/hr-saudi-analytics-manager');
const HRSaudiStatisticsManager = require('../../shared/utils/hr-saudi-statistics-manager');
const HRSaudiRemindersManager = require('../../shared/utils/hr-saudi-reminders-manager');
const HRSaudiAlertsManager = require('../../shared/utils/hr-saudi-alerts-manager');
const { requirePermission } = require('../../shared/middleware/permissions-middleware');

const employeeManager = new HREmployeeManager();
const payrollManager = new HRPayrollManager(employeeManager);
const leaveManager = new HRLeaveManager(employeeManager);
const performanceManager = new HRPerformanceManager(employeeManager);
const recruitmentManager = new HRRecruitmentManager(employeeManager);
const analyticsManager = new HRAnalyticsManager(
  employeeManager,
  payrollManager,
  leaveManager,
  performanceManager,
  recruitmentManager
);
const reportsManager = new HRReportsManager(
  employeeManager,
  payrollManager,
  leaveManager,
  performanceManager,
  recruitmentManager
);
const notificationsManager = new HRNotificationsManager(
  employeeManager,
  payrollManager,
  leaveManager,
  performanceManager,
  recruitmentManager
);
const integrationManager = new HRIntegrationManager(employeeManager);
const backupManager = new HRBackupManager(
  employeeManager,
  payrollManager,
  leaveManager,
  performanceManager,
  recruitmentManager
);
const searchEngine = new HRSearchEngine(
  employeeManager,
  payrollManager,
  leaveManager,
  performanceManager,
  recruitmentManager
);
const exportImportManager = new HRExportImportManager(
  employeeManager,
  payrollManager,
  leaveManager,
  performanceManager,
  recruitmentManager
);
const archiveManager = new HRArchiveManager(
  employeeManager,
  payrollManager,
  leaveManager,
  performanceManager,
  recruitmentManager
);
const performanceOptimizer = new HRPerformanceOptimizer(
  employeeManager,
  payrollManager,
  leaveManager,
  performanceManager,
  recruitmentManager
);

// Saudi Systems
const hijriCalendar = new HRSaudiHijriCalendar();
const gosiManager = new HRSaudiGOSIManager(employeeManager, payrollManager);
const taxManager = new HRSaudiTaxManager(employeeManager, payrollManager);
const laborLawManager = new HRSaudiLaborLawManager(employeeManager, leaveManager, payrollManager);
const holidaysManager = new HRSaudiHolidaysManager(hijriCalendar);
const visaResidencyManager = new HRSaudiVisaResidencyManager(employeeManager);
const healthInsuranceManager = new HRSaudiHealthInsuranceManager(employeeManager);
const ramadanManager = new HRSaudiRamadanManager(hijriCalendar, employeeManager, null);
const governmentIntegration = new HRSaudiGovernmentIntegration(
  employeeManager,
  gosiManager,
  taxManager
);
const saudiNotificationsManager = new HRSaudiNotificationsManager(
  gosiManager,
  taxManager,
  visaResidencyManager,
  healthInsuranceManager,
  ramadanManager,
  hijriCalendar
);
const saudiReportsManager = new HRSaudiReportsManager(
  gosiManager,
  taxManager,
  laborLawManager,
  visaResidencyManager,
  healthInsuranceManager,
  ramadanManager,
  employeeManager
);
const saudiAnalyticsManager = new HRSaudiAnalyticsManager(
  gosiManager,
  taxManager,
  laborLawManager,
  visaResidencyManager,
  healthInsuranceManager,
  ramadanManager,
  employeeManager,
  payrollManager
);
const saudiStatisticsManager = new HRSaudiStatisticsManager(
  gosiManager,
  taxManager,
  laborLawManager,
  visaResidencyManager,
  healthInsuranceManager,
  employeeManager,
  payrollManager
);
const saudiRemindersManager = new HRSaudiRemindersManager(
  gosiManager,
  taxManager,
  visaResidencyManager,
  healthInsuranceManager,
  ramadanManager,
  hijriCalendar
);
const saudiAlertsManager = new HRSaudiAlertsManager(
  laborLawManager,
  gosiManager,
  taxManager,
  visaResidencyManager,
  healthInsuranceManager
);

// ========== Employees Management ==========

/**
 * إضافة موظف
 */
router.post('/employees', requirePermission('hr.employees.edit'), async (req, res) => {
  try {
    const employee = employeeManager.addEmployee(req.body);
    res.json({ success: true, data: employee });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تحديث موظف
 */
router.put('/employees/:employeeId', requirePermission('hr.employees.edit'), async (req, res) => {
  try {
    const employee = employeeManager.updateEmployee(req.params.employeeId, req.body);
    res.json({ success: true, data: employee });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على موظف
 */
router.get('/employees/:employeeId', requirePermission('hr.employees.view'), async (req, res) => {
  try {
    const employee = employeeManager.getEmployee(req.params.employeeId);
    if (!employee) {
      return res.status(404).json({ success: false, error: 'Employee not found' });
    }
    res.json({ success: true, data: employee });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على جميع الموظفين
 */
router.get('/employees', requirePermission('hr.employees.view'), async (req, res) => {
  try {
    const employees = employeeManager.getAllEmployees(req.query);
    res.json({ success: true, data: employees });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * إحصائيات الموظفين
 */
router.get('/employees/statistics', requirePermission('hr.employees.view'), async (req, res) => {
  try {
    const statistics = employeeManager.getEmployeeStatistics();
    res.json({ success: true, data: statistics });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Departments Management ==========

/**
 * إضافة قسم
 */
router.post('/departments', requirePermission('hr.departments.edit'), async (req, res) => {
  try {
    const department = employeeManager.addDepartment(req.body);
    res.json({ success: true, data: department });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على جميع الأقسام
 */
router.get('/departments', requirePermission('hr.departments.view'), async (req, res) => {
  try {
    const departments = employeeManager.getAllDepartments();
    res.json({ success: true, data: departments });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Positions Management ==========

/**
 * إضافة منصب
 */
router.post('/positions', requirePermission('hr.positions.edit'), async (req, res) => {
  try {
    const position = employeeManager.addPosition(req.body);
    res.json({ success: true, data: position });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على جميع المناصب
 */
router.get('/positions', requirePermission('hr.positions.view'), async (req, res) => {
  try {
    const positions = employeeManager.getAllPositions(req.query);
    res.json({ success: true, data: positions });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Payroll Management ==========

/**
 * إنشاء هيكل راتب
 */
router.post(
  '/payroll/salary-structures',
  requirePermission('hr.payroll.edit'),
  async (req, res) => {
    try {
      const structure = payrollManager.createSalaryStructure(req.body.employeeId, req.body);
      res.json({ success: true, data: structure });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * توليد كشف راتب
 */
router.post('/payroll/generate', requirePermission('hr.payroll.edit'), async (req, res) => {
  try {
    const payroll = payrollManager.generatePayroll(
      req.body.employeeId,
      req.body.month,
      req.body.year
    );

    // إرسال إشعار تلقائي
    await notificationsManager.handlePayrollEvent(payroll);

    res.json({ success: true, data: payroll });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الموافقة على كشف راتب
 */
router.post(
  '/payroll/:payrollId/approve',
  requirePermission('hr.payroll.approve'),
  async (req, res) => {
    try {
      const payroll = payrollManager.approvePayroll(req.params.payrollId, req.body.approvedBy);
      res.json({ success: true, data: payroll });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * الحصول على كشوف الرواتب
 */
router.get('/payroll/records', requirePermission('hr.payroll.view'), async (req, res) => {
  try {
    const records = payrollManager.getPayrollRecords(req.query);
    res.json({ success: true, data: records });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * إحصائيات الرواتب
 */
router.get('/payroll/statistics', requirePermission('hr.payroll.view'), async (req, res) => {
  try {
    const statistics = payrollManager.getPayrollStatistics(req.query.month, req.query.year);
    res.json({ success: true, data: statistics });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Leave Management ==========

/**
 * طلب إجازة
 */
router.post('/leaves/requests', requirePermission('hr.leaves.edit'), async (req, res) => {
  try {
    const request = leaveManager.requestLeave(req.body.employeeId, req.body);

    // إرسال إشعار تلقائي
    await notificationsManager.handleLeaveRequestEvent(request);

    res.json({ success: true, data: request });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الموافقة على طلب إجازة
 */
router.post(
  '/leaves/requests/:requestId/approve',
  requirePermission('hr.leaves.approve'),
  async (req, res) => {
    try {
      const request = leaveManager.approveLeave(req.params.requestId, req.body.approvedBy);
      res.json({ success: true, data: request });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * رفض طلب إجازة
 */
router.post(
  '/leaves/requests/:requestId/reject',
  requirePermission('hr.leaves.approve'),
  async (req, res) => {
    try {
      const request = leaveManager.rejectLeave(
        req.params.requestId,
        req.body.rejectedBy,
        req.body.reason
      );
      res.json({ success: true, data: request });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * الحصول على طلبات الإجازة
 */
router.get('/leaves/requests', requirePermission('hr.leaves.view'), async (req, res) => {
  try {
    const requests = leaveManager.getLeaveRequests(req.query);
    res.json({ success: true, data: requests });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على رصيد الإجازة
 */
router.get('/leaves/balance/:employeeId', requirePermission('hr.leaves.view'), async (req, res) => {
  try {
    const balance = leaveManager.getLeaveBalance(req.params.employeeId, req.query.leaveTypeId);
    res.json({ success: true, data: balance });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * إحصائيات الإجازات
 */
router.get('/leaves/statistics', requirePermission('hr.leaves.view'), async (req, res) => {
  try {
    const statistics = leaveManager.getLeaveStatistics(req.query.employeeId);
    res.json({ success: true, data: statistics });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Performance Management ==========

/**
 * إنشاء تقييم
 */
router.post(
  '/performance/evaluations',
  requirePermission('hr.performance.edit'),
  async (req, res) => {
    try {
      const evaluation = performanceManager.createEvaluation(req.body.employeeId, req.body);
      res.json({ success: true, data: evaluation });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * إكمال تقييم
 */
router.post(
  '/performance/evaluations/:evaluationId/complete',
  requirePermission('hr.performance.edit'),
  async (req, res) => {
    try {
      const evaluation = performanceManager.completeEvaluation(req.params.evaluationId);
      res.json({ success: true, data: evaluation });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * الحصول على التقييمات
 */
router.get(
  '/performance/evaluations',
  requirePermission('hr.performance.view'),
  async (req, res) => {
    try {
      const evaluations = performanceManager.getEvaluations(req.query);
      res.json({ success: true, data: evaluations });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * الحصول على معايير التقييم
 */
router.get('/performance/criteria', requirePermission('hr.performance.view'), async (req, res) => {
  try {
    const criteria = performanceManager.getAllCriteria();
    res.json({ success: true, data: criteria });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * إحصائيات التقييمات
 */
router.get(
  '/performance/statistics',
  requirePermission('hr.performance.view'),
  async (req, res) => {
    try {
      const statistics = performanceManager.getPerformanceStatistics(req.query.employeeId);
      res.json({ success: true, data: statistics });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Recruitment Management ==========

/**
 * إنشاء إعلان وظيفي
 */
router.post(
  '/recruitment/job-postings',
  requirePermission('hr.recruitment.edit'),
  async (req, res) => {
    try {
      const posting = recruitmentManager.createJobPosting(req.body);
      res.json({ success: true, data: posting });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * تقديم طلب توظيف
 */
router.post(
  '/recruitment/applications',
  requirePermission('hr.recruitment.edit'),
  async (req, res) => {
    try {
      const application = recruitmentManager.submitApplication(req.body.jobPostingId, req.body);

      // إرسال إشعار تلقائي
      await notificationsManager.handleApplicationEvent(application);

      res.json({ success: true, data: application });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * جدولة مقابلة
 */
router.post(
  '/recruitment/interviews',
  requirePermission('hr.recruitment.edit'),
  async (req, res) => {
    try {
      const interview = recruitmentManager.scheduleInterview(req.body.applicationId, req.body);
      res.json({ success: true, data: interview });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * إكمال مقابلة
 */
router.post(
  '/recruitment/interviews/:interviewId/complete',
  requirePermission('hr.recruitment.edit'),
  async (req, res) => {
    try {
      const interview = recruitmentManager.completeInterview(req.params.interviewId, req.body);
      res.json({ success: true, data: interview });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * تقديم عرض عمل
 */
router.post('/recruitment/offers', requirePermission('hr.recruitment.edit'), async (req, res) => {
  try {
    const offer = recruitmentManager.makeOffer(req.body.applicationId, req.body);
    res.json({ success: true, data: offer });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على الإعلانات الوظيفية
 */
router.get(
  '/recruitment/job-postings',
  requirePermission('hr.recruitment.view'),
  async (req, res) => {
    try {
      const postings = recruitmentManager.getJobPostings(req.query);
      res.json({ success: true, data: postings });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * الحصول على طلبات التوظيف
 */
router.get(
  '/recruitment/applications',
  requirePermission('hr.recruitment.view'),
  async (req, res) => {
    try {
      const applications = recruitmentManager.getApplications(req.query);
      res.json({ success: true, data: applications });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * إحصائيات التوظيف
 */
router.get(
  '/recruitment/statistics',
  requirePermission('hr.recruitment.view'),
  async (req, res) => {
    try {
      const statistics = recruitmentManager.getRecruitmentStatistics();
      res.json({ success: true, data: statistics });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Analytics ==========

/**
 * تحليل شامل للموارد البشرية
 */
router.get('/analytics/comprehensive', requirePermission('hr.analytics.view'), async (req, res) => {
  try {
    const analysis = await analyticsManager.comprehensiveAnalysis(req.query);
    res.json({ success: true, data: analysis });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تقرير تحليلي شامل
 */
router.get('/analytics/report', requirePermission('hr.analytics.view'), async (req, res) => {
  try {
    const report = await analyticsManager.generateAnalyticalReport(req.query);
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تحليل الموظفين حسب القسم
 */
router.get('/analytics/departments', requirePermission('hr.analytics.view'), async (req, res) => {
  try {
    const analysis = analyticsManager.getDepartmentAnalysis();
    res.json({ success: true, data: analysis });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تحليل التكلفة لكل موظف
 */
router.get(
  '/analytics/cost-per-employee',
  requirePermission('hr.analytics.view'),
  async (req, res) => {
    try {
      const analysis = analyticsManager.getCostPerEmployeeAnalysis(req.query.month, req.query.year);
      res.json({ success: true, data: analysis });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Reports ==========

/**
 * تقرير الموظفين
 */
router.get('/reports/employees', requirePermission('hr.reports.view'), async (req, res) => {
  try {
    const report = reportsManager.generateEmployeeReport(req.query);
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تقرير الرواتب
 */
router.get('/reports/payroll', requirePermission('hr.reports.view'), async (req, res) => {
  try {
    const report = reportsManager.generatePayrollReport(req.query.month, req.query.year, req.query);
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تقرير الإجازات
 */
router.get('/reports/leaves', requirePermission('hr.reports.view'), async (req, res) => {
  try {
    const report = reportsManager.generateLeaveReport(req.query);
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تقرير التقييمات
 */
router.get('/reports/performance', requirePermission('hr.reports.view'), async (req, res) => {
  try {
    const report = reportsManager.generatePerformanceReport(req.query);
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تقرير التوظيف
 */
router.get('/reports/recruitment', requirePermission('hr.reports.view'), async (req, res) => {
  try {
    const report = reportsManager.generateRecruitmentReport(req.query);
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تقرير شامل
 */
router.get('/reports/comprehensive', requirePermission('hr.reports.view'), async (req, res) => {
  try {
    const report = reportsManager.generateComprehensiveReport(req.query);
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * حفظ تقرير
 */
router.post('/reports/save', requirePermission('hr.reports.edit'), async (req, res) => {
  try {
    const report = reportsManager.saveReport(req.body);
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على تقرير محفوظ
 */
router.get('/reports/:reportId', requirePermission('hr.reports.view'), async (req, res) => {
  try {
    const report = reportsManager.getReport(req.params.reportId);
    if (!report) {
      return res.status(404).json({ success: false, error: 'Report not found' });
    }
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على جميع التقارير المحفوظة
 */
router.get('/reports', requirePermission('hr.reports.view'), async (req, res) => {
  try {
    const reports = reportsManager.getAllReports(req.query);
    res.json({ success: true, data: reports });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Notifications ==========

/**
 * الحصول على الإشعارات
 */
router.get('/notifications', requirePermission('hr.notifications.view'), async (req, res) => {
  try {
    const notifications = notificationsManager.getNotifications(req.query);
    res.json({ success: true, data: notifications });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على قواعد الإشعارات
 */
router.get('/notifications/rules', requirePermission('hr.notifications.view'), async (req, res) => {
  try {
    const rules = notificationsManager.getNotificationRules();
    res.json({ success: true, data: rules });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تفعيل/تعطيل قاعدة إشعار
 */
router.post(
  '/notifications/rules/:ruleId/toggle',
  requirePermission('hr.notifications.edit'),
  async (req, res) => {
    try {
      const success = notificationsManager.toggleNotificationRule(
        req.params.ruleId,
        req.body.enabled
      );
      res.json({ success, data: { ruleId: req.params.ruleId, enabled: req.body.enabled } });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * تحديد إشعار كمقروء
 */
router.post(
  '/notifications/:notificationId/read',
  requirePermission('hr.notifications.edit'),
  async (req, res) => {
    try {
      const success = notificationsManager.markAsRead(req.params.notificationId);
      res.json({ success, data: { notificationId: req.params.notificationId } });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Integration ==========

/**
 * مزامنة مع نظام خارجي
 */
router.post(
  '/integration/:systemId/sync/:employeeId',
  requirePermission('hr.integration.edit'),
  async (req, res) => {
    try {
      const result = await integrationManager.syncWithSystem(
        req.params.systemId,
        req.params.employeeId,
        req.body
      );
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * الحصول على التكاملات
 */
router.get('/integration', requirePermission('hr.integration.view'), async (req, res) => {
  try {
    const integrations = integrationManager.getIntegrations(req.query);
    res.json({ success: true, data: integrations });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تفعيل/تعطيل تكامل
 */
router.post(
  '/integration/:systemId/toggle',
  requirePermission('hr.integration.edit'),
  async (req, res) => {
    try {
      const success = integrationManager.toggleIntegration(req.params.systemId, req.body.enabled);
      res.json({ success, data: { systemId: req.params.systemId, enabled: req.body.enabled } });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * تقرير التكامل
 */
router.get('/integration/report', requirePermission('hr.integration.view'), async (req, res) => {
  try {
    const report = integrationManager.getIntegrationReport();
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Backup ==========

/**
 * إنشاء نسخة احتياطية
 */
router.post('/backup/create', requirePermission('hr.backup.edit'), async (req, res) => {
  try {
    const backup = await backupManager.createBackup(req.body.type || 'full');
    res.json({ success: true, data: backup });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * استعادة نسخة احتياطية
 */
router.post('/backup/:backupId/restore', requirePermission('hr.backup.edit'), async (req, res) => {
  try {
    const result = await backupManager.restoreBackup(req.params.backupId, req.body.type || 'full');
    res.json({ success: true, data: result });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على النسخ الاحتياطية
 */
router.get('/backup', requirePermission('hr.backup.view'), async (req, res) => {
  try {
    const backups = backupManager.getBackups(req.query);
    res.json({ success: true, data: backups });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * حذف نسخة احتياطية
 */
router.delete('/backup/:backupId', requirePermission('hr.backup.edit'), async (req, res) => {
  try {
    const success = backupManager.deleteBackup(req.params.backupId);
    res.json({ success, data: { backupId: req.params.backupId } });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * إحصائيات النسخ الاحتياطية
 */
router.get('/backup/statistics', requirePermission('hr.backup.view'), async (req, res) => {
  try {
    const statistics = backupManager.getBackupStatistics();
    res.json({ success: true, data: statistics });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Search ==========

/**
 * بحث شامل
 */
router.get('/search', requirePermission('hr.search.view'), async (req, res) => {
  try {
    const results = await searchEngine.comprehensiveSearch(req.query.q || '', req.query);
    res.json({ success: true, data: results });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * بحث متقدم
 */
router.post('/search/advanced', requirePermission('hr.search.view'), async (req, res) => {
  try {
    const results = await searchEngine.advancedSearch(req.body);
    res.json({ success: true, data: results });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Export/Import ==========

/**
 * تصدير الموظفين
 */
router.get('/export/employees', requirePermission('hr.export.view'), async (req, res) => {
  try {
    const exportData = exportImportManager.exportEmployees(req.query.format || 'json', req.query);
    res.json({ success: true, data: exportData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * استيراد الموظفين
 */
router.post('/import/employees', requirePermission('hr.import.edit'), async (req, res) => {
  try {
    const result = exportImportManager.importEmployees(req.body.data, req.body.format || 'json');
    res.json({ success: true, data: result });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تصدير كشوف الرواتب
 */
router.get('/export/payroll', requirePermission('hr.export.view'), async (req, res) => {
  try {
    const exportData = exportImportManager.exportPayroll(req.query.format || 'json', req.query);
    res.json({ success: true, data: exportData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تصدير طلبات الإجازة
 */
router.get('/export/leaves', requirePermission('hr.export.view'), async (req, res) => {
  try {
    const exportData = exportImportManager.exportLeaves(req.query.format || 'json', req.query);
    res.json({ success: true, data: exportData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تصدير شامل
 */
router.get('/export/all', requirePermission('hr.export.view'), async (req, res) => {
  try {
    const exportData = exportImportManager.exportAll(req.query.format || 'json');
    res.json({ success: true, data: exportData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Archive ==========

/**
 * أرشفة سجل
 */
router.post(
  '/archive/:recordType/:recordId',
  requirePermission('hr.archive.edit'),
  async (req, res) => {
    try {
      const archived = archiveManager.archiveRecord(
        req.params.recordType,
        req.params.recordId,
        req.body.reason
      );
      res.json({ success: true, data: archived });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * استعادة سجل مؤرشف
 */
router.post(
  '/archive/:archiveId/restore',
  requirePermission('hr.archive.edit'),
  async (req, res) => {
    try {
      const result = archiveManager.restoreRecord(req.params.archiveId);
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * أرشفة تلقائية
 */
router.post('/archive/auto', requirePermission('hr.archive.edit'), async (req, res) => {
  try {
    const result = await archiveManager.autoArchive();
    res.json({ success: true, data: result });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على السجلات المؤرشفة
 */
router.get('/archive', requirePermission('hr.archive.view'), async (req, res) => {
  try {
    const records = archiveManager.getArchivedRecords(req.query);
    res.json({ success: true, data: records });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على قواعد الأرشفة
 */
router.get('/archive/rules', requirePermission('hr.archive.view'), async (req, res) => {
  try {
    const rules = archiveManager.getArchiveRules();
    res.json({ success: true, data: rules });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تفعيل/تعطيل قاعدة أرشفة
 */
router.post(
  '/archive/rules/:ruleId/toggle',
  requirePermission('hr.archive.edit'),
  async (req, res) => {
    try {
      const success = archiveManager.toggleArchiveRule(req.params.ruleId, req.body.enabled);
      res.json({ success, data: { ruleId: req.params.ruleId, enabled: req.body.enabled } });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * إحصائيات الأرشيف
 */
router.get('/archive/statistics', requirePermission('hr.archive.view'), async (req, res) => {
  try {
    const statistics = archiveManager.getArchiveStatistics();
    res.json({ success: true, data: statistics });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Performance ==========

/**
 * إحصائيات الأداء
 */
router.get(
  '/performance/statistics',
  requirePermission('hr.performance.view'),
  async (req, res) => {
    try {
      const statistics = performanceOptimizer.getPerformanceStatistics();
      res.json({ success: true, data: statistics });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * تحليل الأداء
 */
router.get('/performance/analyze', requirePermission('hr.performance.view'), async (req, res) => {
  try {
    const analysis = performanceOptimizer.analyzePerformance();
    res.json({ success: true, data: analysis });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * مسح الذاكرة المؤقتة
 */
router.post(
  '/performance/cache/clear',
  requirePermission('hr.performance.edit'),
  async (req, res) => {
    try {
      const result = performanceOptimizer.clearCache();
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * تحسين الذاكرة
 */
router.post('/performance/optimize', requirePermission('hr.performance.edit'), async (req, res) => {
  try {
    const result = performanceOptimizer.optimizeMemory();
    res.json({ success: true, data: result });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Saudi Systems ==========

// GOSI
router.get(
  '/saudi/gosi/contribution/:employeeId/:month/:year',
  requirePermission('hr.saudi.gosi.view'),
  async (req, res) => {
    try {
      const contribution = gosiManager.calculateGOSIContribution(
        req.params.employeeId,
        parseInt(req.params.month),
        parseInt(req.params.year)
      );
      res.json({ success: true, data: contribution });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/saudi/gosi/report/:month/:year',
  requirePermission('hr.saudi.gosi.view'),
  async (req, res) => {
    try {
      const report = gosiManager.generateGOSIReport(
        parseInt(req.params.month),
        parseInt(req.params.year)
      );
      res.json({ success: true, data: report });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.post(
  '/saudi/gosi/submit/:month/:year',
  requirePermission('hr.saudi.gosi.edit'),
  async (req, res) => {
    try {
      const result = await governmentIntegration.submitGOSIReport(
        parseInt(req.params.month),
        parseInt(req.params.year)
      );
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// Tax & Zakat
router.get(
  '/saudi/tax/:employeeId/:month/:year',
  requirePermission('hr.saudi.tax.view'),
  async (req, res) => {
    try {
      const taxRecord = taxManager.calculateAllTaxes(
        req.params.employeeId,
        parseInt(req.params.month),
        parseInt(req.params.year)
      );
      res.json({ success: true, data: taxRecord });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/saudi/tax/report/:month/:year',
  requirePermission('hr.saudi.tax.view'),
  async (req, res) => {
    try {
      const report = taxManager.generateTaxReport(
        parseInt(req.params.month),
        parseInt(req.params.year)
      );
      res.json({ success: true, data: report });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// Labor Law
router.get(
  '/saudi/labor-law/compliance/:employeeId',
  requirePermission('hr.saudi.labor.view'),
  async (req, res) => {
    try {
      const compliance = laborLawManager.checkCompliance(req.params.employeeId);
      res.json({ success: true, data: compliance });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/saudi/labor-law/compliance',
  requirePermission('hr.saudi.labor.view'),
  async (req, res) => {
    try {
      const compliance = laborLawManager.checkOverallCompliance();
      res.json({ success: true, data: compliance });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get('/saudi/labor-law/rules', requirePermission('hr.saudi.labor.view'), async (req, res) => {
  try {
    const rules = laborLawManager.getLaborLawRules();
    res.json({ success: true, data: rules });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Hijri Calendar
router.get('/saudi/hijri/current', requirePermission('hr.saudi.hijri.view'), async (req, res) => {
  try {
    const hijriDate = hijriCalendar.getCurrentHijriDate();
    res.json({ success: true, data: hijriDate });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/saudi/hijri/convert', requirePermission('hr.saudi.hijri.view'), async (req, res) => {
  try {
    const { date, to } = req.body;
    let result;
    if (to === 'hijri') {
      result = hijriCalendar.gregorianToHijri(date);
    } else {
      result = hijriCalendar.hijriToGregorian(date.year, date.month, date.day);
    }
    res.json({ success: true, data: result });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Holidays
router.get(
  '/saudi/holidays/:year',
  requirePermission('hr.saudi.holidays.view'),
  async (req, res) => {
    try {
      const holidays = holidaysManager.getPublicHolidays(parseInt(req.params.year));
      res.json({ success: true, data: holidays });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/saudi/holidays/upcoming',
  requirePermission('hr.saudi.holidays.view'),
  async (req, res) => {
    try {
      const holidays = holidaysManager.getUpcomingHolidays(parseInt(req.query.limit) || 5);
      res.json({ success: true, data: holidays });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/saudi/holidays/working-days/:year/:month',
  requirePermission('hr.saudi.holidays.view'),
  async (req, res) => {
    try {
      const workingDays = holidaysManager.calculateWorkingDays(
        parseInt(req.params.year),
        parseInt(req.params.month)
      );
      res.json({ success: true, data: workingDays });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// Visa & Residency
router.post('/saudi/visa/register', requirePermission('hr.saudi.visa.edit'), async (req, res) => {
  try {
    const visa = visaResidencyManager.registerVisa(req.body.employeeId, req.body);
    res.json({ success: true, data: visa });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post(
  '/saudi/residency/register',
  requirePermission('hr.saudi.residency.edit'),
  async (req, res) => {
    try {
      const residency = visaResidencyManager.registerResidency(req.body.employeeId, req.body);
      res.json({ success: true, data: residency });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/saudi/visa/employee/:employeeId',
  requirePermission('hr.saudi.visa.view'),
  async (req, res) => {
    try {
      const visas = visaResidencyManager.getEmployeeVisas(req.params.employeeId);
      res.json({ success: true, data: visas });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/saudi/residency/employee/:employeeId',
  requirePermission('hr.saudi.residency.view'),
  async (req, res) => {
    try {
      const residencies = visaResidencyManager.getEmployeeResidencies(req.params.employeeId);
      res.json({ success: true, data: residencies });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/saudi/visa-residency/expiring',
  requirePermission('hr.saudi.visa.view'),
  async (req, res) => {
    try {
      const expiring = visaResidencyManager.checkExpiringDocuments(parseInt(req.query.days) || 30);
      res.json({ success: true, data: expiring });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// Health Insurance
router.post(
  '/saudi/health-insurance/register',
  requirePermission('hr.saudi.insurance.edit'),
  async (req, res) => {
    try {
      const insurance = healthInsuranceManager.registerInsurance(req.body.employeeId, req.body);
      res.json({ success: true, data: insurance });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/saudi/health-insurance/employee/:employeeId',
  requirePermission('hr.saudi.insurance.view'),
  async (req, res) => {
    try {
      const insurance = healthInsuranceManager.getEmployeeInsurance(req.params.employeeId);
      res.json({ success: true, data: insurance });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/saudi/health-insurance/expiring',
  requirePermission('hr.saudi.insurance.view'),
  async (req, res) => {
    try {
      const expiring = healthInsuranceManager.checkExpiringInsurance(
        parseInt(req.query.days) || 30
      );
      res.json({ success: true, data: expiring });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// Ramadan
router.get(
  '/saudi/ramadan/dates/:year',
  requirePermission('hr.saudi.ramadan.view'),
  async (req, res) => {
    try {
      const dates = ramadanManager.getRamadanDates(parseInt(req.params.year));
      res.json({ success: true, data: dates });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.post(
  '/saudi/ramadan/schedule',
  requirePermission('hr.saudi.ramadan.edit'),
  async (req, res) => {
    try {
      const schedule = ramadanManager.applyRamadanSchedule(
        req.body.employeeId,
        req.body.ramadanYear
      );
      res.json({ success: true, data: schedule });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/saudi/ramadan/bonus/:employeeId/:year',
  requirePermission('hr.saudi.ramadan.view'),
  async (req, res) => {
    try {
      const bonus = ramadanManager.calculateRamadanBonus(
        req.params.employeeId,
        parseInt(req.params.year)
      );
      res.json({ success: true, data: bonus });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/saudi/ramadan/report/:year',
  requirePermission('hr.saudi.ramadan.view'),
  async (req, res) => {
    try {
      const report = ramadanManager.generateRamadanReport(parseInt(req.params.year));
      res.json({ success: true, data: report });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// Government Integration
router.get(
  '/saudi/government/integration/status',
  requirePermission('hr.saudi.government.view'),
  async (req, res) => {
    try {
      const status = governmentIntegration.getIntegrationStatus();
      res.json({ success: true, data: status });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.post(
  '/saudi/government/verify/national-id',
  requirePermission('hr.saudi.government.view'),
  async (req, res) => {
    try {
      const result = await governmentIntegration.verifyNationalId(req.body.nationalId);
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.post(
  '/saudi/government/verify/iqama',
  requirePermission('hr.saudi.government.view'),
  async (req, res) => {
    try {
      const result = await governmentIntegration.verifyIqama(req.body.iqamaNumber);
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.post(
  '/saudi/government/test-connection/:systemId',
  requirePermission('hr.saudi.government.edit'),
  async (req, res) => {
    try {
      const result = await governmentIntegration.testConnection(req.params.systemId);
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Saudi Notifications ==========

router.get(
  '/saudi/notifications',
  requirePermission('hr.saudi.notifications.view'),
  async (req, res) => {
    try {
      const notifications = await saudiNotificationsManager.checkNotifications();
      res.json({ success: true, data: notifications });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/saudi/notifications/list',
  requirePermission('hr.saudi.notifications.view'),
  async (req, res) => {
    try {
      const notifications = saudiNotificationsManager.getNotifications(req.query);
      res.json({ success: true, data: notifications });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.post(
  '/saudi/notifications/:notificationId/read',
  requirePermission('hr.saudi.notifications.edit'),
  async (req, res) => {
    try {
      const success = saudiNotificationsManager.markAsRead(req.params.notificationId);
      res.json({ success, data: { notificationId: req.params.notificationId } });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.delete(
  '/saudi/notifications/:notificationId',
  requirePermission('hr.saudi.notifications.edit'),
  async (req, res) => {
    try {
      const success = saudiNotificationsManager.deleteNotification(req.params.notificationId);
      res.json({ success, data: { notificationId: req.params.notificationId } });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/saudi/notifications/statistics',
  requirePermission('hr.saudi.notifications.view'),
  async (req, res) => {
    try {
      const statistics = saudiNotificationsManager.getNotificationStatistics();
      res.json({ success: true, data: statistics });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Saudi Reports ==========

router.get(
  '/saudi/reports/comprehensive/:year',
  requirePermission('hr.saudi.reports.view'),
  async (req, res) => {
    try {
      const report = saudiReportsManager.generateComprehensiveReport(
        parseInt(req.params.year),
        req.query.month ? parseInt(req.query.month) : null
      );
      res.json({ success: true, data: report });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/saudi/reports/gosi/annual/:year',
  requirePermission('hr.saudi.reports.view'),
  async (req, res) => {
    try {
      const report = saudiReportsManager.generateGOSIMonthlyReport(parseInt(req.params.year));
      res.json({ success: true, data: report });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/saudi/reports/tax/annual/:year',
  requirePermission('hr.saudi.reports.view'),
  async (req, res) => {
    try {
      const report = saudiReportsManager.generateTaxAnnualReport(parseInt(req.params.year));
      res.json({ success: true, data: report });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/saudi/reports/employees/nationality',
  requirePermission('hr.saudi.reports.view'),
  async (req, res) => {
    try {
      const report = saudiReportsManager.generateEmployeesByNationalityReport();
      res.json({ success: true, data: report });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/saudi/reports/compliance',
  requirePermission('hr.saudi.reports.view'),
  async (req, res) => {
    try {
      const report = saudiReportsManager.generateComplianceReport();
      res.json({ success: true, data: report });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Saudi Analytics ==========

router.get(
  '/saudi/analytics/comprehensive/:year',
  requirePermission('hr.saudi.analytics.view'),
  async (req, res) => {
    try {
      const analytics = saudiAnalyticsManager.generateComprehensiveAnalytics(
        parseInt(req.params.year),
        req.query.month ? parseInt(req.query.month) : null
      );
      res.json({ success: true, data: analytics });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/saudi/analytics/gosi/:year',
  requirePermission('hr.saudi.analytics.view'),
  async (req, res) => {
    try {
      const analytics = saudiAnalyticsManager.analyzeGOSI(
        parseInt(req.params.year),
        req.query.month ? parseInt(req.query.month) : null
      );
      res.json({ success: true, data: analytics });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/saudi/analytics/tax/:year',
  requirePermission('hr.saudi.analytics.view'),
  async (req, res) => {
    try {
      const analytics = saudiAnalyticsManager.analyzeTax(
        parseInt(req.params.year),
        req.query.month ? parseInt(req.query.month) : null
      );
      res.json({ success: true, data: analytics });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/saudi/analytics/compliance',
  requirePermission('hr.saudi.analytics.view'),
  async (req, res) => {
    try {
      const analytics = saudiAnalyticsManager.analyzeCompliance();
      res.json({ success: true, data: analytics });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/saudi/analytics/employees',
  requirePermission('hr.saudi.analytics.view'),
  async (req, res) => {
    try {
      const analytics = saudiAnalyticsManager.analyzeEmployees();
      res.json({ success: true, data: analytics });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Saudi Statistics ==========

router.get(
  '/saudi/statistics/comprehensive',
  requirePermission('hr.saudi.statistics.view'),
  async (req, res) => {
    try {
      const statistics = saudiStatisticsManager.getComprehensiveStatistics(
        req.query.year ? parseInt(req.query.year) : null,
        req.query.month ? parseInt(req.query.month) : null
      );
      res.json({ success: true, data: statistics });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/saudi/statistics/employees',
  requirePermission('hr.saudi.statistics.view'),
  async (req, res) => {
    try {
      const statistics = saudiStatisticsManager.getEmployeeStatistics();
      res.json({ success: true, data: statistics });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/saudi/statistics/gosi',
  requirePermission('hr.saudi.statistics.view'),
  async (req, res) => {
    try {
      const statistics = saudiStatisticsManager.getGOSIStatistics(
        req.query.year ? parseInt(req.query.year) : new Date().getFullYear(),
        req.query.month ? parseInt(req.query.month) : null
      );
      res.json({ success: true, data: statistics });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/saudi/statistics/tax',
  requirePermission('hr.saudi.statistics.view'),
  async (req, res) => {
    try {
      const statistics = saudiStatisticsManager.getTaxStatistics(
        req.query.year ? parseInt(req.query.year) : new Date().getFullYear(),
        req.query.month ? parseInt(req.query.month) : null
      );
      res.json({ success: true, data: statistics });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/saudi/statistics/compliance',
  requirePermission('hr.saudi.statistics.view'),
  async (req, res) => {
    try {
      const statistics = saudiStatisticsManager.getComplianceStatistics();
      res.json({ success: true, data: statistics });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Saudi Reminders ==========

router.get(
  '/saudi/reminders/check',
  requirePermission('hr.saudi.reminders.view'),
  async (req, res) => {
    try {
      const reminders = await saudiRemindersManager.checkReminders();
      res.json({ success: true, data: reminders });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get('/saudi/reminders', requirePermission('hr.saudi.reminders.view'), async (req, res) => {
  try {
    const reminders = saudiRemindersManager.getReminders(req.query);
    res.json({ success: true, data: reminders });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post(
  '/saudi/reminders/:reminderId/complete',
  requirePermission('hr.saudi.reminders.edit'),
  async (req, res) => {
    try {
      const success = saudiRemindersManager.markAsCompleted(req.params.reminderId);
      res.json({ success, data: { reminderId: req.params.reminderId } });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.delete(
  '/saudi/reminders/:reminderId',
  requirePermission('hr.saudi.reminders.edit'),
  async (req, res) => {
    try {
      const success = saudiRemindersManager.deleteReminder(req.params.reminderId);
      res.json({ success, data: { reminderId: req.params.reminderId } });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/saudi/reminders/statistics',
  requirePermission('hr.saudi.reminders.view'),
  async (req, res) => {
    try {
      const statistics = saudiRemindersManager.getReminderStatistics();
      res.json({ success: true, data: statistics });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Saudi Alerts ==========

router.get('/saudi/alerts/check', requirePermission('hr.saudi.alerts.view'), async (req, res) => {
  try {
    const alerts = await saudiAlertsManager.checkAlerts();
    res.json({ success: true, data: alerts });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/saudi/alerts', requirePermission('hr.saudi.alerts.view'), async (req, res) => {
  try {
    const alerts = saudiAlertsManager.getAlerts(req.query);
    res.json({ success: true, data: alerts });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post(
  '/saudi/alerts/:alertId/acknowledge',
  requirePermission('hr.saudi.alerts.edit'),
  async (req, res) => {
    try {
      const success = saudiAlertsManager.acknowledgeAlert(req.params.alertId);
      res.json({ success, data: { alertId: req.params.alertId } });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.delete(
  '/saudi/alerts/:alertId',
  requirePermission('hr.saudi.alerts.edit'),
  async (req, res) => {
    try {
      const success = saudiAlertsManager.deleteAlert(req.params.alertId);
      res.json({ success, data: { alertId: req.params.alertId } });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

router.get(
  '/saudi/alerts/statistics',
  requirePermission('hr.saudi.alerts.view'),
  async (req, res) => {
    try {
      const statistics = saudiAlertsManager.getAlertStatistics();
      res.json({ success: true, data: statistics });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

module.exports = router;
