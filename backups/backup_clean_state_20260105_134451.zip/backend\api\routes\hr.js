/**
 * 👥 HR Management Routes
 * مسارات إدارة الموارد البشرية
 */

const express = require('express');
const router = express.Router();
let Employee, Department, Attendance, Leave;
try {
  Employee = require('../models/Employee');
} catch (e) {
  Employee = {
    findById: async id => ({ id }),
    find: async () => [],
    create: async data => ({ id: Date.now(), ...data }),
  };
}
try {
  Department = require('../models/Department');
} catch (e) {
  Department = { find: async () => [], create: async data => ({ id: Date.now(), ...data }) };
}
try {
  Attendance = require('../models/Attendance');
} catch (e) {
  Attendance = { find: async () => [], create: async data => ({ id: Date.now(), ...data }) };
}
try {
  Leave = require('../models/Leave');
} catch (e) {
  Leave = { find: async () => [], create: async data => ({ id: Date.now(), ...data }) };
}
const authenticateToken = require('../middleware/authenticateToken');
const logger = require('../../shared/logging/logger');

// Real-time event emitter (if available)
let io = null;
try {
  const realtimeModule = require('../realtime');
  io = realtimeModule.io;
} catch (error) {
  // Real-time not available
}

/**
 * Emit real-time event
 */
function emitEvent(eventType, entityType, data) {
  if (io) {
    io.emit('hr:update', {
      action: eventType,
      entityType: entityType,
      entityId: data.id,
      data: data,
    });
  }
}

// Apply authentication to all routes
router.use(authenticateToken);

/**
 * Employees Routes
 */
router.get('/employees', async (req, res) => {
  try {
    const employees = await Employee.findAll({
      order: [['createdAt', 'DESC']],
    });
    res.json(employees);
  } catch (error) {
    logger.error('Error fetching employees:', error);
    res.status(500).json({ error: 'خطأ في جلب الموظفين' });
  }
});

router.get('/employees/:id', async (req, res) => {
  try {
    const employee = await Employee.findByPk(req.params.id);
    if (!employee) {
      return res.status(404).json({ error: 'الموظف غير موجود' });
    }
    res.json(employee);
  } catch (error) {
    logger.error('Error fetching employee:', error);
    res.status(500).json({ error: 'خطأ في جلب الموظف' });
  }
});

router.post('/employees', async (req, res) => {
  try {
    const employee = await Employee.create(req.body);
    emitEvent('create', 'employee', employee);
    logger.info('Employee created', { id: employee.id, name: employee.name });
    res.status(201).json(employee);
  } catch (error) {
    logger.error('Error creating employee:', error);
    res.status(400).json({ error: 'خطأ في إضافة الموظف' });
  }
});

router.put('/employees/:id', async (req, res) => {
  try {
    const [updated] = await Employee.update(req.body, {
      where: { id: req.params.id },
    });
    if (updated) {
      const employee = await Employee.findByPk(req.params.id);
      emitEvent('update', 'employee', employee);
      logger.info('Employee updated', { id: employee.id });
      res.json(employee);
    } else {
      res.status(404).json({ error: 'الموظف غير موجود' });
    }
  } catch (error) {
    logger.error('Error updating employee:', error);
    res.status(400).json({ error: 'خطأ في تحديث الموظف' });
  }
});

router.delete('/employees/:id', async (req, res) => {
  try {
    const deleted = await Employee.destroy({
      where: { id: req.params.id },
    });
    if (deleted) {
      // Also delete related attendance and leaves
      await Attendance.destroy({ where: { employeeId: req.params.id } });
      await Leave.destroy({ where: { employeeId: req.params.id } });
      emitEvent('delete', 'employee', { id: req.params.id });
      logger.info('Employee deleted', { id: req.params.id });
      res.json({ message: 'تم حذف الموظف بنجاح' });
    } else {
      res.status(404).json({ error: 'الموظف غير موجود' });
    }
  } catch (error) {
    logger.error('Error deleting employee:', error);
    res.status(400).json({ error: 'خطأ في حذف الموظف' });
  }
});

/**
 * Departments Routes
 */
router.get('/departments', async (req, res) => {
  try {
    const departments = await Department.findAll({
      order: [['name', 'ASC']],
    });
    res.json(departments);
  } catch (error) {
    logger.error('Error fetching departments:', error);
    res.status(500).json({ error: 'خطأ في جلب الأقسام' });
  }
});

router.get('/departments/:id', async (req, res) => {
  try {
    const department = await Department.findByPk(req.params.id);
    if (!department) {
      return res.status(404).json({ error: 'القسم غير موجود' });
    }
    res.json(department);
  } catch (error) {
    logger.error('Error fetching department:', error);
    res.status(500).json({ error: 'خطأ في جلب القسم' });
  }
});

/**
 * Attendance Routes
 */
router.get('/attendance', async (req, res) => {
  try {
    const attendance = await Attendance.findAll({
      order: [['date', 'DESC']],
      limit: 100,
    });
    res.json(attendance);
  } catch (error) {
    logger.error('Error fetching attendance:', error);
    res.status(500).json({ error: 'خطأ في جلب سجلات الحضور' });
  }
});

router.post('/attendance', async (req, res) => {
  try {
    const attendance = await Attendance.create(req.body);
    emitEvent('create', 'attendance', attendance);
    logger.info('Attendance recorded', { id: attendance.id, employeeId: attendance.employeeId });
    res.status(201).json(attendance);
  } catch (error) {
    logger.error('Error creating attendance:', error);
    res.status(400).json({ error: 'خطأ في تسجيل الحضور' });
  }
});

/**
 * Leaves Routes
 */
router.get('/leaves', async (req, res) => {
  try {
    const leaves = await Leave.findAll({
      order: [['startDate', 'DESC']],
    });
    res.json(leaves);
  } catch (error) {
    logger.error('Error fetching leaves:', error);
    res.status(500).json({ error: 'خطأ في جلب الإجازات' });
  }
});

router.post('/leaves', async (req, res) => {
  try {
    const leave = await Leave.create(req.body);
    emitEvent('create', 'leave', leave);
    logger.info('Leave created', { id: leave.id, employeeId: leave.employeeId });
    res.status(201).json(leave);
  } catch (error) {
    logger.error('Error creating leave:', error);
    res.status(400).json({ error: 'خطأ في إضافة الإجازة' });
  }
});

router.put('/leaves/:id', async (req, res) => {
  try {
    const [updated] = await Leave.update(req.body, {
      where: { id: req.params.id },
    });
    if (updated) {
      const leave = await Leave.findByPk(req.params.id);
      emitEvent('update', 'leave', leave);
      logger.info('Leave updated', { id: leave.id });
      res.json(leave);
    } else {
      res.status(404).json({ error: 'الإجازة غير موجودة' });
    }
  } catch (error) {
    logger.error('Error updating leave:', error);
    res.status(400).json({ error: 'خطأ في تحديث الإجازة' });
  }
});

module.exports = router;
