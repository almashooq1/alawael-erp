/**
 * 🔗 Integration Management Routes
 * API routes for integrations, connections, webhooks, and API keys
 */

const express = require('express');
const router = express.Router();

// Mock data storage
const integrations = [];
const connections = [];
const webhooks = [];
const apiKeys = [];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Integrations ====================

router.get('/integrations', async (req, res) => {
  try {
    res.json({ success: true, data: integrations });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/integrations/:id', async (req, res) => {
  try {
    const integration = integrations.find(i => i.id === parseInt(req.params.id));
    if (!integration) {
      return res.status(404).json({ success: false, error: 'Integration not found' });
    }
    res.json({ success: true, data: integration });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/integrations', async (req, res) => {
  try {
    const integration = {
      id: integrations.length > 0 ? Math.max(...integrations.map(i => i.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    integrations.push(integration);

    emitEvent('integration:update', {
      action: 'create',
      entityType: 'integration',
      entityId: integration.id,
      data: integration,
    });

    res.status(201).json({ success: true, data: integration });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/integrations/:id', async (req, res) => {
  try {
    const index = integrations.findIndex(i => i.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Integration not found' });
    }

    integrations[index] = {
      ...integrations[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    emitEvent('integration:update', {
      action: 'update',
      entityType: 'integration',
      entityId: integrations[index].id,
      data: integrations[index],
    });

    res.json({ success: true, data: integrations[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.delete('/integrations/:id', async (req, res) => {
  try {
    const index = integrations.findIndex(i => i.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Integration not found' });
    }

    const deletedIntegration = integrations[index];
    integrations.splice(index, 1);

    emitEvent('integration:update', {
      action: 'delete',
      entityType: 'integration',
      entityId: deletedIntegration.id,
    });

    res.json({ success: true, message: 'Integration deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Connections ====================

router.get('/connections', async (req, res) => {
  try {
    res.json({ success: true, data: connections });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/connections', async (req, res) => {
  try {
    const connection = {
      id: connections.length > 0 ? Math.max(...connections.map(c => c.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    connections.push(connection);

    emitEvent('integration:update', {
      action: 'create',
      entityType: 'connection',
      entityId: connection.id,
      data: connection,
    });

    res.status(201).json({ success: true, data: connection });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Webhooks ====================

router.get('/webhooks', async (req, res) => {
  try {
    res.json({ success: true, data: webhooks });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/webhooks', async (req, res) => {
  try {
    const webhook = {
      id: webhooks.length > 0 ? Math.max(...webhooks.map(w => w.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    webhooks.push(webhook);

    emitEvent('integration:update', {
      action: 'create',
      entityType: 'webhook',
      entityId: webhook.id,
      data: webhook,
    });

    res.status(201).json({ success: true, data: webhook });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== API Keys ====================

router.get('/api-keys', async (req, res) => {
  try {
    res.json({ success: true, data: apiKeys });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/api-keys', async (req, res) => {
  try {
    const apiKey = {
      id: apiKeys.length > 0 ? Math.max(...apiKeys.map(k => k.id)) + 1 : 1,
      key: `api_${Date.now()}_${Math.random().toString(36).substring(7)}`,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    apiKeys.push(apiKey);

    emitEvent('integration:update', {
      action: 'create',
      entityType: 'apiKey',
      entityId: apiKey.id,
      data: apiKey,
    });

    res.status(201).json({ success: true, data: apiKey });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.delete('/api-keys/:id', async (req, res) => {
  try {
    const index = apiKeys.findIndex(k => k.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'API key not found' });
    }

    const deletedKey = apiKeys[index];
    apiKeys.splice(index, 1);

    emitEvent('integration:update', {
      action: 'delete',
      entityType: 'apiKey',
      entityId: deletedKey.id,
    });

    res.json({ success: true, message: 'API key deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
