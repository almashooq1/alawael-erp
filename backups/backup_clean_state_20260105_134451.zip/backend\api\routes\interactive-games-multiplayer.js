/**
 * Interactive Games Multiplayer Routes
 * مسارات الألعاب الجماعية
 */

const express = require('express');
const router = express.Router();
const gameMultiplayer = require('../../shared/utils/game-multiplayer');
const { authenticateToken, optionalAuth } = require('../middleware/auth-middleware');

// Create room
router.post('/rooms', authenticateToken, (req, res) => {
  try {
    const { gameId, ...config } = req.body;
    const hostId = req.user?.id || req.body.hostId;

    if (!gameId) {
      return res.status(400).json({
        success: false,
        error: 'Game ID is required',
      });
    }

    const room = gameMultiplayer.createRoom(gameId, { ...config, hostId });

    res.json({
      success: true,
      data: room,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Join room
router.post('/rooms/:roomId/join', authenticateToken, (req, res) => {
  try {
    const { roomId } = req.params;
    const playerId = req.user?.id || req.body.playerId;

    if (!playerId) {
      return res.status(400).json({
        success: false,
        error: 'Player ID is required',
      });
    }

    const result = gameMultiplayer.joinRoom(roomId, playerId);

    res.json({
      success: true,
      data: result,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Leave room
router.post('/rooms/:roomId/leave', authenticateToken, (req, res) => {
  try {
    const { roomId } = req.params;
    const playerId = req.user?.id || req.body.playerId;

    if (!playerId) {
      return res.status(400).json({
        success: false,
        error: 'Player ID is required',
      });
    }

    const success = gameMultiplayer.leaveRoom(roomId, playerId);

    res.json({
      success,
      message: success ? 'Left room successfully' : 'Failed to leave room',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Start match
router.post('/rooms/:roomId/start', authenticateToken, (req, res) => {
  try {
    const { roomId } = req.params;
    const match = gameMultiplayer.startMatch(roomId);

    res.json({
      success: true,
      data: match,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Update player score in match
router.put('/matches/:matchId/score', authenticateToken, (req, res) => {
  try {
    const { matchId } = req.params;
    const { playerId, score, progressData } = req.body;

    if (!playerId || score === undefined) {
      return res.status(400).json({
        success: false,
        error: 'Player ID and score are required',
      });
    }

    const player = gameMultiplayer.updatePlayerScore(matchId, playerId, score, progressData);

    res.json({
      success: true,
      data: player,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// End match
router.post('/matches/:matchId/end', authenticateToken, (req, res) => {
  try {
    const { matchId } = req.params;
    const match = gameMultiplayer.endMatch(matchId);

    res.json({
      success: true,
      data: match,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get room
router.get('/rooms/:roomId', optionalAuth, (req, res) => {
  try {
    const { roomId } = req.params;
    const room = gameMultiplayer.getRoom(roomId);

    if (!room) {
      return res.status(404).json({
        success: false,
        error: 'Room not found',
      });
    }

    res.json({
      success: true,
      data: room,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get match
router.get('/matches/:matchId', optionalAuth, (req, res) => {
  try {
    const { matchId } = req.params;
    const match = gameMultiplayer.getMatch(matchId);

    if (!match) {
      return res.status(404).json({
        success: false,
        error: 'Match not found',
      });
    }

    res.json({
      success: true,
      data: match,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get available rooms
router.get('/rooms', optionalAuth, (req, res) => {
  try {
    const { gameId } = req.query;
    const rooms = gameMultiplayer.getAvailableRooms(gameId);

    res.json({
      success: true,
      data: {
        rooms,
        count: rooms.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

module.exports = router;
