/**
 * Interactive Games Routes
 * مسارات الألعاب التفاعلية
 */

const express = require('express');
const router = express.Router();
const gamesSystem = require('../../shared/utils/interactive-games-system');
const gameAdaptiveEngine = require('../../shared/utils/game-adaptive-engine');
const gameProgressAnalyzer = require('../../shared/utils/game-progress-analyzer');
const gameMultiplayer = require('../../shared/utils/game-multiplayer');
const gameAICoach = require('../../shared/utils/game-ai-coach');
const gameAccessibility = require('../../shared/utils/game-accessibility');
const { authenticateToken, optionalAuth } = require('../middleware/auth-middleware');

// Initialize default games
initializeDefaultGames();

function initializeDefaultGames() {
  // Memory Game
  gamesSystem.registerGame('memory-game', {
    name: 'لعبة الذاكرة',
    description: 'لعبة لتحسين الذاكرة والتركيز',
    category: 'cognitive',
    suitableFor: ['intellectual', 'autism', 'adhd'],
    ageRange: { min: 4, max: 18 },
    skills: ['memory', 'attention', 'concentration'],
    defaultDifficulty: 'medium',
    defaultTimeLimit: 300000, // 5 minutes
    achievements: {
      highScore: {
        threshold: 80,
        name: 'ذاكرة قوية',
        description: 'حصلت على 80 نقطة أو أكثر',
      },
      levelUp: {
        threshold: 5,
        name: 'متقدم',
        description: 'وصلت للمستوى 5',
      },
      endurance: {
        threshold: 600000,
        name: 'صبر ومثابرة',
        description: 'لعبت لأكثر من 10 دقائق',
      },
    },
  });

  // Motor Skills Game
  gamesSystem.registerGame('motor-skills', {
    name: 'لعبة المهارات الحركية',
    description: 'لعبة لتحسين المهارات الحركية الدقيقة',
    category: 'motor',
    suitableFor: ['physical', 'cerebral_palsy', 'down_syndrome'],
    ageRange: { min: 3, max: 16 },
    skills: ['fine_motor', 'hand_eye_coordination', 'precision'],
    defaultDifficulty: 'easy',
    defaultTimeLimit: 600000, // 10 minutes
    achievements: {
      highScore: {
        threshold: 70,
        name: 'حركة دقيقة',
        description: 'حصلت على 70 نقطة أو أكثر',
      },
      levelUp: {
        threshold: 3,
        name: 'تحسن حركي',
        description: 'وصلت للمستوى 3',
      },
    },
  });

  // Language Game
  gamesSystem.registerGame('language-game', {
    name: 'لعبة اللغة والتواصل',
    description: 'لعبة لتحسين مهارات اللغة والتواصل',
    category: 'language',
    suitableFor: ['speech', 'autism', 'hearing'],
    ageRange: { min: 3, max: 12 },
    skills: ['vocabulary', 'pronunciation', 'communication'],
    defaultDifficulty: 'medium',
    defaultTimeLimit: 450000, // 7.5 minutes
    achievements: {
      highScore: {
        threshold: 75,
        name: 'متحدث ممتاز',
        description: 'حصلت على 75 نقطة أو أكثر',
      },
      levelUp: {
        threshold: 4,
        name: 'تحسن لغوي',
        description: 'وصلت للمستوى 4',
      },
    },
  });

  // Social Skills Game
  gamesSystem.registerGame('social-skills', {
    name: 'لعبة المهارات الاجتماعية',
    description: 'لعبة لتحسين المهارات الاجتماعية والتفاعل',
    category: 'social',
    suitableFor: ['autism', 'adhd', 'social'],
    ageRange: { min: 5, max: 15 },
    skills: ['social_interaction', 'empathy', 'cooperation'],
    defaultDifficulty: 'medium',
    defaultTimeLimit: 600000,
    achievements: {
      highScore: {
        threshold: 80,
        name: 'اجتماعي ممتاز',
        description: 'حصلت على 80 نقطة أو أكثر',
      },
    },
  });

  // Math Game
  gamesSystem.registerGame('math-game', {
    name: 'لعبة الرياضيات',
    description: 'لعبة لتحسين مهارات الرياضيات',
    category: 'academic',
    suitableFor: ['intellectual', 'learning', 'adhd'],
    ageRange: { min: 6, max: 14 },
    skills: ['counting', 'calculation', 'problem_solving'],
    defaultDifficulty: 'medium',
    defaultTimeLimit: 300000,
    achievements: {
      highScore: {
        threshold: 85,
        name: 'عالم رياضيات',
        description: 'حصلت على 85 نقطة أو أكثر',
      },
    },
  });

  // Sensory Integration Game
  gamesSystem.registerGame('sensory-integration', {
    name: 'لعبة التكامل الحسي',
    description: 'لعبة لتحسين التكامل الحسي والوعي الحسي',
    category: 'sensory',
    suitableFor: ['autism', 'sensory', 'adhd'],
    ageRange: { min: 3, max: 12 },
    skills: ['sensory_awareness', 'focus', 'calming'],
    defaultDifficulty: 'easy',
    defaultTimeLimit: 600000,
    achievements: {
      highScore: {
        threshold: 70,
        name: 'وعي حسي ممتاز',
        description: 'حصلت على 70 نقطة أو أكثر',
      },
    },
  });

  // Visual Perception Game
  gamesSystem.registerGame('visual-perception', {
    name: 'لعبة الإدراك البصري',
    description: 'لعبة لتحسين الإدراك البصري والتمييز',
    category: 'visual',
    suitableFor: ['visual_impairment', 'autism', 'learning'],
    ageRange: { min: 4, max: 16 },
    skills: ['visual_discrimination', 'pattern_recognition', 'spatial_awareness'],
    defaultDifficulty: 'medium',
    defaultTimeLimit: 450000,
    achievements: {
      highScore: {
        threshold: 80,
        name: 'إدراك بصري قوي',
        description: 'حصلت على 80 نقطة أو أكثر',
      },
    },
  });

  // Attention & Focus Game
  gamesSystem.registerGame('attention-focus', {
    name: 'لعبة الانتباه والتركيز',
    description: 'لعبة لتحسين الانتباه والتركيز',
    category: 'cognitive',
    suitableFor: ['adhd', 'autism', 'attention'],
    ageRange: { min: 5, max: 15 },
    skills: ['attention', 'focus', 'sustained_attention'],
    defaultDifficulty: 'medium',
    defaultTimeLimit: 300000,
    achievements: {
      highScore: {
        threshold: 75,
        name: 'تركيز عالي',
        description: 'حصلت على 75 نقطة أو أكثر',
      },
      endurance: {
        threshold: 600000,
        name: 'صبر وتركيز',
        description: 'لعبت لأكثر من 10 دقائق',
      },
    },
  });

  // Problem Solving Game
  gamesSystem.registerGame('problem-solving', {
    name: 'لعبة حل المشاكل',
    description: 'لعبة لتحسين مهارات حل المشاكل والتفكير المنطقي',
    category: 'cognitive',
    suitableFor: ['intellectual', 'autism', 'learning'],
    ageRange: { min: 6, max: 16 },
    skills: ['problem_solving', 'logical_thinking', 'reasoning'],
    defaultDifficulty: 'medium',
    defaultTimeLimit: 450000,
    achievements: {
      highScore: {
        threshold: 80,
        name: 'حل مشاكل ممتاز',
        description: 'حصلت على 80 نقطة أو أكثر',
      },
    },
  });

  // Fine Motor Skills Game
  gamesSystem.registerGame('fine-motor', {
    name: 'لعبة المهارات الحركية الدقيقة',
    description: 'لعبة لتحسين المهارات الحركية الدقيقة',
    category: 'motor',
    suitableFor: ['physical', 'cerebral_palsy', 'down_syndrome'],
    ageRange: { min: 3, max: 12 },
    skills: ['fine_motor', 'hand_eye_coordination', 'precision', 'dexterity'],
    defaultDifficulty: 'easy',
    defaultTimeLimit: 600000,
    achievements: {
      highScore: {
        threshold: 75,
        name: 'حركة دقيقة',
        description: 'حصلت على 75 نقطة أو أكثر',
      },
    },
  });

  // Gross Motor Skills Game
  gamesSystem.registerGame('gross-motor', {
    name: 'لعبة المهارات الحركية الكبيرة',
    description: 'لعبة لتحسين المهارات الحركية الكبيرة والتوازن',
    category: 'motor',
    suitableFor: ['physical', 'cerebral_palsy', 'balance'],
    ageRange: { min: 4, max: 14 },
    skills: ['gross_motor', 'balance', 'coordination', 'strength'],
    defaultDifficulty: 'medium',
    defaultTimeLimit: 600000,
    achievements: {
      highScore: {
        threshold: 70,
        name: 'حركة قوية',
        description: 'حصلت على 70 نقطة أو أكثر',
      },
    },
  });

  // Emotional Regulation Game
  gamesSystem.registerGame('emotional-regulation', {
    name: 'لعبة التنظيم العاطفي',
    description: 'لعبة لتحسين التنظيم العاطفي وإدارة المشاعر',
    category: 'emotional',
    suitableFor: ['autism', 'emotional', 'behavioral'],
    ageRange: { min: 5, max: 14 },
    skills: ['emotional_recognition', 'self_regulation', 'empathy'],
    defaultDifficulty: 'medium',
    defaultTimeLimit: 450000,
    achievements: {
      highScore: {
        threshold: 75,
        name: 'تنظيم عاطفي ممتاز',
        description: 'حصلت على 75 نقطة أو أكثر',
      },
    },
  });

  // Sequencing Game
  gamesSystem.registerGame('sequencing', {
    name: 'لعبة التسلسل',
    description: 'لعبة لتحسين مهارات التسلسل والترتيب',
    category: 'cognitive',
    suitableFor: ['intellectual', 'autism', 'learning'],
    ageRange: { min: 4, max: 12 },
    skills: ['sequencing', 'order', 'logical_thinking'],
    defaultDifficulty: 'medium',
    defaultTimeLimit: 300000,
    achievements: {
      highScore: {
        threshold: 80,
        name: 'تسلسل ممتاز',
        description: 'حصلت على 80 نقطة أو أكثر',
      },
    },
  });

  // Matching Game
  gamesSystem.registerGame('matching', {
    name: 'لعبة المطابقة',
    description: 'لعبة لتحسين مهارات المطابقة والتصنيف',
    category: 'cognitive',
    suitableFor: ['intellectual', 'autism', 'visual'],
    ageRange: { min: 3, max: 10 },
    skills: ['matching', 'classification', 'visual_discrimination'],
    defaultDifficulty: 'easy',
    defaultTimeLimit: 300000,
    achievements: {
      highScore: {
        threshold: 85,
        name: 'مطابقة ممتازة',
        description: 'حصلت على 85 نقطة أو أكثر',
      },
    },
  });

  // Puzzle Game
  gamesSystem.registerGame('puzzle', {
    name: 'لعبة الألغاز',
    description: 'لعبة لتحسين مهارات حل الألغاز والتفكير',
    category: 'cognitive',
    suitableFor: ['intellectual', 'autism', 'problem_solving'],
    ageRange: { min: 5, max: 16 },
    skills: ['problem_solving', 'spatial_thinking', 'patience'],
    defaultDifficulty: 'medium',
    defaultTimeLimit: 600000,
    achievements: {
      highScore: {
        threshold: 80,
        name: 'حل ألغاز ممتاز',
        description: 'حصلت على 80 نقطة أو أكثر',
      },
    },
  });

  // Color Recognition Game
  gamesSystem.registerGame('color-recognition', {
    name: 'لعبة التعرف على الألوان',
    description: 'لعبة لتحسين التعرف على الألوان والتمييز',
    category: 'visual',
    suitableFor: ['visual', 'autism', 'learning'],
    ageRange: { min: 3, max: 8 },
    skills: ['color_recognition', 'visual_discrimination', 'naming'],
    defaultDifficulty: 'easy',
    defaultTimeLimit: 300000,
    achievements: {
      highScore: {
        threshold: 90,
        name: 'خبير ألوان',
        description: 'حصلت على 90 نقطة أو أكثر',
      },
    },
  });

  // Shape Recognition Game
  gamesSystem.registerGame('shape-recognition', {
    name: 'لعبة التعرف على الأشكال',
    description: 'لعبة لتحسين التعرف على الأشكال الهندسية',
    category: 'visual',
    suitableFor: ['visual', 'autism', 'learning'],
    ageRange: { min: 3, max: 10 },
    skills: ['shape_recognition', 'spatial_awareness', 'naming'],
    defaultDifficulty: 'easy',
    defaultTimeLimit: 300000,
    achievements: {
      highScore: {
        threshold: 85,
        name: 'خبير أشكال',
        description: 'حصلت على 85 نقطة أو أكثر',
      },
    },
  });

  // Number Recognition Game
  gamesSystem.registerGame('number-recognition', {
    name: 'لعبة التعرف على الأرقام',
    description: 'لعبة لتحسين التعرف على الأرقام والعد',
    category: 'academic',
    suitableFor: ['intellectual', 'learning', 'autism'],
    ageRange: { min: 3, max: 10 },
    skills: ['number_recognition', 'counting', 'number_sense'],
    defaultDifficulty: 'easy',
    defaultTimeLimit: 300000,
    achievements: {
      highScore: {
        threshold: 85,
        name: 'خبير أرقام',
        description: 'حصلت على 85 نقطة أو أكثر',
      },
    },
  });

  // Letter Recognition Game
  gamesSystem.registerGame('letter-recognition', {
    name: 'لعبة التعرف على الحروف',
    description: 'لعبة لتحسين التعرف على الحروف الأبجدية',
    category: 'language',
    suitableFor: ['speech', 'learning', 'autism'],
    ageRange: { min: 4, max: 10 },
    skills: ['letter_recognition', 'phonics', 'reading_readiness'],
    defaultDifficulty: 'easy',
    defaultTimeLimit: 300000,
    achievements: {
      highScore: {
        threshold: 85,
        name: 'خبير حروف',
        description: 'حصلت على 85 نقطة أو أكثر',
      },
    },
  });

  // Rhythm & Music Game
  gamesSystem.registerGame('rhythm-music', {
    name: 'لعبة الإيقاع والموسيقى',
    description: 'لعبة لتحسين الإحساس بالإيقاع والموسيقى',
    category: 'sensory',
    suitableFor: ['hearing', 'autism', 'sensory'],
    ageRange: { min: 4, max: 14 },
    skills: ['rhythm', 'listening', 'coordination'],
    defaultDifficulty: 'medium',
    defaultTimeLimit: 450000,
    achievements: {
      highScore: {
        threshold: 75,
        name: 'إيقاع ممتاز',
        description: 'حصلت على 75 نقطة أو أكثر',
      },
    },
  });

  // Story Comprehension Game
  gamesSystem.registerGame('story-comprehension', {
    name: 'لعبة فهم القصص',
    description: 'لعبة لتحسين فهم القصص والاستيعاب',
    category: 'language',
    suitableFor: ['speech', 'learning', 'autism'],
    ageRange: { min: 5, max: 14 },
    skills: ['comprehension', 'listening', 'memory'],
    defaultDifficulty: 'medium',
    defaultTimeLimit: 600000,
    achievements: {
      highScore: {
        threshold: 80,
        name: 'فهم ممتاز',
        description: 'حصلت على 80 نقطة أو أكثر',
      },
    },
  });

  // Time Management Game
  gamesSystem.registerGame('time-management', {
    name: 'لعبة إدارة الوقت',
    description: 'لعبة لتحسين فهم الوقت وإدارته',
    category: 'life_skills',
    suitableFor: ['intellectual', 'autism', 'life_skills'],
    ageRange: { min: 6, max: 16 },
    skills: ['time_awareness', 'scheduling', 'planning'],
    defaultDifficulty: 'medium',
    defaultTimeLimit: 450000,
    achievements: {
      highScore: {
        threshold: 75,
        name: 'إدارة وقت ممتازة',
        description: 'حصلت على 75 نقطة أو أكثر',
      },
    },
  });

  // Money Management Game
  gamesSystem.registerGame('money-management', {
    name: 'لعبة إدارة المال',
    description: 'لعبة لتحسين فهم المال وإدارته',
    category: 'life_skills',
    suitableFor: ['intellectual', 'life_skills', 'learning'],
    ageRange: { min: 7, max: 16 },
    skills: ['money_recognition', 'counting_money', 'budgeting'],
    defaultDifficulty: 'medium',
    defaultTimeLimit: 450000,
    achievements: {
      highScore: {
        threshold: 80,
        name: 'إدارة مال ممتازة',
        description: 'حصلت على 80 نقطة أو أكثر',
      },
    },
  });

  // Self-Care Skills Game
  gamesSystem.registerGame('self-care', {
    name: 'لعبة مهارات العناية الذاتية',
    description: 'لعبة لتحسين مهارات العناية الذاتية',
    category: 'life_skills',
    suitableFor: ['intellectual', 'autism', 'life_skills'],
    ageRange: { min: 5, max: 14 },
    skills: ['self_care', 'independence', 'daily_living'],
    defaultDifficulty: 'medium',
    defaultTimeLimit: 600000,
    achievements: {
      highScore: {
        threshold: 75,
        name: 'عناية ذاتية ممتازة',
        description: 'حصلت على 75 نقطة أو أكثر',
      },
    },
  });

  // Additional 20+ Professional Games
  registerAdditionalGames();
}

function registerAdditionalGames() {
  // Visual Processing Games
  gamesSystem.registerGame('visual-tracking', {
    name: 'لعبة تتبع البصر',
    description: 'لعبة لتحسين تتبع الحركة البصرية',
    category: 'visual',
    suitableFor: ['visual_impairment', 'autism', 'adhd'],
    ageRange: { min: 4, max: 14 },
    skills: ['visual_tracking', 'eye_movement', 'focus'],
    defaultDifficulty: 'medium',
    defaultTimeLimit: 300000,
    smartFeatures: ['adaptive_difficulty', 'real_time_feedback'],
    achievements: {
      highScore: { threshold: 80, name: 'تتبع ممتاز', description: 'حصلت على 80 نقطة أو أكثر' },
    },
  });

  gamesSystem.registerGame('pattern-recognition', {
    name: 'لعبة التعرف على الأنماط',
    description: 'لعبة لتحسين التعرف على الأنماط والترتيب',
    category: 'cognitive',
    suitableFor: ['intellectual', 'autism', 'learning'],
    ageRange: { min: 5, max: 16 },
    skills: ['pattern_recognition', 'logical_thinking', 'prediction'],
    defaultDifficulty: 'medium',
    defaultTimeLimit: 450000,
    smartFeatures: ['ai_adaptation', 'personalized_path'],
    achievements: {
      highScore: { threshold: 85, name: 'خبير أنماط', description: 'حصلت على 85 نقطة أو أكثر' },
    },
  });

  // Auditory Processing Games
  gamesSystem.registerGame('auditory-discrimination', {
    name: 'لعبة التمييز السمعي',
    description: 'لعبة لتحسين التمييز بين الأصوات',
    category: 'auditory',
    suitableFor: ['hearing', 'autism', 'auditory_processing'],
    ageRange: { min: 4, max: 12 },
    skills: ['auditory_discrimination', 'listening', 'sound_recognition'],
    defaultDifficulty: 'medium',
    defaultTimeLimit: 300000,
    smartFeatures: ['adaptive_volume', 'sound_adaptation'],
    achievements: {
      highScore: {
        threshold: 75,
        name: 'تمييز سمعي ممتاز',
        description: 'حصلت على 75 نقطة أو أكثر',
      },
    },
  });

  gamesSystem.registerGame('phonological-awareness', {
    name: 'لعبة الوعي الصوتي',
    description: 'لعبة لتحسين الوعي الصوتي والنطق',
    category: 'language',
    suitableFor: ['speech', 'learning', 'autism'],
    ageRange: { min: 4, max: 10 },
    skills: ['phonological_awareness', 'sound_manipulation', 'rhyming'],
    defaultDifficulty: 'easy',
    defaultTimeLimit: 300000,
    smartFeatures: ['voice_recognition', 'pronunciation_feedback'],
    achievements: {
      highScore: { threshold: 80, name: 'وعي صوتي ممتاز', description: 'حصلت على 80 نقطة أو أكثر' },
    },
  });

  // Executive Function Games
  gamesSystem.registerGame('executive-function', {
    name: 'لعبة الوظائف التنفيذية',
    description: 'لعبة لتحسين الوظائف التنفيذية والتخطيط',
    category: 'cognitive',
    suitableFor: ['adhd', 'autism', 'executive_dysfunction'],
    ageRange: { min: 6, max: 16 },
    skills: ['planning', 'organization', 'working_memory', 'inhibition'],
    defaultDifficulty: 'medium',
    defaultTimeLimit: 600000,
    smartFeatures: ['task_sequencing', 'adaptive_complexity'],
    achievements: {
      highScore: {
        threshold: 75,
        name: 'وظائف تنفيذية ممتازة',
        description: 'حصلت على 75 نقطة أو أكثر',
      },
    },
  });

  gamesSystem.registerGame('working-memory', {
    name: 'لعبة الذاكرة العاملة',
    description: 'لعبة لتحسين الذاكرة العاملة والاحتفاظ بالمعلومات',
    category: 'cognitive',
    suitableFor: ['intellectual', 'adhd', 'memory'],
    ageRange: { min: 5, max: 16 },
    skills: ['working_memory', 'information_retention', 'multi_task'],
    defaultDifficulty: 'medium',
    defaultTimeLimit: 450000,
    smartFeatures: ['memory_adaptation', 'progressive_challenge'],
    achievements: {
      highScore: {
        threshold: 80,
        name: 'ذاكرة عاملة قوية',
        description: 'حصلت على 80 نقطة أو أكثر',
      },
    },
  });

  // Social Cognition Games
  gamesSystem.registerGame('social-cognition', {
    name: 'لعبة الإدراك الاجتماعي',
    description: 'لعبة لتحسين فهم المواقف الاجتماعية',
    category: 'social',
    suitableFor: ['autism', 'social', 'emotional'],
    ageRange: { min: 6, max: 16 },
    skills: ['social_understanding', 'perspective_taking', 'emotion_recognition'],
    defaultDifficulty: 'medium',
    defaultTimeLimit: 600000,
    smartFeatures: ['scenario_adaptation', 'emotion_analysis'],
    achievements: {
      highScore: {
        threshold: 80,
        name: 'إدراك اجتماعي ممتاز',
        description: 'حصلت على 80 نقطة أو أكثر',
      },
    },
  });

  gamesSystem.registerGame('emotion-recognition', {
    name: 'لعبة التعرف على المشاعر',
    description: 'لعبة لتحسين التعرف على المشاعر والتعبير عنها',
    category: 'emotional',
    suitableFor: ['autism', 'emotional', 'social'],
    ageRange: { min: 4, max: 14 },
    skills: ['emotion_recognition', 'emotion_expression', 'empathy'],
    defaultDifficulty: 'medium',
    defaultTimeLimit: 450000,
    smartFeatures: ['facial_recognition', 'emotion_matching'],
    achievements: {
      highScore: { threshold: 85, name: 'خبير مشاعر', description: 'حصلت على 85 نقطة أو أكثر' },
    },
  });

  // Spatial Awareness Games
  gamesSystem.registerGame('spatial-awareness', {
    name: 'لعبة الوعي المكاني',
    description: 'لعبة لتحسين الوعي المكاني والتوجه',
    category: 'spatial',
    suitableFor: ['visual', 'autism', 'spatial'],
    ageRange: { min: 5, max: 14 },
    skills: ['spatial_awareness', 'orientation', 'navigation'],
    defaultDifficulty: 'medium',
    defaultTimeLimit: 450000,
    smartFeatures: ['3d_visualization', 'spatial_adaptation'],
    achievements: {
      highScore: {
        threshold: 80,
        name: 'وعي مكاني ممتاز',
        description: 'حصلت على 80 نقطة أو أكثر',
      },
    },
  });

  gamesSystem.registerGame('visual-spatial', {
    name: 'لعبة البصري المكاني',
    description: 'لعبة لتحسين المهارات البصرية المكانية',
    category: 'spatial',
    suitableFor: ['visual', 'autism', 'learning'],
    ageRange: { min: 4, max: 12 },
    skills: ['visual_spatial', 'rotation', 'transformation'],
    defaultDifficulty: 'medium',
    defaultTimeLimit: 300000,
    smartFeatures: ['rotation_adaptation', 'complexity_scaling'],
    achievements: {
      highScore: {
        threshold: 75,
        name: 'بصري مكاني ممتاز',
        description: 'حصلت على 75 نقطة أو أكثر',
      },
    },
  });

  // Reading Readiness Games
  gamesSystem.registerGame('reading-readiness', {
    name: 'لعبة الاستعداد للقراءة',
    description: 'لعبة لتحسين مهارات الاستعداد للقراءة',
    category: 'academic',
    suitableFor: ['learning', 'speech', 'autism'],
    ageRange: { min: 4, max: 10 },
    skills: ['letter_sound', 'word_recognition', 'reading_fluency'],
    defaultDifficulty: 'easy',
    defaultTimeLimit: 450000,
    smartFeatures: ['phonics_adaptation', 'reading_level'],
    achievements: {
      highScore: { threshold: 85, name: 'مستعد للقراءة', description: 'حصلت على 85 نقطة أو أكثر' },
    },
  });

  gamesSystem.registerGame('vocabulary-building', {
    name: 'لعبة بناء المفردات',
    description: 'لعبة لتحسين بناء المفردات واللغة',
    category: 'language',
    suitableFor: ['speech', 'learning', 'autism'],
    ageRange: { min: 5, max: 12 },
    skills: ['vocabulary', 'word_meaning', 'language_expansion'],
    defaultDifficulty: 'medium',
    defaultTimeLimit: 450000,
    smartFeatures: ['vocabulary_adaptation', 'contextual_learning'],
    achievements: {
      highScore: { threshold: 80, name: 'مفردات غنية', description: 'حصلت على 80 نقطة أو أكثر' },
    },
  });

  // Motor Coordination Games
  gamesSystem.registerGame('bilateral-coordination', {
    name: 'لعبة التنسيق الثنائي',
    description: 'لعبة لتحسين التنسيق بين اليدين',
    category: 'motor',
    suitableFor: ['physical', 'cerebral_palsy', 'coordination'],
    ageRange: { min: 4, max: 12 },
    skills: ['bilateral_coordination', 'hand_cooperation', 'crossing_midline'],
    defaultDifficulty: 'medium',
    defaultTimeLimit: 600000,
    smartFeatures: ['coordination_adaptation', 'progressive_challenge'],
    achievements: {
      highScore: { threshold: 70, name: 'تنسيق ممتاز', description: 'حصلت على 70 نقطة أو أكثر' },
    },
  });

  gamesSystem.registerGame('balance-coordination', {
    name: 'لعبة التوازن والتنسيق',
    description: 'لعبة لتحسين التوازن والتنسيق الحركي',
    category: 'motor',
    suitableFor: ['physical', 'balance', 'cerebral_palsy'],
    ageRange: { min: 4, max: 14 },
    skills: ['balance', 'coordination', 'stability'],
    defaultDifficulty: 'medium',
    defaultTimeLimit: 600000,
    smartFeatures: ['balance_tracking', 'adaptive_support'],
    achievements: {
      highScore: { threshold: 75, name: 'توازن ممتاز', description: 'حصلت على 75 نقطة أو أكثر' },
    },
  });

  // Cognitive Flexibility Games
  gamesSystem.registerGame('cognitive-flexibility', {
    name: 'لعبة المرونة المعرفية',
    description: 'لعبة لتحسين المرونة المعرفية والتبديل',
    category: 'cognitive',
    suitableFor: ['adhd', 'autism', 'flexibility'],
    ageRange: { min: 6, max: 16 },
    skills: ['cognitive_flexibility', 'task_switching', 'adaptation'],
    defaultDifficulty: 'medium',
    defaultTimeLimit: 450000,
    smartFeatures: ['flexibility_training', 'switch_adaptation'],
    achievements: {
      highScore: {
        threshold: 80,
        name: 'مرونة معرفية ممتازة',
        description: 'حصلت على 80 نقطة أو أكثر',
      },
    },
  });

  gamesSystem.registerGame('inhibition-control', {
    name: 'لعبة التحكم في التثبيط',
    description: 'لعبة لتحسين التحكم في التثبيط والاندفاع',
    category: 'cognitive',
    suitableFor: ['adhd', 'impulse_control', 'behavioral'],
    ageRange: { min: 5, max: 14 },
    skills: ['inhibition', 'impulse_control', 'self_control'],
    defaultDifficulty: 'medium',
    defaultTimeLimit: 450000,
    smartFeatures: ['inhibition_training', 'impulse_monitoring'],
    achievements: {
      highScore: { threshold: 75, name: 'تحكم ممتاز', description: 'حصلت على 75 نقطة أو أكثر' },
    },
  });

  // Sensory Processing Games
  gamesSystem.registerGame('sensory-processing', {
    name: 'لعبة المعالجة الحسية',
    description: 'لعبة لتحسين معالجة المعلومات الحسية',
    category: 'sensory',
    suitableFor: ['autism', 'sensory', 'adhd'],
    ageRange: { min: 3, max: 12 },
    skills: ['sensory_processing', 'sensory_integration', 'modulation'],
    defaultDifficulty: 'easy',
    defaultTimeLimit: 600000,
    smartFeatures: ['sensory_adaptation', 'modulation_control'],
    achievements: {
      highScore: {
        threshold: 70,
        name: 'معالجة حسية ممتازة',
        description: 'حصلت على 70 نقطة أو أكثر',
      },
    },
  });

  gamesSystem.registerGame('tactile-discrimination', {
    name: 'لعبة التمييز اللمسي',
    description: 'لعبة لتحسين التمييز اللمسي والإحساس',
    category: 'sensory',
    suitableFor: ['sensory', 'autism', 'tactile'],
    ageRange: { min: 3, max: 10 },
    skills: ['tactile_discrimination', 'touch_sensitivity', 'texture_recognition'],
    defaultDifficulty: 'easy',
    defaultTimeLimit: 450000,
    smartFeatures: ['tactile_adaptation', 'sensitivity_control'],
    achievements: {
      highScore: {
        threshold: 75,
        name: 'تمييز لمسي ممتاز',
        description: 'حصلت على 75 نقطة أو أكثر',
      },
    },
  });

  // Life Skills Advanced Games
  gamesSystem.registerGame('safety-skills', {
    name: 'لعبة مهارات السلامة',
    description: 'لعبة لتحسين مهارات السلامة والحماية',
    category: 'life_skills',
    suitableFor: ['intellectual', 'autism', 'safety'],
    ageRange: { min: 6, max: 16 },
    skills: ['safety_awareness', 'danger_recognition', 'self_protection'],
    defaultDifficulty: 'medium',
    defaultTimeLimit: 600000,
    smartFeatures: ['safety_scenarios', 'real_world_application'],
    achievements: {
      highScore: { threshold: 90, name: 'خبير سلامة', description: 'حصلت على 90 نقطة أو أكثر' },
    },
  });

  gamesSystem.registerGame('social-communication', {
    name: 'لعبة التواصل الاجتماعي',
    description: 'لعبة لتحسين التواصل الاجتماعي والمحادثة',
    category: 'social',
    suitableFor: ['autism', 'social', 'communication'],
    ageRange: { min: 5, max: 16 },
    skills: ['conversation', 'turn_taking', 'social_cues'],
    defaultDifficulty: 'medium',
    defaultTimeLimit: 600000,
    smartFeatures: ['conversation_simulation', 'social_adaptation'],
    achievements: {
      highScore: {
        threshold: 80,
        name: 'تواصل اجتماعي ممتاز',
        description: 'حصلت على 80 نقطة أو أكثر',
      },
    },
  });

  gamesSystem.registerGame('daily-routines', {
    name: 'لعبة الروتين اليومي',
    description: 'لعبة لتحسين فهم وإدارة الروتين اليومي',
    category: 'life_skills',
    suitableFor: ['autism', 'intellectual', 'life_skills'],
    ageRange: { min: 5, max: 14 },
    skills: ['routine_understanding', 'sequence_following', 'independence'],
    defaultDifficulty: 'medium',
    defaultTimeLimit: 600000,
    smartFeatures: ['routine_customization', 'sequence_adaptation'],
    achievements: {
      highScore: { threshold: 85, name: 'روتين ممتاز', description: 'حصلت على 85 نقطة أو أكثر' },
    },
  });

  // Advanced Academic Games
  gamesSystem.registerGame('reading-comprehension', {
    name: 'لعبة فهم القراءة',
    description: 'لعبة لتحسين فهم القراءة والاستيعاب',
    category: 'academic',
    suitableFor: ['learning', 'intellectual', 'reading'],
    ageRange: { min: 6, max: 16 },
    skills: ['reading_comprehension', 'inference', 'critical_thinking'],
    defaultDifficulty: 'medium',
    defaultTimeLimit: 600000,
    smartFeatures: ['comprehension_level', 'text_adaptation'],
    achievements: {
      highScore: {
        threshold: 80,
        name: 'فهم قراءة ممتاز',
        description: 'حصلت على 80 نقطة أو أكثر',
      },
    },
  });

  gamesSystem.registerGame('writing-skills', {
    name: 'لعبة مهارات الكتابة',
    description: 'لعبة لتحسين مهارات الكتابة والتعبير',
    category: 'academic',
    suitableFor: ['learning', 'writing', 'fine_motor'],
    ageRange: { min: 6, max: 14 },
    skills: ['writing', 'spelling', 'sentence_formation'],
    defaultDifficulty: 'medium',
    defaultTimeLimit: 600000,
    smartFeatures: ['writing_adaptation', 'spell_check'],
    achievements: {
      highScore: { threshold: 75, name: 'كتابة ممتازة', description: 'حصلت على 75 نقطة أو أكثر' },
    },
  });

  gamesSystem.registerGame('science-concepts', {
    name: 'لعبة المفاهيم العلمية',
    description: 'لعبة لتحسين فهم المفاهيم العلمية',
    category: 'academic',
    suitableFor: ['intellectual', 'learning', 'science'],
    ageRange: { min: 7, max: 16 },
    skills: ['scientific_thinking', 'observation', 'experimentation'],
    defaultDifficulty: 'medium',
    defaultTimeLimit: 600000,
    smartFeatures: ['concept_adaptation', 'experiment_simulation'],
    achievements: {
      highScore: { threshold: 80, name: 'عالم صغير', description: 'حصلت على 80 نقطة أو أكثر' },
    },
  });
}

// Get all games
router.get('/', optionalAuth, (req, res) => {
  try {
    const filters = {
      disabilityType: req.query.disabilityType,
      ageRange:
        req.query.ageMin && req.query.ageMax
          ? {
              min: parseInt(req.query.ageMin),
              max: parseInt(req.query.ageMax),
            }
          : undefined,
      skill: req.query.skill,
    };

    const games = gamesSystem.getAllGames(filters);

    res.json({
      success: true,
      data: {
        games,
        count: games.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get game details
router.get('/:gameId', optionalAuth, (req, res) => {
  try {
    const { gameId } = req.params;
    const game = gamesSystem.getGame(gameId);

    if (!game) {
      return res.status(404).json({
        success: false,
        error: 'Game not found',
      });
    }

    res.json({
      success: true,
      data: game,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Register new game (admin only)
router.post('/', require('../middleware/auth-middleware').requireAdmin, (req, res) => {
  try {
    const { gameId, ...config } = req.body;

    if (!gameId) {
      return res.status(400).json({
        success: false,
        error: 'Game ID is required',
      });
    }

    const game = gamesSystem.registerGame(gameId, config);

    res.json({
      success: true,
      data: game,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Start game session
router.post('/:gameId/start', authenticateToken, (req, res) => {
  try {
    const { gameId } = req.params;
    const { patientId, adaptations } = req.body;

    if (!patientId) {
      return res.status(400).json({
        success: false,
        error: 'Patient ID is required',
      });
    }

    const session = gamesSystem.startSession(patientId, gameId, adaptations || {});

    res.json({
      success: true,
      data: session,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Update session progress
router.put('/sessions/:sessionId/progress', authenticateToken, (req, res) => {
  try {
    const { sessionId } = req.params;
    const progressData = req.body;

    const session = gamesSystem.updateProgress(sessionId, progressData);

    res.json({
      success: true,
      data: session,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// End session
router.post('/sessions/:sessionId/end', authenticateToken, (req, res) => {
  try {
    const { sessionId } = req.params;
    const result = gamesSystem.endSession(sessionId);

    res.json({
      success: true,
      data: result,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get patient progress
router.get('/progress/:patientId', authenticateToken, (req, res) => {
  try {
    const { patientId } = req.params;
    const gameId = req.query.gameId || null;

    const progress = gamesSystem.getPatientProgress(patientId, gameId);

    res.json({
      success: true,
      data: {
        patientId,
        gameId,
        progress,
        count: progress.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get recommendations
router.get('/recommendations/:patientId', authenticateToken, (req, res) => {
  try {
    const { patientId } = req.params;
    const recommendations = gamesSystem.getRecommendations(patientId);
    const adaptiveRecommendations = gameAdaptiveEngine.getRecommendations(patientId);

    res.json({
      success: true,
      data: {
        patientId,
        recommendations: [...recommendations, ...adaptiveRecommendations],
        count: recommendations.length + adaptiveRecommendations.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Create adaptive profile
router.post('/adaptive/profile', authenticateToken, (req, res) => {
  try {
    const { patientId, ...initialData } = req.body;

    if (!patientId) {
      return res.status(400).json({
        success: false,
        error: 'Patient ID is required',
      });
    }

    const profile = gameAdaptiveEngine.createProfile(patientId, initialData);

    res.json({
      success: true,
      data: profile,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get adaptive profile
router.get('/adaptive/profile/:patientId', authenticateToken, (req, res) => {
  try {
    const { patientId } = req.params;
    const profile = gameAdaptiveEngine.getProfile(patientId);

    if (!profile) {
      return res.status(404).json({
        success: false,
        error: 'Profile not found',
      });
    }

    res.json({
      success: true,
      data: profile,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Analyze progress
router.get('/analyze/:patientId/:gameId', authenticateToken, (req, res) => {
  try {
    const { patientId, gameId } = req.params;
    const sessions = gamesSystem.getPatientProgress(patientId, gameId);

    const analysis = gameProgressAnalyzer.analyzeProgress(patientId, gameId, sessions);

    res.json({
      success: true,
      data: analysis,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Compare patients
router.post('/compare', authenticateToken, (req, res) => {
  try {
    const { patientIds, gameId } = req.body;

    if (!patientIds || !Array.isArray(patientIds) || patientIds.length < 2) {
      return res.status(400).json({
        success: false,
        error: 'At least 2 patient IDs are required',
      });
    }

    if (!gameId) {
      return res.status(400).json({
        success: false,
        error: 'Game ID is required',
      });
    }

    // Get sessions for all patients
    const allSessions = {};
    patientIds.forEach(patientId => {
      const sessions = gamesSystem.getPatientProgress(patientId, gameId);
      if (sessions.length > 0) {
        gameProgressAnalyzer.analyzeProgress(patientId, gameId, sessions);
      }
    });

    const comparison = gameProgressAnalyzer.comparePatients(patientIds, gameId);

    res.json({
      success: true,
      data: {
        gameId,
        comparison,
        count: comparison.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Multiplayer Routes
// Create room
router.post('/multiplayer/rooms', authenticateToken, (req, res) => {
  try {
    const { gameId, ...config } = req.body;
    const hostId = req.user?.id || req.body.hostId;

    if (!gameId) {
      return res.status(400).json({
        success: false,
        error: 'Game ID is required',
      });
    }

    const room = gameMultiplayer.createRoom(gameId, { ...config, hostId });

    res.json({
      success: true,
      data: room,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Join room
router.post('/multiplayer/rooms/:roomId/join', authenticateToken, (req, res) => {
  try {
    const { roomId } = req.params;
    const playerId = req.user?.id || req.body.playerId;

    if (!playerId) {
      return res.status(400).json({
        success: false,
        error: 'Player ID is required',
      });
    }

    const result = gameMultiplayer.joinRoom(roomId, playerId);

    res.json({
      success: true,
      data: result,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Start match
router.post('/multiplayer/rooms/:roomId/start', authenticateToken, (req, res) => {
  try {
    const { roomId } = req.params;
    const match = gameMultiplayer.startMatch(roomId);

    res.json({
      success: true,
      data: match,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get available rooms
router.get('/multiplayer/rooms', optionalAuth, (req, res) => {
  try {
    const { gameId } = req.query;
    const rooms = gameMultiplayer.getAvailableRooms(gameId);

    res.json({
      success: true,
      data: {
        rooms,
        count: rooms.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// AI Coach Routes
// Get coaching tips
router.post('/coach/tips', authenticateToken, (req, res) => {
  try {
    const { patientId, gameId, sessionData } = req.body;

    if (!patientId || !gameId) {
      return res.status(400).json({
        success: false,
        error: 'Patient ID and Game ID are required',
      });
    }

    const tips = gameAICoach.provideTip(patientId, gameId, sessionData || {});

    res.json({
      success: true,
      data: {
        tips,
        count: tips.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get strategy
router.post('/coach/strategy', authenticateToken, (req, res) => {
  try {
    const { patientId, gameId, history } = req.body;

    if (!patientId || !gameId) {
      return res.status(400).json({
        success: false,
        error: 'Patient ID and Game ID are required',
      });
    }

    const strategy = gameAICoach.generateStrategy(patientId, gameId, history || []);

    res.json({
      success: true,
      data: strategy,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Accessibility Routes
// Create accessibility profile
router.post('/accessibility/profile', authenticateToken, (req, res) => {
  try {
    const { patientId, needs } = req.body;

    if (!patientId) {
      return res.status(400).json({
        success: false,
        error: 'Patient ID is required',
      });
    }

    const profile = gameAccessibility.createProfile(patientId, needs || {});

    res.json({
      success: true,
      data: profile,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get accessibility profile
router.get('/accessibility/profile/:patientId', authenticateToken, (req, res) => {
  try {
    const { patientId } = req.params;
    const profile = gameAccessibility.getProfile(patientId);

    if (!profile) {
      return res.status(404).json({
        success: false,
        error: 'Profile not found',
      });
    }

    res.json({
      success: true,
      data: profile,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get accessibility recommendations
router.get('/accessibility/recommendations/:patientId', authenticateToken, (req, res) => {
  try {
    const { patientId } = req.params;
    const { gameId } = req.query;

    const recommendations = gameAccessibility.getRecommendations(patientId, gameId);

    res.json({
      success: true,
      data: {
        recommendations,
        count: recommendations.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Game Content Generation Routes
// Generate game content
router.post('/content/generate', authenticateToken, (req, res) => {
  try {
    const { type, count, difficulty, options } = req.body;

    if (!type) {
      return res.status(400).json({
        success: false,
        error: 'Content type is required',
      });
    }

    let content;

    switch (type) {
      case 'memory':
        content = gameContentGenerator.generateMemoryCards(
          count || 8,
          options?.cardType || 'images'
        );
        break;
      case 'math':
        content = gameContentGenerator.generateMathQuestions(count || 10, difficulty || 'medium');
        break;
      case 'language':
        content = gameContentGenerator.generateLanguageQuestions(
          count || 10,
          options?.questionType || 'letters'
        );
        break;
      case 'visual':
        content = gameContentGenerator.generateVisualQuestions(count || 10);
        break;
      default:
        return res.status(400).json({
          success: false,
          error: 'Invalid content type',
        });
    }

    res.json({
      success: true,
      data: {
        type,
        content,
        count: content.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get game template
router.get('/templates/:templateId', optionalAuth, (req, res) => {
  try {
    const { templateId } = req.params;
    const template = gameTemplates.getTemplate(templateId);

    if (!template) {
      return res.status(404).json({
        success: false,
        error: 'Template not found',
      });
    }

    res.json({
      success: true,
      data: template,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Create game from template
router.post(
  '/templates/:templateId/create',
  require('../middleware/auth-middleware').requireAdmin,
  (req, res) => {
    try {
      const { templateId } = req.params;
      const gameData = req.body;

      const game = gameTemplates.createGameFromTemplate(templateId, gameData);

      res.json({
        success: true,
        data: game,
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: error.message,
      });
    }
  }
);

// Smart Game Engine Routes
// Initialize AI model
router.post('/smart/initialize', authenticateToken, (req, res) => {
  try {
    const { patientId, gameId } = req.body;

    if (!patientId || !gameId) {
      return res.status(400).json({
        success: false,
        error: 'Patient ID and Game ID are required',
      });
    }

    const model = smartGameEngine.initializeAIModel(patientId, gameId);

    res.json({
      success: true,
      data: model,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get AI insights
router.get('/smart/insights/:patientId/:gameId', authenticateToken, (req, res) => {
  try {
    const { patientId, gameId } = req.params;
    const insights = smartGameEngine.getAIInsights(patientId, gameId);

    res.json({
      success: true,
      data: insights,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Generate game path
router.post('/smart/path', authenticateToken, (req, res) => {
  try {
    const { patientId, gameId, goals } = req.body;

    if (!patientId || !gameId) {
      return res.status(400).json({
        success: false,
        error: 'Patient ID and Game ID are required',
      });
    }

    const path = smartGameEngine.generateGamePath(patientId, gameId, goals);

    res.json({
      success: true,
      data: path,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Predict optimal difficulty
router.post('/smart/predict-difficulty', authenticateToken, (req, res) => {
  try {
    const { patientId, gameId, currentPerformance } = req.body;

    if (!patientId || !gameId) {
      return res.status(400).json({
        success: false,
        error: 'Patient ID and Game ID are required',
      });
    }

    const difficulty = smartGameEngine.predictOptimalDifficulty(
      patientId,
      gameId,
      currentPerformance || {}
    );

    res.json({
      success: true,
      data: {
        predictedDifficulty: difficulty,
        confidence: 0.85,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Real-time adaptation
router.post('/smart/adapt', authenticateToken, (req, res) => {
  try {
    const { patientId, gameId, currentSession } = req.body;

    if (!patientId || !gameId) {
      return res.status(400).json({
        success: false,
        error: 'Patient ID and Game ID are required',
      });
    }

    const adaptations = smartGameEngine.adaptInRealTime(patientId, gameId, currentSession || {});

    res.json({
      success: true,
      data: adaptations,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Game Analytics Routes
// Get game analytics
router.get('/:gameId/analytics', optionalAuth, (req, res) => {
  try {
    const { gameId } = req.params;
    const { timeRange = 'all' } = req.query;

    // Get all sessions for this game
    const allSessions = gamesSystem.getGameSessions(gameId);

    // Filter by time range
    let filteredSessions = allSessions;
    if (timeRange !== 'all') {
      const now = Date.now();
      const ranges = {
        day: 24 * 60 * 60 * 1000,
        week: 7 * 24 * 60 * 60 * 1000,
        month: 30 * 24 * 60 * 60 * 1000,
      };
      const cutoff = now - ranges[timeRange];
      filteredSessions = allSessions.filter(s => s.timestamp >= cutoff);
    }

    const analytics = gameAnalyticsEngine.analyzeGamePerformance(gameId, filteredSessions);

    res.json({
      success: true,
      data: analytics,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get patterns for patient
router.get('/:gameId/patterns/:patientId', authenticateToken, (req, res) => {
  try {
    const { gameId, patientId } = req.params;
    const sessions = gamesSystem.getPatientProgress(patientId, gameId);

    const patterns = gameAnalyticsEngine.detectPatterns(patientId, gameId, sessions);

    res.json({
      success: true,
      data: patterns,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get predictions for patient
router.get('/:gameId/predictions/:patientId', authenticateToken, (req, res) => {
  try {
    const { gameId, patientId } = req.params;
    const sessions = gamesSystem.getPatientProgress(patientId, gameId);

    const predictions = gameAnalyticsEngine.predictPerformance(patientId, gameId, sessions);

    res.json({
      success: true,
      data: predictions,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get patient game stats
router.get('/patient/:patientId/stats', authenticateToken, (req, res) => {
  try {
    const { patientId } = req.params;
    const allProgress = gamesSystem.getPatientProgress(patientId);
    const allGames = gamesSystem.getAllGames();

    const stats = {
      totalGames: allGames.length,
      completedGames: 0,
      averageScore: 0,
      improvement: 0,
      gamesPlayed: new Set(allProgress.map(p => p.gameId)).size,
    };

    if (allProgress.length > 0) {
      const completed = allProgress.filter(p => p.status === 'completed');
      stats.completedGames = completed.length;

      if (completed.length > 0) {
        stats.averageScore =
          completed.reduce((sum, p) => sum + (p.score || 0), 0) / completed.length;
      }

      // Calculate improvement
      if (allProgress.length >= 2) {
        const firstHalf = allProgress.slice(0, Math.floor(allProgress.length / 2));
        const secondHalf = allProgress.slice(Math.floor(allProgress.length / 2));

        const firstAvg = firstHalf.reduce((sum, p) => sum + (p.score || 0), 0) / firstHalf.length;
        const secondAvg =
          secondHalf.reduce((sum, p) => sum + (p.score || 0), 0) / secondHalf.length;

        if (firstAvg > 0) {
          stats.improvement = ((secondAvg - firstAvg) / firstAvg) * 100;
        }
      }
    }

    res.json({
      success: true,
      data: stats,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get game sessions
router.get('/:gameId/sessions', optionalAuth, (req, res) => {
  try {
    const { gameId } = req.params;
    const sessions = gamesSystem.getGameSessions(gameId);

    res.json({
      success: true,
      data: {
        sessions,
        count: sessions.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get patient progress
router.get('/patient/:patientId/progress', authenticateToken, (req, res) => {
  try {
    const { patientId } = req.params;
    const { gameId, timeRange = 'all' } = req.query;

    let progress = gamesSystem.getPatientProgress(patientId, gameId || null);

    // Filter by time range
    if (timeRange !== 'all') {
      const now = Date.now();
      const ranges = {
        day: 24 * 60 * 60 * 1000,
        week: 7 * 24 * 60 * 60 * 1000,
        month: 30 * 24 * 60 * 60 * 1000,
      };
      const cutoff = now - ranges[timeRange];
      progress = progress.filter(p => p.timestamp >= cutoff);
    }

    res.json({
      success: true,
      data: {
        progress,
        count: progress.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Start game session
router.post('/sessions', authenticateToken, (req, res) => {
  try {
    const { patientId, gameId, adaptations } = req.body;

    if (!patientId || !gameId) {
      return res.status(400).json({
        success: false,
        error: 'Patient ID and Game ID are required',
      });
    }

    const session = gamesSystem.startSession(patientId, gameId, adaptations || {});

    res.json({
      success: true,
      data: { session },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Update session progress
router.post('/sessions/:sessionId/progress', authenticateToken, (req, res) => {
  try {
    const { sessionId } = req.params;
    const { score, level, progress } = req.body;

    const updatedSession = gamesSystem.updateProgress(sessionId, {
      score,
      level,
      progress,
    });

    res.json({
      success: true,
      data: { session: updatedSession },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// End game session
router.post('/sessions/:sessionId/end', authenticateToken, (req, res) => {
  try {
    const { sessionId } = req.params;
    const { score, level, progress } = req.body;

    const result = gamesSystem.endSession(sessionId, {
      score,
      level,
      progress,
    });

    res.json({
      success: true,
      data: result,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get patient achievements
router.get('/patient/:patientId/achievements', authenticateToken, (req, res) => {
  try {
    const { patientId } = req.params;
    const { gameId } = req.query;

    const progress = gamesSystem.getPatientProgress(patientId, gameId || null);
    const achievements = [];

    // Process achievements from progress
    progress.forEach(session => {
      if (session.achievements && session.achievements.length > 0) {
        session.achievements.forEach(achievement => {
          achievements.push({
            ...achievement,
            gameId: session.gameId,
            unlockedAt: session.timestamp,
          });
        });
      }
    });

    // Get all possible achievements for games
    const allGames = gamesSystem.getAllGames();
    allGames.forEach(game => {
      if (game.achievements) {
        Object.keys(game.achievements).forEach(achievementKey => {
          const achievement = game.achievements[achievementKey];
          const existing = achievements.find(
            a => a.gameId === game.id && a.name === achievement.name
          );

          if (!existing) {
            achievements.push({
              name: achievement.name,
              description: achievement.description,
              type: achievementKey,
              threshold: achievement.threshold,
              unlocked: false,
              gameId: game.id,
            });
          }
        });
      }
    });

    res.json({
      success: true,
      data: {
        achievements: achievements.filter(a => !gameId || a.gameId === gameId),
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get leaderboard
router.get('/leaderboard', optionalAuth, (req, res) => {
  try {
    const { timeRange = 'all' } = req.query;
    const allGames = gamesSystem.getAllGames();
    const leaderboard = [];

    allGames.forEach(game => {
      const sessions = gamesSystem.getGameSessions(game.id);

      // Filter by time range
      let filteredSessions = sessions;
      if (timeRange !== 'all') {
        const now = Date.now();
        const ranges = {
          day: 24 * 60 * 60 * 1000,
          week: 7 * 24 * 60 * 60 * 1000,
          month: 30 * 24 * 60 * 60 * 1000,
        };
        const cutoff = now - ranges[timeRange];
        filteredSessions = sessions.filter(s => s.timestamp >= cutoff);
      }

      // Group by patient
      const patientScores = {};
      filteredSessions.forEach(session => {
        if (!patientScores[session.patientId]) {
          patientScores[session.patientId] = {
            patientId: session.patientId,
            score: 0,
            accuracy: 0,
            level: 0,
            sessions: 0,
          };
        }
        patientScores[session.patientId].score += session.score || 0;
        patientScores[session.patientId].accuracy += session.metrics?.accuracy || 0;
        patientScores[session.patientId].level = Math.max(
          patientScores[session.patientId].level,
          session.level || 0
        );
        patientScores[session.patientId].sessions++;
      });

      // Calculate averages and add to leaderboard
      Object.values(patientScores).forEach(entry => {
        entry.accuracy = entry.accuracy / entry.sessions;
        leaderboard.push(entry);
      });
    });

    // Sort by score
    leaderboard.sort((a, b) => b.score - a.score);

    res.json({
      success: true,
      data: {
        leaderboard: leaderboard.slice(0, 100), // Top 100
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get game leaderboard
router.get('/:gameId/leaderboard', optionalAuth, (req, res) => {
  try {
    const { gameId } = req.params;
    const { timeRange = 'all' } = req.query;

    const sessions = gamesSystem.getGameSessions(gameId);

    // Filter by time range
    let filteredSessions = sessions;
    if (timeRange !== 'all') {
      const now = Date.now();
      const ranges = {
        day: 24 * 60 * 60 * 1000,
        week: 7 * 24 * 60 * 60 * 1000,
        month: 30 * 24 * 60 * 60 * 1000,
      };
      const cutoff = now - ranges[timeRange];
      filteredSessions = sessions.filter(s => s.timestamp >= cutoff);
    }

    // Group by patient
    const patientScores = {};
    filteredSessions.forEach(session => {
      if (!patientScores[session.patientId]) {
        patientScores[session.patientId] = {
          patientId: session.patientId,
          score: 0,
          accuracy: 0,
          level: 0,
          sessions: 0,
        };
      }
      patientScores[session.patientId].score += session.score || 0;
      patientScores[session.patientId].accuracy += session.metrics?.accuracy || 0;
      patientScores[session.patientId].level = Math.max(
        patientScores[session.patientId].level,
        session.level || 0
      );
      patientScores[session.patientId].sessions++;
    });

    // Calculate averages
    const leaderboard = Object.values(patientScores).map(entry => ({
      ...entry,
      accuracy: entry.accuracy / entry.sessions,
    }));

    // Sort by score
    leaderboard.sort((a, b) => b.score - a.score);

    res.json({
      success: true,
      data: {
        leaderboard: leaderboard.slice(0, 50), // Top 50
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get game recommendations
router.get('/recommendations/:patientId', authenticateToken, (req, res) => {
  try {
    const { patientId } = req.params;
    const { category } = req.query;

    const recommendations = gamesSystem.getRecommendations(patientId);

    // Filter by category if provided
    const filtered = category
      ? recommendations.filter(r => r.category === category)
      : recommendations;

    res.json({
      success: true,
      data: {
        recommendations: filtered,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

module.exports = router;
