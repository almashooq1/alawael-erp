/**
 * 📦 Inventory & Equipment Management Routes
 */

const express = require('express');
const router = express.Router();
const InventoryEquipmentManager = require('../../shared/utils/inventory-equipment-manager');

const inventoryManager = new InventoryEquipmentManager();

// Inventory
router.post('/inventory', async (req, res) => {
  try {
    const item = inventoryManager.addInventoryItem(req.body);
    res.json({ success: true, data: item });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/inventory', async (req, res) => {
  try {
    const items = inventoryManager.getInventoryItems(req.query);
    res.json({ success: true, data: items });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/inventory/:id/quantity', async (req, res) => {
  try {
    const item = inventoryManager.updateInventoryQuantity(
      req.params.id,
      req.body.quantity,
      req.body.operation || 'set'
    );
    res.json({ success: true, data: item });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Equipment
router.post('/equipment', async (req, res) => {
  try {
    const equipment = inventoryManager.addEquipment(req.body);
    res.json({ success: true, data: equipment });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/equipment', async (req, res) => {
  try {
    const equipment = inventoryManager.getEquipment(req.query);
    res.json({ success: true, data: equipment });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Maintenance
router.post('/equipment/:id/maintenance', async (req, res) => {
  try {
    const maintenance = inventoryManager.scheduleMaintenance(req.params.id, req.body);
    res.json({ success: true, data: maintenance });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Suppliers
router.post('/suppliers', async (req, res) => {
  try {
    const supplier = inventoryManager.addSupplier(req.body);
    res.json({ success: true, data: supplier });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/suppliers', async (req, res) => {
  try {
    const suppliers = inventoryManager.getSuppliers(req.query);
    res.json({ success: true, data: suppliers });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Purchase Orders
router.post('/purchase-orders', async (req, res) => {
  try {
    const order = inventoryManager.createPurchaseOrder(req.body);
    res.json({ success: true, data: order });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/purchase-orders/:id/receive', async (req, res) => {
  try {
    const order = inventoryManager.receiveOrder(req.params.id, req.body.receivedItems);
    res.json({ success: true, data: order });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Auto Reorder
router.post('/auto-reorder', async (req, res) => {
  try {
    const orders = inventoryManager.autoReorderLowStockItems();
    res.json({ success: true, data: orders });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Reports
router.get('/reports', async (req, res) => {
  try {
    const report = inventoryManager.getInventoryReport();
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
