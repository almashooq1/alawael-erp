/**
 * 📦 Inventory Management Routes
 * مسارات إدارة المخزون والإمدادات
 */

const express = require('express');
const router = express.Router();
let InventoryItem;
try {
  InventoryItem = require('../models/InventoryItem');
} catch (e) {
  InventoryItem = {
    findById: async id => ({ id }),
    create: async data => ({ id: Date.now(), ...data }),
    find: async () => [],
  };
}
const authenticateToken = require('../middleware/authenticateToken');
const logger = require('../../shared/logging/logger');

// Real-time event emitter (if available)
let io = null;
try {
  const realtimeModule = require('../realtime');
  io = realtimeModule.io;
} catch (error) {
  // Real-time not available
}

/**
 * Emit real-time event
 */
function emitEvent(eventType, entityType, data) {
  if (io) {
    io.emit('inventory:update', {
      action: eventType,
      entityType: entityType,
      entityId: data.id,
      data: data,
    });
  }
}

// Apply authentication to all routes
router.use(authenticateToken);

/**
 * Inventory Items Routes
 */
router.get('/', async (req, res) => {
  try {
    const items = await InventoryItem.findAll({
      order: [['createdAt', 'DESC']],
    });
    res.json(items);
  } catch (error) {
    logger.error('Error fetching inventory items:', error);
    res.status(500).json({ error: 'خطأ في جلب المواد' });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const item = await InventoryItem.findByPk(req.params.id);
    if (!item) {
      return res.status(404).json({ error: 'المادة غير موجودة' });
    }
    res.json(item);
  } catch (error) {
    logger.error('Error fetching inventory item:', error);
    res.status(500).json({ error: 'خطأ في جلب المادة' });
  }
});

router.post('/', async (req, res) => {
  try {
    const item = await InventoryItem.create(req.body);
    emitEvent('create', 'item', item);
    logger.info('Inventory item created', { id: item.id, name: item.name });
    res.status(201).json(item);
  } catch (error) {
    logger.error('Error creating inventory item:', error);
    res.status(400).json({ error: 'خطأ في إضافة المادة' });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const [updated] = await InventoryItem.update(req.body, {
      where: { id: req.params.id },
    });
    if (updated) {
      const item = await InventoryItem.findByPk(req.params.id);
      emitEvent('update', 'item', item);
      logger.info('Inventory item updated', { id: item.id });
      res.json(item);
    } else {
      res.status(404).json({ error: 'المادة غير موجودة' });
    }
  } catch (error) {
    logger.error('Error updating inventory item:', error);
    res.status(400).json({ error: 'خطأ في تحديث المادة' });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    const deleted = await InventoryItem.destroy({
      where: { id: req.params.id },
    });
    if (deleted) {
      emitEvent('delete', 'item', { id: req.params.id });
      logger.info('Inventory item deleted', { id: req.params.id });
      res.json({ message: 'تم حذف المادة بنجاح' });
    } else {
      res.status(404).json({ error: 'المادة غير موجودة' });
    }
  } catch (error) {
    logger.error('Error deleting inventory item:', error);
    res.status(400).json({ error: 'خطأ في حذف المادة' });
  }
});

/**
 * Categories Routes
 */
router.get('/categories', async (req, res) => {
  try {
    // In production, use InventoryCategory model
    // For now, return default categories
    const categories = [
      { id: 1, name: 'أدوية', icon: '💊' },
      { id: 2, name: 'مستلزمات طبية', icon: '🏥' },
      { id: 3, name: 'مستلزمات نظافة', icon: '🧹' },
      { id: 4, name: 'مواد غذائية', icon: '🍎' },
      { id: 5, name: 'مستلزمات مكتبية', icon: '📝' },
    ];
    res.json(categories);
  } catch (error) {
    logger.error('Error fetching categories:', error);
    res.status(500).json({ error: 'خطأ في جلب الفئات' });
  }
});

module.exports = router;
