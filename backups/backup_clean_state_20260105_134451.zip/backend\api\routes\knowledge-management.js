/**
 * 📚 Knowledge Management Routes
 * API routes for knowledge management system
 */

const express = require('express');
const router = express.Router();

// Mock data storage (replace with database)
const articles = [];
const categories = [];
const resources = [];
const faqs = [];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Articles ====================

router.get('/articles', async (req, res) => {
  try {
    const { categoryId, search } = req.query;
    let filtered = articles;

    if (categoryId) {
      filtered = filtered.filter(a => a.categoryId === parseInt(categoryId));
    }

    if (search) {
      const query = search.toLowerCase();
      filtered = filtered.filter(
        a =>
          a.title.toLowerCase().includes(query) ||
          (a.content && a.content.toLowerCase().includes(query)) ||
          (a.tags && a.tags.some(tag => tag.toLowerCase().includes(query)))
      );
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.get('/articles/:id', async (req, res) => {
  try {
    const article = articles.find(a => a.id === parseInt(req.params.id));
    if (!article) {
      return res.status(404).json({
        success: false,
        error: 'Article not found',
      });
    }

    // Increment views
    article.views = (article.views || 0) + 1;

    res.json({
      success: true,
      data: article,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/articles', async (req, res) => {
  try {
    const article = {
      id: articles.length > 0 ? Math.max(...articles.map(a => a.id)) + 1 : 1,
      ...req.body,
      views: 0,
      likes: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    articles.push(article);

    emitEvent('knowledge:article:updated', {
      action: 'create',
      entityId: article.id,
      data: article,
    });

    res.json({
      success: true,
      data: article,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.put('/articles/:id', async (req, res) => {
  try {
    const index = articles.findIndex(a => a.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Article not found',
      });
    }

    articles[index] = {
      ...articles[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    emitEvent('knowledge:article:updated', {
      action: 'update',
      entityId: articles[index].id,
      data: articles[index],
    });

    res.json({
      success: true,
      data: articles[index],
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.delete('/articles/:id', async (req, res) => {
  try {
    const index = articles.findIndex(a => a.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Article not found',
      });
    }

    articles.splice(index, 1);

    emitEvent('knowledge:article:updated', {
      action: 'delete',
      entityId: parseInt(req.params.id),
    });

    res.json({
      success: true,
      message: 'Article deleted successfully',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/articles/:id/like', async (req, res) => {
  try {
    const article = articles.find(a => a.id === parseInt(req.params.id));
    if (!article) {
      return res.status(404).json({
        success: false,
        error: 'Article not found',
      });
    }

    article.likes = (article.likes || 0) + 1;

    emitEvent('knowledge:article:updated', {
      action: 'update',
      entityId: article.id,
      data: article,
    });

    res.json({
      success: true,
      data: article,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Categories ====================

router.get('/categories', async (req, res) => {
  try {
    res.json({
      success: true,
      data: categories,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/categories', async (req, res) => {
  try {
    const category = {
      id: categories.length > 0 ? Math.max(...categories.map(c => c.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
    };

    categories.push(category);

    emitEvent('knowledge:category:updated', {
      action: 'create',
      entityId: category.id,
      data: category,
    });

    res.json({
      success: true,
      data: category,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Resources ====================

router.get('/resources', async (req, res) => {
  try {
    res.json({
      success: true,
      data: resources,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/resources', async (req, res) => {
  try {
    const resource = {
      id: resources.length > 0 ? Math.max(...resources.map(r => r.id)) + 1 : 1,
      ...req.body,
      uploadedAt: new Date().toISOString(),
    };

    resources.push(resource);

    emitEvent('knowledge:resource:updated', {
      action: 'create',
      entityId: resource.id,
      data: resource,
    });

    res.json({
      success: true,
      data: resource,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== FAQs ====================

router.get('/faqs', async (req, res) => {
  try {
    res.json({
      success: true,
      data: faqs,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/faqs', async (req, res) => {
  try {
    const faq = {
      id: faqs.length > 0 ? Math.max(...faqs.map(f => f.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
    };

    faqs.push(faq);

    res.json({
      success: true,
      data: faq,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

module.exports = { router, setIO };
