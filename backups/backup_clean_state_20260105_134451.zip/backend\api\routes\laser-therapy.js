/**
 * 🔴 Laser Therapy Routes
 * API routes for laser therapy sessions, devices, programs, and progress
 */

const express = require('express');
const router = express.Router();

// Mock data storage
const sessions = [];
const devices = [];
const programs = [];
const progress = [];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Sessions ====================

router.get('/sessions', async (req, res) => {
  try {
    res.json({ success: true, data: sessions });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/sessions', async (req, res) => {
  try {
    const session = {
      id: sessions.length > 0 ? Math.max(...sessions.map(s => s.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    sessions.push(session);

    emitEvent('laserTherapy:update', {
      action: 'create',
      entityType: 'session',
      entityId: session.id,
      data: session,
    });

    res.status(201).json({ success: true, data: session });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/sessions/:id', async (req, res) => {
  try {
    const index = sessions.findIndex(s => s.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Session not found' });
    }

    sessions[index] = {
      ...sessions[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    emitEvent('laserTherapy:update', {
      action: 'update',
      entityType: 'session',
      entityId: sessions[index].id,
      data: sessions[index],
    });

    res.json({ success: true, data: sessions[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.delete('/sessions/:id', async (req, res) => {
  try {
    const index = sessions.findIndex(s => s.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Session not found' });
    }

    const deletedSession = sessions[index];
    sessions.splice(index, 1);

    emitEvent('laserTherapy:update', {
      action: 'delete',
      entityType: 'session',
      entityId: deletedSession.id,
    });

    res.json({ success: true, message: 'Session deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Devices ====================

router.get('/devices', async (req, res) => {
  try {
    res.json({ success: true, data: devices });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/devices', async (req, res) => {
  try {
    const device = {
      id: devices.length > 0 ? Math.max(...devices.map(d => d.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    devices.push(device);

    emitEvent('laserTherapy:update', {
      action: 'create',
      entityType: 'device',
      entityId: device.id,
      data: device,
    });

    res.status(201).json({ success: true, data: device });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Programs ====================

router.get('/programs', async (req, res) => {
  try {
    res.json({ success: true, data: programs });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/programs', async (req, res) => {
  try {
    const program = {
      id: programs.length > 0 ? Math.max(...programs.map(p => p.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    programs.push(program);

    emitEvent('laserTherapy:update', {
      action: 'create',
      entityType: 'program',
      entityId: program.id,
      data: program,
    });

    res.status(201).json({ success: true, data: program });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Progress ====================

router.get('/progress', async (req, res) => {
  try {
    res.json({ success: true, data: progress });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/progress', async (req, res) => {
  try {
    const prog = {
      id: progress.length > 0 ? Math.max(...progress.map(p => p.id)) + 1 : 1,
      ...req.body,
      date: new Date().toISOString(),
    };
    progress.push(prog);

    emitEvent('laserTherapy:update', {
      action: 'create',
      entityType: 'progress',
      entityId: prog.id,
      data: prog,
    });

    res.status(201).json({ success: true, data: prog });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
