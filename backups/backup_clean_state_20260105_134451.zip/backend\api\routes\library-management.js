/**
 * 📖 Library Management Routes
 * API routes for books, borrowers, loans, and categories
 */

const express = require('express');
const router = express.Router();

// Mock data storage
const books = [];
const borrowers = [];
const loans = [];
const categories = [
  { id: 1, name: 'تأهيل', code: 'rehabilitation' },
  { id: 2, name: 'طب', code: 'medical' },
  { id: 3, name: 'تعليم', code: 'education' },
];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Books ====================

router.get('/books', async (req, res) => {
  try {
    res.json({ success: true, data: books });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/books/:id', async (req, res) => {
  try {
    const book = books.find(b => b.id === parseInt(req.params.id));
    if (!book) {
      return res.status(404).json({ success: false, error: 'Book not found' });
    }
    res.json({ success: true, data: book });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/books', async (req, res) => {
  try {
    const book = {
      id: books.length > 0 ? Math.max(...books.map(b => b.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    books.push(book);

    emitEvent('library:update', {
      action: 'create',
      entityType: 'book',
      entityId: book.id,
      data: book,
    });

    res.status(201).json({ success: true, data: book });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/books/:id', async (req, res) => {
  try {
    const index = books.findIndex(b => b.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Book not found' });
    }

    books[index] = {
      ...books[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    emitEvent('library:update', {
      action: 'update',
      entityType: 'book',
      entityId: books[index].id,
      data: books[index],
    });

    res.json({ success: true, data: books[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.delete('/books/:id', async (req, res) => {
  try {
    const index = books.findIndex(b => b.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Book not found' });
    }

    const deletedBook = books[index];
    books.splice(index, 1);

    emitEvent('library:update', {
      action: 'delete',
      entityType: 'book',
      entityId: deletedBook.id,
    });

    res.json({ success: true, message: 'Book deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Borrowers ====================

router.get('/borrowers', async (req, res) => {
  try {
    res.json({ success: true, data: borrowers });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/borrowers', async (req, res) => {
  try {
    const borrower = {
      id: borrowers.length > 0 ? Math.max(...borrowers.map(b => b.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    borrowers.push(borrower);

    emitEvent('library:update', {
      action: 'create',
      entityType: 'borrower',
      entityId: borrower.id,
      data: borrower,
    });

    res.status(201).json({ success: true, data: borrower });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Loans ====================

router.get('/loans', async (req, res) => {
  try {
    res.json({ success: true, data: loans });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/loans', async (req, res) => {
  try {
    const loan = {
      id: loans.length > 0 ? Math.max(...loans.map(l => l.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    loans.push(loan);

    emitEvent('library:update', {
      action: 'create',
      entityType: 'loan',
      entityId: loan.id,
      data: loan,
    });

    res.status(201).json({ success: true, data: loan });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Categories ====================

router.get('/categories', async (req, res) => {
  try {
    res.json({ success: true, data: categories });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/categories', async (req, res) => {
  try {
    const category = {
      id: categories.length > 0 ? Math.max(...categories.map(c => c.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    categories.push(category);

    emitEvent('library:update', {
      action: 'create',
      entityType: 'category',
      entityId: category.id,
      data: category,
    });

    res.status(201).json({ success: true, data: category });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
