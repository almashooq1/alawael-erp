/**
 * 🏠 Life Skills Management Routes
 * مسارات إدارة المهارات الحياتية
 */

const express = require('express');
const router = express.Router();
const LifeSkillProgram = require('../models/LifeSkillProgram');
const authenticateToken = require('../middleware/authenticateToken');
const logger = require('../../shared/logging/logger');

// Real-time event emitter (if available)
let io = null;
try {
  const realtimeModule = require('../realtime');
  io = realtimeModule.io;
} catch (error) {
  // Real-time not available
}

/**
 * Emit real-time event
 */
function emitEvent(eventType, entityType, data) {
  if (io) {
    io.emit('lifeSkills:update', {
      action: eventType,
      entityType: entityType,
      entityId: data.id,
      data: data,
    });
  }
}

// Apply authentication to all routes
router.use(authenticateToken);

/**
 * Life Skills Programs Routes
 */
router.get('/programs', async (req, res) => {
  try {
    const programs = await LifeSkillProgram.findAll({
      order: [['createdAt', 'DESC']],
    });
    res.json(programs);
  } catch (error) {
    logger.error('Error fetching life skills programs:', error);
    res.status(500).json({ error: 'خطأ في جلب برامج المهارات الحياتية' });
  }
});

router.post('/programs', async (req, res) => {
  try {
    const program = await LifeSkillProgram.create(req.body);
    emitEvent('create', 'program', program);
    logger.info('Life skills program created', { id: program.id, name: program.name });
    res.status(201).json(program);
  } catch (error) {
    logger.error('Error creating life skills program:', error);
    res.status(400).json({ error: 'خطأ في إضافة برنامج المهارات الحياتية' });
  }
});

module.exports = router;
