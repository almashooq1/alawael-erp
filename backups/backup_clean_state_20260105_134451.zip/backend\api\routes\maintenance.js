/**
 * 🔧 Maintenance Management Routes
 * مسارات إدارة الصيانة
 */

const express = require('express');
const router = express.Router();
const MaintenanceRequest = require('../models/MaintenanceRequest');
const authenticateToken = require('../middleware/authenticateToken');
const logger = require('../../shared/logging/logger');

// Real-time event emitter (if available)
let io = null;
try {
  const realtimeModule = require('../realtime');
  io = realtimeModule.io;
} catch (error) {
  // Real-time not available
}

/**
 * Emit real-time event
 */
function emitEvent(eventType, entityType, data) {
  if (io) {
    io.emit('maintenance:update', {
      action: eventType,
      entityType: entityType,
      entityId: data.id,
      data: data,
    });
  }
}

// Apply authentication to all routes
router.use(authenticateToken);

/**
 * Maintenance Requests Routes
 */
router.get('/requests', async (req, res) => {
  try {
    const requests = await MaintenanceRequest.findAll({
      order: [['createdAt', 'DESC']],
      limit: 100,
    });
    res.json(requests);
  } catch (error) {
    logger.error('Error fetching maintenance requests:', error);
    res.status(500).json({ error: 'خطأ في جلب طلبات الصيانة' });
  }
});

router.post('/requests', async (req, res) => {
  try {
    const request = await MaintenanceRequest.create(req.body);
    emitEvent('create', 'request', request);
    logger.info('Maintenance request created', { id: request.id, type: request.type });
    res.status(201).json(request);
  } catch (error) {
    logger.error('Error creating maintenance request:', error);
    res.status(400).json({ error: 'خطأ في إضافة طلب الصيانة' });
  }
});

module.exports = router;
