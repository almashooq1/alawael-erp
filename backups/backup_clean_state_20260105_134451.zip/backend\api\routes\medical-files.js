/**
 * 📁 Medical Files Management Routes
 * مسارات إدارة الملفات الطبية
 */

const express = require('express');
const router = express.Router();
const authenticateToken = require('../middleware/authenticateToken');
const logger = require('../../shared/logging/logger');

// Real-time event emitter (if available)
let io = null;
try {
  const realtimeModule = require('../realtime');
  io = realtimeModule.io;
} catch (error) {
  // Real-time not available
}

/**
 * Emit real-time event
 */
function emitEvent(eventType, entityType, data) {
  if (io) {
    io.emit('medicalFiles:update', {
      action: eventType,
      entityType: entityType,
      entityId: data.id,
      data: data,
    });
  }
}

// Apply authentication to all routes
router.use(authenticateToken);

// In-memory storage (in production, use database)
const filesStore = [];
const categoriesStore = [
  { id: 1, name: 'تقارير طبية', icon: '📄' },
  { id: 2, name: 'صور طبية', icon: '🖼️' },
  { id: 3, name: 'فيديوهات', icon: '🎥' },
  { id: 4, name: 'تحاليل', icon: '🧪' },
  { id: 5, name: 'أشعة', icon: '📷' },
  { id: 6, name: 'ملفات PDF', icon: '📕' },
  { id: 7, name: 'وثائق', icon: '📋' },
];
const archivedFilesStore = [];

/**
 * Medical Files Routes
 */
router.get('/', async (req, res) => {
  try {
    res.json(filesStore);
  } catch (error) {
    logger.error('Error fetching medical files:', error);
    res.status(500).json({ error: 'خطأ في جلب الملفات' });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const file = filesStore.find(f => f.id === parseInt(req.params.id));
    if (!file) {
      return res.status(404).json({ error: 'الملف غير موجود' });
    }
    res.json(file);
  } catch (error) {
    logger.error('Error fetching medical file:', error);
    res.status(500).json({ error: 'خطأ في جلب الملف' });
  }
});

router.post('/', async (req, res) => {
  try {
    const file = {
      id: Date.now(),
      ...req.body,
      uploadDate: new Date(),
      createdAt: new Date(),
    };
    filesStore.push(file);
    emitEvent('create', 'file', file);
    logger.info('Medical file created', { id: file.id });
    res.status(201).json(file);
  } catch (error) {
    logger.error('Error creating medical file:', error);
    res.status(400).json({ error: 'خطأ في رفع الملف' });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const index = filesStore.findIndex(f => f.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ error: 'الملف غير موجود' });
    }
    filesStore[index] = { ...filesStore[index], ...req.body };
    emitEvent('update', 'file', filesStore[index]);
    logger.info('Medical file updated', { id: req.params.id });
    res.json(filesStore[index]);
  } catch (error) {
    logger.error('Error updating medical file:', error);
    res.status(400).json({ error: 'خطأ في تحديث الملف' });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    const index = filesStore.findIndex(f => f.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ error: 'الملف غير موجود' });
    }
    filesStore.splice(index, 1);
    emitEvent('delete', 'file', { id: req.params.id });
    logger.info('Medical file deleted', { id: req.params.id });
    res.json({ message: 'تم حذف الملف بنجاح' });
  } catch (error) {
    logger.error('Error deleting medical file:', error);
    res.status(400).json({ error: 'خطأ في حذف الملف' });
  }
});

/**
 * File Upload Route
 */
router.post('/upload', async (req, res) => {
  try {
    // In production, handle actual file upload using multer or similar
    const file = {
      id: Date.now(),
      ...req.body,
      uploadDate: new Date(),
      createdAt: new Date(),
    };
    filesStore.push(file);
    emitEvent('create', 'file', file);
    logger.info('Medical file uploaded', { id: file.id });
    res.status(201).json(file);
  } catch (error) {
    logger.error('Error uploading medical file:', error);
    res.status(400).json({ error: 'خطأ في رفع الملف' });
  }
});

/**
 * Categories Routes
 */
router.get('/categories', async (req, res) => {
  try {
    res.json(categoriesStore);
  } catch (error) {
    logger.error('Error fetching categories:', error);
    res.status(500).json({ error: 'خطأ في جلب التصنيفات' });
  }
});

router.get('/categories/:id', async (req, res) => {
  try {
    const category = categoriesStore.find(c => c.id === parseInt(req.params.id));
    if (!category) {
      return res.status(404).json({ error: 'التصنيف غير موجود' });
    }
    res.json(category);
  } catch (error) {
    logger.error('Error fetching category:', error);
    res.status(500).json({ error: 'خطأ في جلب التصنيف' });
  }
});

router.post('/categories', async (req, res) => {
  try {
    const category = {
      id: Date.now(),
      ...req.body,
    };
    categoriesStore.push(category);
    emitEvent('create', 'category', category);
    logger.info('Category created', { id: category.id });
    res.status(201).json(category);
  } catch (error) {
    logger.error('Error creating category:', error);
    res.status(400).json({ error: 'خطأ في إضافة التصنيف' });
  }
});

router.put('/categories/:id', async (req, res) => {
  try {
    const index = categoriesStore.findIndex(c => c.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ error: 'التصنيف غير موجود' });
    }
    categoriesStore[index] = { ...categoriesStore[index], ...req.body };
    emitEvent('update', 'category', categoriesStore[index]);
    logger.info('Category updated', { id: req.params.id });
    res.json(categoriesStore[index]);
  } catch (error) {
    logger.error('Error updating category:', error);
    res.status(400).json({ error: 'خطأ في تحديث التصنيف' });
  }
});

router.delete('/categories/:id', async (req, res) => {
  try {
    const index = categoriesStore.findIndex(c => c.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ error: 'التصنيف غير موجود' });
    }
    categoriesStore.splice(index, 1);
    emitEvent('delete', 'category', { id: req.params.id });
    logger.info('Category deleted', { id: req.params.id });
    res.json({ message: 'تم حذف التصنيف بنجاح' });
  } catch (error) {
    logger.error('Error deleting category:', error);
    res.status(400).json({ error: 'خطأ في حذف التصنيف' });
  }
});

/**
 * Archive Routes
 */
router.get('/archive', async (req, res) => {
  try {
    res.json(archivedFilesStore);
  } catch (error) {
    logger.error('Error fetching archived files:', error);
    res.status(500).json({ error: 'خطأ في جلب الأرشيف' });
  }
});

router.post('/:id/archive', async (req, res) => {
  try {
    const index = filesStore.findIndex(f => f.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ error: 'الملف غير موجود' });
    }
    const file = { ...filesStore[index], archivedDate: new Date() };
    archivedFilesStore.push(file);
    filesStore.splice(index, 1);
    emitEvent('update', 'file', file);
    logger.info('File archived', { id: req.params.id });
    res.json(file);
  } catch (error) {
    logger.error('Error archiving file:', error);
    res.status(400).json({ error: 'خطأ في أرشفة الملف' });
  }
});

router.post('/:id/restore', async (req, res) => {
  try {
    const index = archivedFilesStore.findIndex(f => f.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ error: 'الملف غير موجود في الأرشيف' });
    }
    const file = { ...archivedFilesStore[index] };
    delete file.archivedDate;
    filesStore.push(file);
    archivedFilesStore.splice(index, 1);
    emitEvent('update', 'file', file);
    logger.info('File restored', { id: req.params.id });
    res.json(file);
  } catch (error) {
    logger.error('Error restoring file:', error);
    res.status(400).json({ error: 'خطأ في استعادة الملف' });
  }
});

module.exports = router;
