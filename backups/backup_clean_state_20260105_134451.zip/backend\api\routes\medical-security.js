/**
 * 🔒 Medical Security Management Routes
 * مسارات إدارة الأمان والخصوصية الطبية
 */

const express = require('express');
const router = express.Router();
const SecuritySettings = require('../models/SecuritySettings');
const AuditLog = require('../models/AuditLog');
const authenticateToken = require('../middleware/authenticateToken');
const logger = require('../../shared/logging/logger');

// Real-time event emitter (if available)
let io = null;
try {
  const realtimeModule = require('../realtime');
  io = realtimeModule.io;
} catch (error) {
  // Real-time not available
}

/**
 * Emit real-time event
 */
function emitEvent(eventType, entityType, data) {
  if (io) {
    io.emit('medicalSecurity:update', {
      action: eventType,
      entityType: entityType,
      entityId: data.id,
      data: data,
    });
  }
}

// Apply authentication to all routes
router.use(authenticateToken);

/**
 * Security Settings Routes
 */
router.get('/settings', async (req, res) => {
  try {
    const settings = await SecuritySettings.findOne({
      where: { id: 1 },
    });
    if (!settings) {
      // Return default settings
      const defaultSettings = {
        encryption: true,
        accessControl: true,
        auditLog: true,
        dataRetention: 365,
        compliance: {
          hipaa: false,
          gdpr: false,
          local: true,
        },
        twoFactorAuth: false,
        sessionTimeout: 30,
      };
      return res.json(defaultSettings);
    }
    res.json(settings);
  } catch (error) {
    logger.error('Error fetching security settings:', error);
    res.status(500).json({ error: 'خطأ في جلب إعدادات الأمان' });
  }
});

router.put('/settings', async (req, res) => {
  try {
    const [settings, created] = await SecuritySettings.upsert(
      {
        id: 1,
        ...req.body,
      },
      {
        returning: true,
      }
    );
    emitEvent('update', 'settings', settings);
    logger.info('Security settings updated', { id: settings.id });
    res.json(settings);
  } catch (error) {
    logger.error('Error updating security settings:', error);
    res.status(400).json({ error: 'خطأ في تحديث إعدادات الأمان' });
  }
});

/**
 * Audit Logs Routes
 */
router.get('/audit-logs', async (req, res) => {
  try {
    const logs = await AuditLog.findAll({
      order: [['timestamp', 'DESC']],
      limit: 1000,
    });
    res.json(logs);
  } catch (error) {
    logger.error('Error fetching audit logs:', error);
    res.status(500).json({ error: 'خطأ في جلب سجلات التدقيق' });
  }
});

router.post('/audit-logs', async (req, res) => {
  try {
    const log = await AuditLog.create({
      ...req.body,
      timestamp: new Date(),
    });
    emitEvent('create', 'audit', log);
    logger.info('Audit log created', { id: log.id, action: log.action });
    res.status(201).json(log);
  } catch (error) {
    logger.error('Error creating audit log:', error);
    res.status(400).json({ error: 'خطأ في إضافة سجل التدقيق' });
  }
});

router.get('/audit-logs/:id', async (req, res) => {
  try {
    const log = await AuditLog.findByPk(req.params.id);
    if (!log) {
      return res.status(404).json({ error: 'سجل التدقيق غير موجود' });
    }
    res.json(log);
  } catch (error) {
    logger.error('Error fetching audit log:', error);
    res.status(500).json({ error: 'خطأ في جلب سجل التدقيق' });
  }
});

module.exports = router;
