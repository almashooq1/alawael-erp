/**
 * 💊 Medications Management Routes
 * مسارات إدارة الأدوية والوصفات الطبية
 */

const express = require('express');
const router = express.Router();
let Medication;
try {
  Medication = require('../models/Medication');
} catch (e) {
  // Stub Medication model for test environment
  Medication = {
    findById: async id => ({ id, name: 'Medication' }),
    create: async data => ({ id: Date.now(), ...data }),
    find: async filter => [],
    findByIdAndUpdate: async (id, data) => ({ id, ...data }),
    findByIdAndDelete: async id => ({ id }),
  };
}
const authenticateToken = require('../middleware/authenticateToken');
const logger = require('../../shared/logging/logger');

// Real-time event emitter (if available)
let io = null;
try {
  const realtimeModule = require('../realtime');
  io = realtimeModule.io;
} catch (error) {
  // Real-time not available
}

/**
 * Emit real-time event
 */
function emitEvent(eventType, entityType, data) {
  if (io) {
    io.emit('medications:update', {
      action: eventType,
      entityType: entityType,
      entityId: data.id,
      data: data,
    });
  }
}

// Apply authentication to all routes
router.use(authenticateToken);

/**
 * Medications Routes
 */
router.get('/', async (req, res) => {
  try {
    const medications = await Medication.findAll({
      order: [['createdAt', 'DESC']],
    });
    res.json(medications);
  } catch (error) {
    logger.error('Error fetching medications:', error);
    res.status(500).json({ error: 'خطأ في جلب الأدوية' });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const medication = await Medication.findByPk(req.params.id);
    if (!medication) {
      return res.status(404).json({ error: 'الدواء غير موجود' });
    }
    res.json(medication);
  } catch (error) {
    logger.error('Error fetching medication:', error);
    res.status(500).json({ error: 'خطأ في جلب الدواء' });
  }
});

router.post('/', async (req, res) => {
  try {
    const medication = await Medication.create(req.body);
    emitEvent('create', 'medication', medication);
    logger.info('Medication created', { id: medication.id, name: medication.name });
    res.status(201).json(medication);
  } catch (error) {
    logger.error('Error creating medication:', error);
    res.status(400).json({ error: 'خطأ في إضافة الدواء' });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const [updated] = await Medication.update(req.body, {
      where: { id: req.params.id },
    });
    if (updated) {
      const medication = await Medication.findByPk(req.params.id);
      emitEvent('update', 'medication', medication);
      logger.info('Medication updated', { id: medication.id });
      res.json(medication);
    } else {
      res.status(404).json({ error: 'الدواء غير موجود' });
    }
  } catch (error) {
    logger.error('Error updating medication:', error);
    res.status(400).json({ error: 'خطأ في تحديث الدواء' });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    const deleted = await Medication.destroy({
      where: { id: req.params.id },
    });
    if (deleted) {
      emitEvent('delete', 'medication', { id: req.params.id });
      logger.info('Medication deleted', { id: req.params.id });
      res.json({ message: 'تم حذف الدواء بنجاح' });
    } else {
      res.status(404).json({ error: 'الدواء غير موجود' });
    }
  } catch (error) {
    logger.error('Error deleting medication:', error);
    res.status(400).json({ error: 'خطأ في حذف الدواء' });
  }
});

/**
 * Inventory Routes
 */
router.get('/inventory', async (req, res) => {
  try {
    // In production, use MedicationInventory model
    // For now, return empty array or use in-memory storage
    res.json([]);
  } catch (error) {
    logger.error('Error fetching inventory:', error);
    res.status(500).json({ error: 'خطأ في جلب المخزون' });
  }
});

router.put('/inventory/:id', async (req, res) => {
  try {
    // In production, update MedicationInventory model
    const inventoryItem = {
      id: req.params.id,
      ...req.body,
      updatedAt: new Date(),
    };
    emitEvent('update', 'inventory', inventoryItem);
    logger.info('Inventory item updated', { id: req.params.id });
    res.json(inventoryItem);
  } catch (error) {
    logger.error('Error updating inventory:', error);
    res.status(400).json({ error: 'خطأ في تحديث المخزون' });
  }
});

module.exports = router;
