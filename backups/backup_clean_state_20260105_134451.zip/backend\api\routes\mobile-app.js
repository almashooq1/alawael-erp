/**
 * 📱 Mobile App Management Routes
 * مسارات إدارة التطبيق المحمول
 */

const express = require('express');
const router = express.Router();
const MobileAppSettings = require('../models/MobileAppSettings');
const authenticateToken = require('../middleware/authenticateToken');
const logger = require('../../shared/logging/logger');

// Real-time event emitter (if available)
let io = null;
try {
  const realtimeModule = require('../realtime');
  io = realtimeModule.io;
} catch (error) {
  // Real-time not available
}

/**
 * Emit real-time event
 */
function emitEvent(eventType, entityType, data) {
  if (io) {
    io.emit('mobileApp:update', {
      action: eventType,
      entityType: entityType,
      data: data,
    });
  }
}

// Apply authentication to all routes
router.use(authenticateToken);

/**
 * Mobile App Settings Routes
 */
router.get('/settings', async (req, res) => {
  try {
    const settings = await MobileAppSettings.findOne();
    if (!settings) {
      // Return default settings
      return res.json({
        enabled: true,
        version: '1.0.0',
        features: {
          patients: true,
          sessions: true,
          progress: true,
          notifications: true,
          appointments: true,
        },
      });
    }
    res.json(settings);
  } catch (error) {
    logger.error('Error fetching mobile app settings:', error);
    res.status(500).json({ error: 'خطأ في جلب إعدادات التطبيق' });
  }
});

router.put('/settings', async (req, res) => {
  try {
    const [settings, created] = await MobileAppSettings.upsert(req.body, {
      returning: true,
    });
    emitEvent('update', 'settings', settings);
    logger.info('Mobile app settings updated', { enabled: settings.enabled });
    res.json(settings);
  } catch (error) {
    logger.error('Error updating mobile app settings:', error);
    res.status(400).json({ error: 'خطأ في تحديث إعدادات التطبيق' });
  }
});

module.exports = router;
