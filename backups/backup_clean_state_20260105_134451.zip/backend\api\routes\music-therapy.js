/**
 * 🎵 Music Therapy Routes
 * API routes for music therapy sessions, instruments, playlists, and progress
 */

const express = require('express');
const router = express.Router();

// Mock data storage
const sessions = [];
const instruments = [];
const playlists = [];
const progress = [];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Sessions ====================

router.get('/sessions', async (req, res) => {
  try {
    res.json({ success: true, data: sessions });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/sessions', async (req, res) => {
  try {
    const session = {
      id: sessions.length > 0 ? Math.max(...sessions.map(s => s.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    sessions.push(session);

    emitEvent('musicTherapy:update', {
      action: 'create',
      entityType: 'session',
      entityId: session.id,
      data: session,
    });

    res.status(201).json({ success: true, data: session });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/sessions/:id', async (req, res) => {
  try {
    const index = sessions.findIndex(s => s.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Session not found' });
    }

    sessions[index] = {
      ...sessions[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    emitEvent('musicTherapy:update', {
      action: 'update',
      entityType: 'session',
      entityId: sessions[index].id,
      data: sessions[index],
    });

    res.json({ success: true, data: sessions[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.delete('/sessions/:id', async (req, res) => {
  try {
    const index = sessions.findIndex(s => s.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Session not found' });
    }

    const deletedSession = sessions[index];
    sessions.splice(index, 1);

    emitEvent('musicTherapy:update', {
      action: 'delete',
      entityType: 'session',
      entityId: deletedSession.id,
    });

    res.json({ success: true, message: 'Session deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Instruments ====================

router.get('/instruments', async (req, res) => {
  try {
    res.json({ success: true, data: instruments });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/instruments', async (req, res) => {
  try {
    const instrument = {
      id: instruments.length > 0 ? Math.max(...instruments.map(i => i.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    instruments.push(instrument);

    emitEvent('musicTherapy:update', {
      action: 'create',
      entityType: 'instrument',
      entityId: instrument.id,
      data: instrument,
    });

    res.status(201).json({ success: true, data: instrument });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Playlists ====================

router.get('/playlists', async (req, res) => {
  try {
    res.json({ success: true, data: playlists });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/playlists', async (req, res) => {
  try {
    const playlist = {
      id: playlists.length > 0 ? Math.max(...playlists.map(p => p.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    playlists.push(playlist);

    emitEvent('musicTherapy:update', {
      action: 'create',
      entityType: 'playlist',
      entityId: playlist.id,
      data: playlist,
    });

    res.status(201).json({ success: true, data: playlist });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Progress ====================

router.get('/progress', async (req, res) => {
  try {
    res.json({ success: true, data: progress });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/progress', async (req, res) => {
  try {
    const prog = {
      id: progress.length > 0 ? Math.max(...progress.map(p => p.id)) + 1 : 1,
      ...req.body,
      date: new Date().toISOString(),
    };
    progress.push(prog);

    emitEvent('musicTherapy:update', {
      action: 'create',
      entityType: 'progress',
      entityId: prog.id,
      data: prog,
    });

    res.status(201).json({ success: true, data: prog });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
