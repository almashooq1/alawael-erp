/**
 * 🔔 Advanced Notifications Routes
 * API routes for notifications, templates, channels, and preferences
 */

const express = require('express');
const router = express.Router();

// Mock data storage
const notifications = [];
const templates = [];
const channels = [];
const preferences = [];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Notifications ====================

router.get('/notifications', async (req, res) => {
  try {
    res.json({ success: true, data: notifications });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/notifications/:id', async (req, res) => {
  try {
    const notification = notifications.find(n => n.id === parseInt(req.params.id));
    if (!notification) {
      return res.status(404).json({ success: false, error: 'Notification not found' });
    }
    res.json({ success: true, data: notification });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/notifications', async (req, res) => {
  try {
    const notification = {
      id: notifications.length > 0 ? Math.max(...notifications.map(n => n.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    notifications.push(notification);

    emitEvent('notification:update', {
      action: 'create',
      entityType: 'notification',
      entityId: notification.id,
      data: notification,
    });

    res.status(201).json({ success: true, data: notification });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/notifications/:id', async (req, res) => {
  try {
    const index = notifications.findIndex(n => n.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Notification not found' });
    }

    notifications[index] = {
      ...notifications[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    emitEvent('notification:update', {
      action: 'update',
      entityType: 'notification',
      entityId: notifications[index].id,
      data: notifications[index],
    });

    res.json({ success: true, data: notifications[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.delete('/notifications/:id', async (req, res) => {
  try {
    const index = notifications.findIndex(n => n.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Notification not found' });
    }

    const deletedNotification = notifications[index];
    notifications.splice(index, 1);

    emitEvent('notification:update', {
      action: 'delete',
      entityType: 'notification',
      entityId: deletedNotification.id,
    });

    res.json({ success: true, message: 'Notification deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Templates ====================

router.get('/templates', async (req, res) => {
  try {
    res.json({ success: true, data: templates });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/templates', async (req, res) => {
  try {
    const template = {
      id: templates.length > 0 ? Math.max(...templates.map(t => t.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    templates.push(template);

    emitEvent('notification:update', {
      action: 'create',
      entityType: 'template',
      entityId: template.id,
      data: template,
    });

    res.status(201).json({ success: true, data: template });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Channels ====================

router.get('/channels', async (req, res) => {
  try {
    res.json({ success: true, data: channels });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/channels', async (req, res) => {
  try {
    const channel = {
      id: channels.length > 0 ? Math.max(...channels.map(c => c.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    channels.push(channel);

    emitEvent('notification:update', {
      action: 'create',
      entityType: 'channel',
      entityId: channel.id,
      data: channel,
    });

    res.status(201).json({ success: true, data: channel });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Preferences ====================

router.get('/preferences', async (req, res) => {
  try {
    res.json({ success: true, data: preferences });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/preferences', async (req, res) => {
  try {
    const preference = {
      id: preferences.length > 0 ? Math.max(...preferences.map(p => p.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    preferences.push(preference);

    emitEvent('notification:update', {
      action: 'create',
      entityType: 'preference',
      entityId: preference.id,
      data: preference,
    });

    res.status(201).json({ success: true, data: preference });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
