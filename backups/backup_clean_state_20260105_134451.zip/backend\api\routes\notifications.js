/**
 * Notifications Routes
 * مسارات الإشعارات
 */

const express = require('express');
const router = express.Router();
const notificationManager = require('../../shared/utils/notification-manager');

// Get notifications
router.get('/', (req, res) => {
  try {
    const filters = {
      unreadOnly: req.query.unreadOnly === 'true',
      type: req.query.type,
      limit: req.query.limit ? parseInt(req.query.limit) : undefined,
    };

    const notifications = notificationManager.getNotifications(filters);
    const unreadCount = notificationManager.getUnreadCount();

    res.json({
      success: true,
      data: {
        notifications,
        unreadCount,
        total: notifications.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Create notification
router.post('/', (req, res) => {
  try {
    const { type, title, message, data } = req.body;
    const notification = notificationManager.createNotification(
      type || 'info',
      title,
      message,
      data || {}
    );

    res.json({
      success: true,
      data: notification,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Mark as read
router.put('/:id/read', (req, res) => {
  try {
    const { id } = req.params;
    const success = notificationManager.markAsRead(id);

    if (success) {
      res.json({
        success: true,
        message: 'Notification marked as read',
      });
    } else {
      res.status(404).json({
        success: false,
        error: 'Notification not found',
      });
    }
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Mark all as read
router.put('/read-all', (req, res) => {
  try {
    const count = notificationManager.markAllAsRead();
    res.json({
      success: true,
      message: `${count} notifications marked as read`,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Delete notification
router.delete('/:id', (req, res) => {
  try {
    const { id } = req.params;
    const success = notificationManager.deleteNotification(id);

    if (success) {
      res.json({
        success: true,
        message: 'Notification deleted',
      });
    } else {
      res.status(404).json({
        success: false,
        error: 'Notification not found',
      });
    }
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get unread count
router.get('/unread/count', (req, res) => {
  try {
    const count = notificationManager.getUnreadCount();
    res.json({
      success: true,
      data: { count },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Subscribe to notifications (WebSocket endpoint placeholder)
router.post('/subscribe', (req, res) => {
  try {
    const { userId } = req.body;
    // In real implementation, this would set up WebSocket connection
    res.json({
      success: true,
      message: 'Subscribed to notifications',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Configure channels
router.put('/channels', (req, res) => {
  try {
    const config = req.body;
    notificationManager.configureChannels(config);
    res.json({
      success: true,
      message: 'Channels configured successfully',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

module.exports = router;
