/**
 * 🍎 Nutrition Management Routes
 * مسارات إدارة التغذية والوجبات
 */

const express = require('express');
const router = express.Router();

const mockStub = {
  find: async () => [],
  findById: async () => null,
  findOne: async () => null,
  create: async () => ({}),
  updateOne: async () => ({ modifiedCount: 0 }),
  deleteOne: async () => ({ deletedCount: 0 }),
  countDocuments: async () => 0,
  aggregate: () => ({
    sort: () => ({ limit: () => ({ skip: () => ({ toArray: async () => [] }) }) }),
  }),
};

const Meal = (() => {
  try {
    return require('../models/Meal');
  } catch (e) {
    return mockStub;
  }
})();
const Menu = (() => {
  try {
    return require('../models/Menu');
  } catch (e) {
    return mockStub;
  }
})();
const DietPlan = (() => {
  try {
    return require('../models/DietPlan');
  } catch (e) {
    return mockStub;
  }
})();

const authenticateToken = require('../middleware/authenticateToken');
const logger = require('../../shared/logging/logger');

// Real-time event emitter (if available)
let io = null;
try {
  const realtimeModule = require('../realtime');
  io = realtimeModule.io;
} catch (error) {
  // Real-time not available
}

/**
 * Emit real-time event
 */
function emitEvent(eventType, entityType, data) {
  if (io) {
    io.emit('nutrition:update', {
      action: eventType,
      entityType: entityType,
      entityId: data.id,
      data: data,
    });
  }
}

// Apply authentication to all routes
router.use(authenticateToken);

/**
 * Meals Routes
 */
router.get('/meals', async (req, res) => {
  try {
    const meals = await Meal.findAll({
      order: [['createdAt', 'DESC']],
    });
    res.json(meals);
  } catch (error) {
    logger.error('Error fetching meals:', error);
    res.status(500).json({ error: 'خطأ في جلب الوجبات' });
  }
});

router.post('/meals', async (req, res) => {
  try {
    const meal = await Meal.create(req.body);
    emitEvent('create', 'meal', meal);
    logger.info('Meal created', { id: meal.id, name: meal.name });
    res.status(201).json(meal);
  } catch (error) {
    logger.error('Error creating meal:', error);
    res.status(400).json({ error: 'خطأ في إضافة الوجبة' });
  }
});

router.put('/meals/:id', async (req, res) => {
  try {
    const [updated] = await Meal.update(req.body, {
      where: { id: req.params.id },
    });
    if (updated) {
      const meal = await Meal.findByPk(req.params.id);
      emitEvent('update', 'meal', meal);
      logger.info('Meal updated', { id: meal.id });
      res.json(meal);
    } else {
      res.status(404).json({ error: 'الوجبة غير موجودة' });
    }
  } catch (error) {
    logger.error('Error updating meal:', error);
    res.status(400).json({ error: 'خطأ في تحديث الوجبة' });
  }
});

router.delete('/meals/:id', async (req, res) => {
  try {
    const deleted = await Meal.destroy({
      where: { id: req.params.id },
    });
    if (deleted) {
      emitEvent('delete', 'meal', { id: req.params.id });
      logger.info('Meal deleted', { id: req.params.id });
      res.json({ message: 'تم حذف الوجبة بنجاح' });
    } else {
      res.status(404).json({ error: 'الوجبة غير موجودة' });
    }
  } catch (error) {
    logger.error('Error deleting meal:', error);
    res.status(400).json({ error: 'خطأ في حذف الوجبة' });
  }
});

/**
 * Menus Routes
 */
router.get('/menus', async (req, res) => {
  try {
    const menus = await Menu.findAll({
      order: [['name', 'ASC']],
    });
    res.json(menus);
  } catch (error) {
    logger.error('Error fetching menus:', error);
    res.status(500).json({ error: 'خطأ في جلب القوائم' });
  }
});

router.post('/menus', async (req, res) => {
  try {
    const menu = await Menu.create(req.body);
    emitEvent('create', 'menu', menu);
    logger.info('Menu created', { id: menu.id, name: menu.name });
    res.status(201).json(menu);
  } catch (error) {
    logger.error('Error creating menu:', error);
    res.status(400).json({ error: 'خطأ في إضافة القائمة' });
  }
});

/**
 * Diet Plans Routes
 */
router.get('/diet-plans', async (req, res) => {
  try {
    const dietPlans = await DietPlan.findAll({
      order: [['createdAt', 'DESC']],
    });
    res.json(dietPlans);
  } catch (error) {
    logger.error('Error fetching diet plans:', error);
    res.status(500).json({ error: 'خطأ في جلب خطط التغذية' });
  }
});

router.post('/diet-plans', async (req, res) => {
  try {
    const dietPlan = await DietPlan.create(req.body);
    emitEvent('create', 'dietPlan', dietPlan);
    logger.info('Diet plan created', { id: dietPlan.id, patientId: dietPlan.patientId });
    res.status(201).json(dietPlan);
  } catch (error) {
    logger.error('Error creating diet plan:', error);
    res.status(400).json({ error: 'خطأ في إضافة خطة التغذية' });
  }
});

module.exports = router;
