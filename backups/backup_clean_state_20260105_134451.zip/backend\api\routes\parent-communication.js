/**
 * 👨‍👩‍👧 Parent Communication Management Routes
 * مسارات إدارة التواصل مع أولياء الأمور
 */

const express = require('express');
const router = express.Router();
const Communication = require('../models/Communication');
const Meeting = require('../models/Meeting');
const authenticateToken = require('../middleware/authenticateToken');
const logger = require('../../shared/logging/logger');

// Real-time event emitter (if available)
let io = null;
try {
  const realtimeModule = require('../realtime');
  io = realtimeModule.io;
} catch (error) {
  // Real-time not available
}

/**
 * Emit real-time event
 */
function emitEvent(eventType, entityType, data) {
  if (io) {
    io.emit('parentCommunication:update', {
      action: eventType,
      entityType: entityType,
      entityId: data.id,
      data: data,
    });
  }
}

// Apply authentication to all routes
router.use(authenticateToken);

/**
 * Communications Routes
 */
router.get('/', async (req, res) => {
  try {
    const communications = await Communication.findAll({
      order: [['createdAt', 'DESC']],
      limit: 100,
    });
    res.json(communications);
  } catch (error) {
    logger.error('Error fetching communications:', error);
    res.status(500).json({ error: 'خطأ في جلب الاتصالات' });
  }
});

router.post('/', async (req, res) => {
  try {
    const communication = await Communication.create(req.body);
    emitEvent('create', 'communication', communication);
    logger.info('Communication created', {
      id: communication.id,
      patientId: communication.patientId,
    });
    res.status(201).json(communication);
  } catch (error) {
    logger.error('Error creating communication:', error);
    res.status(400).json({ error: 'خطأ في إضافة الاتصال' });
  }
});

/**
 * Meetings Routes
 */
router.get('/meetings', async (req, res) => {
  try {
    const meetings = await Meeting.findAll({
      order: [['date', 'DESC']],
      limit: 100,
    });
    res.json(meetings);
  } catch (error) {
    logger.error('Error fetching meetings:', error);
    res.status(500).json({ error: 'خطأ في جلب اللقاءات' });
  }
});

router.post('/meetings', async (req, res) => {
  try {
    const meeting = await Meeting.create(req.body);
    emitEvent('create', 'meeting', meeting);
    logger.info('Meeting created', { id: meeting.id, patientId: meeting.patientId });
    res.status(201).json(meeting);
  } catch (error) {
    logger.error('Error creating meeting:', error);
    res.status(400).json({ error: 'خطأ في جدولة اللقاء' });
  }
});

module.exports = router;
