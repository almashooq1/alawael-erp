/**
 * 🤝 Partnerships Routes
 * API routes for partnerships management system
 */

const express = require('express');
const router = express.Router();

// Mock data storage (replace with database)
const partnerships = [];
const organizations = [];
const agreements = [];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Partnerships ====================

router.get('/partnerships', async (req, res) => {
  try {
    const { status, type, search } = req.query;
    let filtered = partnerships;

    if (status) {
      filtered = filtered.filter(p => p.status === status);
    }

    if (type) {
      filtered = filtered.filter(p => p.type === type);
    }

    if (search) {
      const query = search.toLowerCase();
      filtered = filtered.filter(
        p =>
          p.organizationName.toLowerCase().includes(query) ||
          (p.description && p.description.toLowerCase().includes(query)) ||
          (p.contactPerson && p.contactPerson.toLowerCase().includes(query))
      );
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.get('/partnerships/:id', async (req, res) => {
  try {
    const partnership = partnerships.find(p => p.id === parseInt(req.params.id));
    if (!partnership) {
      return res.status(404).json({
        success: false,
        error: 'Partnership not found',
      });
    }
    res.json({
      success: true,
      data: partnership,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/partnerships', async (req, res) => {
  try {
    const partnership = {
      id: partnerships.length > 0 ? Math.max(...partnerships.map(p => p.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'pending',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    partnerships.push(partnership);

    emitEvent('partnerships:updated', {
      action: 'create',
      entityId: partnership.id,
      data: partnership,
    });

    res.json({
      success: true,
      data: partnership,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.put('/partnerships/:id', async (req, res) => {
  try {
    const index = partnerships.findIndex(p => p.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Partnership not found',
      });
    }

    partnerships[index] = {
      ...partnerships[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    emitEvent('partnerships:updated', {
      action: 'update',
      entityId: partnerships[index].id,
      data: partnerships[index],
    });

    res.json({
      success: true,
      data: partnerships[index],
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.delete('/partnerships/:id', async (req, res) => {
  try {
    const index = partnerships.findIndex(p => p.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Partnership not found',
      });
    }

    partnerships.splice(index, 1);

    emitEvent('partnerships:updated', {
      action: 'delete',
      entityId: parseInt(req.params.id),
    });

    res.json({
      success: true,
      message: 'Partnership deleted successfully',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Organizations ====================

router.get('/organizations', async (req, res) => {
  try {
    res.json({
      success: true,
      data: organizations,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/organizations', async (req, res) => {
  try {
    const organization = {
      id: organizations.length > 0 ? Math.max(...organizations.map(o => o.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
    };

    organizations.push(organization);

    res.json({
      success: true,
      data: organization,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Agreements ====================

router.get('/agreements', async (req, res) => {
  try {
    res.json({
      success: true,
      data: agreements,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/agreements', async (req, res) => {
  try {
    const agreement = {
      id: agreements.length > 0 ? Math.max(...agreements.map(a => a.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'pending',
      createdAt: new Date().toISOString(),
    };

    agreements.push(agreement);

    emitEvent('partnerships:agreement:updated', {
      action: 'create',
      entityId: agreement.id,
      data: agreement,
    });

    res.json({
      success: true,
      data: agreement,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

module.exports = router;
module.exports.setIO = setIO;
