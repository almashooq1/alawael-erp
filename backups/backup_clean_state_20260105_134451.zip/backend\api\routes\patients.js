/**
 * 🏥 Patients Management Routes
 * مسارات إدارة الحالات والمستفيدين
 */

const express = require('express');
const router = express.Router();
const Patient = require('../models/Patient');
const authenticateToken = require('../middleware/authenticateToken');
const logger = require('../../shared/logging/logger');

// Real-time event emitter (if available)
let io = null;
try {
  const realtimeModule = require('../realtime');
  io = realtimeModule.io;
} catch (error) {
  // Real-time not available
}

/**
 * Emit real-time event
 */
function emitEvent(eventType, entityType, data) {
  if (io) {
    io.emit('patients:update', {
      action: eventType,
      entityType: entityType,
      entityId: data.id,
      data: data,
    });
  }
}

// Apply authentication to all routes
router.use(authenticateToken);

/**
 * Patients Routes
 */
router.get('/', async (req, res) => {
  try {
    const patients = await Patient.findAll({
      order: [['createdAt', 'DESC']],
    });
    res.json(patients);
  } catch (error) {
    logger.error('Error fetching patients:', error);
    res.status(500).json({ error: 'خطأ في جلب الحالات' });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const patient = await Patient.findByPk(req.params.id);
    if (!patient) {
      return res.status(404).json({ error: 'الحالة غير موجودة' });
    }
    res.json(patient);
  } catch (error) {
    logger.error('Error fetching patient:', error);
    res.status(500).json({ error: 'خطأ في جلب الحالة' });
  }
});

router.post('/', async (req, res) => {
  try {
    const patient = await Patient.create(req.body);
    emitEvent('create', 'patient', patient);
    logger.info('Patient created', { id: patient.id, name: patient.name });
    res.status(201).json(patient);
  } catch (error) {
    logger.error('Error creating patient:', error);
    res.status(400).json({ error: 'خطأ في إضافة الحالة' });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const [updated] = await Patient.update(req.body, {
      where: { id: req.params.id },
    });
    if (updated) {
      const patient = await Patient.findByPk(req.params.id);
      emitEvent('update', 'patient', patient);
      logger.info('Patient updated', { id: patient.id });
      res.json(patient);
    } else {
      res.status(404).json({ error: 'الحالة غير موجودة' });
    }
  } catch (error) {
    logger.error('Error updating patient:', error);
    res.status(400).json({ error: 'خطأ في تحديث الحالة' });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    const deleted = await Patient.destroy({
      where: { id: req.params.id },
    });
    if (deleted) {
      emitEvent('delete', 'patient', { id: req.params.id });
      logger.info('Patient deleted', { id: req.params.id });
      res.json({ message: 'تم حذف الحالة بنجاح' });
    } else {
      res.status(404).json({ error: 'الحالة غير موجودة' });
    }
  } catch (error) {
    logger.error('Error deleting patient:', error);
    res.status(400).json({ error: 'خطأ في حذف الحالة' });
  }
});

/**
 * Disability Types Routes
 */
router.get('/disability-types', async (req, res) => {
  try {
    // For now, return default disability types
    // In production, this should come from a database table
    const disabilityTypes = [
      { id: 1, name: 'إعاقة حركية', category: 'جسدية', description: 'إعاقة في الحركة' },
      { id: 2, name: 'إعاقة بصرية', category: 'جسدية', description: 'إعاقة في البصر' },
      { id: 3, name: 'إعاقة سمعية', category: 'جسدية', description: 'إعاقة في السمع' },
      { id: 4, name: 'إعاقة ذهنية', category: 'ذهنية', description: 'إعاقة في القدرات الذهنية' },
      { id: 5, name: 'إعاقة نفسية', category: 'نفسية', description: 'إعاقة نفسية' },
      { id: 6, name: 'إعاقات متعددة', category: 'متعددة', description: 'أكثر من إعاقة' },
      { id: 7, name: 'إعاقة نادرة', category: 'نادرة', description: 'إعاقة نادرة' },
    ];
    res.json(disabilityTypes);
  } catch (error) {
    logger.error('Error fetching disability types:', error);
    res.status(500).json({ error: 'خطأ في جلب أنواع الإعاقات' });
  }
});

/**
 * Patient Assessments Routes
 */
router.get('/assessments', async (req, res) => {
  try {
    // In production, this should use an Assessment model
    // For now, return empty array or fetch from a related table
    res.json([]);
  } catch (error) {
    logger.error('Error fetching assessments:', error);
    res.status(500).json({ error: 'خطأ في جلب التقييمات' });
  }
});

router.post('/assessments', async (req, res) => {
  try {
    // In production, create assessment using Assessment model
    const assessment = req.body;
    assessment.id = Date.now();
    assessment.createdAt = new Date();
    emitEvent('create', 'assessment', assessment);
    logger.info('Assessment created', { id: assessment.id });
    res.status(201).json(assessment);
  } catch (error) {
    logger.error('Error creating assessment:', error);
    res.status(400).json({ error: 'خطأ في إضافة التقييم' });
  }
});

router.put('/assessments/:id', async (req, res) => {
  try {
    const assessment = { ...req.body, id: req.params.id };
    emitEvent('update', 'assessment', assessment);
    logger.info('Assessment updated', { id: req.params.id });
    res.json(assessment);
  } catch (error) {
    logger.error('Error updating assessment:', error);
    res.status(400).json({ error: 'خطأ في تحديث التقييم' });
  }
});

router.delete('/assessments/:id', async (req, res) => {
  try {
    emitEvent('delete', 'assessment', { id: req.params.id });
    logger.info('Assessment deleted', { id: req.params.id });
    res.json({ message: 'تم حذف التقييم بنجاح' });
  } catch (error) {
    logger.error('Error deleting assessment:', error);
    res.status(400).json({ error: 'خطأ في حذف التقييم' });
  }
});

/**
 * Patient Guardians Routes
 */
router.get('/guardians', async (req, res) => {
  try {
    // In production, this should use a Guardian model
    res.json([]);
  } catch (error) {
    logger.error('Error fetching guardians:', error);
    res.status(500).json({ error: 'خطأ في جلب الأوصياء' });
  }
});

router.post('/guardians', async (req, res) => {
  try {
    const guardian = req.body;
    guardian.id = Date.now();
    guardian.createdAt = new Date();
    emitEvent('create', 'guardian', guardian);
    logger.info('Guardian created', { id: guardian.id });
    res.status(201).json(guardian);
  } catch (error) {
    logger.error('Error creating guardian:', error);
    res.status(400).json({ error: 'خطأ في إضافة ولي الأمر' });
  }
});

router.put('/guardians/:id', async (req, res) => {
  try {
    const guardian = { ...req.body, id: req.params.id };
    emitEvent('update', 'guardian', guardian);
    logger.info('Guardian updated', { id: req.params.id });
    res.json(guardian);
  } catch (error) {
    logger.error('Error updating guardian:', error);
    res.status(400).json({ error: 'خطأ في تحديث ولي الأمر' });
  }
});

router.delete('/guardians/:id', async (req, res) => {
  try {
    emitEvent('delete', 'guardian', { id: req.params.id });
    logger.info('Guardian deleted', { id: req.params.id });
    res.json({ message: 'تم حذف ولي الأمر بنجاح' });
  } catch (error) {
    logger.error('Error deleting guardian:', error);
    res.status(400).json({ error: 'خطأ في حذف ولي الأمر' });
  }
});

module.exports = router;
