/**
 * 💳 Payments Management Routes
 * مسارات إدارة المدفوعات والرسوم
 */

const express = require('express');
const router = express.Router();
const Payment = require('../models/Payment');
const authenticateToken = require('../middleware/authenticateToken');
const logger = require('../../shared/logging/logger');

// Real-time event emitter (if available)
let io = null;
try {
  const realtimeModule = require('../realtime');
  io = realtimeModule.io;
} catch (error) {
  // Real-time not available
}

/**
 * Emit real-time event
 */
function emitEvent(eventType, entityType, data) {
  if (io) {
    io.emit('payments:update', {
      action: eventType,
      entityType: entityType,
      entityId: data.id,
      data: data,
    });
  }
}

// Apply authentication to all routes
router.use(authenticateToken);

/**
 * Payments Routes
 */
router.get('/', async (req, res) => {
  try {
    const payments = await Payment.findAll({
      order: [['date', 'DESC']],
    });
    res.json(payments);
  } catch (error) {
    logger.error('Error fetching payments:', error);
    res.status(500).json({ error: 'خطأ في جلب المدفوعات' });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const payment = await Payment.findByPk(req.params.id);
    if (!payment) {
      return res.status(404).json({ error: 'الدفعة غير موجودة' });
    }
    res.json(payment);
  } catch (error) {
    logger.error('Error fetching payment:', error);
    res.status(500).json({ error: 'خطأ في جلب الدفعة' });
  }
});

router.post('/', async (req, res) => {
  try {
    const payment = await Payment.create(req.body);
    emitEvent('create', 'payment', payment);
    logger.info('Payment created', { id: payment.id, amount: payment.amount });
    res.status(201).json(payment);
  } catch (error) {
    logger.error('Error creating payment:', error);
    res.status(400).json({ error: 'خطأ في إضافة الدفعة' });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const [updated] = await Payment.update(req.body, {
      where: { id: req.params.id },
    });
    if (updated) {
      const payment = await Payment.findByPk(req.params.id);
      emitEvent('update', 'payment', payment);
      logger.info('Payment updated', { id: payment.id });
      res.json(payment);
    } else {
      res.status(404).json({ error: 'الدفعة غير موجودة' });
    }
  } catch (error) {
    logger.error('Error updating payment:', error);
    res.status(400).json({ error: 'خطأ في تحديث الدفعة' });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    const deleted = await Payment.destroy({
      where: { id: req.params.id },
    });
    if (deleted) {
      emitEvent('delete', 'payment', { id: req.params.id });
      logger.info('Payment deleted', { id: req.params.id });
      res.json({ message: 'تم حذف الدفعة بنجاح' });
    } else {
      res.status(404).json({ error: 'الدفعة غير موجودة' });
    }
  } catch (error) {
    logger.error('Error deleting payment:', error);
    res.status(400).json({ error: 'خطأ في حذف الدفعة' });
  }
});

/**
 * Payment Methods Routes
 */
router.get('/methods', async (req, res) => {
  try {
    // Default payment methods
    const methods = [
      { id: 1, name: 'نقدي', icon: '💵' },
      { id: 2, name: 'بطاقة', icon: '💳' },
      { id: 3, name: 'تحويل', icon: '🏦' },
      { id: 4, name: 'شيك', icon: '📝' },
    ];
    res.json(methods);
  } catch (error) {
    logger.error('Error fetching payment methods:', error);
    res.status(500).json({ error: 'خطأ في جلب طرق الدفع' });
  }
});

module.exports = router;
