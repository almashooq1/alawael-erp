/**
 * 🔐 Advanced Permissions Routes
 * API routes for roles, permissions, policies, and assignments
 */

const express = require('express');
const router = express.Router();

// Mock data storage
const roles = [];
const permissions = [];
const policies = [];
const assignments = [];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Roles ====================

router.get('/roles', async (req, res) => {
  try {
    res.json({ success: true, data: roles });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/roles/:id', async (req, res) => {
  try {
    const role = roles.find(r => r.id === parseInt(req.params.id));
    if (!role) {
      return res.status(404).json({ success: false, error: 'Role not found' });
    }
    res.json({ success: true, data: role });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/roles', async (req, res) => {
  try {
    const role = {
      id: roles.length > 0 ? Math.max(...roles.map(r => r.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    roles.push(role);

    emitEvent('permissions:update', {
      action: 'create',
      entityType: 'role',
      entityId: role.id,
      data: role,
    });

    res.status(201).json({ success: true, data: role });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/roles/:id', async (req, res) => {
  try {
    const index = roles.findIndex(r => r.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Role not found' });
    }

    roles[index] = {
      ...roles[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    emitEvent('permissions:update', {
      action: 'update',
      entityType: 'role',
      entityId: roles[index].id,
      data: roles[index],
    });

    res.json({ success: true, data: roles[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.delete('/roles/:id', async (req, res) => {
  try {
    const index = roles.findIndex(r => r.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Role not found' });
    }

    const deletedRole = roles[index];
    roles.splice(index, 1);

    emitEvent('permissions:update', {
      action: 'delete',
      entityType: 'role',
      entityId: deletedRole.id,
    });

    res.json({ success: true, message: 'Role deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Permissions ====================

router.get('/permissions', async (req, res) => {
  try {
    res.json({ success: true, data: permissions });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/permissions', async (req, res) => {
  try {
    const permission = {
      id: permissions.length > 0 ? Math.max(...permissions.map(p => p.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    permissions.push(permission);

    emitEvent('permissions:update', {
      action: 'create',
      entityType: 'permission',
      entityId: permission.id,
      data: permission,
    });

    res.status(201).json({ success: true, data: permission });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Policies ====================

router.get('/policies', async (req, res) => {
  try {
    res.json({ success: true, data: policies });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/policies', async (req, res) => {
  try {
    const policy = {
      id: policies.length > 0 ? Math.max(...policies.map(p => p.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    policies.push(policy);

    emitEvent('permissions:update', {
      action: 'create',
      entityType: 'policy',
      entityId: policy.id,
      data: policy,
    });

    res.status(201).json({ success: true, data: policy });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Assignments ====================

router.get('/assignments', async (req, res) => {
  try {
    res.json({ success: true, data: assignments });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/assignments', async (req, res) => {
  try {
    const assignment = {
      id: assignments.length > 0 ? Math.max(...assignments.map(a => a.id)) + 1 : 1,
      ...req.body,
      assignedAt: new Date().toISOString(),
    };
    assignments.push(assignment);

    emitEvent('permissions:update', {
      action: 'create',
      entityType: 'assignment',
      entityId: assignment.id,
      data: assignment,
    });

    res.status(201).json({ success: true, data: assignment });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
