/**
 * Permissions Analytics Routes
 * API routes for permissions analytics and statistics
 */

const express = require('express');
const router = express.Router();
const PermissionsAnalyticsManager = require('../../shared/utils/permissions-analytics-manager');
const { requirePermission } = require('../../shared/middleware/permissions-middleware');

const analyticsManager = new PermissionsAnalyticsManager();

/**
 * الحصول على إحصائيات صلاحية
 */
router.get(
  '/permissions/:permissionId/stats',
  requirePermission('system.permissions'),
  async (req, res) => {
    try {
      const stats = analyticsManager.getPermissionStats(
        req.params.permissionId,
        req.query.startDate || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
        req.query.endDate || new Date().toISOString()
      );
      res.json({ success: true, data: stats });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * الحصول على إحصائيات دور
 */
router.get('/roles/:roleId/stats', requirePermission('system.permissions'), async (req, res) => {
  try {
    const stats = analyticsManager.getRoleStats(
      req.params.roleId,
      req.query.startDate || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
      req.query.endDate || new Date().toISOString()
    );
    res.json({ success: true, data: stats });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على إحصائيات مستخدم
 */
router.get('/users/:userId/stats', requirePermission('system.permissions'), async (req, res) => {
  try {
    const stats = analyticsManager.getUserStats(
      req.params.userId,
      req.query.startDate || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
      req.query.endDate || new Date().toISOString()
    );
    res.json({ success: true, data: stats });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تقرير التحليلات الشامل
 */
router.get('/report', requirePermission('system.permissions'), async (req, res) => {
  try {
    const report = analyticsManager.getAnalyticsReport(
      req.query.startDate || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
      req.query.endDate || new Date().toISOString()
    );
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
