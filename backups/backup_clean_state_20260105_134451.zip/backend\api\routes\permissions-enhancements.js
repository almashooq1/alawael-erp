/**
 * Permissions Enhancements Routes
 * API routes for permissions notifications, backup, and review
 */

const express = require('express');
const router = express.Router();
const PermissionsNotificationsManager = require('../../shared/utils/permissions-notifications-manager');
const PermissionsBackupManager = require('../../shared/utils/permissions-backup-manager');
const PermissionsReviewManager = require('../../shared/utils/permissions-review-manager');
const { requirePermission } = require('../../shared/middleware/permissions-middleware');

const notificationsManager = new PermissionsNotificationsManager();
const backupManager = new PermissionsBackupManager();
const reviewManager = new PermissionsReviewManager();

// ========== Notifications ==========

/**
 * الاشتراك في نوع إشعار
 */
router.post('/notifications/subscribe', async (req, res) => {
  try {
    notificationsManager.subscribe(req.body.userId, req.body.notificationType);
    res.json({ success: true, message: 'Subscribed successfully' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على إشعارات مستخدم
 */
router.get('/notifications/:userId', async (req, res) => {
  try {
    const notifications = notificationsManager.getUserNotifications(req.params.userId, req.query);
    res.json({ success: true, data: notifications });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تحديد إشعار كمقروء
 */
router.post('/notifications/:id/read', async (req, res) => {
  try {
    const notification = notificationsManager.markAsRead(req.params.id);
    res.json({ success: true, data: notification });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * إحصائيات الإشعارات
 */
router.get('/notifications/:userId/stats', async (req, res) => {
  try {
    const stats = notificationsManager.getNotificationsStats(req.params.userId);
    res.json({ success: true, data: stats });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Backup ==========

/**
 * إنشاء نسخة احتياطية
 */
router.post('/backup', requirePermission('system.permissions'), async (req, res) => {
  try {
    const backup = backupManager.createBackup(req.body.data, req.body.metadata);
    res.json({ success: true, data: backup });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على النسخ الاحتياطية
 */
router.get('/backup', requirePermission('system.permissions'), async (req, res) => {
  try {
    const backups = backupManager.getBackups(req.query);
    res.json({ success: true, data: backups });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * استعادة نسخة احتياطية
 */
router.post('/backup/:id/restore', requirePermission('system.permissions'), async (req, res) => {
  try {
    const data = backupManager.restoreBackup(req.params.id);
    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تصدير نسخة احتياطية
 */
router.get('/backup/:id/export', requirePermission('system.permissions'), async (req, res) => {
  try {
    const backupJson = backupManager.exportBackup(req.params.id);
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Content-Disposition', `attachment; filename="backup-${req.params.id}.json"`);
    res.send(backupJson);
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * استيراد نسخة احتياطية
 */
router.post('/backup/import', requirePermission('system.permissions'), async (req, res) => {
  try {
    const backup = backupManager.importBackup(req.body.backupJson, req.body.metadata);
    res.json({ success: true, data: backup });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * إحصائيات النسخ الاحتياطية
 */
router.get('/backup/stats', requirePermission('system.permissions'), async (req, res) => {
  try {
    const stats = backupManager.getBackupStats();
    res.json({ success: true, data: stats });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Review ==========

/**
 * إنشاء مراجعة
 */
router.post('/review', requirePermission('system.permissions'), async (req, res) => {
  try {
    const review = reviewManager.createReview(req.body);
    res.json({ success: true, data: review });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * إضافة نتيجة مراجعة
 */
router.post('/review/:id/findings', requirePermission('system.permissions'), async (req, res) => {
  try {
    const finding = reviewManager.addFinding(req.params.id, req.body);
    res.json({ success: true, data: finding });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * إضافة توصية
 */
router.post(
  '/review/:id/recommendations',
  requirePermission('system.permissions'),
  async (req, res) => {
    try {
      const recommendation = reviewManager.addRecommendation(req.params.id, req.body);
      res.json({ success: true, data: recommendation });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * جدولة مراجعة دورية
 */
router.post('/review/schedule', requirePermission('system.permissions'), async (req, res) => {
  try {
    const schedule = reviewManager.scheduleReview(req.body);
    res.json({ success: true, data: schedule });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على المراجعات المستحقة
 */
router.get('/review/due', requirePermission('system.permissions'), async (req, res) => {
  try {
    const dueReviews = reviewManager.getDueReviews();
    res.json({ success: true, data: dueReviews });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تقرير المراجعات
 */
router.get('/review/report', requirePermission('system.permissions'), async (req, res) => {
  try {
    const report = reviewManager.getReviewReport();
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
