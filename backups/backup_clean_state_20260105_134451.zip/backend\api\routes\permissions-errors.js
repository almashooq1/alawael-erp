/**
 * Permissions Error Handling Routes
 * API routes for error management and reporting
 */

const express = require('express');
const router = express.Router();
const PermissionsErrorHandler = require('../../shared/utils/permissions-error-handler');
const { requirePermission } = require('../../shared/middleware/permissions-middleware');

const errorHandler = new PermissionsErrorHandler();

/**
 * الحصول على الأخطاء
 */
router.get('/errors', requirePermission('system.permissions'), async (req, res) => {
  try {
    const errors = errorHandler.getErrors(req.query);
    res.json({ success: true, data: errors });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تحديد خطأ كمحلول
 */
router.post('/errors/:id/resolve', requirePermission('system.permissions'), async (req, res) => {
  try {
    const error = errorHandler.resolveError(req.params.id);
    if (error) {
      res.json({ success: true, data: error });
    } else {
      res.status(404).json({ success: false, error: 'Error not found' });
    }
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تقرير الأخطاء
 */
router.get('/errors/report', requirePermission('system.permissions'), async (req, res) => {
  try {
    const report = errorHandler.getErrorReport(
      req.query.startDate || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
      req.query.endDate || new Date().toISOString()
    );
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
