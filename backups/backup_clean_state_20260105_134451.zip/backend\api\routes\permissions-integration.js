/**
 * Permissions Integration Routes
 * API routes for integrating permissions with external systems
 */

const express = require('express');
const router = express.Router();
const PermissionsIntegrationManager = require('../../shared/utils/permissions-integration-manager');
const { requirePermission } = require('../../shared/middleware/permissions-middleware');

const integrationManager = new PermissionsIntegrationManager();

/**
 * تسجيل تكامل
 */
router.post('/integrations', requirePermission('system.permissions'), async (req, res) => {
  try {
    const integration = integrationManager.registerIntegration(req.body);
    res.json({ success: true, data: integration });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على التكاملات
 */
router.get('/integrations', requirePermission('system.permissions'), async (req, res) => {
  try {
    const integrations = integrationManager.getIntegrations(req.query);
    res.json({ success: true, data: integrations });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * مزامنة الأدوار من نظام خارجي
 */
router.post('/integrations/:id/sync', requirePermission('system.permissions'), async (req, res) => {
  try {
    const result = await integrationManager.syncRolesFromExternal(req.params.id);
    res.json({ success: true, data: result });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * مزامنة صلاحيات مستخدم
 */
router.post(
  '/integrations/:id/sync-user/:userId',
  requirePermission('system.permissions'),
  async (req, res) => {
    try {
      const result = await integrationManager.syncUserPermissions(req.params.userId, req.params.id);
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * إنشاء مهمة مزامنة
 */
router.post('/sync-jobs', requirePermission('system.permissions'), async (req, res) => {
  try {
    const job = integrationManager.createSyncJob(req.body.integrationId, req.body.schedule);
    res.json({ success: true, data: job });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تقرير التكامل
 */
router.get('/report', requirePermission('system.permissions'), async (req, res) => {
  try {
    const report = integrationManager.getIntegrationReport();
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
