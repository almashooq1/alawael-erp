/**
 * Permissions Management Routes
 * API routes for managing roles and permissions
 */

const express = require('express');
const router = express.Router();
const PermissionsManager = require('../../shared/utils/permissions-manager');
const {
  requirePermission,
  requireRole,
} = require('../../shared/middleware/permissions-middleware');

const permissionsManager = new PermissionsManager();

// ========== Roles Management ==========

/**
 * الحصول على جميع الأدوار
 */
router.get('/roles', async (req, res) => {
  try {
    const roles = permissionsManager.getRoles(req.query);
    res.json({ success: true, data: roles });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على دور محدد
 */
router.get('/roles/:id', async (req, res) => {
  try {
    const role = permissionsManager.roles.get(req.params.id);
    if (!role) {
      return res.status(404).json({ success: false, error: 'Role not found' });
    }

    const rolePermissions = permissionsManager.getRolePermissions(req.params.id);
    res.json({
      success: true,
      data: { ...role, permissions: rolePermissions },
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * إنشاء دور جديد
 */
router.post('/roles', requirePermission('system.roles'), async (req, res) => {
  try {
    const role = permissionsManager.createRole(req.body);
    res.json({ success: true, data: role });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تحديث دور
 */
router.put('/roles/:id', requirePermission('system.roles'), async (req, res) => {
  try {
    const role = permissionsManager.roles.get(req.params.id);
    if (!role) {
      return res.status(404).json({ success: false, error: 'Role not found' });
    }

    if (role.isSystem) {
      return res.status(403).json({
        success: false,
        error: 'Cannot modify system role',
      });
    }

    Object.assign(role, req.body);
    role.updatedAt = new Date().toISOString();

    res.json({ success: true, data: role });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * حذف دور
 */
router.delete('/roles/:id', requirePermission('system.roles'), async (req, res) => {
  try {
    const role = permissionsManager.roles.get(req.params.id);
    if (!role) {
      return res.status(404).json({ success: false, error: 'Role not found' });
    }

    if (role.isSystem) {
      return res.status(403).json({
        success: false,
        error: 'Cannot delete system role',
      });
    }

    permissionsManager.roles.delete(req.params.id);
    permissionsManager.rolePermissions.delete(req.params.id);

    res.json({ success: true, message: 'Role deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Permissions Management ==========

/**
 * الحصول على جميع الصلاحيات
 */
router.get('/permissions', async (req, res) => {
  try {
    const permissions = permissionsManager.getPermissions(req.query);
    res.json({ success: true, data: permissions });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * إنشاء صلاحية جديدة
 */
router.post('/permissions', requirePermission('system.permissions'), async (req, res) => {
  try {
    if (!req.body.id) {
      return res.status(400).json({
        success: false,
        error: 'Permission ID is required',
      });
    }

    const permission = permissionsManager.createPermission(req.body);
    res.json({ success: true, data: permission });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Role-Permission Assignment ==========

/**
 * تعيين صلاحية لدور
 */
router.post(
  '/roles/:roleId/permissions/:permissionId',
  requirePermission('system.roles'),
  async (req, res) => {
    try {
      permissionsManager.assignPermissionToRole(req.params.roleId, req.params.permissionId);
      res.json({ success: true, message: 'Permission assigned to role' });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * إزالة صلاحية من دور
 */
router.delete(
  '/roles/:roleId/permissions/:permissionId',
  requirePermission('system.roles'),
  async (req, res) => {
    try {
      permissionsManager.removePermissionFromRole(req.params.roleId, req.params.permissionId);
      res.json({ success: true, message: 'Permission removed from role' });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * تحديث صلاحيات دور (استبدال كامل)
 */
router.put('/roles/:roleId/permissions', requirePermission('system.roles'), async (req, res) => {
  try {
    const { permissionIds } = req.body;
    const roleId = req.params.roleId;

    // إزالة جميع الصلاحيات الحالية
    permissionsManager.rolePermissions.set(roleId, new Set());

    // إضافة الصلاحيات الجديدة
    if (Array.isArray(permissionIds)) {
      permissionIds.forEach(permId => {
        try {
          permissionsManager.assignPermissionToRole(roleId, permId);
        } catch (error) {
          // تجاهل الأخطاء للصلاحيات غير الموجودة
        }
      });
    }

    res.json({ success: true, message: 'Role permissions updated' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== User-Role Assignment ==========

/**
 * تعيين دور لمستخدم
 */
router.post('/users/:userId/roles/:roleId', requirePermission('system.users'), async (req, res) => {
  try {
    permissionsManager.assignRoleToUser(req.params.userId, req.params.roleId);
    res.json({ success: true, message: 'Role assigned to user' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * إزالة دور من مستخدم
 */
router.delete(
  '/users/:userId/roles/:roleId',
  requirePermission('system.users'),
  async (req, res) => {
    try {
      permissionsManager.removeRoleFromUser(req.params.userId, req.params.roleId);
      res.json({ success: true, message: 'Role removed from user' });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * الحصول على أدوار مستخدم
 */
router.get('/users/:userId/roles', async (req, res) => {
  try {
    const roles = permissionsManager.getUserRoles(req.params.userId);
    res.json({ success: true, data: roles });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على صلاحيات مستخدم
 */
router.get('/users/:userId/permissions', async (req, res) => {
  try {
    const permissions = permissionsManager.getUserPermissions(req.params.userId);
    res.json({ success: true, data: permissions });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * التحقق من صلاحية مستخدم
 */
router.get('/users/:userId/permissions/:permissionId/check', async (req, res) => {
  try {
    const hasPermission = permissionsManager.hasPermission(
      req.params.userId,
      req.params.permissionId
    );
    res.json({ success: true, data: { hasPermission } });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Reports ==========

/**
 * تقرير الصلاحيات
 */
router.get('/report', requirePermission('system.permissions'), async (req, res) => {
  try {
    const report = permissionsManager.getPermissionsReport();
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
