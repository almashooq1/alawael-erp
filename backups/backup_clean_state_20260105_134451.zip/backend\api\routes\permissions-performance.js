/**
 * Permissions Performance Routes
 * API routes for performance monitoring and optimization
 */

const express = require('express');
const router = express.Router();
const {
  getPerformanceMetrics,
  cleanupCache,
  getPerformanceManager,
} = require('../../shared/middleware/permissions-performance-middleware');
const { requirePermission } = require('../../shared/middleware/permissions-middleware');

/**
 * الحصول على مقاييس الأداء
 */
router.get('/metrics', requirePermission('system.permissions'), getPerformanceMetrics);

/**
 * تنظيف الكاش
 */
router.post('/cache/cleanup', requirePermission('system.permissions'), cleanupCache);

/**
 * إبطال كاش مستخدم
 */
router.post(
  '/cache/invalidate/user/:userId',
  requirePermission('system.permissions'),
  async (req, res) => {
    try {
      const perfManager = getPerformanceManager();
      perfManager.invalidateUserCache(req.params.userId);
      res.json({ success: true, message: 'User cache invalidated' });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * إبطال كاش دور
 */
router.post(
  '/cache/invalidate/role/:roleId',
  requirePermission('system.permissions'),
  async (req, res) => {
    try {
      const perfManager = getPerformanceManager();
      perfManager.invalidateRoleCache(req.params.roleId);
      res.json({ success: true, message: 'Role cache invalidated' });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * إحصائيات الكاش
 */
router.get('/cache/stats', requirePermission('system.permissions'), async (req, res) => {
  try {
    const perfManager = getPerformanceManager();
    const cacheStats = perfManager.cache.getStats();
    res.json({ success: true, data: cacheStats });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
