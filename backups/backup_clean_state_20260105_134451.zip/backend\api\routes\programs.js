/**
 * 📋 Programs Management Routes
 * مسارات إدارة البرامج التأهيلية
 */

const express = require('express');
const router = express.Router();
const Program = (() => {
  try {
    return require('../models/Program');
  } catch (e) {
    return {
      findAll: async () => [],
      findByPk: async () => null,
      create: async data => ({ id: 'mock-id', ...data }),
      update: async () => [1],
      destroy: async () => 1,
    };
  }
})();
const ProgramAssignment = (() => {
  try {
    return require('../models/ProgramAssignment');
  } catch (e) {
    return {
      findAll: async () => [],
      findByPk: async () => null,
      create: async data => ({ id: 'mock-id', ...data }),
      update: async () => [1],
      destroy: async () => 1,
    };
  }
})();
const authenticateToken = require('../middleware/authenticateToken');
const logger = require('../../shared/logging/logger');

// Real-time event emitter (if available)
let io = null;
try {
  const realtimeModule = require('../realtime');
  io = realtimeModule.io;
} catch (error) {
  // Real-time not available
}

/**
 * Emit real-time event
 */
function emitEvent(eventType, entityType, data) {
  if (io) {
    io.emit('programs:update', {
      action: eventType,
      entityType: entityType,
      entityId: data.id,
      data: data,
    });
  }
}

// Apply authentication to all routes
router.use(authenticateToken);

/**
 * Programs Routes
 */
router.get('/', async (req, res) => {
  try {
    const programs = await Program.findAll({
      order: [['createdAt', 'DESC']],
    });
    res.json(programs);
  } catch (error) {
    logger.error('Error fetching programs:', error);
    res.status(500).json({ error: 'خطأ في جلب البرامج' });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const program = await Program.findByPk(req.params.id);
    if (!program) {
      return res.status(404).json({ error: 'البرنامج غير موجود' });
    }
    res.json(program);
  } catch (error) {
    logger.error('Error fetching program:', error);
    res.status(500).json({ error: 'خطأ في جلب البرنامج' });
  }
});

router.post('/', async (req, res) => {
  try {
    const program = await Program.create(req.body);
    emitEvent('create', 'program', program);
    logger.info('Program created', { id: program.id, name: program.name });
    res.status(201).json(program);
  } catch (error) {
    logger.error('Error creating program:', error);
    res.status(400).json({ error: 'خطأ في إضافة البرنامج' });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const [updated] = await Program.update(req.body, {
      where: { id: req.params.id },
    });
    if (updated) {
      const program = await Program.findByPk(req.params.id);
      emitEvent('update', 'program', program);
      logger.info('Program updated', { id: program.id });
      res.json(program);
    } else {
      res.status(404).json({ error: 'البرنامج غير موجود' });
    }
  } catch (error) {
    logger.error('Error updating program:', error);
    res.status(400).json({ error: 'خطأ في تحديث البرنامج' });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    const deleted = await Program.destroy({
      where: { id: req.params.id },
    });
    if (deleted) {
      // Also delete related assignments
      await ProgramAssignment.destroy({ where: { programId: req.params.id } });
      emitEvent('delete', 'program', { id: req.params.id });
      logger.info('Program deleted', { id: req.params.id });
      res.json({ message: 'تم حذف البرنامج بنجاح' });
    } else {
      res.status(404).json({ error: 'البرنامج غير موجود' });
    }
  } catch (error) {
    logger.error('Error deleting program:', error);
    res.status(400).json({ error: 'خطأ في حذف البرنامج' });
  }
});

/**
 * Program Assignments Routes
 */
router.get('/assignments', async (req, res) => {
  try {
    const assignments = await ProgramAssignment.findAll({
      order: [['createdAt', 'DESC']],
    });
    res.json(assignments);
  } catch (error) {
    logger.error('Error fetching program assignments:', error);
    res.status(500).json({ error: 'خطأ في جلب تعيينات البرامج' });
  }
});

router.post('/assignments', async (req, res) => {
  try {
    const assignment = await ProgramAssignment.create(req.body);
    emitEvent('create', 'assignment', assignment);
    logger.info('Program assignment created', {
      id: assignment.id,
      programId: assignment.programId,
    });
    res.status(201).json(assignment);
  } catch (error) {
    logger.error('Error creating program assignment:', error);
    res.status(400).json({ error: 'خطأ في إضافة تعيين البرنامج' });
  }
});

router.delete('/assignments/:id', async (req, res) => {
  try {
    const deleted = await ProgramAssignment.destroy({
      where: { id: req.params.id },
    });
    if (deleted) {
      emitEvent('delete', 'assignment', { id: req.params.id });
      logger.info('Program assignment deleted', { id: req.params.id });
      res.json({ message: 'تم حذف تعيين البرنامج بنجاح' });
    } else {
      res.status(404).json({ error: 'تعيين البرنامج غير موجود' });
    }
  } catch (error) {
    logger.error('Error deleting program assignment:', error);
    res.status(400).json({ error: 'خطأ في حذف تعيين البرنامج' });
  }
});

module.exports = router;
