/**
 * 📊 Progress Management Routes
 * مسارات إدارة تتبع التقدم
 */

const express = require('express');
const router = express.Router();
const ProgressRecord = (() => {
  try {
    return require('../models/ProgressRecord');
  } catch (e) {
    return {
      findAll: async () => [],
      findByPk: async () => null,
      create: async data => ({ id: 'mock-id', ...data }),
      update: async () => [1],
      destroy: async () => 1,
    };
  }
})();
const ProgressIndicator = (() => {
  try {
    return require('../models/ProgressIndicator');
  } catch (e) {
    return {
      findAll: async () => [],
      findByPk: async () => null,
      create: async data => ({ id: 'mock-id', ...data }),
      update: async () => [1],
      destroy: async () => 1,
    };
  }
})();
const authenticateToken = require('../middleware/authenticateToken');
const logger = require('../../shared/logging/logger');

// Real-time event emitter (if available)
let io = null;
try {
  const realtimeModule = require('../realtime');
  io = realtimeModule.io;
} catch (error) {
  // Real-time not available
}

/**
 * Emit real-time event
 */
function emitEvent(eventType, entityType, data) {
  if (io) {
    io.emit('progress:update', {
      action: eventType,
      entityType: entityType,
      entityId: data.id,
      data: data,
    });
  }
}

// Apply authentication to all routes
router.use(authenticateToken);

/**
 * Progress Records Routes
 */
router.get('/records', async (req, res) => {
  try {
    const records = await ProgressRecord.findAll({
      order: [['date', 'DESC']],
      limit: 100,
    });
    res.json(records);
  } catch (error) {
    logger.error('Error fetching progress records:', error);
    res.status(500).json({ error: 'خطأ في جلب سجلات التقدم' });
  }
});

router.post('/records', async (req, res) => {
  try {
    const record = await ProgressRecord.create(req.body);
    emitEvent('create', 'record', record);
    logger.info('Progress record created', { id: record.id, patientId: record.patientId });
    res.status(201).json(record);
  } catch (error) {
    logger.error('Error creating progress record:', error);
    res.status(400).json({ error: 'خطأ في تسجيل التقدم' });
  }
});

router.put('/records/:id', async (req, res) => {
  try {
    const [updated] = await ProgressRecord.update(req.body, {
      where: { id: req.params.id },
    });
    if (updated) {
      const record = await ProgressRecord.findByPk(req.params.id);
      emitEvent('update', 'record', record);
      logger.info('Progress record updated', { id: record.id });
      res.json(record);
    } else {
      res.status(404).json({ error: 'سجل التقدم غير موجود' });
    }
  } catch (error) {
    logger.error('Error updating progress record:', error);
    res.status(400).json({ error: 'خطأ في تحديث سجل التقدم' });
  }
});

router.delete('/records/:id', async (req, res) => {
  try {
    const deleted = await ProgressRecord.destroy({
      where: { id: req.params.id },
    });
    if (deleted) {
      emitEvent('delete', 'record', { id: req.params.id });
      logger.info('Progress record deleted', { id: req.params.id });
      res.json({ message: 'تم حذف سجل التقدم بنجاح' });
    } else {
      res.status(404).json({ error: 'سجل التقدم غير موجود' });
    }
  } catch (error) {
    logger.error('Error deleting progress record:', error);
    res.status(400).json({ error: 'خطأ في حذف سجل التقدم' });
  }
});

/**
 * Progress Indicators Routes
 */
router.get('/indicators', async (req, res) => {
  try {
    const indicators = await ProgressIndicator.findAll({
      order: [['name', 'ASC']],
    });
    res.json(indicators);
  } catch (error) {
    logger.error('Error fetching progress indicators:', error);
    res.status(500).json({ error: 'خطأ في جلب مؤشرات التقدم' });
  }
});

router.post('/indicators', async (req, res) => {
  try {
    const indicator = await ProgressIndicator.create(req.body);
    emitEvent('create', 'indicator', indicator);
    logger.info('Progress indicator created', { id: indicator.id, name: indicator.name });
    res.status(201).json(indicator);
  } catch (error) {
    logger.error('Error creating progress indicator:', error);
    res.status(400).json({ error: 'خطأ في إضافة مؤشر التقدم' });
  }
});

router.put('/indicators/:id', async (req, res) => {
  try {
    const [updated] = await ProgressIndicator.update(req.body, {
      where: { id: req.params.id },
    });
    if (updated) {
      const indicator = await ProgressIndicator.findByPk(req.params.id);
      emitEvent('update', 'indicator', indicator);
      logger.info('Progress indicator updated', { id: indicator.id });
      res.json(indicator);
    } else {
      res.status(404).json({ error: 'مؤشر التقدم غير موجود' });
    }
  } catch (error) {
    logger.error('Error updating progress indicator:', error);
    res.status(400).json({ error: 'خطأ في تحديث مؤشر التقدم' });
  }
});

router.delete('/indicators/:id', async (req, res) => {
  try {
    const deleted = await ProgressIndicator.destroy({
      where: { id: req.params.id },
    });
    if (deleted) {
      emitEvent('delete', 'indicator', { id: req.params.id });
      logger.info('Progress indicator deleted', { id: req.params.id });
      res.json({ message: 'تم حذف مؤشر التقدم بنجاح' });
    } else {
      res.status(404).json({ error: 'مؤشر التقدم غير موجود' });
    }
  } catch (error) {
    logger.error('Error deleting progress indicator:', error);
    res.status(400).json({ error: 'خطأ في حذف مؤشر التقدم' });
  }
});

module.exports = router;
