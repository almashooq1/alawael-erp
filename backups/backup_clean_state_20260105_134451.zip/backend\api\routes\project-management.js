/**
 * 📊 Project Management Routes
 * API routes for projects, tasks, milestones, and teams
 */

const express = require('express');
const router = express.Router();

// Mock data storage
const projects = [];
const tasks = [];
const milestones = [];
const teams = [];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Projects ====================

router.get('/projects', async (req, res) => {
  try {
    res.json({ success: true, data: projects });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/projects/:id', async (req, res) => {
  try {
    const project = projects.find(p => p.id === parseInt(req.params.id));
    if (!project) {
      return res.status(404).json({ success: false, error: 'Project not found' });
    }
    res.json({ success: true, data: project });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/projects', async (req, res) => {
  try {
    const project = {
      id: projects.length > 0 ? Math.max(...projects.map(p => p.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    projects.push(project);

    emitEvent('projects:update', {
      action: 'create',
      entityType: 'project',
      entityId: project.id,
      data: project,
    });

    res.status(201).json({ success: true, data: project });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/projects/:id', async (req, res) => {
  try {
    const index = projects.findIndex(p => p.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Project not found' });
    }

    projects[index] = {
      ...projects[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    emitEvent('projects:update', {
      action: 'update',
      entityType: 'project',
      entityId: projects[index].id,
      data: projects[index],
    });

    res.json({ success: true, data: projects[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.delete('/projects/:id', async (req, res) => {
  try {
    const index = projects.findIndex(p => p.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Project not found' });
    }

    const deletedProject = projects[index];
    projects.splice(index, 1);

    emitEvent('projects:update', {
      action: 'delete',
      entityType: 'project',
      entityId: deletedProject.id,
    });

    res.json({ success: true, message: 'Project deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Tasks ====================

router.get('/tasks', async (req, res) => {
  try {
    res.json({ success: true, data: tasks });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/tasks', async (req, res) => {
  try {
    const task = {
      id: tasks.length > 0 ? Math.max(...tasks.map(t => t.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    tasks.push(task);

    emitEvent('projects:update', {
      action: 'create',
      entityType: 'task',
      entityId: task.id,
      data: task,
    });

    res.status(201).json({ success: true, data: task });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Milestones ====================

router.get('/milestones', async (req, res) => {
  try {
    res.json({ success: true, data: milestones });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/milestones', async (req, res) => {
  try {
    const milestone = {
      id: milestones.length > 0 ? Math.max(...milestones.map(m => m.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    milestones.push(milestone);

    emitEvent('projects:update', {
      action: 'create',
      entityType: 'milestone',
      entityId: milestone.id,
      data: milestone,
    });

    res.status(201).json({ success: true, data: milestone });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Teams ====================

router.get('/teams', async (req, res) => {
  try {
    res.json({ success: true, data: teams });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/teams', async (req, res) => {
  try {
    const team = {
      id: teams.length > 0 ? Math.max(...teams.map(t => t.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    teams.push(team);

    emitEvent('projects:update', {
      action: 'create',
      entityType: 'team',
      entityId: team.id,
      data: team,
    });

    res.status(201).json({ success: true, data: team });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
