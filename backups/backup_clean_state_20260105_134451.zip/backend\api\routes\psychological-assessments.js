/**
 * 🧠 Psychological Assessments Routes
 * API routes for psychological assessments, tests, results, and reports
 */

const express = require('express');
const router = express.Router();

// Mock data storage
const assessments = [];
const tests = [];
const results = [];
const reports = [];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Assessments ====================

router.get('/assessments', async (req, res) => {
  try {
    res.json({ success: true, data: assessments });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/assessments/:id', async (req, res) => {
  try {
    const assessment = assessments.find(a => a.id === parseInt(req.params.id));
    if (!assessment) {
      return res.status(404).json({ success: false, error: 'Assessment not found' });
    }
    res.json({ success: true, data: assessment });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/assessments', async (req, res) => {
  try {
    const assessment = {
      id: assessments.length > 0 ? Math.max(...assessments.map(a => a.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    assessments.push(assessment);

    emitEvent('psychologicalAssessments:update', {
      action: 'create',
      entityType: 'assessment',
      entityId: assessment.id,
      data: assessment,
    });

    res.status(201).json({ success: true, data: assessment });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/assessments/:id', async (req, res) => {
  try {
    const index = assessments.findIndex(a => a.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Assessment not found' });
    }

    assessments[index] = {
      ...assessments[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    emitEvent('psychologicalAssessments:update', {
      action: 'update',
      entityType: 'assessment',
      entityId: assessments[index].id,
      data: assessments[index],
    });

    res.json({ success: true, data: assessments[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.delete('/assessments/:id', async (req, res) => {
  try {
    const index = assessments.findIndex(a => a.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Assessment not found' });
    }

    const deletedAssessment = assessments[index];
    assessments.splice(index, 1);

    emitEvent('psychologicalAssessments:update', {
      action: 'delete',
      entityType: 'assessment',
      entityId: deletedAssessment.id,
    });

    res.json({ success: true, message: 'Assessment deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Tests ====================

router.get('/tests', async (req, res) => {
  try {
    res.json({ success: true, data: tests });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/tests', async (req, res) => {
  try {
    const test = {
      id: tests.length > 0 ? Math.max(...tests.map(t => t.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    tests.push(test);

    emitEvent('psychologicalAssessments:update', {
      action: 'create',
      entityType: 'test',
      entityId: test.id,
      data: test,
    });

    res.status(201).json({ success: true, data: test });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Results ====================

router.get('/results', async (req, res) => {
  try {
    res.json({ success: true, data: results });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/results', async (req, res) => {
  try {
    const result = {
      id: results.length > 0 ? Math.max(...results.map(r => r.id)) + 1 : 1,
      ...req.body,
      date: new Date().toISOString(),
    };
    results.push(result);

    emitEvent('psychologicalAssessments:update', {
      action: 'create',
      entityType: 'result',
      entityId: result.id,
      data: result,
    });

    res.status(201).json({ success: true, data: result });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Reports ====================

router.get('/reports', async (req, res) => {
  try {
    res.json({ success: true, data: reports });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/reports', async (req, res) => {
  try {
    const report = {
      id: reports.length > 0 ? Math.max(...reports.map(r => r.id)) + 1 : 1,
      ...req.body,
      date: new Date().toISOString(),
    };
    reports.push(report);

    emitEvent('psychologicalAssessments:update', {
      action: 'create',
      entityType: 'report',
      entityId: report.id,
      data: report,
    });

    res.status(201).json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
