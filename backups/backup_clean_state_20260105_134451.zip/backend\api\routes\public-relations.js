/**
 * 📢 Public Relations Management Routes
 * مسارات إدارة العلاقات العامة
 */

const express = require('express');
const router = express.Router();
const PressRelease = require('../models/PressRelease');
const authenticateToken = require('../middleware/authenticateToken');
const logger = require('../../shared/logging/logger');

// Real-time event emitter (if available)
let io = null;
try {
  const realtimeModule = require('../realtime');
  io = realtimeModule.io;
} catch (error) {
  // Real-time not available
}

/**
 * Emit real-time event
 */
function emitEvent(eventType, entityType, data) {
  if (io) {
    io.emit('publicRelations:update', {
      action: eventType,
      entityType: entityType,
      entityId: data.id,
      data: data,
    });
  }
}

// Apply authentication to all routes
router.use(authenticateToken);

/**
 * Press Releases Routes
 */
router.get('/press-releases', async (req, res) => {
  try {
    const pressReleases = await PressRelease.findAll({
      order: [['createdAt', 'DESC']],
      limit: 100,
    });
    res.json(pressReleases);
  } catch (error) {
    logger.error('Error fetching press releases:', error);
    res.status(500).json({ error: 'خطأ في جلب البيانات الصحفية' });
  }
});

router.post('/press-releases', async (req, res) => {
  try {
    const pressRelease = await PressRelease.create(req.body);
    emitEvent('create', 'pressRelease', pressRelease);
    logger.info('Press release created', { id: pressRelease.id, title: pressRelease.title });
    res.status(201).json(pressRelease);
  } catch (error) {
    logger.error('Error creating press release:', error);
    res.status(400).json({ error: 'خطأ في إضافة البيان الصحفي' });
  }
});

module.exports = router;
