/**
 * ⭐ Quality Management Routes
 * مسارات إدارة الجودة
 */

const express = require('express');
const router = express.Router();
const QualityStandard = require('../models/QualityStandard');
const QualityAudit = require('../models/QualityAudit');
const QualityImprovement = require('../models/QualityImprovement');
const QualityCertification = require('../models/QualityCertification');
const authenticateToken = require('../middleware/authenticateToken');
const logger = require('../../shared/logging/logger');

// Real-time event emitter (if available)
let io = null;
try {
  const realtimeModule = require('../realtime');
  io = realtimeModule.io;
} catch (error) {
  // Real-time not available
}

/**
 * Emit real-time event
 */
function emitEvent(eventType, entityType, data) {
  if (io) {
    io.emit('quality:update', {
      action: eventType,
      entityType: entityType,
      entityId: data.id,
      data: data,
    });
  }
}

// Apply authentication to all routes
router.use(authenticateToken);

/**
 * Quality Standards Routes
 */
router.get('/standards', async (req, res) => {
  try {
    const standards = await QualityStandard.findAll();
    res.json(standards);
  } catch (error) {
    logger.error('Error fetching quality standards:', error);
    res.status(500).json({ error: 'خطأ في جلب المعايير' });
  }
});

router.get('/standards/:id', async (req, res) => {
  try {
    const standard = await QualityStandard.findByPk(req.params.id);
    if (!standard) {
      return res.status(404).json({ error: 'المعيار غير موجود' });
    }
    res.json(standard);
  } catch (error) {
    logger.error('Error fetching quality standard:', error);
    res.status(500).json({ error: 'خطأ في جلب المعيار' });
  }
});

router.post('/standards', async (req, res) => {
  try {
    const standard = await QualityStandard.create(req.body);
    emitEvent('create', 'standards', standard);
    logger.info('Quality standard created', { id: standard.id, name: standard.name });
    res.status(201).json(standard);
  } catch (error) {
    logger.error('Error creating quality standard:', error);
    res.status(400).json({ error: 'خطأ في إضافة المعيار' });
  }
});

router.put('/standards/:id', async (req, res) => {
  try {
    const [updated] = await QualityStandard.update(req.body, {
      where: { id: req.params.id },
    });
    if (updated) {
      const standard = await QualityStandard.findByPk(req.params.id);
      emitEvent('update', 'standards', standard);
      logger.info('Quality standard updated', { id: standard.id });
      res.json(standard);
    } else {
      res.status(404).json({ error: 'المعيار غير موجود' });
    }
  } catch (error) {
    logger.error('Error updating quality standard:', error);
    res.status(400).json({ error: 'خطأ في تحديث المعيار' });
  }
});

router.delete('/standards/:id', async (req, res) => {
  try {
    const deleted = await QualityStandard.destroy({
      where: { id: req.params.id },
    });
    if (deleted) {
      emitEvent('delete', 'standards', { id: req.params.id });
      logger.info('Quality standard deleted', { id: req.params.id });
      res.json({ message: 'تم حذف المعيار بنجاح' });
    } else {
      res.status(404).json({ error: 'المعيار غير موجود' });
    }
  } catch (error) {
    logger.error('Error deleting quality standard:', error);
    res.status(400).json({ error: 'خطأ في حذف المعيار' });
  }
});

/**
 * Quality Audits Routes
 */
router.get('/audits', async (req, res) => {
  try {
    const audits = await QualityAudit.findAll({
      order: [['date', 'DESC']],
    });
    res.json(audits);
  } catch (error) {
    logger.error('Error fetching quality audits:', error);
    res.status(500).json({ error: 'خطأ في جلب التدقيقات' });
  }
});

router.get('/audits/:id', async (req, res) => {
  try {
    const audit = await QualityAudit.findByPk(req.params.id);
    if (!audit) {
      return res.status(404).json({ error: 'التدقيق غير موجود' });
    }
    res.json(audit);
  } catch (error) {
    logger.error('Error fetching quality audit:', error);
    res.status(500).json({ error: 'خطأ في جلب التدقيق' });
  }
});

router.post('/audits', async (req, res) => {
  try {
    const audit = await QualityAudit.create(req.body);
    emitEvent('create', 'audits', audit);
    logger.info('Quality audit created', { id: audit.id });
    res.status(201).json(audit);
  } catch (error) {
    logger.error('Error creating quality audit:', error);
    res.status(400).json({ error: 'خطأ في إضافة التدقيق' });
  }
});

router.put('/audits/:id', async (req, res) => {
  try {
    const [updated] = await QualityAudit.update(req.body, {
      where: { id: req.params.id },
    });
    if (updated) {
      const audit = await QualityAudit.findByPk(req.params.id);
      emitEvent('update', 'audits', audit);
      logger.info('Quality audit updated', { id: audit.id });
      res.json(audit);
    } else {
      res.status(404).json({ error: 'التدقيق غير موجود' });
    }
  } catch (error) {
    logger.error('Error updating quality audit:', error);
    res.status(400).json({ error: 'خطأ في تحديث التدقيق' });
  }
});

router.delete('/audits/:id', async (req, res) => {
  try {
    const deleted = await QualityAudit.destroy({
      where: { id: req.params.id },
    });
    if (deleted) {
      emitEvent('delete', 'audits', { id: req.params.id });
      logger.info('Quality audit deleted', { id: req.params.id });
      res.json({ message: 'تم حذف التدقيق بنجاح' });
    } else {
      res.status(404).json({ error: 'التدقيق غير موجود' });
    }
  } catch (error) {
    logger.error('Error deleting quality audit:', error);
    res.status(400).json({ error: 'خطأ في حذف التدقيق' });
  }
});

/**
 * Quality Improvements Routes
 */
router.get('/improvements', async (req, res) => {
  try {
    const improvements = await QualityImprovement.findAll({
      order: [['date', 'DESC']],
    });
    res.json(improvements);
  } catch (error) {
    logger.error('Error fetching quality improvements:', error);
    res.status(500).json({ error: 'خطأ في جلب خطط التحسين' });
  }
});

router.get('/improvements/:id', async (req, res) => {
  try {
    const improvement = await QualityImprovement.findByPk(req.params.id);
    if (!improvement) {
      return res.status(404).json({ error: 'خطة التحسين غير موجودة' });
    }
    res.json(improvement);
  } catch (error) {
    logger.error('Error fetching quality improvement:', error);
    res.status(500).json({ error: 'خطأ في جلب خطة التحسين' });
  }
});

router.post('/improvements', async (req, res) => {
  try {
    const improvement = await QualityImprovement.create(req.body);
    emitEvent('create', 'improvements', improvement);
    logger.info('Quality improvement created', { id: improvement.id });
    res.status(201).json(improvement);
  } catch (error) {
    logger.error('Error creating quality improvement:', error);
    res.status(400).json({ error: 'خطأ في إضافة خطة التحسين' });
  }
});

router.put('/improvements/:id', async (req, res) => {
  try {
    const [updated] = await QualityImprovement.update(req.body, {
      where: { id: req.params.id },
    });
    if (updated) {
      const improvement = await QualityImprovement.findByPk(req.params.id);
      res.json(improvement);
    } else {
      res.status(404).json({ error: 'خطة التحسين غير موجودة' });
    }
  } catch (error) {
    logger.error('Error updating quality improvement:', error);
    res.status(400).json({ error: 'خطأ في تحديث خطة التحسين' });
  }
});

router.post('/improvements/:id/complete', async (req, res) => {
  try {
    const [updated] = await QualityImprovement.update(
      { status: 'مكتمل' },
      { where: { id: req.params.id } }
    );
    if (updated) {
      const improvement = await QualityImprovement.findByPk(req.params.id);
      emitEvent('update', 'improvements', improvement);
      logger.info('Quality improvement completed', { id: improvement.id });
      res.json(improvement);
    } else {
      res.status(404).json({ error: 'خطة التحسين غير موجودة' });
    }
  } catch (error) {
    logger.error('Error completing quality improvement:', error);
    res.status(400).json({ error: 'خطأ في إكمال خطة التحسين' });
  }
});

router.delete('/improvements/:id', async (req, res) => {
  try {
    const deleted = await QualityImprovement.destroy({
      where: { id: req.params.id },
    });
    if (deleted) {
      emitEvent('delete', 'improvements', { id: req.params.id });
      logger.info('Quality improvement deleted', { id: req.params.id });
      res.json({ message: 'تم حذف خطة التحسين بنجاح' });
    } else {
      res.status(404).json({ error: 'خطة التحسين غير موجودة' });
    }
  } catch (error) {
    logger.error('Error deleting quality improvement:', error);
    res.status(400).json({ error: 'خطأ في حذف خطة التحسين' });
  }
});

/**
 * Quality Certifications Routes
 */
router.get('/certifications', async (req, res) => {
  try {
    const certifications = await QualityCertification.findAll({
      order: [['issueDate', 'DESC']],
    });
    res.json(certifications);
  } catch (error) {
    logger.error('Error fetching quality certifications:', error);
    res.status(500).json({ error: 'خطأ في جلب الشهادات' });
  }
});

router.get('/certifications/:id', async (req, res) => {
  try {
    const certification = await QualityCertification.findByPk(req.params.id);
    if (!certification) {
      return res.status(404).json({ error: 'الشهادة غير موجودة' });
    }
    res.json(certification);
  } catch (error) {
    logger.error('Error fetching quality certification:', error);
    res.status(500).json({ error: 'خطأ في جلب الشهادة' });
  }
});

router.post('/certifications', async (req, res) => {
  try {
    const certification = await QualityCertification.create(req.body);
    emitEvent('create', 'certifications', certification);
    logger.info('Quality certification created', { id: certification.id });
    res.status(201).json(certification);
  } catch (error) {
    logger.error('Error creating quality certification:', error);
    res.status(400).json({ error: 'خطأ في إضافة الشهادة' });
  }
});

router.put('/certifications/:id', async (req, res) => {
  try {
    const [updated] = await QualityCertification.update(req.body, {
      where: { id: req.params.id },
    });
    if (updated) {
      const certification = await QualityCertification.findByPk(req.params.id);
      emitEvent('update', 'certifications', certification);
      logger.info('Quality certification updated', { id: certification.id });
      res.json(certification);
    } else {
      res.status(404).json({ error: 'الشهادة غير موجودة' });
    }
  } catch (error) {
    logger.error('Error updating quality certification:', error);
    res.status(400).json({ error: 'خطأ في تحديث الشهادة' });
  }
});

router.delete('/certifications/:id', async (req, res) => {
  try {
    const deleted = await QualityCertification.destroy({
      where: { id: req.params.id },
    });
    if (deleted) {
      emitEvent('delete', 'certifications', { id: req.params.id });
      logger.info('Quality certification deleted', { id: req.params.id });
      res.json({ message: 'تم حذف الشهادة بنجاح' });
    } else {
      res.status(404).json({ error: 'الشهادة غير موجودة' });
    }
  } catch (error) {
    logger.error('Error deleting quality certification:', error);
    res.status(400).json({ error: 'خطأ في حذف الشهادة' });
  }
});

/**
 * Quality Statistics
 */
router.get('/statistics', async (req, res) => {
  try {
    const [standards, audits, improvements, certifications] = await Promise.all([
      QualityStandard.findAll(),
      QualityAudit.findAll(),
      QualityImprovement.findAll(),
      QualityCertification.findAll(),
    ]);

    const stats = {
      appliedStandards: standards.filter(s => s.status === 'مطبق').length,
      completedAudits: audits.filter(a => a.status === 'مكتمل').length,
      totalImprovements: improvements.length,
      activeCertifications: certifications.filter(c => c.status === 'نشط').length,
      totalStandards: standards.length,
      totalAudits: audits.length,
      totalCertifications: certifications.length,
      pendingImprovements: improvements.filter(i => i.status === 'قيد التنفيذ').length,
    };

    res.json(stats);
  } catch (error) {
    logger.error('Error calculating quality statistics:', error);
    res.status(500).json({ error: 'خطأ في حساب الإحصائيات' });
  }
});

module.exports = router;
