/**
 * 🎮 Recreation Management Routes
 * مسارات إدارة الترفيه
 */

const express = require('express');
const router = express.Router();

const RecreationActivity = (() => {
  try {
    return require('../models/RecreationActivity');
  } catch (e) {
    return {
      find: async () => [],
      findById: async () => null,
      findOne: async () => null,
      create: async () => ({}),
      updateOne: async () => ({ modifiedCount: 0 }),
      deleteOne: async () => ({ deletedCount: 0 }),
      countDocuments: async () => 0,
      aggregate: () => ({
        sort: () => ({ limit: () => ({ skip: () => ({ toArray: async () => [] }) }) }),
      }),
    };
  }
})();

const authenticateToken = require('../middleware/authenticateToken');
const logger = require('../../shared/logging/logger');

// Real-time event emitter (if available)
let io = null;
try {
  const realtimeModule = require('../realtime');
  io = realtimeModule.io;
} catch (error) {
  // Real-time not available
}

/**
 * Emit real-time event
 */
function emitEvent(eventType, entityType, data) {
  if (io) {
    io.emit('recreation:update', {
      action: eventType,
      entityType: entityType,
      entityId: data.id,
      data: data,
    });
  }
}

// Apply authentication to all routes
router.use(authenticateToken);

/**
 * Recreation Activities Routes
 */
router.get('/activities', async (req, res) => {
  try {
    const activities = await RecreationActivity.findAll({
      order: [['createdAt', 'DESC']],
    });
    res.json(activities);
  } catch (error) {
    logger.error('Error fetching recreation activities:', error);
    res.status(500).json({ error: 'خطأ في جلب أنشطة الترفيه' });
  }
});

router.post('/activities', async (req, res) => {
  try {
    const activity = await RecreationActivity.create(req.body);
    emitEvent('create', 'activity', activity);
    logger.info('Recreation activity created', { id: activity.id, name: activity.name });
    res.status(201).json(activity);
  } catch (error) {
    logger.error('Error creating recreation activity:', error);
    res.status(400).json({ error: 'خطأ في إضافة نشاط الترفيه' });
  }
});

module.exports = router;
