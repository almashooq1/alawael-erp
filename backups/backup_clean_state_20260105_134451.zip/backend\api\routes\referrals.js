/**
 * 🔄 Referrals Management Routes
 * مسارات إدارة الإحالات
 */

const express = require('express');
const router = express.Router();

const Referral = (() => {
  try {
    return require('../models/Referral');
  } catch (e) {
    return {
      find: async () => [],
      findById: async () => null,
      findOne: async () => null,
      create: async () => ({}),
      updateOne: async () => ({ modifiedCount: 0 }),
      deleteOne: async () => ({ deletedCount: 0 }),
      countDocuments: async () => 0,
      aggregate: () => ({
        sort: () => ({ limit: () => ({ skip: () => ({ toArray: async () => [] }) }) }),
      }),
    };
  }
})();

const authenticateToken = require('../middleware/authenticateToken');
const logger = require('../../shared/logging/logger');

// Real-time event emitter (if available)
let io = null;
try {
  const realtimeModule = require('../realtime');
  io = realtimeModule.io;
} catch (error) {
  // Real-time not available
}

/**
 * Emit real-time event
 */
function emitEvent(eventType, entityType, data) {
  if (io) {
    io.emit('referrals:update', {
      action: eventType,
      entityType: entityType,
      entityId: data.id,
      data: data,
    });
  }
}

// Apply authentication to all routes
router.use(authenticateToken);

/**
 * Referrals Routes
 */
router.get('/', async (req, res) => {
  try {
    const referrals = await Referral.findAll({
      order: [['createdAt', 'DESC']],
      limit: 100,
    });
    res.json(referrals);
  } catch (error) {
    logger.error('Error fetching referrals:', error);
    res.status(500).json({ error: 'خطأ في جلب الإحالات' });
  }
});

router.post('/', async (req, res) => {
  try {
    const referral = await Referral.create(req.body);
    emitEvent('create', 'referral', referral);
    logger.info('Referral created', { id: referral.id, patientId: referral.patientId });
    res.status(201).json(referral);
  } catch (error) {
    logger.error('Error creating referral:', error);
    res.status(400).json({ error: 'خطأ في إضافة الإحالة' });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const [updated] = await Referral.update(req.body, {
      where: { id: req.params.id },
    });
    if (updated) {
      const referral = await Referral.findByPk(req.params.id);
      emitEvent('update', 'referral', referral);
      logger.info('Referral updated', { id: referral.id });
      res.json(referral);
    } else {
      res.status(404).json({ error: 'الإحالة غير موجودة' });
    }
  } catch (error) {
    logger.error('Error updating referral:', error);
    res.status(400).json({ error: 'خطأ في تحديث الإحالة' });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    const deleted = await Referral.destroy({
      where: { id: req.params.id },
    });
    if (deleted) {
      emitEvent('delete', 'referral', { id: req.params.id });
      logger.info('Referral deleted', { id: req.params.id });
      res.json({ message: 'تم حذف الإحالة بنجاح' });
    } else {
      res.status(404).json({ error: 'الإحالة غير موجودة' });
    }
  } catch (error) {
    logger.error('Error deleting referral:', error);
    res.status(400).json({ error: 'خطأ في حذف الإحالة' });
  }
});

module.exports = router;
