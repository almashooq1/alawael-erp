/**
 * Rehabilitation Appointments Routes
 * مسارات المواعيد لتأهيل ذوي الإعاقة
 */

const express = require('express');
const router = express.Router();
const appointmentScheduler = require('../../shared/utils/appointment-scheduler');
const { authenticateToken, optionalAuth } = require('../middleware/auth-middleware');

// Get all appointments
router.get('/', authenticateToken, (req, res) => {
  try {
    const filters = {
      status: req.query.status,
      patientId: req.query.patientId,
      therapistId: req.query.therapistId,
      startDate: req.query.startDate ? parseInt(req.query.startDate) : undefined,
      endDate: req.query.endDate ? parseInt(req.query.endDate) : undefined,
    };

    const appointments = appointmentScheduler.getAllAppointments(filters);

    res.json({
      success: true,
      data: {
        appointments,
        count: appointments.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get appointment by ID
router.get('/:id', authenticateToken, (req, res) => {
  try {
    const appointment = appointmentScheduler.getAppointment(req.params.id);

    if (!appointment) {
      return res.status(404).json({
        success: false,
        error: 'Appointment not found',
      });
    }

    res.json({
      success: true,
      data: appointment,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Create appointment
router.post('/', authenticateToken, (req, res) => {
  try {
    const appointment = appointmentScheduler.createAppointment(req.body);

    res.status(201).json({
      success: true,
      data: appointment,
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      error: error.message,
    });
  }
});

// Update appointment
router.put('/:id', authenticateToken, (req, res) => {
  try {
    const appointment = appointmentScheduler.updateAppointment(req.params.id, req.body);

    res.json({
      success: true,
      data: appointment,
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      error: error.message,
    });
  }
});

// Cancel appointment
router.post('/:id/cancel', authenticateToken, (req, res) => {
  try {
    const { reason } = req.body;
    const appointment = appointmentScheduler.cancelAppointment(req.params.id, reason);

    res.json({
      success: true,
      data: appointment,
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      error: error.message,
    });
  }
});

// Complete appointment
router.post('/:id/complete', authenticateToken, (req, res) => {
  try {
    const { notes } = req.body;
    const appointment = appointmentScheduler.completeAppointment(req.params.id, notes);

    res.json({
      success: true,
      data: appointment,
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      error: error.message,
    });
  }
});

// Get calendar
router.get('/calendar/view', authenticateToken, (req, res) => {
  try {
    const startDate = req.query.startDate ? parseInt(req.query.startDate) : Date.now();
    const endDate = req.query.endDate
      ? parseInt(req.query.endDate)
      : Date.now() + 30 * 24 * 60 * 60 * 1000;

    const calendar = appointmentScheduler.getCalendar(startDate, endDate);

    res.json({
      success: true,
      data: calendar,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get pending reminders
router.get('/reminders/pending', authenticateToken, (req, res) => {
  try {
    const reminders = appointmentScheduler.getPendingReminders();

    res.json({
      success: true,
      data: {
        reminders,
        count: reminders.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Mark reminder as sent
router.post('/reminders/:appointmentId/sent', authenticateToken, (req, res) => {
  try {
    appointmentScheduler.markReminderSent(req.params.appointmentId);

    res.json({
      success: true,
      message: 'Reminder marked as sent',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get appointment statistics
router.get('/stats/overview', authenticateToken, (req, res) => {
  try {
    const startDate = req.query.startDate
      ? parseInt(req.query.startDate)
      : Date.now() - 30 * 24 * 60 * 60 * 1000;
    const endDate = req.query.endDate ? parseInt(req.query.endDate) : Date.now();

    const stats = appointmentScheduler.getAppointmentStats(startDate, endDate);

    res.json({
      success: true,
      data: stats,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

module.exports = router;
