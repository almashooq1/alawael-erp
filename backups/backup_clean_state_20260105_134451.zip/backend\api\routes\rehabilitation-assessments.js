/**
 * Rehabilitation Assessments Routes
 * مسارات التقييم والتشخيص لتأهيل ذوي الإعاقة
 */

const express = require('express');
const router = express.Router();
const assessmentManager = require('../../shared/utils/assessment-manager');
const { authenticateToken } = require('../middleware/auth-middleware');

// Get all assessments
router.get('/', authenticateToken, (req, res) => {
  try {
    const filters = {
      patientId: req.query.patientId,
      therapistId: req.query.therapistId,
      type: req.query.type,
      status: req.query.status,
    };

    const assessments = assessmentManager.getAllAssessments(filters);

    res.json({
      success: true,
      data: {
        assessments,
        count: assessments.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get assessment by ID
router.get('/:id', authenticateToken, (req, res) => {
  try {
    const assessment = assessmentManager.getAssessment(req.params.id);

    if (!assessment) {
      return res.status(404).json({
        success: false,
        error: 'Assessment not found',
      });
    }

    res.json({
      success: true,
      data: assessment,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Create assessment
router.post('/', authenticateToken, (req, res) => {
  try {
    const assessment = assessmentManager.createAssessment(req.body);

    res.status(201).json({
      success: true,
      data: assessment,
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      error: error.message,
    });
  }
});

// Update assessment
router.put('/:id', authenticateToken, (req, res) => {
  try {
    const assessment = assessmentManager.updateAssessment(req.params.id, req.body);

    res.json({
      success: true,
      data: assessment,
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      error: error.message,
    });
  }
});

// Submit assessment
router.post('/:id/submit', authenticateToken, (req, res) => {
  try {
    const assessment = assessmentManager.submitAssessment(req.params.id);

    res.json({
      success: true,
      data: assessment,
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      error: error.message,
    });
  }
});

// Get templates
router.get('/templates/list', authenticateToken, (req, res) => {
  try {
    const templates = assessmentManager.getAllTemplates();

    res.json({
      success: true,
      data: {
        templates,
        count: templates.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get template by ID
router.get('/templates/:templateId', authenticateToken, (req, res) => {
  try {
    const template = assessmentManager.getTemplate(req.params.templateId);

    if (!template) {
      return res.status(404).json({
        success: false,
        error: 'Template not found',
      });
    }

    res.json({
      success: true,
      data: template,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get patient assessments
router.get('/patient/:patientId', authenticateToken, (req, res) => {
  try {
    const { patientId } = req.params;
    const assessments = assessmentManager.getPatientAssessments(patientId);

    res.json({
      success: true,
      data: {
        assessments,
        count: assessments.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Compare assessments
router.post('/compare', authenticateToken, (req, res) => {
  try {
    const { assessmentId1, assessmentId2 } = req.body;

    if (!assessmentId1 || !assessmentId2) {
      return res.status(400).json({
        success: false,
        error: 'Both assessment IDs are required',
      });
    }

    const comparison = assessmentManager.compareAssessments(assessmentId1, assessmentId2);

    res.json({
      success: true,
      data: comparison,
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      error: error.message,
    });
  }
});

module.exports = router;
