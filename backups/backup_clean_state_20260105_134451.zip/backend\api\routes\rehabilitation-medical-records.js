/**
 * Rehabilitation Medical Records Routes
 * مسارات الملفات الطبية لتأهيل ذوي الإعاقة
 */

const express = require('express');
const router = express.Router();
const medicalRecordsManager = require('../../shared/utils/medical-records-manager');
const { authenticateToken } = require('../middleware/auth-middleware');

// Get all records for patient
router.get('/patient/:patientId', authenticateToken, (req, res) => {
  try {
    const { patientId } = req.params;
    const filters = {
      type: req.query.type,
      startDate: req.query.startDate ? parseInt(req.query.startDate) : undefined,
      endDate: req.query.endDate ? parseInt(req.query.endDate) : undefined,
    };

    const records = medicalRecordsManager.getPatientRecords(patientId, filters);

    res.json({
      success: true,
      data: {
        records,
        count: records.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get record by ID
router.get('/:id', authenticateToken, (req, res) => {
  try {
    const record = medicalRecordsManager.getRecord(req.params.id);

    if (!record) {
      return res.status(404).json({
        success: false,
        error: 'Record not found',
      });
    }

    res.json({
      success: true,
      data: record,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Create medical record
router.post('/', authenticateToken, (req, res) => {
  try {
    const record = medicalRecordsManager.createRecord(req.body);

    res.status(201).json({
      success: true,
      data: record,
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      error: error.message,
    });
  }
});

// Update record
router.put('/:id', authenticateToken, (req, res) => {
  try {
    const record = medicalRecordsManager.updateRecord(req.params.id, req.body);

    res.json({
      success: true,
      data: record,
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      error: error.message,
    });
  }
});

// Add attachment
router.post('/:id/attachments', authenticateToken, (req, res) => {
  try {
    const attachment = medicalRecordsManager.addAttachment(req.params.id, req.body);

    res.status(201).json({
      success: true,
      data: attachment,
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      error: error.message,
    });
  }
});

// Get attachment
router.get('/attachments/:attachmentId', authenticateToken, (req, res) => {
  try {
    const attachment = medicalRecordsManager.getAttachment(req.params.attachmentId);

    if (!attachment) {
      return res.status(404).json({
        success: false,
        error: 'Attachment not found',
      });
    }

    res.json({
      success: true,
      data: attachment,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get record history
router.get('/:id/history', authenticateToken, (req, res) => {
  try {
    const history = medicalRecordsManager.getRecordHistory(req.params.id);

    res.json({
      success: true,
      data: {
        history,
        count: history.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Search records
router.get('/search', authenticateToken, (req, res) => {
  try {
    const { q } = req.query;

    if (!q) {
      return res.status(400).json({
        success: false,
        error: 'Search query is required',
      });
    }

    const results = medicalRecordsManager.searchRecords(q);

    res.json({
      success: true,
      data: {
        results,
        count: results.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get medical history summary
router.get('/patient/:patientId/summary', authenticateToken, (req, res) => {
  try {
    const { patientId } = req.params;
    const summary = medicalRecordsManager.getMedicalHistorySummary(patientId);

    res.json({
      success: true,
      data: summary,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

module.exports = router;
