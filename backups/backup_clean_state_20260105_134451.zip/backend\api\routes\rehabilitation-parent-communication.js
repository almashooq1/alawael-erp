/**
 * Rehabilitation Parent Communication Routes
 * مسارات التواصل مع الأهل
 */

const express = require('express');
const router = express.Router();
const parentCommunicationManager = require('../../shared/utils/parent-communication-manager');
const { authenticateToken } = require('../middleware/auth-middleware');

// Send message
router.post('/send', authenticateToken, (req, res) => {
  try {
    const message = parentCommunicationManager.sendMessage(req.body);

    res.status(201).json({
      success: true,
      data: message,
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      error: error.message,
    });
  }
});

// Get messages
router.get('/', authenticateToken, (req, res) => {
  try {
    const filters = {
      patientId: req.query.patientId,
      guardianId: req.query.guardianId,
      type: req.query.type,
      status: req.query.status,
    };

    const messages = parentCommunicationManager.getMessages(filters);

    res.json({
      success: true,
      data: {
        messages,
        count: messages.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get message by ID
router.get('/:id', authenticateToken, (req, res) => {
  try {
    const messages = parentCommunicationManager.getMessages({});
    const message = messages.find(m => m.id === req.params.id);

    if (!message) {
      return res.status(404).json({
        success: false,
        error: 'Message not found',
      });
    }

    res.json({
      success: true,
      data: message,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Mark message as read
router.post('/:id/read', authenticateToken, (req, res) => {
  try {
    const message = parentCommunicationManager.markAsRead(req.params.id);

    if (!message) {
      return res.status(404).json({
        success: false,
        error: 'Message not found',
      });
    }

    res.json({
      success: true,
      data: message,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Broadcast message
router.post('/broadcast', authenticateToken, (req, res) => {
  try {
    const { messageData, patientIds } = req.body;

    if (!messageData || !patientIds || !Array.isArray(patientIds)) {
      return res.status(400).json({
        success: false,
        error: 'Message data and patient IDs array are required',
      });
    }

    const messages = parentCommunicationManager.broadcastMessage(messageData, patientIds);

    res.status(201).json({
      success: true,
      data: {
        messages,
        count: messages.length,
      },
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      error: error.message,
    });
  }
});

// Get patient messages
router.get('/patient/:patientId', authenticateToken, (req, res) => {
  try {
    const { patientId } = req.params;
    const messages = parentCommunicationManager.getMessages({ patientId });

    res.json({
      success: true,
      data: {
        messages,
        count: messages.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

module.exports = router;
