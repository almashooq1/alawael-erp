/**
 * Rehabilitation Patients Routes
 * مسارات إدارة المرضى لتأهيل ذوي الإعاقة
 */

const express = require('express');
const router = express.Router();
const patientManager = require('../../shared/utils/patient-manager');
const { authenticateToken, optionalAuth } = require('../middleware/auth-middleware');

// Get all patients
router.get('/', authenticateToken, (req, res) => {
  try {
    const filters = {
      status: req.query.status,
      disabilityType: req.query.disabilityType,
      search: req.query.search,
    };

    const patients = patientManager.getAllPatients(filters);

    res.json({
      success: true,
      data: {
        patients,
        count: patients.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get patient by ID
router.get('/:id', authenticateToken, (req, res) => {
  try {
    const patient = patientManager.getPatient(req.params.id);

    if (!patient) {
      return res.status(404).json({
        success: false,
        error: 'Patient not found',
      });
    }

    res.json({
      success: true,
      data: patient,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Create patient
router.post('/', authenticateToken, (req, res) => {
  try {
    const patient = patientManager.createPatient(req.body);

    res.status(201).json({
      success: true,
      data: patient,
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      error: error.message,
    });
  }
});

// Update patient
router.put('/:id', authenticateToken, (req, res) => {
  try {
    const patient = patientManager.updatePatient(req.params.id, req.body);

    res.json({
      success: true,
      data: patient,
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      error: error.message,
    });
  }
});

// Delete patient
router.delete('/:id', authenticateToken, (req, res) => {
  try {
    const patient = patientManager.deletePatient(req.params.id);

    res.json({
      success: true,
      data: patient,
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      error: error.message,
    });
  }
});

// Search patients
router.get('/search', authenticateToken, (req, res) => {
  try {
    const { q } = req.query;

    if (!q) {
      return res.status(400).json({
        success: false,
        error: 'Search query is required',
      });
    }

    const results = patientManager.searchPatients(q);

    res.json({
      success: true,
      data: {
        results,
        count: results.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get patient statistics
router.get('/stats/overview', authenticateToken, (req, res) => {
  try {
    const stats = patientManager.getPatientStats();

    res.json({
      success: true,
      data: stats,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get patient history
router.get('/:id/history', authenticateToken, (req, res) => {
  try {
    const history = patientManager.getPatientHistory(req.params.id);

    res.json({
      success: true,
      data: {
        history,
        count: history.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

module.exports = router;
