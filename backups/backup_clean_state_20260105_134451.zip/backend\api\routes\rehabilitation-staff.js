/**
 * Rehabilitation Staff Routes
 * مسارات الموارد البشرية
 */

const express = require('express');
const router = express.Router();
const staffManager = require('../../shared/utils/staff-manager');
const { authenticateToken } = require('../middleware/auth-middleware');

// Get all staff
router.get('/', authenticateToken, (req, res) => {
  try {
    const filters = {
      role: req.query.role,
      status: req.query.status,
      specialization: req.query.specialization,
    };

    const staff = staffManager.getAllStaff(filters);

    res.json({
      success: true,
      data: {
        staff,
        count: staff.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get staff by ID
router.get('/:id', authenticateToken, (req, res) => {
  try {
    const staff = staffManager.getStaff(req.params.id);

    if (!staff) {
      return res.status(404).json({
        success: false,
        error: 'Staff not found',
      });
    }

    res.json({
      success: true,
      data: staff,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Create staff
router.post('/', authenticateToken, (req, res) => {
  try {
    const staff = staffManager.createStaff(req.body);

    res.status(201).json({
      success: true,
      data: staff,
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      error: error.message,
    });
  }
});

// Update staff
router.put('/:id', authenticateToken, (req, res) => {
  try {
    const staff = staffManager.updateStaff(req.params.id, req.body);

    res.json({
      success: true,
      data: staff,
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      error: error.message,
    });
  }
});

// Get therapists
router.get('/therapists/list', authenticateToken, (req, res) => {
  try {
    const therapists = staffManager.getTherapists();

    res.json({
      success: true,
      data: {
        therapists,
        count: therapists.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get staff schedule
router.get('/:id/schedule', authenticateToken, (req, res) => {
  try {
    const { id } = req.params;
    const startDate = req.query.startDate ? parseInt(req.query.startDate) : Date.now();
    const endDate = req.query.endDate
      ? parseInt(req.query.endDate)
      : Date.now() + 7 * 24 * 60 * 60 * 1000;

    const schedule = staffManager.getStaffSchedule(id, startDate, endDate);

    res.json({
      success: true,
      data: {
        schedule,
        count: schedule.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

module.exports = router;
