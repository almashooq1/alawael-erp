/**
 * Rehabilitation Therapy Sessions Routes
 * مسارات الجلسات العلاجية لتأهيل ذوي الإعاقة
 */

const express = require('express');
const router = express.Router();
const therapySessionsManager = require('../../shared/utils/therapy-sessions-manager');
const { authenticateToken } = require('../middleware/auth-middleware');

// Get all sessions
router.get('/', authenticateToken, (req, res) => {
  try {
    const filters = {
      patientId: req.query.patientId,
      therapistId: req.query.therapistId,
      type: req.query.type,
      status: req.query.status,
      startDate: req.query.startDate ? parseInt(req.query.startDate) : undefined,
      endDate: req.query.endDate ? parseInt(req.query.endDate) : undefined,
    };

    const sessions = therapySessionsManager.getAllSessions(filters);

    res.json({
      success: true,
      data: {
        sessions,
        count: sessions.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get session by ID
router.get('/:id', authenticateToken, (req, res) => {
  try {
    const session = therapySessionsManager.getSession(req.params.id);

    if (!session) {
      return res.status(404).json({
        success: false,
        error: 'Session not found',
      });
    }

    res.json({
      success: true,
      data: session,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Create session
router.post('/', authenticateToken, (req, res) => {
  try {
    const session = therapySessionsManager.createSession(req.body);

    res.status(201).json({
      success: true,
      data: session,
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      error: error.message,
    });
  }
});

// Update session
router.put('/:id', authenticateToken, (req, res) => {
  try {
    const session = therapySessionsManager.updateSession(req.params.id, req.body);

    res.json({
      success: true,
      data: session,
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      error: error.message,
    });
  }
});

// End session
router.post('/:id/end', authenticateToken, (req, res) => {
  try {
    const session = therapySessionsManager.endSession(req.params.id, req.body);

    res.json({
      success: true,
      data: session,
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      error: error.message,
    });
  }
});

// Add progress update
router.post('/:id/progress', authenticateToken, (req, res) => {
  try {
    const progress = therapySessionsManager.addProgressUpdate(req.params.id, req.body);

    res.json({
      success: true,
      data: {
        progress,
        count: progress.length,
      },
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      error: error.message,
    });
  }
});

// Get session progress
router.get('/:id/progress', authenticateToken, (req, res) => {
  try {
    const progress = therapySessionsManager.getSessionProgress(req.params.id);

    res.json({
      success: true,
      data: {
        progress,
        count: progress.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Link game session
router.post('/:id/link-game', authenticateToken, (req, res) => {
  try {
    const { gameSessionId } = req.body;
    const session = therapySessionsManager.linkGameSession(req.params.id, gameSessionId);

    res.json({
      success: true,
      data: session,
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      error: error.message,
    });
  }
});

// Get patient sessions
router.get('/patient/:patientId', authenticateToken, (req, res) => {
  try {
    const { patientId } = req.params;
    const filters = {
      type: req.query.type,
      status: req.query.status,
    };

    const sessions = therapySessionsManager.getPatientSessions(patientId, filters);

    res.json({
      success: true,
      data: {
        sessions,
        count: sessions.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get therapist sessions
router.get('/therapist/:therapistId', authenticateToken, (req, res) => {
  try {
    const { therapistId } = req.params;
    const filters = {
      type: req.query.type,
      status: req.query.status,
    };

    const sessions = therapySessionsManager.getTherapistSessions(therapistId, filters);

    res.json({
      success: true,
      data: {
        sessions,
        count: sessions.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get session statistics
router.get('/stats/overview', authenticateToken, (req, res) => {
  try {
    const { patientId, therapistId } = req.query;
    const stats = therapySessionsManager.getSessionStats(patientId, therapistId);

    res.json({
      success: true,
      data: stats,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

module.exports = router;
