/**
 * Rehabilitation Treatment Plans Routes
 * مسارات الخطط العلاجية
 */

const express = require('express');
const router = express.Router();
const treatmentPlansManager = require('../../shared/utils/treatment-plans-manager');
const { authenticateToken } = require('../middleware/auth-middleware');

// Get all plans
router.get('/', authenticateToken, (req, res) => {
  try {
    const filters = {
      patientId: req.query.patientId,
      therapistId: req.query.therapistId,
      status: req.query.status,
    };

    const plans = treatmentPlansManager.getAllPlans(filters);

    res.json({
      success: true,
      data: {
        plans,
        count: plans.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get plan by ID
router.get('/:id', authenticateToken, (req, res) => {
  try {
    const plan = treatmentPlansManager.getPlan(req.params.id);

    if (!plan) {
      return res.status(404).json({
        success: false,
        error: 'Plan not found',
      });
    }

    res.json({
      success: true,
      data: plan,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Create plan
router.post('/', authenticateToken, (req, res) => {
  try {
    const plan = treatmentPlansManager.createPlan(req.body);

    res.status(201).json({
      success: true,
      data: plan,
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      error: error.message,
    });
  }
});

// Update plan
router.put('/:id', authenticateToken, (req, res) => {
  try {
    const plan = treatmentPlansManager.updatePlan(req.params.id, req.body);

    res.json({
      success: true,
      data: plan,
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      error: error.message,
    });
  }
});

// Update progress
router.post('/:id/progress', authenticateToken, (req, res) => {
  try {
    const progress = treatmentPlansManager.updateProgress(req.params.id, req.body);

    res.json({
      success: true,
      data: {
        progress,
        count: progress.length,
      },
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      error: error.message,
    });
  }
});

// Get plan progress
router.get('/:id/progress', authenticateToken, (req, res) => {
  try {
    const progress = treatmentPlansManager.getPlanProgress(req.params.id);

    res.json({
      success: true,
      data: {
        progress,
        count: progress.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Evaluate plan
router.get('/:id/evaluation', authenticateToken, (req, res) => {
  try {
    const evaluation = treatmentPlansManager.evaluatePlan(req.params.id);

    res.json({
      success: true,
      data: evaluation,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get patient plans
router.get('/patient/:patientId', authenticateToken, (req, res) => {
  try {
    const { patientId } = req.params;
    const plans = treatmentPlansManager.getPatientPlans(patientId);

    res.json({
      success: true,
      data: {
        plans,
        count: plans.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

module.exports = router;
