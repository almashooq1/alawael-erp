/**
 * Reports Routes
 * مسارات التقارير
 */

const express = require('express');
const router = express.Router();
const reportGenerator = require('../../shared/utils/report-generator');
const { authenticateToken, requireAdmin } = require('../middleware/auth-middleware');

// Register template (admin only)
router.post('/templates', requireAdmin, (req, res) => {
  try {
    const { name, template } = req.body;

    if (!name || !template) {
      return res.status(400).json({
        success: false,
        error: 'Template name and template are required',
      });
    }

    const success = reportGenerator.registerTemplate(name, template);

    if (success) {
      res.json({
        success: true,
        message: 'Template registered successfully',
      });
    } else {
      res.status(400).json({
        success: false,
        error: 'Failed to register template',
      });
    }
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Generate report
router.post('/generate', authenticateToken, (req, res) => {
  try {
    const { template, data, options } = req.body;

    if (!template || !data) {
      return res.status(400).json({
        success: false,
        error: 'Template name and data are required',
      });
    }

    const report = reportGenerator.generateReport(template, data, options || {});

    res.json({
      success: true,
      data: report,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Export report
router.get('/export/:reportId', authenticateToken, (req, res) => {
  try {
    const { reportId } = req.params;
    const format = req.query.format || 'json';

    const content = reportGenerator.exportReport(reportId, format);

    res.setHeader('Content-Type', getContentType(format));
    res.setHeader('Content-Disposition', `attachment; filename="report-${reportId}.${format}"`);

    res.send(content);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get report
router.get('/:reportId', authenticateToken, (req, res) => {
  try {
    const { reportId } = req.params;
    const report = reportGenerator.getReport(reportId);

    if (!report) {
      return res.status(404).json({
        success: false,
        error: 'Report not found',
      });
    }

    res.json({
      success: true,
      data: report,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get all reports
router.get('/', authenticateToken, (req, res) => {
  try {
    const limit = req.query.limit ? parseInt(req.query.limit) : 100;
    const reports = reportGenerator.getAllReports(limit);

    res.json({
      success: true,
      data: {
        reports,
        count: reports.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Helper: Get content type
function getContentType(format) {
  const types = {
    json: 'application/json',
    csv: 'text/csv',
    html: 'text/html',
  };
  return types[format] || 'application/json';
}

module.exports = router;
