/**
 * 🔬 Research Management Routes
 * مسارات إدارة البحوث
 */

const express = require('express');
const router = express.Router();
const ResearchProject = require('../models/ResearchProject');
const authenticateToken = require('../middleware/authenticateToken');
const logger = require('../../shared/logging/logger');

// Real-time event emitter (if available)
let io = null;
try {
  const realtimeModule = require('../realtime');
  io = realtimeModule.io;
} catch (error) {
  // Real-time not available
}

/**
 * Emit real-time event
 */
function emitEvent(eventType, entityType, data) {
  if (io) {
    io.emit('research:update', {
      action: eventType,
      entityType: entityType,
      entityId: data.id,
      data: data,
    });
  }
}

// Apply authentication to all routes
router.use(authenticateToken);

/**
 * Research Projects Routes
 */
router.get('/projects', async (req, res) => {
  try {
    const projects = await ResearchProject.findAll({
      order: [['createdAt', 'DESC']],
      limit: 100,
    });
    res.json(projects);
  } catch (error) {
    logger.error('Error fetching research projects:', error);
    res.status(500).json({ error: 'خطأ في جلب المشاريع البحثية' });
  }
});

router.post('/projects', async (req, res) => {
  try {
    const project = await ResearchProject.create(req.body);
    emitEvent('create', 'project', project);
    logger.info('Research project created', { id: project.id, title: project.title });
    res.status(201).json(project);
  } catch (error) {
    logger.error('Error creating research project:', error);
    res.status(400).json({ error: 'خطأ في إضافة المشروع البحثي' });
  }
});

module.exports = router;
