/**
 * ⚠️ Risk Management Routes
 * API routes for risk management system
 */

const express = require('express');
const router = express.Router();

// Mock data storage (replace with database)
const risks = [];
const mitigationStrategies = [];
const riskAssessments = [];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Risks ====================

router.get('/risks', async (req, res) => {
  try {
    const { category, level, status } = req.query;
    let filtered = risks;

    if (category) {
      filtered = filtered.filter(r => r.category === category);
    }

    if (level) {
      filtered = filtered.filter(r => r.level === level);
    }

    if (status) {
      filtered = filtered.filter(r => r.status === status);
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.get('/risks/:id', async (req, res) => {
  try {
    const risk = risks.find(r => r.id === parseInt(req.params.id));
    if (!risk) {
      return res.status(404).json({
        success: false,
        error: 'Risk not found',
      });
    }
    res.json({
      success: true,
      data: risk,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/risks', async (req, res) => {
  try {
    const { probability, impact } = req.body;

    // Calculate risk level
    const probScore =
      probability === 'critical'
        ? 4
        : probability === 'high'
          ? 3
          : probability === 'medium'
            ? 2
            : 1;
    const impactScore =
      impact === 'critical' ? 4 : impact === 'high' ? 3 : impact === 'medium' ? 2 : 1;
    const totalScore = probScore * impactScore;

    let level = 'low';
    if (totalScore >= 12) level = 'critical';
    else if (totalScore >= 8) level = 'high';
    else if (totalScore >= 4) level = 'medium';

    const risk = {
      id: risks.length > 0 ? Math.max(...risks.map(r => r.id)) + 1 : 1,
      ...req.body,
      level,
      status: req.body.status || 'active',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    risks.push(risk);

    emitEvent('risk:updated', {
      action: 'create',
      entityId: risk.id,
      data: risk,
    });

    res.json({
      success: true,
      data: risk,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.put('/risks/:id', async (req, res) => {
  try {
    const index = risks.findIndex(r => r.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Risk not found',
      });
    }

    const { probability, impact } = req.body;

    // Recalculate risk level if probability or impact changed
    if (probability || impact) {
      const prob = probability || risks[index].probability;
      const imp = impact || risks[index].impact;
      const probScore = prob === 'critical' ? 4 : prob === 'high' ? 3 : prob === 'medium' ? 2 : 1;
      const impactScore = imp === 'critical' ? 4 : imp === 'high' ? 3 : imp === 'medium' ? 2 : 1;
      const totalScore = probScore * impactScore;

      let level = 'low';
      if (totalScore >= 12) level = 'critical';
      else if (totalScore >= 8) level = 'high';
      else if (totalScore >= 4) level = 'medium';

      req.body.level = level;
    }

    risks[index] = {
      ...risks[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    emitEvent('risk:updated', {
      action: 'update',
      entityId: risks[index].id,
      data: risks[index],
    });

    res.json({
      success: true,
      data: risks[index],
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.delete('/risks/:id', async (req, res) => {
  try {
    const index = risks.findIndex(r => r.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Risk not found',
      });
    }

    risks.splice(index, 1);

    emitEvent('risk:updated', {
      action: 'delete',
      entityId: parseInt(req.params.id),
    });

    res.json({
      success: true,
      message: 'Risk deleted successfully',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Mitigation Strategies ====================

router.get('/mitigations', async (req, res) => {
  try {
    const { riskId } = req.query;
    let filtered = mitigationStrategies;

    if (riskId) {
      filtered = filtered.filter(m => m.riskId === parseInt(riskId));
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/mitigations', async (req, res) => {
  try {
    const mitigation = {
      id:
        mitigationStrategies.length > 0 ? Math.max(...mitigationStrategies.map(m => m.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    mitigationStrategies.push(mitigation);

    emitEvent('mitigation:updated', {
      action: 'create',
      entityId: mitigation.id,
      data: mitigation,
    });

    res.json({
      success: true,
      data: mitigation,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Risk Assessments ====================

router.get('/assessments', async (req, res) => {
  try {
    res.json({
      success: true,
      data: riskAssessments,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/assessments', async (req, res) => {
  try {
    const assessment = {
      id: riskAssessments.length > 0 ? Math.max(...riskAssessments.map(a => a.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
    };

    riskAssessments.push(assessment);

    res.json({
      success: true,
      data: assessment,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

module.exports = { router, setIO };
