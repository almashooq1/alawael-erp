/**
 * 🛡️ Safety & Security Management Routes
 * مسارات إدارة الأمن والسلامة
 */

const express = require('express');
const router = express.Router();
const SafetyIncident = require('../models/SafetyIncident');
const authenticateToken = require('../middleware/authenticateToken');
const logger = require('../../shared/logging/logger');

// Real-time event emitter (if available)
let io = null;
try {
  const realtimeModule = require('../realtime');
  io = realtimeModule.io;
} catch (error) {
  // Real-time not available
}

/**
 * Emit real-time event
 */
function emitEvent(eventType, entityType, data) {
  if (io) {
    io.emit('safetySecurity:update', {
      action: eventType,
      entityType: entityType,
      entityId: data.id,
      data: data,
    });
  }
}

// Apply authentication to all routes
router.use(authenticateToken);

/**
 * Safety Incidents Routes
 */
router.get('/incidents', async (req, res) => {
  try {
    const incidents = await SafetyIncident.findAll({
      order: [['createdAt', 'DESC']],
      limit: 100,
    });
    res.json(incidents);
  } catch (error) {
    logger.error('Error fetching safety incidents:', error);
    res.status(500).json({ error: 'خطأ في جلب الحوادث' });
  }
});

router.post('/incidents', async (req, res) => {
  try {
    const incident = await SafetyIncident.create(req.body);
    emitEvent('create', 'incident', incident);
    logger.info('Safety incident created', { id: incident.id, type: incident.type });
    res.status(201).json(incident);
  } catch (error) {
    logger.error('Error creating safety incident:', error);
    res.status(400).json({ error: 'خطأ في إضافة الحادث' });
  }
});

module.exports = router;
