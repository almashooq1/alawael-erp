/**
 * Saudi Specialized Systems Routes
 * Routes for systems specific to Saudi rehabilitation centers
 */

const express = require('express');
const router = express.Router();

// Assistive Technology
const AssistiveTechnologyManager = require('../../shared/utils/assistive-technology-manager');
const assistiveTechManager = new AssistiveTechnologyManager();

router.post('/assistive-technology/devices', async (req, res) => {
  try {
    const device = assistiveTechManager.addDevice(req.body);
    res.json({ success: true, data: device });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/assistive-technology/loan', async (req, res) => {
  try {
    const loan = assistiveTechManager.loanDevice(req.body.deviceId, req.body.patientId, req.body);
    res.json({ success: true, data: loan });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/assistive-technology/return', async (req, res) => {
  try {
    const loan = assistiveTechManager.returnDevice(req.body.loanId, req.body);
    res.json({ success: true, data: loan });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/assistive-technology/report', async (req, res) => {
  try {
    const report = assistiveTechManager.getDevicesReport();
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Nejim Integration
const NejimIntegrationManager = require('../../shared/utils/nejm-integration-manager');
const nejimManager = new NejimIntegrationManager();

router.post('/nejim/verify', async (req, res) => {
  try {
    const verification = nejimManager.verifyInsurance(req.body.patientId, req.body);
    res.json({ success: true, data: verification });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/nejim/authorization', async (req, res) => {
  try {
    const authorization = nejimManager.requestAuthorization(req.body.patientId, req.body);
    res.json({ success: true, data: authorization });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/nejim/authorization/:id/approve', async (req, res) => {
  try {
    const authorization = nejimManager.approveAuthorization(req.params.id, req.body);
    res.json({ success: true, data: authorization });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/nejim/claims', async (req, res) => {
  try {
    const claim = nejimManager.submitClaim(req.body.patientId, req.body);
    res.json({ success: true, data: claim });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/nejim/report', async (req, res) => {
  try {
    const report = nejimManager.getInsuranceReport(
      req.query.startDate || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
      req.query.endDate || new Date().toISOString()
    );
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Specialized Educational Programs
const SpecializedEducationalProgramsManager = require('../../shared/utils/specialized-educational-programs-manager');
const educationalProgramsManager = new SpecializedEducationalProgramsManager();

router.post('/educational/programs', async (req, res) => {
  try {
    const program = educationalProgramsManager.createProgram(req.body);
    res.json({ success: true, data: program });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/educational/enroll', async (req, res) => {
  try {
    const enrollment = educationalProgramsManager.enrollStudent(req.body.programId, req.body);
    res.json({ success: true, data: enrollment });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/educational/report', async (req, res) => {
  try {
    const report = educationalProgramsManager.getProgramsReport();
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Advanced Family Communication
const AdvancedFamilyCommunicationManager = require('../../shared/utils/advanced-family-communication-manager');
const familyCommManager = new AdvancedFamilyCommunicationManager();

router.post('/family-communication/families', async (req, res) => {
  try {
    const family = familyCommManager.addFamily(req.body);
    res.json({ success: true, data: family });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/family-communication/communicate', async (req, res) => {
  try {
    const communication = familyCommManager.recordCommunication(req.body.familyId, req.body);
    res.json({ success: true, data: communication });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/family-communication/meetings', async (req, res) => {
  try {
    const meeting = familyCommManager.scheduleMeeting(req.body.familyId, req.body);
    res.json({ success: true, data: meeting });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/family-communication/report', async (req, res) => {
  try {
    const report = familyCommManager.getCommunicationReport(
      req.query.startDate || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
      req.query.endDate || new Date().toISOString()
    );
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Specialized Research & Studies
const SpecializedResearchStudiesManager = require('../../shared/utils/specialized-research-studies-manager');
const researchManager = new SpecializedResearchStudiesManager();

router.post('/research/studies', async (req, res) => {
  try {
    const study = researchManager.createStudy(req.body);
    res.json({ success: true, data: study });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/research/participants', async (req, res) => {
  try {
    const participant = researchManager.addParticipant(req.body.studyId, req.body);
    res.json({ success: true, data: participant });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/research/report', async (req, res) => {
  try {
    const report = researchManager.getResearchReport();
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Government Partnerships
const GovernmentPartnershipsManager = require('../../shared/utils/government-partnerships-manager');
const partnershipsManager = new GovernmentPartnershipsManager();

router.post('/partnerships/government', async (req, res) => {
  try {
    const partnership = partnershipsManager.createPartnership(req.body);
    res.json({ success: true, data: partnership });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/partnerships/collaborations', async (req, res) => {
  try {
    const collaboration = partnershipsManager.recordCollaboration(req.body.partnershipId, req.body);
    res.json({ success: true, data: collaboration });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/partnerships/report', async (req, res) => {
  try {
    const report = partnershipsManager.getPartnershipsReport();
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
