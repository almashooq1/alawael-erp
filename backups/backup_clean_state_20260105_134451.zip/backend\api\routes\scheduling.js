/**
 * 📅 Advanced Scheduling Routes
 * API routes for schedules, appointments, resources, and reminders
 */

const express = require('express');
const router = express.Router();

// Mock data storage
const schedules = [];
const appointments = [];
const resources = [];
const reminders = [];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Schedules ====================

router.get('/schedules', async (req, res) => {
  try {
    res.json({ success: true, data: schedules });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/schedules/:id', async (req, res) => {
  try {
    const schedule = schedules.find(s => s.id === parseInt(req.params.id));
    if (!schedule) {
      return res.status(404).json({ success: false, error: 'Schedule not found' });
    }
    res.json({ success: true, data: schedule });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/schedules', async (req, res) => {
  try {
    const schedule = {
      id: schedules.length > 0 ? Math.max(...schedules.map(s => s.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    schedules.push(schedule);

    emitEvent('scheduling:update', {
      action: 'create',
      entityType: 'schedule',
      entityId: schedule.id,
      data: schedule,
    });

    res.status(201).json({ success: true, data: schedule });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/schedules/:id', async (req, res) => {
  try {
    const index = schedules.findIndex(s => s.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Schedule not found' });
    }

    schedules[index] = {
      ...schedules[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    emitEvent('scheduling:update', {
      action: 'update',
      entityType: 'schedule',
      entityId: schedules[index].id,
      data: schedules[index],
    });

    res.json({ success: true, data: schedules[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.delete('/schedules/:id', async (req, res) => {
  try {
    const index = schedules.findIndex(s => s.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Schedule not found' });
    }

    const deletedSchedule = schedules[index];
    schedules.splice(index, 1);

    emitEvent('scheduling:update', {
      action: 'delete',
      entityType: 'schedule',
      entityId: deletedSchedule.id,
    });

    res.json({ success: true, message: 'Schedule deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Appointments ====================

router.get('/appointments', async (req, res) => {
  try {
    res.json({ success: true, data: appointments });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/appointments', async (req, res) => {
  try {
    const appointment = {
      id: appointments.length > 0 ? Math.max(...appointments.map(a => a.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    appointments.push(appointment);

    emitEvent('scheduling:update', {
      action: 'create',
      entityType: 'appointment',
      entityId: appointment.id,
      data: appointment,
    });

    res.status(201).json({ success: true, data: appointment });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Resources ====================

router.get('/resources', async (req, res) => {
  try {
    res.json({ success: true, data: resources });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/resources', async (req, res) => {
  try {
    const resource = {
      id: resources.length > 0 ? Math.max(...resources.map(r => r.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    resources.push(resource);

    emitEvent('scheduling:update', {
      action: 'create',
      entityType: 'resource',
      entityId: resource.id,
      data: resource,
    });

    res.status(201).json({ success: true, data: resource });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Reminders ====================

router.get('/reminders', async (req, res) => {
  try {
    res.json({ success: true, data: reminders });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/reminders', async (req, res) => {
  try {
    const reminder = {
      id: reminders.length > 0 ? Math.max(...reminders.map(r => r.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    reminders.push(reminder);

    emitEvent('scheduling:update', {
      action: 'create',
      entityType: 'reminder',
      entityId: reminder.id,
      data: reminder,
    });

    res.status(201).json({ success: true, data: reminder });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
