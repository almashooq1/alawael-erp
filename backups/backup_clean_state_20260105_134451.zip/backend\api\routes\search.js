/**
 * Search Routes
 * مسارات البحث
 */

const express = require('express');
const router = express.Router();
const searchEngine = require('../../shared/utils/search-engine');
const { optionalAuth, authenticateToken, requireAdmin } = require('../middleware/auth-middleware');

// Search (optional auth)
router.get('/', optionalAuth, (req, res) => {
  try {
    const { q, limit, type, dateFrom, dateTo, sortBy } = req.query;

    if (!q) {
      return res.status(400).json({
        success: false,
        error: 'Query parameter "q" is required',
      });
    }

    const options = {
      limit: limit ? parseInt(limit) : 10,
      filters: {
        type,
        dateFrom: dateFrom ? new Date(dateFrom) : undefined,
        dateTo: dateTo ? new Date(dateTo) : undefined,
      },
      sortBy: sortBy || 'relevance',
    };

    const results = searchEngine.search(q, options);

    res.json({
      success: true,
      data: {
        query: q,
        results,
        count: results.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Fuzzy search (optional auth)
router.get('/fuzzy', optionalAuth, (req, res) => {
  try {
    const { q, threshold } = req.query;

    if (!q) {
      return res.status(400).json({
        success: false,
        error: 'Query parameter "q" is required',
      });
    }

    const results = searchEngine.fuzzySearch(q, parseFloat(threshold) || 0.7);

    res.json({
      success: true,
      data: {
        query: q,
        results,
        count: results.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Index document (requires auth)
router.post('/index', authenticateToken, (req, res) => {
  try {
    const { id, content, metadata } = req.body;

    if (!id || !content) {
      return res.status(400).json({
        success: false,
        error: 'Both "id" and "content" are required',
      });
    }

    const document = searchEngine.indexDocument(id, content, metadata || {});

    res.json({
      success: true,
      data: document,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get index stats (optional auth)
router.get('/stats', optionalAuth, (req, res) => {
  try {
    const stats = searchEngine.getIndexStats();
    res.json({
      success: true,
      data: stats,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Clear index (requires admin)
router.delete('/index', requireAdmin, (req, res) => {
  try {
    searchEngine.clearIndex();
    res.json({
      success: true,
      message: 'Index cleared successfully',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

module.exports = router;
