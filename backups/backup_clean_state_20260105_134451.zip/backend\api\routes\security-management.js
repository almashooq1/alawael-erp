/**
 * 🔒 Security Management Routes
 * API routes for threats, vulnerabilities, incidents, and policies
 */

const express = require('express');
const router = express.Router();

// Mock data storage
const threats = [];
const vulnerabilities = [];
const incidents = [];
const policies = [];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Threats ====================

router.get('/threats', async (req, res) => {
  try {
    res.json({ success: true, data: threats });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/threats', async (req, res) => {
  try {
    const threat = {
      id: threats.length > 0 ? Math.max(...threats.map(t => t.id)) + 1 : 1,
      ...req.body,
      detectedAt: new Date().toISOString(),
    };
    threats.push(threat);

    emitEvent('security:update', {
      action: 'create',
      entityType: 'threat',
      entityId: threat.id,
      data: threat,
    });

    res.status(201).json({ success: true, data: threat });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Vulnerabilities ====================

router.get('/vulnerabilities', async (req, res) => {
  try {
    res.json({ success: true, data: vulnerabilities });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/vulnerabilities', async (req, res) => {
  try {
    const vulnerability = {
      id: vulnerabilities.length > 0 ? Math.max(...vulnerabilities.map(v => v.id)) + 1 : 1,
      ...req.body,
      discoveredAt: new Date().toISOString(),
    };
    vulnerabilities.push(vulnerability);

    emitEvent('security:update', {
      action: 'create',
      entityType: 'vulnerability',
      entityId: vulnerability.id,
      data: vulnerability,
    });

    res.status(201).json({ success: true, data: vulnerability });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Incidents ====================

router.get('/incidents', async (req, res) => {
  try {
    res.json({ success: true, data: incidents });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/incidents', async (req, res) => {
  try {
    const incident = {
      id: incidents.length > 0 ? Math.max(...incidents.map(i => i.id)) + 1 : 1,
      ...req.body,
      occurredAt: new Date().toISOString(),
    };
    incidents.push(incident);

    emitEvent('security:update', {
      action: 'create',
      entityType: 'incident',
      entityId: incident.id,
      data: incident,
    });

    res.status(201).json({ success: true, data: incident });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Policies ====================

router.get('/policies', async (req, res) => {
  try {
    res.json({ success: true, data: policies });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/policies', async (req, res) => {
  try {
    const policy = {
      id: policies.length > 0 ? Math.max(...policies.map(p => p.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    policies.push(policy);

    emitEvent('security:update', {
      action: 'create',
      entityType: 'policy',
      entityId: policy.id,
      data: policy,
    });

    res.status(201).json({ success: true, data: policy });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
