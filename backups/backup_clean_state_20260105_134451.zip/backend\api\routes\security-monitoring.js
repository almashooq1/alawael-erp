/**
 * Security Monitoring Routes
 * API routes for security monitoring and threat detection
 */

const express = require('express');
const router = express.Router();
const SecurityMonitoringManager = require('../../shared/utils/security-monitoring-manager');
const { requirePermission } = require('../../shared/middleware/permissions-middleware');

const securityManager = new SecurityMonitoringManager();

/**
 * تسجيل حدث أمني
 */
router.post('/events', async (req, res) => {
  try {
    const event = securityManager.logSecurityEvent(req.body);
    res.json({ success: true, data: event });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على الأحداث الأمنية
 */
router.get('/events', requirePermission('system.permissions'), async (req, res) => {
  try {
    const events = securityManager.getSecurityEvents(req.query);
    res.json({ success: true, data: events });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على التهديدات
 */
router.get('/threats', requirePermission('system.permissions'), async (req, res) => {
  try {
    const threats = securityManager.getThreats(req.query);
    res.json({ success: true, data: threats });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تحديث حالة تهديد
 */
router.put('/threats/:id', requirePermission('system.permissions'), async (req, res) => {
  try {
    const threat = securityManager.threats.get(req.params.id);
    if (!threat) {
      return res.status(404).json({ success: false, error: 'Threat not found' });
    }

    threat.status = req.body.status || threat.status;
    threat.updatedAt = new Date().toISOString();

    res.json({ success: true, data: threat });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على التنبيهات
 */
router.get('/alerts', requirePermission('system.permissions'), async (req, res) => {
  try {
    const alerts = Array.from(securityManager.alerts.values());
    res.json({ success: true, data: alerts });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تحديد تنبيه كمقروء
 */
router.post('/alerts/:id/read', requirePermission('system.permissions'), async (req, res) => {
  try {
    const alert = securityManager.alerts.get(req.params.id);
    if (alert) {
      alert.read = true;
      res.json({ success: true, data: alert });
    } else {
      res.status(404).json({ success: false, error: 'Alert not found' });
    }
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تقرير الأمان
 */
router.get('/report', requirePermission('system.permissions'), async (req, res) => {
  try {
    const report = securityManager.getSecurityReport(
      req.query.startDate || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
      req.query.endDate || new Date().toISOString()
    );
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
