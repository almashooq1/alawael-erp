/**
 * 📅 Sessions Management Routes
 * مسارات إدارة الجلسات العلاجية
 */

const express = require('express');
const router = express.Router();
const Session = require('../models/Session');
const authenticateToken = require('../middleware/authenticateToken');
const logger = require('../../shared/logging/logger');

// Real-time event emitter (if available)
let io = null;
try {
  const realtimeModule = require('../realtime');
  io = realtimeModule.io;
} catch (error) {
  // Real-time not available
}

/**
 * Emit real-time event
 */
function emitEvent(eventType, entityType, data) {
  if (io) {
    io.emit('sessions:update', {
      action: eventType,
      entityType: entityType,
      entityId: data.id,
      data: data,
    });
  }
}

// Apply authentication to all routes
router.use(authenticateToken);

/**
 * Sessions Routes
 */
router.get('/', async (req, res) => {
  try {
    const sessions = await Session.findAll({
      order: [
        ['date', 'DESC'],
        ['time', 'ASC'],
      ],
    });
    res.json(sessions);
  } catch (error) {
    logger.error('Error fetching sessions:', error);
    res.status(500).json({ error: 'خطأ في جلب الجلسات' });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const session = await Session.findByPk(req.params.id);
    if (!session) {
      return res.status(404).json({ error: 'الجلسة غير موجودة' });
    }
    res.json(session);
  } catch (error) {
    logger.error('Error fetching session:', error);
    res.status(500).json({ error: 'خطأ في جلب الجلسة' });
  }
});

router.post('/', async (req, res) => {
  try {
    const session = await Session.create(req.body);
    emitEvent('create', 'session', session);
    logger.info('Session created', { id: session.id });
    res.status(201).json(session);
  } catch (error) {
    logger.error('Error creating session:', error);
    res.status(400).json({ error: 'خطأ في إضافة الجلسة' });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const [updated] = await Session.update(req.body, {
      where: { id: req.params.id },
    });
    if (updated) {
      const session = await Session.findByPk(req.params.id);
      emitEvent('update', 'session', session);
      logger.info('Session updated', { id: session.id });
      res.json(session);
    } else {
      res.status(404).json({ error: 'الجلسة غير موجودة' });
    }
  } catch (error) {
    logger.error('Error updating session:', error);
    res.status(400).json({ error: 'خطأ في تحديث الجلسة' });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    const deleted = await Session.destroy({
      where: { id: req.params.id },
    });
    if (deleted) {
      emitEvent('delete', 'session', { id: req.params.id });
      logger.info('Session deleted', { id: req.params.id });
      res.json({ message: 'تم حذف الجلسة بنجاح' });
    } else {
      res.status(404).json({ error: 'الجلسة غير موجودة' });
    }
  } catch (error) {
    logger.error('Error deleting session:', error);
    res.status(400).json({ error: 'خطأ في حذف الجلسة' });
  }
});

/**
 * Session Types Routes
 */
router.get('/types', async (req, res) => {
  try {
    // Default session types
    const sessionTypes = [
      { id: 1, name: 'علاج طبيعي', duration: 60, color: '#3498db' },
      { id: 2, name: 'علاج وظيفي', duration: 45, color: '#27ae60' },
      { id: 3, name: 'نطق ولغة', duration: 30, color: '#e67e22' },
      { id: 4, name: 'علاج نفسي', duration: 60, color: '#9b59b6' },
      { id: 5, name: 'تعليمي', duration: 45, color: '#f39c12' },
      { id: 6, name: 'ترفيهي', duration: 60, color: '#e74c3c' },
      { id: 7, name: 'جماعي', duration: 90, color: '#16a085' },
    ];
    res.json(sessionTypes);
  } catch (error) {
    logger.error('Error fetching session types:', error);
    res.status(500).json({ error: 'خطأ في جلب أنواع الجلسات' });
  }
});

/**
 * Attendance Routes
 */
router.get('/attendance', async (req, res) => {
  try {
    // In production, this should use an Attendance model
    res.json([]);
  } catch (error) {
    logger.error('Error fetching attendance:', error);
    res.status(500).json({ error: 'خطأ في جلب الحضور' });
  }
});

router.post('/attendance', async (req, res) => {
  try {
    const attendance = req.body;
    attendance.id = Date.now();
    attendance.createdAt = new Date();
    emitEvent('create', 'attendance', attendance);
    logger.info('Attendance created', { id: attendance.id });
    res.status(201).json(attendance);
  } catch (error) {
    logger.error('Error creating attendance:', error);
    res.status(400).json({ error: 'خطأ في إضافة الحضور' });
  }
});

router.put('/attendance/:id', async (req, res) => {
  try {
    const attendance = { ...req.body, id: req.params.id };
    emitEvent('update', 'attendance', attendance);
    logger.info('Attendance updated', { id: req.params.id });
    res.json(attendance);
  } catch (error) {
    logger.error('Error updating attendance:', error);
    res.status(400).json({ error: 'خطأ في تحديث الحضور' });
  }
});

router.delete('/attendance/:id', async (req, res) => {
  try {
    emitEvent('delete', 'attendance', { id: req.params.id });
    logger.info('Attendance deleted', { id: req.params.id });
    res.json({ message: 'تم حذف الحضور بنجاح' });
  } catch (error) {
    logger.error('Error deleting attendance:', error);
    res.status(400).json({ error: 'خطأ في حذف الحضور' });
  }
});

module.exports = router;
