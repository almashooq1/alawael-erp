/**
 * Smart Archive Routes
 * API routes for smart archive management
 */

const express = require('express');
const router = express.Router();
const SmartArchiveManager = require('../../shared/utils/smart-archive-manager');
const ArchiveClassificationManager = require('../../shared/utils/archive-classification-manager');
const ArchiveSearchEngine = require('../../shared/utils/archive-search-engine');
const ArchivePermissionsManager = require('../../shared/utils/archive-permissions-manager');
const { requirePermission } = require('../../shared/middleware/permissions-middleware');

const archiveManager = new SmartArchiveManager();
const classificationManager = new ArchiveClassificationManager();
const searchEngine = new ArchiveSearchEngine();
const permissionsManager = new ArchivePermissionsManager();

// ربط permissionsManager بـ archiveManager
permissionsManager.setDocumentGetter(documentId => {
  return archiveManager.documents.get(documentId);
});

// ========== Document Management ==========

/**
 * إضافة وثيقة
 */
router.post('/documents', requirePermission('archive.edit'), async (req, res) => {
  try {
    const document = archiveManager.addDocument(req.body);

    // تصنيف تلقائي
    const classification = classificationManager.classifyDocument(document);
    if (classification.confidence >= 30) {
      document.category = classification.category;
      document.priority = classification.priority;
      document.confidentiality = classification.confidentiality;
      document.tags = [...new Set([...document.tags, ...classification.suggestedTags])];
    }

    // فهرسة للبحث
    searchEngine.indexDocument(document);

    res.json({ success: true, data: document, classification });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على وثيقة
 */
router.get('/documents/:id', requirePermission('archive.view'), async (req, res) => {
  try {
    const document = archiveManager.documents.get(req.params.id);
    if (!document) {
      return res.status(404).json({ success: false, error: 'Document not found' });
    }

    // التحقق من الصلاحيات
    const userId = req.user?.id || req.user?.userId;
    if (!permissionsManager.hasDocumentAccess(userId, req.params.id, 'view')) {
      return res.status(403).json({ success: false, error: 'Access denied' });
    }

    const metadata = archiveManager.metadata.get(req.params.id);
    const related = archiveManager.getRelatedDocuments(req.params.id);

    res.json({
      success: true,
      data: {
        ...document,
        metadata,
        relatedDocuments: related,
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تحديث وثيقة
 */
router.put('/documents/:id', requirePermission('archive.edit'), async (req, res) => {
  try {
    const document = archiveManager.updateDocument(
      req.params.id,
      req.body,
      req.body.changeDescription || ''
    );

    // إعادة فهرسة
    searchEngine.indexDocument(document);

    res.json({ success: true, data: document });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * أرشفة وثيقة
 */
router.post('/documents/:id/archive', requirePermission('archive.archive'), async (req, res) => {
  try {
    const document = archiveManager.archiveDocument(req.params.id, req.body.reason || '');
    res.json({ success: true, data: document });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * استعادة وثيقة
 */
router.post('/documents/:id/restore', requirePermission('archive.restore'), async (req, res) => {
  try {
    const document = archiveManager.restoreDocument(req.params.id);
    res.json({ success: true, data: document });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Search ==========

/**
 * بحث بسيط
 */
router.get('/search', requirePermission('archive.view'), async (req, res) => {
  try {
    const query = req.query.q || '';
    const filters = {
      category: req.query.category,
      status: req.query.status,
      priority: req.query.priority,
      confidentiality: req.query.confidentiality,
      startDate: req.query.startDate,
      endDate: req.query.endDate,
    };

    let results;
    if (query) {
      // استخدام محرك البحث
      const searchResults = searchEngine.advancedSearch(query, filters);
      results = searchResults.map(result => {
        const doc = archiveManager.documents.get(result.documentId);
        return { ...doc, relevanceScore: result.score };
      });
    } else {
      // بحث عادي
      results = archiveManager.searchDocuments('', filters);
    }

    res.json({ success: true, data: results });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * بحث ضبابي
 */
router.get('/search/fuzzy', requirePermission('archive.view'), async (req, res) => {
  try {
    const query = req.query.q || '';
    const threshold = parseFloat(req.query.threshold) || 0.7;

    const searchResults = searchEngine.fuzzySearch(query, threshold);
    const results = searchResults.map(result => {
      const doc = archiveManager.documents.get(result.documentId);
      return { ...doc, similarityScore: result.score };
    });

    res.json({ success: true, data: results });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Classification ==========

/**
 * تصنيف وثيقة
 */
router.post('/documents/:id/classify', requirePermission('archive.edit'), async (req, res) => {
  try {
    const document = archiveManager.documents.get(req.params.id);
    if (!document) {
      return res.status(404).json({ success: false, error: 'Document not found' });
    }

    const classification = classificationManager.classifyDocument(document);
    res.json({ success: true, data: classification });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على قواعد التصنيف
 */
router.get('/classification/rules', requirePermission('archive.view'), async (req, res) => {
  try {
    const rules = classificationManager.getClassificationRules(req.query);
    res.json({ success: true, data: rules });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Versions ==========

/**
 * الحصول على إصدارات وثيقة
 */
router.get('/documents/:id/versions', requirePermission('archive.view'), async (req, res) => {
  try {
    const versions = archiveManager.getDocumentVersions(req.params.id);
    res.json({ success: true, data: versions });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * استعادة إصدار سابق
 */
router.post(
  '/documents/:id/versions/:version/restore',
  requirePermission('archive.edit'),
  async (req, res) => {
    try {
      const document = archiveManager.restoreVersion(req.params.id, parseInt(req.params.version));
      res.json({ success: true, data: document });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Relationships ==========

/**
 * إضافة علاقة بين وثائق
 */
router.post('/documents/:id1/relate/:id2', requirePermission('archive.edit'), async (req, res) => {
  try {
    archiveManager.addRelationship(req.params.id1, req.params.id2, req.body.type || 'related');
    res.json({ success: true, message: 'Relationship added' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Statistics ==========

/**
 * إحصائيات الأرشيف
 */
router.get('/stats', requirePermission('archive.view'), async (req, res) => {
  try {
    const stats = archiveManager.getArchiveStats();
    const searchStats = searchEngine.getIndexStats();

    res.json({
      success: true,
      data: {
        ...stats,
        search: searchStats,
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Categories ==========

/**
 * الحصول على الفئات
 */
router.get('/categories', async (req, res) => {
  try {
    const categories = Array.from(archiveManager.categories.values());
    res.json({ success: true, data: categories });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
