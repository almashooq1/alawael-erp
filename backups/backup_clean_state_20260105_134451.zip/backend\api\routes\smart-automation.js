/**
 * 🤖 Smart Automation Routes
 * API routes for smart automation system
 */

const express = require('express');
const router = express.Router();

// Mock data storage (replace with database)
const automations = [];
const workflows = [];
const executionHistory = [];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Automations ====================

router.get('/automations', async (req, res) => {
  try {
    const { status } = req.query;
    let filtered = automations;

    if (status) {
      filtered = filtered.filter(a => a.status === status);
    }

    res.json({
      success: true,
      data: filtered,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.get('/automations/:id', async (req, res) => {
  try {
    const automation = automations.find(a => a.id === parseInt(req.params.id));
    if (!automation) {
      return res.status(404).json({
        success: false,
        error: 'Automation not found',
      });
    }
    res.json({
      success: true,
      data: automation,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/automations', async (req, res) => {
  try {
    const automation = {
      id: automations.length > 0 ? Math.max(...automations.map(a => a.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      executionCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    automations.push(automation);

    emitEvent('automation:updated', {
      action: 'create',
      entityId: automation.id,
      data: automation,
    });

    res.json({
      success: true,
      data: automation,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.put('/automations/:id', async (req, res) => {
  try {
    const index = automations.findIndex(a => a.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Automation not found',
      });
    }

    automations[index] = {
      ...automations[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    emitEvent('automation:updated', {
      action: 'update',
      entityId: automations[index].id,
      data: automations[index],
    });

    res.json({
      success: true,
      data: automations[index],
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.delete('/automations/:id', async (req, res) => {
  try {
    const index = automations.findIndex(a => a.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Automation not found',
      });
    }

    automations.splice(index, 1);

    emitEvent('automation:updated', {
      action: 'delete',
      entityId: parseInt(req.params.id),
    });

    res.json({
      success: true,
      message: 'Automation deleted successfully',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/automations/:id/execute', async (req, res) => {
  try {
    const automation = automations.find(a => a.id === parseInt(req.params.id));
    if (!automation) {
      return res.status(404).json({
        success: false,
        error: 'Automation not found',
      });
    }

    if (automation.status !== 'active') {
      return res.status(400).json({
        success: false,
        error: 'Automation is not active',
      });
    }

    // Execute automation
    const executionResult = await executeAutomation(automation);

    // Update execution count
    automation.executionCount = (automation.executionCount || 0) + 1;
    automation.lastExecuted = new Date().toISOString();

    // Add to history
    const historyEntry = {
      id: executionHistory.length > 0 ? Math.max(...executionHistory.map(h => h.id)) + 1 : 1,
      automationId: automation.id,
      automationName: automation.name,
      status: executionResult.success ? 'success' : 'failed',
      executedAt: new Date().toISOString(),
      result: executionResult.result,
      error: executionResult.error || null,
    };

    executionHistory.unshift(historyEntry);

    // Keep only last 1000 entries
    if (executionHistory.length > 1000) {
      executionHistory.pop();
    }

    emitEvent('automation:executed', {
      automationId: automation.id,
      execution: historyEntry,
    });

    res.json({
      success: true,
      data: historyEntry,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Workflows ====================

router.get('/workflows', async (req, res) => {
  try {
    res.json({
      success: true,
      data: workflows,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post('/workflows', async (req, res) => {
  try {
    const workflow = {
      id: workflows.length > 0 ? Math.max(...workflows.map(w => w.id)) + 1 : 1,
      ...req.body,
      status: req.body.status || 'active',
      createdAt: new Date().toISOString(),
    };

    workflows.push(workflow);

    res.json({
      success: true,
      data: workflow,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Execution History ====================

router.get('/history', async (req, res) => {
  try {
    const { automationId, limit = 50 } = req.query;
    let filtered = executionHistory;

    if (automationId) {
      filtered = filtered.filter(h => h.automationId === parseInt(automationId));
    }

    res.json({
      success: true,
      data: filtered.slice(0, parseInt(limit)),
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// ==================== Helper Functions ====================

async function executeAutomation(automation) {
  try {
    // Execute each action
    const results = [];

    for (const action of automation.actions || []) {
      const result = await executeAction(action);
      results.push(result);
    }

    return {
      success: true,
      result: results,
    };
  } catch (error) {
    return {
      success: false,
      error: error.message,
    };
  }
}

async function executeAction(action) {
  // Simulate action execution
  switch (action.type) {
    case 'notification':
      // TODO: Send notification
      return { type: 'notification', success: true, message: 'Notification sent' };

    case 'email':
      // TODO: Send email
      return { type: 'email', success: true, message: 'Email sent' };

    case 'sms':
      // TODO: Send SMS
      return { type: 'sms', success: true, message: 'SMS sent' };

    case 'data_update':
      // TODO: Update data
      return { type: 'data_update', success: true, message: 'Data updated' };

    case 'report_generation':
      // TODO: Generate report
      return { type: 'report_generation', success: true, message: 'Report generated' };

    default:
      return { type: action.type, success: false, error: 'Unknown action type' };
  }
}

module.exports = { router, setIO };
