/**
 * 🔔 Smart Notifications Routes
 * API routes for smart notifications system
 */

const express = require('express');
const router = express.Router();

// Mock data storage
const notifications = [];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Notifications ====================

router.get('/', async (req, res) => {
  try {
    const { unread, priority, limit } = req.query;
    let filtered = notifications;

    if (unread === 'true') {
      filtered = filtered.filter(n => !n.read);
    }

    if (priority) {
      filtered = filtered.filter(n => n.priority === priority);
    }

    if (limit) {
      filtered = filtered.slice(0, parseInt(limit));
    }

    res.json({ success: true, data: filtered });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/', async (req, res) => {
  try {
    const notification = {
      id: notifications.length > 0 ? Math.max(...notifications.map(n => n.id)) + 1 : 1,
      ...req.body,
      read: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    notifications.push(notification);

    emitEvent('notifications:update', {
      action: 'create',
      entityType: 'notification',
      entityId: notification.id,
      data: notification,
    });

    res.status(201).json({ success: true, data: notification });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const notification = notifications.find(n => n.id === parseInt(req.params.id));
    if (!notification) {
      return res.status(404).json({ success: false, error: 'Notification not found' });
    }
    res.json({ success: true, data: notification });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const index = notifications.findIndex(n => n.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Notification not found' });
    }

    notifications[index] = {
      ...notifications[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    emitEvent('notifications:update', {
      action: 'update',
      entityType: 'notification',
      entityId: notifications[index].id,
      data: notifications[index],
    });

    res.json({ success: true, data: notifications[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    const index = notifications.findIndex(n => n.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Notification not found' });
    }

    const deletedNotification = notifications[index];
    notifications.splice(index, 1);

    emitEvent('notifications:update', {
      action: 'delete',
      entityType: 'notification',
      entityId: deletedNotification.id,
    });

    res.json({ success: true, message: 'Notification deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Mark as Read ====================

router.put('/:id/read', async (req, res) => {
  try {
    const index = notifications.findIndex(n => n.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Notification not found' });
    }

    notifications[index].read = true;
    notifications[index].updatedAt = new Date().toISOString();

    emitEvent('notifications:update', {
      action: 'update',
      entityType: 'notification',
      entityId: notifications[index].id,
      data: notifications[index],
    });

    res.json({ success: true, data: notifications[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Mark All as Read ====================

router.post('/mark-all-read', async (req, res) => {
  try {
    notifications.forEach(n => {
      n.read = true;
      n.updatedAt = new Date().toISOString();
    });

    emitEvent('notifications:update', {
      action: 'update',
      entityType: 'notification',
      data: { allRead: true },
    });

    res.json({ success: true, message: 'All notifications marked as read' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Preferences ====================

router.get('/preferences', async (req, res) => {
  try {
    // TODO: Load user preferences from database
    const preferences = {
      sound: true,
      desktop: true,
      email: false,
      sms: false,
      priorities: {
        critical: true,
        high: true,
        medium: true,
        low: false,
      },
    };

    res.json({ success: true, data: preferences });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/preferences', async (req, res) => {
  try {
    // TODO: Save user preferences to database
    const preferences = req.body;

    res.json({ success: true, data: preferences });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
