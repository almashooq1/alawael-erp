/**
 * 📱 Social Media Management Routes
 * API routes for accounts, posts, campaigns, and analytics
 */

const express = require('express');
const router = express.Router();

// Mock data storage
const accounts = [];
const posts = [];
const campaigns = [];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Accounts ====================

router.get('/accounts', async (req, res) => {
  try {
    res.json({ success: true, data: accounts });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/accounts', async (req, res) => {
  try {
    const account = {
      id: accounts.length > 0 ? Math.max(...accounts.map(a => a.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    accounts.push(account);

    emitEvent('socialMedia:update', {
      action: 'create',
      entityType: 'account',
      entityId: account.id,
      data: account,
    });

    res.status(201).json({ success: true, data: account });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Posts ====================

router.get('/posts', async (req, res) => {
  try {
    res.json({ success: true, data: posts });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/posts', async (req, res) => {
  try {
    const post = {
      id: posts.length > 0 ? Math.max(...posts.map(p => p.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    posts.push(post);

    emitEvent('socialMedia:update', {
      action: 'create',
      entityType: 'post',
      entityId: post.id,
      data: post,
    });

    res.status(201).json({ success: true, data: post });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/posts/:id', async (req, res) => {
  try {
    const index = posts.findIndex(p => p.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Post not found' });
    }

    posts[index] = {
      ...posts[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    emitEvent('socialMedia:update', {
      action: 'update',
      entityType: 'post',
      entityId: posts[index].id,
      data: posts[index],
    });

    res.json({ success: true, data: posts[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.delete('/posts/:id', async (req, res) => {
  try {
    const index = posts.findIndex(p => p.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Post not found' });
    }

    const deletedPost = posts[index];
    posts.splice(index, 1);

    emitEvent('socialMedia:update', {
      action: 'delete',
      entityType: 'post',
      entityId: deletedPost.id,
    });

    res.json({ success: true, message: 'Post deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Campaigns ====================

router.get('/campaigns', async (req, res) => {
  try {
    res.json({ success: true, data: campaigns });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/campaigns', async (req, res) => {
  try {
    const campaign = {
      id: campaigns.length > 0 ? Math.max(...campaigns.map(c => c.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    campaigns.push(campaign);

    emitEvent('socialMedia:update', {
      action: 'create',
      entityType: 'campaign',
      entityId: campaign.id,
      data: campaign,
    });

    res.status(201).json({ success: true, data: campaign });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Analytics ====================

router.get('/analytics', async (req, res) => {
  try {
    res.json({ success: true, data: analytics });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/analytics', async (req, res) => {
  try {
    const analytic = {
      id: analytics.length > 0 ? Math.max(...analytics.map(a => a.id)) + 1 : 1,
      ...req.body,
      date: new Date().toISOString(),
    };
    analytics.push(analytic);

    emitEvent('socialMedia:update', {
      action: 'create',
      entityType: 'analytic',
      entityId: analytic.id,
      data: analytic,
    });

    res.status(201).json({ success: true, data: analytic });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
