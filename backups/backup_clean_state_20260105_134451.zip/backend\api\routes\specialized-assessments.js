/**
 * 🔬 Specialized Assessments Management Routes
 * مسارات إدارة التقييمات المتخصصة
 */

const express = require('express');
const router = express.Router();
const SpecializedAssessment = require('../models/SpecializedAssessment');
const authenticateToken = require('../middleware/authenticateToken');
const logger = require('../../shared/logging/logger');

// Real-time event emitter (if available)
let io = null;
try {
  const realtimeModule = require('../realtime');
  io = realtimeModule.io;
} catch (error) {
  // Real-time not available
}

/**
 * Emit real-time event
 */
function emitEvent(eventType, entityType, data) {
  if (io) {
    io.emit('specializedAssessments:update', {
      action: eventType,
      entityType: entityType,
      entityId: data.id,
      data: data,
    });
  }
}

// Apply authentication to all routes
router.use(authenticateToken);

/**
 * Specialized Assessments Routes
 */
router.get('/', async (req, res) => {
  try {
    const assessments = await SpecializedAssessment.findAll({
      order: [['createdAt', 'DESC']],
      limit: 100,
    });
    res.json(assessments);
  } catch (error) {
    logger.error('Error fetching specialized assessments:', error);
    res.status(500).json({ error: 'خطأ في جلب التقييمات المتخصصة' });
  }
});

router.post('/', async (req, res) => {
  try {
    const assessment = await SpecializedAssessment.create(req.body);
    emitEvent('create', 'assessment', assessment);
    logger.info('Specialized assessment created', { id: assessment.id, type: assessment.type });
    res.status(201).json(assessment);
  } catch (error) {
    logger.error('Error creating specialized assessment:', error);
    res.status(400).json({ error: 'خطأ في إضافة التقييم المتخصص' });
  }
});

module.exports = router;
