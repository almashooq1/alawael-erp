/**
 * 📅 API Routes for Student Attendance Management
 * مسارات API لإدارة حضور وانصراف الطلاب
 */

const express = require('express');
const router = express.Router();
const StudentAttendanceManager = require('../../shared/utils/student-attendance-manager');
const StudentAttendanceNotifications = require('../../shared/utils/student-attendance-notifications');
const StudentAttendanceAnalytics = require('../../shared/utils/student-attendance-analytics');
const { requirePermission } = require('../../shared/middleware/permissions-middleware');

const attendanceManager = new StudentAttendanceManager();
const notificationsManager = new StudentAttendanceNotifications(attendanceManager);
const analyticsManager = new StudentAttendanceAnalytics(attendanceManager);

// ========== Check-in/Check-out ==========

/**
 * تسجيل حضور طالب
 */
router.post(
  '/check-in/:studentId',
  requirePermission('students.attendance.edit'),
  async (req, res) => {
    try {
      const result = await attendanceManager.checkIn(req.params.studentId, req.body);

      // إرسال إشعارات تلقائية
      if (result.success && result.record) {
        await notificationsManager.handleCheckInEvent(result.record);
      }

      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * تسجيل انصراف طالب
 */
router.post(
  '/check-out/:studentId',
  requirePermission('students.attendance.edit'),
  async (req, res) => {
    try {
      const result = await attendanceManager.checkOut(req.params.studentId, req.body);

      // إرسال إشعارات تلقائية
      if (result.success && result.record) {
        await notificationsManager.handleCheckOutEvent(result.record);
      }

      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * تسجيل حضور عبر QR Code
 */
router.post(
  '/check-in-qr/:studentId',
  requirePermission('students.attendance.edit'),
  async (req, res) => {
    try {
      const result = await attendanceManager.checkInWithQR(
        req.params.studentId,
        req.body.qrCode,
        req.body.location
      );
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * تسجيل حضور عبر Biometric
 */
router.post(
  '/check-in-biometric/:studentId',
  requirePermission('students.attendance.edit'),
  async (req, res) => {
    try {
      const result = await attendanceManager.checkInWithBiometric(
        req.params.studentId,
        req.body.biometricData,
        req.body.location
      );
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * تسجيل حضور عبر GPS
 */
router.post(
  '/check-in-gps/:studentId',
  requirePermission('students.attendance.edit'),
  async (req, res) => {
    try {
      const result = await attendanceManager.checkInWithGPS(
        req.params.studentId,
        req.body.coordinates,
        req.body.location
      );
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Attendance Records ==========

/**
 * الحصول على سجل الحضور
 */
router.get(
  '/records/:studentId',
  requirePermission('students.attendance.view'),
  async (req, res) => {
    try {
      const record = attendanceManager.getAttendanceRecord(req.params.studentId, req.query.date);
      res.json({ success: true, data: record });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * الحصول على سجل الحضور لفترة
 */
router.get(
  '/history/:studentId',
  requirePermission('students.attendance.view'),
  async (req, res) => {
    try {
      const history = attendanceManager.getAttendanceHistory(req.params.studentId, req.query);
      res.json({ success: true, data: history });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Absence Requests ==========

/**
 * طلب غياب
 */
router.post(
  '/absence-requests',
  requirePermission('students.attendance.edit'),
  async (req, res) => {
    try {
      const result = await attendanceManager.requestAbsence(req.body.studentId, req.body);
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * الموافقة على طلب غياب
 */
router.post(
  '/absence-requests/:requestId/approve',
  requirePermission('students.attendance.approve'),
  async (req, res) => {
    try {
      const result = await attendanceManager.approveAbsence(
        req.params.requestId,
        req.body.approvedBy
      );
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * رفض طلب غياب
 */
router.post(
  '/absence-requests/:requestId/reject',
  requirePermission('students.attendance.approve'),
  async (req, res) => {
    try {
      const result = await attendanceManager.rejectAbsence(
        req.params.requestId,
        req.body.rejectedBy,
        req.body.reason
      );
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Statistics & Reports ==========

/**
 * إحصائيات الحضور
 */
router.get(
  '/statistics/:studentId',
  requirePermission('students.attendance.view'),
  async (req, res) => {
    try {
      const statistics = attendanceManager.getAttendanceStatistics(
        req.params.studentId,
        req.query.startDate,
        req.query.endDate
      );
      res.json({ success: true, data: statistics });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * تقرير الحضور
 */
router.get(
  '/reports/:studentId',
  requirePermission('students.attendance.view'),
  async (req, res) => {
    try {
      const report = attendanceManager.getAttendanceReport(
        req.params.studentId,
        req.query.startDate,
        req.query.endDate
      );
      res.json({ success: true, data: report });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Students Management ==========

/**
 * إضافة طالب
 */
router.post('/students', requirePermission('students.edit'), async (req, res) => {
  try {
    const student = attendanceManager.addStudent(req.body);
    res.json({ success: true, data: student });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على طالب
 */
router.get('/students/:studentId', requirePermission('students.view'), async (req, res) => {
  try {
    const student = attendanceManager.getStudent(req.params.studentId);
    if (!student) {
      return res.status(404).json({ success: false, error: 'Student not found' });
    }
    res.json({ success: true, data: student });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على جميع الطلاب
 */
router.get('/students', requirePermission('students.view'), async (req, res) => {
  try {
    const students = attendanceManager.getAllStudents();
    res.json({ success: true, data: students });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Shifts Management ==========

/**
 * الحصول على الفترات
 */
router.get('/shifts', requirePermission('students.attendance.view'), async (req, res) => {
  try {
    const shifts = attendanceManager.getShifts();
    res.json({ success: true, data: shifts });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Notifications ==========

/**
 * الحصول على الإشعارات
 */
router.get('/notifications', requirePermission('students.attendance.view'), async (req, res) => {
  try {
    const notifications = notificationsManager.getNotifications(req.query);
    res.json({ success: true, data: notifications });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على قواعد الإشعارات
 */
router.get(
  '/notifications/rules',
  requirePermission('students.attendance.view'),
  async (req, res) => {
    try {
      const rules = notificationsManager.getNotificationRules();
      res.json({ success: true, data: rules });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * تفعيل/تعطيل قاعدة إشعار
 */
router.post(
  '/notifications/rules/:ruleId/toggle',
  requirePermission('students.attendance.edit'),
  async (req, res) => {
    try {
      const success = notificationsManager.toggleNotificationRule(
        req.params.ruleId,
        req.body.enabled
      );
      res.json({ success, data: { ruleId: req.params.ruleId, enabled: req.body.enabled } });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Analytics ==========

/**
 * تحليل شامل للحضور
 */
router.get(
  '/analytics/:studentId/comprehensive',
  requirePermission('students.attendance.view'),
  async (req, res) => {
    try {
      const analysis = await analyticsManager.comprehensiveAnalysis(
        req.params.studentId,
        req.query.startDate,
        req.query.endDate
      );
      res.json({ success: true, data: analysis });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * تقرير تحليلي شامل
 */
router.get(
  '/analytics/:studentId/report',
  requirePermission('students.attendance.view'),
  async (req, res) => {
    try {
      const report = await analyticsManager.generateAnalyticalReport(
        req.params.studentId,
        req.query.startDate,
        req.query.endDate
      );
      res.json({ success: true, data: report });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

module.exports = router;
