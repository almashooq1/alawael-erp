/**
 * Student Files API Routes
 * API routes for student file management
 */

const express = require('express');
const router = express.Router();
const StudentFileManager = require('../../shared/utils/student-file-manager');
const StudentAnalyticsManager = require('../../shared/utils/student-analytics-manager');
const StudentSearchEngine = require('../../shared/utils/student-search-engine');
const StudentReportsGenerator = require('../../shared/utils/student-reports-generator');
const StudentPredictionsManager = require('../../shared/utils/student-predictions-manager');
const StudentNotificationsManager = require('../../shared/utils/student-notifications-manager');
const StudentIntegrationManager = require('../../shared/utils/student-integration-manager');
const StudentBackupManager = require('../../shared/utils/student-backup-manager');
const StudentExportImportManager = require('../../shared/utils/student-export-import-manager');
const StudentArchiveManager = require('../../shared/utils/student-archive-manager');
const StudentPerformanceManager = require('../../shared/utils/student-performance-manager');
const StudentSecurityManager = require('../../shared/utils/student-security-manager');
const StudentAIIntegration = require('../../shared/utils/student-ai-integration');
const StudentCloudIntegration = require('../../shared/utils/student-cloud-integration');
const StudentStatisticsManager = require('../../shared/utils/student-statistics-manager');
const StudentMonitoringManager = require('../../shared/utils/student-monitoring-manager');
const StudentSmartRecommendations = require('../../shared/utils/student-smart-recommendations');
const StudentDeviceIntegration = require('../../shared/utils/student-device-integration');
const StudentMobileIntegration = require('../../shared/utils/student-mobile-integration');
const StudentGovernmentIntegration = require('../../shared/utils/student-government-integration');
const StudentInsuranceIntegration = require('../../shared/utils/student-insurance-integration');
const StudentAdvancedPredictiveAnalytics = require('../../shared/utils/student-advanced-predictive-analytics');
const StudentEducationalIntegration = require('../../shared/utils/student-educational-integration');
const StudentMedicalIntegration = require('../../shared/utils/student-medical-integration');
const StudentCommunicationIntegration = require('../../shared/utils/student-communication-integration');
const StudentPaymentIntegration = require('../../shared/utils/student-payment-integration');
const StudentHRIntegration = require('../../shared/utils/student-hr-integration');
const StudentAccountingIntegration = require('../../shared/utils/student-accounting-integration');
const { requirePermission } = require('../../shared/middleware/permissions-middleware');

const studentFileManager = new StudentFileManager();
const analyticsManager = new StudentAnalyticsManager(studentFileManager);
const searchEngine = new StudentSearchEngine(studentFileManager);
const reportsGenerator = new StudentReportsGenerator(studentFileManager);
const predictionsManager = new StudentPredictionsManager(studentFileManager, analyticsManager);
const notificationsManager = new StudentNotificationsManager();
const integrationManager = new StudentIntegrationManager(studentFileManager);
const backupManager = new StudentBackupManager(studentFileManager);
const exportImportManager = new StudentExportImportManager(studentFileManager);
const archiveManager = new StudentArchiveManager(studentFileManager);
const performanceManager = new StudentPerformanceManager(studentFileManager);
const securityManager = new StudentSecurityManager();
const aiIntegration = new StudentAIIntegration(studentFileManager, analyticsManager);
const cloudIntegration = new StudentCloudIntegration(studentFileManager);
const statisticsManager = new StudentStatisticsManager(studentFileManager);
const monitoringManager = new StudentMonitoringManager(studentFileManager, analyticsManager);
const smartRecommendations = new StudentSmartRecommendations(
  studentFileManager,
  analyticsManager,
  predictionsManager
);
const deviceIntegration = new StudentDeviceIntegration(studentFileManager);
const mobileIntegration = new StudentMobileIntegration(studentFileManager);
const governmentIntegration = new StudentGovernmentIntegration(studentFileManager);
const insuranceIntegration = new StudentInsuranceIntegration(studentFileManager);
const advancedPredictiveAnalytics = new StudentAdvancedPredictiveAnalytics(
  studentFileManager,
  analyticsManager,
  predictionsManager
);
const educationalIntegration = new StudentEducationalIntegration(studentFileManager);
const medicalIntegration = new StudentMedicalIntegration(studentFileManager);
const communicationIntegration = new StudentCommunicationIntegration(studentFileManager);
const paymentIntegration = new StudentPaymentIntegration(studentFileManager);
const hrIntegration = new StudentHRIntegration(studentFileManager);
const accountingIntegration = new StudentAccountingIntegration(studentFileManager);

// ========== Student Files ==========

/**
 * إنشاء ملف طالب جديد
 */
router.post('/students', requirePermission('students.create'), async (req, res) => {
  try {
    const studentFile = studentFileManager.createStudentFile(req.body);
    res.json({ success: true, data: studentFile });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على ملف طالب
 */
router.get('/students/:studentId', requirePermission('students.view'), async (req, res) => {
  try {
    const file = studentFileManager.getStudentFile(req.params.studentId);
    if (!file) {
      return res.status(404).json({ success: false, error: 'Student file not found' });
    }
    res.json({ success: true, data: file });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تحديث ملف طالب
 */
router.put('/students/:studentId', requirePermission('students.edit'), async (req, res) => {
  try {
    const file = studentFileManager.updateStudentFile(req.params.studentId, req.body);
    res.json({ success: true, data: file });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على جميع ملفات الطلاب
 */
router.get('/students', requirePermission('students.view'), async (req, res) => {
  try {
    const files = studentFileManager.getAllStudentFiles(req.query);
    res.json({ success: true, data: files });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على إحصائيات ملف طالب
 */
router.get('/students/:studentId/stats', requirePermission('students.view'), async (req, res) => {
  try {
    const stats = studentFileManager.getStudentFileStats(req.params.studentId);
    if (!stats) {
      return res.status(404).json({ success: false, error: 'Student file not found' });
    }
    res.json({ success: true, data: stats });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على تقرير شامل لملف طالب
 */
router.get('/students/:studentId/report', requirePermission('students.view'), async (req, res) => {
  try {
    const report = studentFileManager.getStudentFileReport(req.params.studentId);
    if (!report) {
      return res.status(404).json({ success: false, error: 'Student file not found' });
    }
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Documents ==========

/**
 * إضافة وثيقة لملف طالب
 */
router.post(
  '/students/:studentId/documents',
  requirePermission('students.edit'),
  async (req, res) => {
    try {
      const document = studentFileManager.addDocument(req.params.studentId, req.body);
      res.json({ success: true, data: document });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * الحصول على وثائق طالب
 */
router.get(
  '/students/:studentId/documents',
  requirePermission('students.view'),
  async (req, res) => {
    try {
      const file = studentFileManager.getStudentFile(req.params.studentId);
      if (!file) {
        return res.status(404).json({ success: false, error: 'Student file not found' });
      }
      const documents = file.documents
        .map(id => studentFileManager.documents.get(id))
        .filter(Boolean);
      res.json({ success: true, data: documents });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Assessments ==========

/**
 * إضافة تقييم
 */
router.post(
  '/students/:studentId/assessments',
  requirePermission('students.edit'),
  async (req, res) => {
    try {
      const assessment = studentFileManager.addAssessment(req.params.studentId, req.body);
      res.json({ success: true, data: assessment });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * الحصول على تقييمات طالب
 */
router.get(
  '/students/:studentId/assessments',
  requirePermission('students.view'),
  async (req, res) => {
    try {
      const file = studentFileManager.getStudentFile(req.params.studentId);
      if (!file) {
        return res.status(404).json({ success: false, error: 'Student file not found' });
      }
      const assessments = file.assessments
        .map(id => studentFileManager.assessments.get(id))
        .filter(Boolean);
      res.json({ success: true, data: assessments });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Progress Records ==========

/**
 * إضافة سجل تقدم
 */
router.post(
  '/students/:studentId/progress',
  requirePermission('students.edit'),
  async (req, res) => {
    try {
      const progress = studentFileManager.addProgressRecord(req.params.studentId, req.body);
      res.json({ success: true, data: progress });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * الحصول على سجلات التقدم
 */
router.get(
  '/students/:studentId/progress',
  requirePermission('students.view'),
  async (req, res) => {
    try {
      const file = studentFileManager.getStudentFile(req.params.studentId);
      if (!file) {
        return res.status(404).json({ success: false, error: 'Student file not found' });
      }
      const progress = file.progressRecords
        .map(id => studentFileManager.progressRecords.get(id))
        .filter(Boolean);
      res.json({ success: true, data: progress });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Medical Records ==========

/**
 * إضافة سجل طبي
 */
router.post(
  '/students/:studentId/medical',
  requirePermission('students.edit'),
  async (req, res) => {
    try {
      const medical = studentFileManager.addMedicalRecord(req.params.studentId, req.body);
      res.json({ success: true, data: medical });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * الحصول على السجلات الطبية
 */
router.get('/students/:studentId/medical', requirePermission('students.view'), async (req, res) => {
  try {
    const file = studentFileManager.getStudentFile(req.params.studentId);
    if (!file) {
      return res.status(404).json({ success: false, error: 'Student file not found' });
    }
    const medical = file.medicalRecords
      .map(id => studentFileManager.medicalRecords.get(id))
      .filter(Boolean);
    res.json({ success: true, data: medical });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Educational Records ==========

/**
 * إضافة سجل تعليمي
 */
router.post(
  '/students/:studentId/educational',
  requirePermission('students.edit'),
  async (req, res) => {
    try {
      const educational = studentFileManager.addEducationalRecord(req.params.studentId, req.body);
      res.json({ success: true, data: educational });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * الحصول على السجلات التعليمية
 */
router.get(
  '/students/:studentId/educational',
  requirePermission('students.view'),
  async (req, res) => {
    try {
      const file = studentFileManager.getStudentFile(req.params.studentId);
      if (!file) {
        return res.status(404).json({ success: false, error: 'Student file not found' });
      }
      const educational = file.educationalRecords
        .map(id => studentFileManager.educationalRecords.get(id))
        .filter(Boolean);
      res.json({ success: true, data: educational });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Therapy Sessions ==========

/**
 * إضافة جلسة علاجية
 */
router.post(
  '/students/:studentId/therapy',
  requirePermission('students.edit'),
  async (req, res) => {
    try {
      const session = studentFileManager.addTherapySession(req.params.studentId, req.body);
      res.json({ success: true, data: session });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * الحصول على الجلسات العلاجية
 */
router.get('/students/:studentId/therapy', requirePermission('students.view'), async (req, res) => {
  try {
    const file = studentFileManager.getStudentFile(req.params.studentId);
    if (!file) {
      return res.status(404).json({ success: false, error: 'Student file not found' });
    }
    const sessions = file.therapySessions
      .map(id => studentFileManager.therapySessions.get(id))
      .filter(Boolean);
    res.json({ success: true, data: sessions });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Family Contacts ==========

/**
 * إضافة تواصل مع الأسرة
 */
router.post(
  '/students/:studentId/family-contacts',
  requirePermission('students.edit'),
  async (req, res) => {
    try {
      const contact = studentFileManager.addFamilyContact(req.params.studentId, req.body);
      res.json({ success: true, data: contact });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * الحصول على تواصل الأسرة
 */
router.get(
  '/students/:studentId/family-contacts',
  requirePermission('students.view'),
  async (req, res) => {
    try {
      const file = studentFileManager.getStudentFile(req.params.studentId);
      if (!file) {
        return res.status(404).json({ success: false, error: 'Student file not found' });
      }
      const contacts = file.familyContacts
        .map(id => studentFileManager.familyContacts.get(id))
        .filter(Boolean);
      res.json({ success: true, data: contacts });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Analytics ==========

/**
 * تحليل تقدم الطالب
 */
router.get(
  '/students/:studentId/analytics/progress',
  requirePermission('students.view'),
  async (req, res) => {
    try {
      const trends = analyticsManager.analyzeStudentProgress(req.params.studentId);
      res.json({ success: true, data: trends });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * تحديد مجالات التحسين
 */
router.get(
  '/students/:studentId/analytics/improvement-areas',
  requirePermission('students.view'),
  async (req, res) => {
    try {
      const areas = analyticsManager.identifyImprovementAreas(req.params.studentId);
      res.json({ success: true, data: areas });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * تحديد عوامل الخطر
 */
router.get(
  '/students/:studentId/analytics/risks',
  requirePermission('students.view'),
  async (req, res) => {
    try {
      const risks = analyticsManager.identifyRiskFactors(req.params.studentId);
      res.json({ success: true, data: risks });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * توليد توصيات ذكية
 */
router.get(
  '/students/:studentId/analytics/recommendations',
  requirePermission('students.view'),
  async (req, res) => {
    try {
      const recommendations = analyticsManager.generateRecommendations(req.params.studentId);
      res.json({ success: true, data: recommendations });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * تقرير تحليلي شامل
 */
router.get(
  '/students/:studentId/analytics/comprehensive',
  requirePermission('students.view'),
  async (req, res) => {
    try {
      const report = analyticsManager.getComprehensiveReport(req.params.studentId);
      res.json({ success: true, data: report });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Search ==========

/**
 * بحث بسيط
 */
router.get('/search', requirePermission('students.view'), async (req, res) => {
  try {
    const results = searchEngine.search(req.query.q || '', req.query);
    res.json({ success: true, data: results });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * بحث متقدم
 */
router.post('/search/advanced', requirePermission('students.view'), async (req, res) => {
  try {
    const results = searchEngine.advancedSearch(req.body);
    res.json({ success: true, data: results });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Reports ==========

/**
 * توليد تقرير شامل
 */
router.get(
  '/students/:studentId/reports/comprehensive',
  requirePermission('students.view'),
  async (req, res) => {
    try {
      const report = reportsGenerator.generateComprehensiveReport(req.params.studentId);
      if (!report) {
        return res.status(404).json({ success: false, error: 'Student file not found' });
      }
      res.json({ success: true, data: report });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * توليد تقرير حسب قالب
 */
router.get(
  '/students/:studentId/reports/template/:templateId',
  requirePermission('students.view'),
  async (req, res) => {
    try {
      const report = reportsGenerator.generateReportByTemplate(
        req.params.studentId,
        req.params.templateId
      );
      if (!report) {
        return res
          .status(404)
          .json({ success: false, error: 'Student file or template not found' });
      }
      res.json({ success: true, data: report });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * توليد تقرير إحصائي
 */
router.post('/reports/statistics', requirePermission('students.view'), async (req, res) => {
  try {
    const report = reportsGenerator.generateStatisticsReport(req.body.studentIds);
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Predictions ==========

/**
 * التنبؤ بتقدم الطالب
 */
router.get(
  '/students/:studentId/predictions/progress',
  requirePermission('students.view'),
  async (req, res) => {
    try {
      const timeframe = parseInt(req.query.timeframe) || 30;
      const prediction = predictionsManager.predictStudentProgress(req.params.studentId, timeframe);
      res.json({ success: true, data: prediction });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * التنبؤ باحتمالية النجاح
 */
router.get(
  '/students/:studentId/predictions/success',
  requirePermission('students.view'),
  async (req, res) => {
    try {
      const prediction = predictionsManager.predictSuccessProbability(req.params.studentId);
      res.json({ success: true, data: prediction });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * التنبؤ باحتياجات الطالب المستقبلية
 */
router.get(
  '/students/:studentId/predictions/needs',
  requirePermission('students.view'),
  async (req, res) => {
    try {
      const prediction = predictionsManager.predictFutureNeeds(req.params.studentId);
      res.json({ success: true, data: prediction });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Notifications ==========

/**
 * الحصول على إشعارات مستخدم
 */
router.get('/notifications/:userId', async (req, res) => {
  try {
    const notifications = notificationsManager.getUserNotifications(req.params.userId, req.query);
    res.json({ success: true, data: notifications });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تحديد إشعار كمقروء
 */
router.post('/notifications/:id/read', async (req, res) => {
  try {
    const notification = notificationsManager.markAsRead(req.params.id);
    res.json({ success: true, data: notification });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * إحصائيات الإشعارات
 */
router.get('/notifications/:userId/stats', async (req, res) => {
  try {
    const stats = notificationsManager.getNotificationsStats(req.params.userId);
    res.json({ success: true, data: stats });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * إرسال إشعار بناءً على التحليلات
 */
router.post(
  '/students/:studentId/notifications/analytics',
  requirePermission('students.view'),
  async (req, res) => {
    try {
      const analytics = analyticsManager.getComprehensiveReport(req.params.studentId);
      const userId = req.body.userId || 'system';
      const notifications = notificationsManager.sendAnalyticsBasedNotification(
        userId,
        req.params.studentId,
        analytics
      );
      res.json({ success: true, data: notifications });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Integration ==========

/**
 * تسجيل تكامل
 */
router.post('/integration', requirePermission('students.edit'), async (req, res) => {
  try {
    const integration = integrationManager.registerIntegration(req.body);
    res.json({ success: true, data: integration });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * مزامنة مع نظام التأهيل
 */
router.post(
  '/students/:studentId/integration/rehabilitation',
  requirePermission('students.edit'),
  async (req, res) => {
    try {
      const result = await integrationManager.syncWithRehabilitationSystem(req.params.studentId);
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * مزامنة شاملة مع جميع الأنظمة
 */
router.post(
  '/students/:studentId/integration/sync-all',
  requirePermission('students.edit'),
  async (req, res) => {
    try {
      const result = await integrationManager.syncWithAllSystems(req.params.studentId);
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Backup ==========

/**
 * إنشاء نسخة احتياطية
 */
router.post('/backup', requirePermission('students.edit'), async (req, res) => {
  try {
    const backup = backupManager.createBackup(req.body.metadata || {});
    res.json({ success: true, data: backup });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على النسخ الاحتياطية
 */
router.get('/backup', requirePermission('students.view'), async (req, res) => {
  try {
    const backups = backupManager.getBackups(req.query);
    res.json({ success: true, data: backups });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * استعادة نسخة احتياطية
 */
router.post('/backup/:id/restore', requirePermission('students.edit'), async (req, res) => {
  try {
    const result = backupManager.restoreBackup(req.params.id, req.body);
    res.json({ success: true, data: result });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تصدير نسخة احتياطية
 */
router.get('/backup/:id/export', requirePermission('students.view'), async (req, res) => {
  try {
    const backupJson = backupManager.exportBackup(req.params.id);
    res.setHeader('Content-Type', 'application/json');
    res.setHeader(
      'Content-Disposition',
      `attachment; filename="student-backup-${req.params.id}.json"`
    );
    res.send(backupJson);
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Export/Import ==========

/**
 * تصدير ملف طالب
 */
router.get('/students/:studentId/export', requirePermission('students.view'), async (req, res) => {
  try {
    const format = req.query.format || 'json';
    const data = exportImportManager.exportStudentFile(req.params.studentId, format);

    if (format === 'json') {
      res.setHeader('Content-Type', 'application/json');
      res.setHeader(
        'Content-Disposition',
        `attachment; filename="student-${req.params.studentId}.json"`
      );
      res.send(data);
    } else if (format === 'csv') {
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader(
        'Content-Disposition',
        `attachment; filename="student-${req.params.studentId}.csv"`
      );
      res.send(data);
    } else {
      res.status(400).json({ success: false, error: 'Unsupported format' });
    }
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * استيراد ملف طالب
 */
router.post('/students/import', requirePermission('students.create'), async (req, res) => {
  try {
    const format = req.body.format || 'json';
    const result = exportImportManager.importStudentFile(req.body.data, format);
    res.json({ success: true, data: result });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Archive ==========

/**
 * أرشفة ملف طالب
 */
router.post(
  '/students/:studentId/archive',
  requirePermission('students.edit'),
  async (req, res) => {
    try {
      const archived = archiveManager.archiveStudentFile(req.params.studentId, req.body.reason);
      res.json({ success: true, data: archived });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * استعادة ملف طالب من الأرشيف
 */
router.post(
  '/students/:studentId/restore',
  requirePermission('students.edit'),
  async (req, res) => {
    try {
      const restored = archiveManager.restoreStudentFile(req.params.studentId);
      res.json({ success: true, data: restored });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * تنفيذ قواعد الأرشفة
 */
router.post('/archive/execute-rules', requirePermission('students.edit'), async (req, res) => {
  try {
    const result = await archiveManager.executeArchiveRules();
    res.json({ success: true, data: result });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على الملفات المؤرشفة
 */
router.get('/archive', requirePermission('students.view'), async (req, res) => {
  try {
    const archived = archiveManager.getArchivedFiles(req.query);
    res.json({ success: true, data: archived });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تقرير الأرشفة
 */
router.get('/archive/report', requirePermission('students.view'), async (req, res) => {
  try {
    const report = archiveManager.getArchiveReport();
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Performance ==========

/**
 * تحسين الأداء
 */
router.post('/performance/optimize', requirePermission('students.edit'), async (req, res) => {
  try {
    const result = performanceManager.optimizePerformance();
    res.json({ success: true, data: result });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على مقاييس الأداء
 */
router.get('/performance/metrics', requirePermission('students.view'), async (req, res) => {
  try {
    const metrics = performanceManager.getPerformanceMetrics(req.query.operation);
    res.json({ success: true, data: metrics });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تقرير الأداء
 */
router.get('/performance/report', requirePermission('students.view'), async (req, res) => {
  try {
    const report = performanceManager.getPerformanceReport();
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Security ==========

/**
 * الحصول على سجلات الوصول
 */
router.get('/security/access-logs', requirePermission('students.view'), async (req, res) => {
  try {
    const logs = securityManager.getAccessLogs(req.query);
    res.json({ success: true, data: logs });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على الأحداث الأمنية
 */
router.get('/security/events', requirePermission('students.view'), async (req, res) => {
  try {
    const events = securityManager.getSecurityEvents(req.query);
    res.json({ success: true, data: events });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تقرير الأمان
 */
router.get('/security/report', requirePermission('students.view'), async (req, res) => {
  try {
    const report = securityManager.getSecurityReport();
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== AI Integration ==========

/**
 * تحليل التقدم باستخدام الذكاء الاصطناعي
 */
router.get(
  '/students/:studentId/ai/progress',
  requirePermission('students.view'),
  async (req, res) => {
    try {
      const analysis = await aiIntegration.analyzeProgressWithAI(req.params.studentId);
      res.json({ success: true, data: analysis });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * تحليل المخاطر باستخدام الذكاء الاصطناعي
 */
router.get(
  '/students/:studentId/ai/risks',
  requirePermission('students.view'),
  async (req, res) => {
    try {
      const analysis = await aiIntegration.analyzeRisksWithAI(req.params.studentId);
      res.json({ success: true, data: analysis });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * تحليل شامل باستخدام الذكاء الاصطناعي
 */
router.get(
  '/students/:studentId/ai/comprehensive',
  requirePermission('students.view'),
  async (req, res) => {
    try {
      const analysis = await aiIntegration.comprehensiveAIAnalysis(req.params.studentId);
      res.json({ success: true, data: analysis });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Cloud Integration ==========

/**
 * تسجيل مزود سحابي
 */
router.post('/cloud/providers', requirePermission('students.edit'), async (req, res) => {
  try {
    const provider = cloudIntegration.registerCloudProvider(req.body);
    res.json({ success: true, data: provider });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * رفع ملف طالب إلى السحابة
 */
router.post(
  '/cloud/upload/:providerId/:studentId',
  requirePermission('students.edit'),
  async (req, res) => {
    try {
      const result = await cloudIntegration.uploadToCloud(
        req.params.providerId,
        req.params.studentId
      );
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * مزامنة مع السحابة
 */
router.post('/cloud/sync/:providerId', requirePermission('students.edit'), async (req, res) => {
  try {
    const result = await cloudIntegration.syncWithCloud(req.params.providerId);
    res.json({ success: true, data: result });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تقرير التكامل السحابي
 */
router.get('/cloud/report', requirePermission('students.view'), async (req, res) => {
  try {
    const report = cloudIntegration.getCloudReport();
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Statistics ==========

/**
 * الحصول على إحصائيات شاملة
 */
router.get('/statistics/comprehensive', requirePermission('students.view'), async (req, res) => {
  try {
    const statistics = statisticsManager.getComprehensiveStatistics(req.query);
    res.json({ success: true, data: statistics });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تقرير إحصائي شامل
 */
router.get('/statistics/report', requirePermission('students.view'), async (req, res) => {
  try {
    const report = statisticsManager.getDetailedReport(req.query);
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Monitoring ==========

/**
 * مراقبة طالب
 */
router.post(
  '/students/:studentId/monitor',
  requirePermission('students.view'),
  async (req, res) => {
    try {
      const monitoring = await monitoringManager.monitorStudent(req.params.studentId);
      res.json({ success: true, data: monitoring });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * مراقبة جميع الطلاب
 */
router.post('/monitor/all', requirePermission('students.view'), async (req, res) => {
  try {
    const result = await monitoringManager.monitorAllStudents(req.body);
    res.json({ success: true, data: result });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على التنبيهات
 */
router.get('/monitoring/alerts', requirePermission('students.view'), async (req, res) => {
  try {
    const alerts = monitoringManager.getAlerts(req.query);
    res.json({ success: true, data: alerts });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تحديد تنبيه كمقروء
 */
router.post(
  '/monitoring/alerts/:id/acknowledge',
  requirePermission('students.edit'),
  async (req, res) => {
    try {
      const alert = monitoringManager.acknowledgeAlert(req.params.id);
      res.json({ success: true, data: alert });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * تقرير المراقبة
 */
router.get('/monitoring/report', requirePermission('students.view'), async (req, res) => {
  try {
    const report = monitoringManager.getMonitoringReport();
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Smart Recommendations ==========

/**
 * توليد توصيات ذكية شاملة
 */
router.get(
  '/students/:studentId/recommendations/smart',
  requirePermission('students.view'),
  async (req, res) => {
    try {
      const recommendations = await smartRecommendations.generateSmartRecommendations(
        req.params.studentId
      );
      res.json({ success: true, data: recommendations });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * الحصول على توصيات مخصصة
 */
router.get(
  '/students/:studentId/recommendations/personalized',
  requirePermission('students.view'),
  async (req, res) => {
    try {
      const recommendations = smartRecommendations.getPersonalizedRecommendations(
        req.params.studentId,
        req.query
      );
      res.json({ success: true, data: recommendations });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * الحصول على توصيات بناءً على أنماط مماثلة
 */
router.get(
  '/students/:studentId/recommendations/similar',
  requirePermission('students.view'),
  async (req, res) => {
    try {
      const recommendations = smartRecommendations.getRecommendationsBySimilarPatterns(
        req.params.studentId
      );
      res.json({ success: true, data: recommendations });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Device Integration ==========

/**
 * تسجيل جهاز ذكي
 */
router.post('/devices', requirePermission('students.edit'), async (req, res) => {
  try {
    const device = deviceIntegration.registerDevice(req.body);
    res.json({ success: true, data: device });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * مزامنة بيانات من جهاز
 */
router.post('/devices/:deviceId/sync', requirePermission('students.edit'), async (req, res) => {
  try {
    const result = await deviceIntegration.syncDeviceData(req.params.deviceId, req.body);
    res.json({ success: true, data: result });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على بيانات جهاز
 */
router.get(
  '/students/:studentId/devices/data',
  requirePermission('students.view'),
  async (req, res) => {
    try {
      const data = deviceIntegration.getDeviceData(req.params.studentId, req.query);
      res.json({ success: true, data });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * تقرير التكامل مع الأجهزة
 */
router.get('/devices/report', requirePermission('students.view'), async (req, res) => {
  try {
    const report = deviceIntegration.getDeviceReport();
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Mobile Integration ==========

/**
 * تسجيل تطبيق محمول
 */
router.post('/mobile/apps', requirePermission('students.edit'), async (req, res) => {
  try {
    const app = mobileIntegration.registerMobileApp(req.body);
    res.json({ success: true, data: app });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تسجيل جلسة تطبيق
 */
router.post('/mobile/sessions', async (req, res) => {
  try {
    const session = mobileIntegration.registerAppSession(req.body);
    res.json({ success: true, data: session });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * مزامنة بيانات من التطبيق
 */
router.post('/mobile/apps/:appId/sync', requirePermission('students.edit'), async (req, res) => {
  try {
    const result = await mobileIntegration.syncAppData(req.params.appId, req.body);
    res.json({ success: true, data: result });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * الحصول على بيانات للتطبيق
 */
router.get(
  '/mobile/apps/:appId/students/:studentId',
  requirePermission('students.view'),
  async (req, res) => {
    try {
      const data = mobileIntegration.getAppData(req.params.appId, req.params.studentId);
      res.json({ success: true, data });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * تقرير التكامل مع التطبيقات المحمولة
 */
router.get('/mobile/report', requirePermission('students.view'), async (req, res) => {
  try {
    const report = mobileIntegration.getMobileAppReport();
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Government Integration ==========

/**
 * التحقق من بيانات طالب مع نظام حكومي
 */
router.post(
  '/students/:studentId/government/:systemId/verify',
  requirePermission('students.view'),
  async (req, res) => {
    try {
      const verification = await governmentIntegration.verifyWithGovernmentSystem(
        req.params.systemId,
        req.params.studentId
      );
      res.json({ success: true, data: verification });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * مزامنة مع نظام حكومي
 */
router.post(
  '/students/:studentId/government/:systemId/sync',
  requirePermission('students.edit'),
  async (req, res) => {
    try {
      const result = await governmentIntegration.syncWithGovernmentSystem(
        req.params.systemId,
        req.params.studentId
      );
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * تقرير التكامل الحكومي
 */
router.get('/government/report', requirePermission('students.view'), async (req, res) => {
  try {
    const report = governmentIntegration.getGovernmentIntegrationReport();
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Insurance Integration ==========

/**
 * التحقق من تأمين طالب
 */
router.post(
  '/students/:studentId/insurance/:providerId/verify',
  requirePermission('students.view'),
  async (req, res) => {
    try {
      const verification = await insuranceIntegration.verifyInsurance(
        req.params.studentId,
        req.params.providerId
      );
      res.json({ success: true, data: verification });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * طلب تفويض علاج
 */
router.post(
  '/students/:studentId/insurance/:providerId/authorize',
  requirePermission('students.edit'),
  async (req, res) => {
    try {
      const authorization = await insuranceIntegration.requestAuthorization(
        req.params.studentId,
        req.params.providerId,
        req.body
      );
      res.json({ success: true, data: authorization });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * تقديم مطالبة تأمين
 */
router.post(
  '/students/:studentId/insurance/:providerId/claim',
  requirePermission('students.edit'),
  async (req, res) => {
    try {
      const claim = await insuranceIntegration.submitClaim(
        req.params.studentId,
        req.params.providerId,
        req.body
      );
      res.json({ success: true, data: claim });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * الحصول على مطالبات طالب
 */
router.get(
  '/students/:studentId/insurance/claims',
  requirePermission('students.view'),
  async (req, res) => {
    try {
      const claims = insuranceIntegration.getStudentClaims(req.params.studentId, req.query);
      res.json({ success: true, data: claims });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * تقرير التكامل مع التأمين
 */
router.get('/insurance/report', requirePermission('students.view'), async (req, res) => {
  try {
    const report = insuranceIntegration.getInsuranceReport();
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Advanced Predictive Analytics ==========

/**
 * التنبؤ بنجاح العلاج
 */
router.get(
  '/students/:studentId/predictive/treatment-success',
  requirePermission('students.view'),
  async (req, res) => {
    try {
      const prediction = await advancedPredictiveAnalytics.predictTreatmentSuccess(
        req.params.studentId
      );
      res.json({ success: true, data: prediction });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * التنبؤ باحتياجات الموارد
 */
router.get(
  '/students/:studentId/predictive/resource-needs',
  requirePermission('students.view'),
  async (req, res) => {
    try {
      const timeframe = parseInt(req.query.timeframe) || 30;
      const prediction = await advancedPredictiveAnalytics.predictResourceNeeds(
        req.params.studentId,
        timeframe
      );
      res.json({ success: true, data: prediction });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * التنبؤ بمدة العلاج
 */
router.get(
  '/students/:studentId/predictive/treatment-duration',
  requirePermission('students.view'),
  async (req, res) => {
    try {
      const prediction = await advancedPredictiveAnalytics.predictTreatmentDuration(
        req.params.studentId
      );
      res.json({ success: true, data: prediction });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * التنبؤ بمخاطر الانسحاب
 */
router.get(
  '/students/:studentId/predictive/dropout-risk',
  requirePermission('students.view'),
  async (req, res) => {
    try {
      const prediction = await advancedPredictiveAnalytics.predictDropoutRisk(req.params.studentId);
      res.json({ success: true, data: prediction });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * تحليل تنبؤي شامل
 */
router.get(
  '/students/:studentId/predictive/comprehensive',
  requirePermission('students.view'),
  async (req, res) => {
    try {
      const analysis = await advancedPredictiveAnalytics.comprehensivePredictiveAnalysis(
        req.params.studentId
      );
      res.json({ success: true, data: analysis });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

// ========== Educational Integration ==========

/**
 * مزامنة مع نظام تعليمي
 */
router.post(
  '/students/:studentId/educational/:systemId/sync',
  requirePermission('students.edit'),
  async (req, res) => {
    try {
      const result = await educationalIntegration.syncWithEducationalSystem(
        req.params.systemId,
        req.params.studentId
      );
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * مزامنة الدرجات
 */
router.post(
  '/students/:studentId/educational/:systemId/grades',
  requirePermission('students.view'),
  async (req, res) => {
    try {
      const result = await educationalIntegration.syncGrades(
        req.params.systemId,
        req.params.studentId
      );
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * مزامنة الحضور
 */
router.post(
  '/students/:studentId/educational/:systemId/attendance',
  requirePermission('students.view'),
  async (req, res) => {
    try {
      const result = await educationalIntegration.syncAttendance(
        req.params.systemId,
        req.params.studentId
      );
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * تقرير التكامل التعليمي
 */
router.get('/educational/report', requirePermission('students.view'), async (req, res) => {
  try {
    const report = educationalIntegration.getEducationalIntegrationReport();
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Medical Integration ==========

/**
 * مزامنة السجلات الطبية
 */
router.post(
  '/students/:studentId/medical/:systemId/sync',
  requirePermission('students.edit'),
  async (req, res) => {
    try {
      const result = await medicalIntegration.syncMedicalRecords(
        req.params.systemId,
        req.params.studentId
      );
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * مزامنة نتائج المختبرات
 */
router.post(
  '/students/:studentId/medical/:systemId/lab-results',
  requirePermission('students.view'),
  async (req, res) => {
    try {
      const result = await medicalIntegration.syncLabResults(
        req.params.systemId,
        req.params.studentId
      );
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * مزامنة الأدوية
 */
router.post(
  '/students/:studentId/medical/:systemId/medications',
  requirePermission('students.view'),
  async (req, res) => {
    try {
      const result = await medicalIntegration.syncMedications(
        req.params.systemId,
        req.params.studentId
      );
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * تقرير التكامل الطبي
 */
router.get('/medical/report', requirePermission('students.view'), async (req, res) => {
  try {
    const report = medicalIntegration.getMedicalIntegrationReport();
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Communication Integration ==========

/**
 * إرسال رسالة عبر قناة اتصال
 */
router.post(
  '/students/:studentId/communication/:channelId/send',
  requirePermission('students.edit'),
  async (req, res) => {
    try {
      const result = await communicationIntegration.sendMessage(
        req.params.channelId,
        req.params.studentId,
        req.body
      );
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * إرسال إشعار تلقائي
 */
router.post(
  '/students/:studentId/communication/:channelId/notify',
  requirePermission('students.edit'),
  async (req, res) => {
    try {
      const result = await communicationIntegration.sendAutomaticNotification(
        req.params.channelId,
        req.params.studentId,
        req.body.notificationType,
        req.body.data
      );
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * الحصول على الرسائل
 */
router.get('/communication/messages', requirePermission('students.view'), async (req, res) => {
  try {
    const messages = communicationIntegration.getMessages(req.query);
    res.json({ success: true, data: messages });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * تقرير التكامل مع الاتصالات
 */
router.get('/communication/report', requirePermission('students.view'), async (req, res) => {
  try {
    const report = communicationIntegration.getCommunicationReport();
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Payment Integration ==========

/**
 * معالجة دفعة
 */
router.post(
  '/students/:studentId/payment/:systemId/process',
  requirePermission('students.edit'),
  async (req, res) => {
    try {
      const result = await paymentIntegration.processPayment(
        req.params.systemId,
        req.params.studentId,
        req.body
      );
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * الاستعلام عن دفعة
 */
router.get(
  '/payment/:systemId/inquire/:transactionId',
  requirePermission('students.view'),
  async (req, res) => {
    try {
      const result = await paymentIntegration.inquirePayment(
        req.params.systemId,
        req.params.transactionId
      );
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * استرداد دفعة
 */
router.post(
  '/payment/:systemId/refund/:transactionId',
  requirePermission('students.edit'),
  async (req, res) => {
    try {
      const result = await paymentIntegration.refundPayment(
        req.params.systemId,
        req.params.transactionId,
        req.body.amount
      );
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * الحصول على سجل الدفعات
 */
router.get(
  '/students/:studentId/payment/history',
  requirePermission('students.view'),
  async (req, res) => {
    try {
      const history = paymentIntegration.getPaymentHistory(req.params.studentId, req.query);
      res.json({ success: true, data: history });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * تقرير التكامل مع أنظمة الدفع
 */
router.get('/payment/report', requirePermission('students.view'), async (req, res) => {
  try {
    const report = paymentIntegration.getPaymentIntegrationReport();
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== HR Integration ==========

/**
 * تعيين موظف لطالب
 */
router.post(
  '/students/:studentId/hr/assign',
  requirePermission('students.edit'),
  async (req, res) => {
    try {
      const result = await hrIntegration.assignStaffToStudent(
        req.params.studentId,
        req.body.staffId,
        req.body.role,
        req.body.startDate
      );
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * إلغاء تعيين موظف
 */
router.post(
  '/students/:studentId/hr/unassign',
  requirePermission('students.edit'),
  async (req, res) => {
    try {
      const result = await hrIntegration.unassignStaffFromStudent(
        req.params.studentId,
        req.body.staffId
      );
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * مزامنة مع نظام الموارد البشرية
 */
router.post(
  '/students/:studentId/hr/:systemId/sync',
  requirePermission('students.edit'),
  async (req, res) => {
    try {
      const result = await hrIntegration.syncWithHRSystem(
        req.params.systemId,
        req.params.studentId
      );
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * الحصول على الموظفين المعينين
 */
router.get(
  '/students/:studentId/hr/staff',
  requirePermission('students.view'),
  async (req, res) => {
    try {
      const staff = hrIntegration.getAssignedStaff(req.params.studentId);
      res.json({ success: true, data: staff });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * تقرير التكامل مع الموارد البشرية
 */
router.get('/hr/report', requirePermission('students.view'), async (req, res) => {
  try {
    const report = hrIntegration.getHRIntegrationReport();
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== Accounting Integration ==========

/**
 * تسجيل معاملة مالية
 */
router.post(
  '/students/:studentId/accounting/:systemId/transaction',
  requirePermission('students.edit'),
  async (req, res) => {
    try {
      const result = await accountingIntegration.recordTransaction(
        req.params.systemId,
        req.params.studentId,
        req.body
      );
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * إنشاء فاتورة
 */
router.post(
  '/students/:studentId/accounting/:systemId/invoice',
  requirePermission('students.edit'),
  async (req, res) => {
    try {
      const result = await accountingIntegration.createInvoice(
        req.params.systemId,
        req.params.studentId,
        req.body
      );
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * مزامنة مع نظام المحاسبة
 */
router.post(
  '/students/:studentId/accounting/:systemId/sync',
  requirePermission('students.edit'),
  async (req, res) => {
    try {
      const result = await accountingIntegration.syncWithAccountingSystem(
        req.params.systemId,
        req.params.studentId
      );
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * الحصول على السجل المالي
 */
router.get(
  '/students/:studentId/accounting/history',
  requirePermission('students.view'),
  async (req, res) => {
    try {
      const history = accountingIntegration.getFinancialHistory(req.params.studentId, req.query);
      res.json({ success: true, data: history });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }
);

/**
 * تقرير التكامل مع المحاسبة
 */
router.get('/accounting/report', requirePermission('students.view'), async (req, res) => {
  try {
    const report = accountingIntegration.getAccountingIntegrationReport();
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
