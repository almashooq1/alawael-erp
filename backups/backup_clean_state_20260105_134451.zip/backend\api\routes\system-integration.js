/**
 * System Integration Routes
 * مسارات تكامل الأنظمة
 */

const express = require('express');
const router = express.Router();
const systemIntegration = require('../../shared/utils/system-integration');
const analyticsDashboard = require('../../shared/utils/analytics-dashboard');
const notificationManager = require('../../shared/utils/notification-manager');
const { authenticateToken, requireAdmin } = require('../middleware/auth-middleware');

// Initialize integrations
systemIntegration.integrateWithAnalytics(analyticsDashboard);
systemIntegration.integrateWithNotifications(notificationManager);

// Register services from SERVICES-INDEX.md
const services = [
  { name: 'gamification-service', port: 3032, url: 'http://localhost:3032' },
  { name: 'budget-service', port: 3033, url: 'http://localhost:3033' },
  { name: 'training-service', port: 3034, url: 'http://localhost:3034' },
  { name: 'quality-service', port: 3035, url: 'http://localhost:3035' },
  { name: 'social-service', port: 3036, url: 'http://localhost:3036' },
  { name: 'volunteer-service', port: 3037, url: 'http://localhost:3037' },
  { name: 'partnership-service', port: 3038, url: 'http://localhost:3038' },
  { name: 'innovation-service', port: 3039, url: 'http://localhost:3039' },
  { name: 'community-partnership-service', port: 3040, url: 'http://localhost:3040' },
  { name: 'lms-service', port: 3031, url: 'http://localhost:3031' },
  { name: 'services-gateway', port: 3050, url: 'http://localhost:3050' },
];

// Auto-register services
services.forEach(service => {
  systemIntegration.registerService(service.name, {
    port: service.port,
    url: service.url,
    type: 'microservice',
  });
});

// Get integration status
router.get('/status', authenticateToken, (req, res) => {
  try {
    const status = systemIntegration.getIntegrationStatus();
    res.json({
      success: true,
      data: status,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get all services
router.get('/services', authenticateToken, (req, res) => {
  try {
    const services = systemIntegration.getAllServices();
    res.json({
      success: true,
      data: services,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Register new service (admin only)
router.post('/services', requireAdmin, (req, res) => {
  try {
    const { name, port, url, type } = req.body;

    if (!name || !url) {
      return res.status(400).json({
        success: false,
        error: 'Service name and URL are required',
      });
    }

    const success = systemIntegration.registerService(name, {
      port,
      url,
      type: type || 'microservice',
    });

    if (success) {
      res.json({
        success: true,
        message: 'Service registered successfully',
        data: systemIntegration.getService(name),
      });
    } else {
      res.status(400).json({
        success: false,
        error: 'Failed to register service',
      });
    }
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Connect services
router.post('/connect', requireAdmin, (req, res) => {
  try {
    const { service1, service2, type } = req.body;

    if (!service1 || !service2) {
      return res.status(400).json({
        success: false,
        error: 'Both service1 and service2 are required',
      });
    }

    const connectionId = systemIntegration.connectServices(service1, service2, type || 'api');

    res.json({
      success: true,
      message: 'Services connected successfully',
      data: {
        connectionId,
        ...systemIntegration.getConnections(service1)[0],
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Check service health
router.get('/health/:serviceName', authenticateToken, async (req, res) => {
  try {
    const { serviceName } = req.params;
    const health = await systemIntegration.checkServiceHealth(serviceName);

    res.json({
      success: true,
      data: {
        service: serviceName,
        ...health,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Check all services health
router.get('/health', authenticateToken, async (req, res) => {
  try {
    const health = await systemIntegration.checkAllServicesHealth();
    res.json({
      success: true,
      data: health,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Get service connections
router.get('/connections/:serviceName', authenticateToken, (req, res) => {
  try {
    const { serviceName } = req.params;
    const connections = systemIntegration.getConnections(serviceName);

    res.json({
      success: true,
      data: {
        service: serviceName,
        connections,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

module.exports = router;
