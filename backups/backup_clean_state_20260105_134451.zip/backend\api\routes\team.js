/**
 * 👨‍⚕️ Team Management Routes
 * مسارات إدارة الفريق الطبي والعلاجي
 */

const express = require('express');
const router = express.Router();
const Therapist = (() => {
  try {
    return require('../models/Therapist');
  } catch (e) {
    return {
      findAll: async () => [],
      findByPk: async () => null,
      create: async d => ({ id: 'mock-id', ...d }),
      update: async () => [1],
      destroy: async () => 1,
    };
  }
})();
const Doctor = (() => {
  try {
    return require('../models/Doctor');
  } catch (e) {
    return {
      findAll: async () => [],
      findByPk: async () => null,
      create: async d => ({ id: 'mock-id', ...d }),
      update: async () => [1],
      destroy: async () => 1,
    };
  }
})();
const Nurse = (() => {
  try {
    return require('../models/Nurse');
  } catch (e) {
    return {
      findAll: async () => [],
      findByPk: async () => null,
      create: async d => ({ id: 'mock-id', ...d }),
      update: async () => [1],
      destroy: async () => 1,
    };
  }
})();
const Administrator = (() => {
  try {
    return require('../models/Administrator');
  } catch (e) {
    return {
      findAll: async () => [],
      findByPk: async () => null,
      create: async d => ({ id: 'mock-id', ...d }),
      update: async () => [1],
      destroy: async () => 1,
    };
  }
})();
const authenticateToken = require('../middleware/authenticateToken');
const logger = require('../../shared/logging/logger');

// Real-time event emitter (if available)
let io = null;
try {
  const realtimeModule = require('../realtime');
  io = realtimeModule.io;
} catch (error) {
  // Real-time not available
}

/**
 * Emit real-time event
 */
function emitEvent(eventType, entityType, data) {
  if (io) {
    io.emit('team:update', {
      action: eventType,
      entityType: entityType,
      entityId: data.id,
      data: data,
    });
  }
}

// Apply authentication to all routes
router.use(authenticateToken);

/**
 * Therapists Routes
 */
router.get('/therapists', async (req, res) => {
  try {
    const therapists = await Therapist.findAll({
      order: [['name', 'ASC']],
    });
    res.json(therapists);
  } catch (error) {
    logger.error('Error fetching therapists:', error);
    res.status(500).json({ error: 'خطأ في جلب المعالجين' });
  }
});

router.post('/therapists', async (req, res) => {
  try {
    const therapist = await Therapist.create(req.body);
    emitEvent('create', 'therapist', therapist);
    logger.info('Therapist created', { id: therapist.id, name: therapist.name });
    res.status(201).json(therapist);
  } catch (error) {
    logger.error('Error creating therapist:', error);
    res.status(400).json({ error: 'خطأ في إضافة المعالج' });
  }
});

router.put('/therapists/:id', async (req, res) => {
  try {
    const [updated] = await Therapist.update(req.body, {
      where: { id: req.params.id },
    });
    if (updated) {
      const therapist = await Therapist.findByPk(req.params.id);
      emitEvent('update', 'therapist', therapist);
      logger.info('Therapist updated', { id: therapist.id });
      res.json(therapist);
    } else {
      res.status(404).json({ error: 'المعالج غير موجود' });
    }
  } catch (error) {
    logger.error('Error updating therapist:', error);
    res.status(400).json({ error: 'خطأ في تحديث المعالج' });
  }
});

router.delete('/therapists/:id', async (req, res) => {
  try {
    const deleted = await Therapist.destroy({
      where: { id: req.params.id },
    });
    if (deleted) {
      emitEvent('delete', 'therapist', { id: req.params.id });
      logger.info('Therapist deleted', { id: req.params.id });
      res.json({ message: 'تم حذف المعالج بنجاح' });
    } else {
      res.status(404).json({ error: 'المعالج غير موجود' });
    }
  } catch (error) {
    logger.error('Error deleting therapist:', error);
    res.status(400).json({ error: 'خطأ في حذف المعالج' });
  }
});

/**
 * Doctors Routes
 */
router.get('/doctors', async (req, res) => {
  try {
    const doctors = await Doctor.findAll({
      order: [['name', 'ASC']],
    });
    res.json(doctors);
  } catch (error) {
    logger.error('Error fetching doctors:', error);
    res.status(500).json({ error: 'خطأ في جلب الأطباء' });
  }
});

router.post('/doctors', async (req, res) => {
  try {
    const doctor = await Doctor.create(req.body);
    emitEvent('create', 'doctor', doctor);
    logger.info('Doctor created', { id: doctor.id, name: doctor.name });
    res.status(201).json(doctor);
  } catch (error) {
    logger.error('Error creating doctor:', error);
    res.status(400).json({ error: 'خطأ في إضافة الطبيب' });
  }
});

router.put('/doctors/:id', async (req, res) => {
  try {
    const [updated] = await Doctor.update(req.body, {
      where: { id: req.params.id },
    });
    if (updated) {
      const doctor = await Doctor.findByPk(req.params.id);
      emitEvent('update', 'doctor', doctor);
      logger.info('Doctor updated', { id: doctor.id });
      res.json(doctor);
    } else {
      res.status(404).json({ error: 'الطبيب غير موجود' });
    }
  } catch (error) {
    logger.error('Error updating doctor:', error);
    res.status(400).json({ error: 'خطأ في تحديث الطبيب' });
  }
});

router.delete('/doctors/:id', async (req, res) => {
  try {
    const deleted = await Doctor.destroy({
      where: { id: req.params.id },
    });
    if (deleted) {
      emitEvent('delete', 'doctor', { id: req.params.id });
      logger.info('Doctor deleted', { id: req.params.id });
      res.json({ message: 'تم حذف الطبيب بنجاح' });
    } else {
      res.status(404).json({ error: 'الطبيب غير موجود' });
    }
  } catch (error) {
    logger.error('Error deleting doctor:', error);
    res.status(400).json({ error: 'خطأ في حذف الطبيب' });
  }
});

/**
 * Nurses Routes
 */
router.get('/nurses', async (req, res) => {
  try {
    const nurses = await Nurse.findAll({
      order: [['name', 'ASC']],
    });
    res.json(nurses);
  } catch (error) {
    logger.error('Error fetching nurses:', error);
    res.status(500).json({ error: 'خطأ في جلب الممرضين' });
  }
});

router.post('/nurses', async (req, res) => {
  try {
    const nurse = await Nurse.create(req.body);
    emitEvent('create', 'nurse', nurse);
    logger.info('Nurse created', { id: nurse.id, name: nurse.name });
    res.status(201).json(nurse);
  } catch (error) {
    logger.error('Error creating nurse:', error);
    res.status(400).json({ error: 'خطأ في إضافة الممرض' });
  }
});

router.put('/nurses/:id', async (req, res) => {
  try {
    const [updated] = await Nurse.update(req.body, {
      where: { id: req.params.id },
    });
    if (updated) {
      const nurse = await Nurse.findByPk(req.params.id);
      emitEvent('update', 'nurse', nurse);
      logger.info('Nurse updated', { id: nurse.id });
      res.json(nurse);
    } else {
      res.status(404).json({ error: 'الممرض غير موجود' });
    }
  } catch (error) {
    logger.error('Error updating nurse:', error);
    res.status(400).json({ error: 'خطأ في تحديث الممرض' });
  }
});

router.delete('/nurses/:id', async (req, res) => {
  try {
    const deleted = await Nurse.destroy({
      where: { id: req.params.id },
    });
    if (deleted) {
      emitEvent('delete', 'nurse', { id: req.params.id });
      logger.info('Nurse deleted', { id: req.params.id });
      res.json({ message: 'تم حذف الممرض بنجاح' });
    } else {
      res.status(404).json({ error: 'الممرض غير موجود' });
    }
  } catch (error) {
    logger.error('Error deleting nurse:', error);
    res.status(400).json({ error: 'خطأ في حذف الممرض' });
  }
});

module.exports = router;
