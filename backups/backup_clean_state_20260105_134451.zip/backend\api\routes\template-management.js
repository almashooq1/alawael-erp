/**
 * 📄 Template Management Routes
 * API routes for templates, categories, versions, and usage
 */

const express = require('express');
const router = express.Router();

// Mock data storage
const templates = [];
const categories = [];
const versions = [];
const usage = [];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Templates ====================

router.get('/templates', async (req, res) => {
  try {
    res.json({ success: true, data: templates });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/templates/:id', async (req, res) => {
  try {
    const template = templates.find(t => t.id === parseInt(req.params.id));
    if (!template) {
      return res.status(404).json({ success: false, error: 'Template not found' });
    }
    res.json({ success: true, data: template });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/templates', async (req, res) => {
  try {
    const template = {
      id: templates.length > 0 ? Math.max(...templates.map(t => t.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    templates.push(template);

    emitEvent('template:update', {
      action: 'create',
      entityType: 'template',
      entityId: template.id,
      data: template,
    });

    res.status(201).json({ success: true, data: template });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/templates/:id', async (req, res) => {
  try {
    const index = templates.findIndex(t => t.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Template not found' });
    }

    templates[index] = {
      ...templates[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    emitEvent('template:update', {
      action: 'update',
      entityType: 'template',
      entityId: templates[index].id,
      data: templates[index],
    });

    res.json({ success: true, data: templates[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.delete('/templates/:id', async (req, res) => {
  try {
    const index = templates.findIndex(t => t.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Template not found' });
    }

    const deletedTemplate = templates[index];
    templates.splice(index, 1);

    emitEvent('template:update', {
      action: 'delete',
      entityType: 'template',
      entityId: deletedTemplate.id,
    });

    res.json({ success: true, message: 'Template deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Categories ====================

router.get('/categories', async (req, res) => {
  try {
    res.json({ success: true, data: categories });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/categories', async (req, res) => {
  try {
    const category = {
      id: categories.length > 0 ? Math.max(...categories.map(c => c.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    categories.push(category);

    emitEvent('template:update', {
      action: 'create',
      entityType: 'category',
      entityId: category.id,
      data: category,
    });

    res.status(201).json({ success: true, data: category });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Versions ====================

router.get('/versions', async (req, res) => {
  try {
    res.json({ success: true, data: versions });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/versions', async (req, res) => {
  try {
    const version = {
      id: versions.length > 0 ? Math.max(...versions.map(v => v.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    versions.push(version);

    emitEvent('template:update', {
      action: 'create',
      entityType: 'version',
      entityId: version.id,
      data: version,
    });

    res.status(201).json({ success: true, data: version });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Usage ====================

router.get('/usage', async (req, res) => {
  try {
    res.json({ success: true, data: usage });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/usage', async (req, res) => {
  try {
    const usageItem = {
      id: usage.length > 0 ? Math.max(...usage.map(u => u.id)) + 1 : 1,
      ...req.body,
      lastUsed: new Date().toISOString(),
    };
    usage.push(usageItem);

    emitEvent('template:update', {
      action: 'create',
      entityType: 'usage',
      entityId: usageItem.id,
      data: usageItem,
    });

    res.status(201).json({ success: true, data: usageItem });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
