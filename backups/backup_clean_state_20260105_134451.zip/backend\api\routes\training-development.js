/**
 * 🎓 Training & Development Management Routes
 * مسارات إدارة التدريب والتطوير
 */

const express = require('express');
const router = express.Router();
const TrainingProgram = require('../models/TrainingProgram');
const Course = require('../models/Course');
const authenticateToken = require('../middleware/authenticateToken');
const logger = require('../../shared/logging/logger');

// Real-time event emitter (if available)
let io = null;
try {
  const realtimeModule = require('../realtime');
  io = realtimeModule.io;
} catch (error) {
  // Real-time not available
}

/**
 * Emit real-time event
 */
function emitEvent(eventType, entityType, data) {
  if (io) {
    io.emit('trainingDevelopment:update', {
      action: eventType,
      entityType: entityType,
      entityId: data.id,
      data: data,
    });
  }
}

// Apply authentication to all routes
router.use(authenticateToken);

/**
 * Training Programs Routes
 */
router.get('/programs', async (req, res) => {
  try {
    const programs = await TrainingProgram.findAll({
      order: [['createdAt', 'DESC']],
    });
    res.json(programs);
  } catch (error) {
    logger.error('Error fetching training programs:', error);
    res.status(500).json({ error: 'خطأ في جلب البرامج التدريبية' });
  }
});

router.post('/programs', async (req, res) => {
  try {
    const program = await TrainingProgram.create(req.body);
    emitEvent('create', 'program', program);
    logger.info('Training program created', { id: program.id, name: program.name });
    res.status(201).json(program);
  } catch (error) {
    logger.error('Error creating training program:', error);
    res.status(400).json({ error: 'خطأ في إضافة البرنامج التدريبي' });
  }
});

/**
 * Courses Routes
 */
router.get('/courses', async (req, res) => {
  try {
    const courses = await Course.findAll({
      order: [['createdAt', 'DESC']],
    });
    res.json(courses);
  } catch (error) {
    logger.error('Error fetching courses:', error);
    res.status(500).json({ error: 'خطأ في جلب الدورات' });
  }
});

router.post('/courses', async (req, res) => {
  try {
    const course = await Course.create(req.body);
    emitEvent('create', 'course', course);
    logger.info('Course created', { id: course.id, name: course.name });
    res.status(201).json(course);
  } catch (error) {
    logger.error('Error creating course:', error);
    res.status(400).json({ error: 'خطأ في إضافة الدورة' });
  }
});

module.exports = router;
