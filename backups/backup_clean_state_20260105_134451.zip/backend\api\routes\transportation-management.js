/**
 * 🚐 Transportation Management Routes
 */

const express = require('express');
const router = express.Router();
const TransportationManager = require('../../shared/utils/transportation-manager');

const transportationManager = new TransportationManager();

// Vehicles
router.post('/vehicles', async (req, res) => {
  try {
    const vehicle = transportationManager.addVehicle(req.body);
    res.json({ success: true, data: vehicle });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/vehicles', async (req, res) => {
  try {
    const vehicles = transportationManager.getVehicles(req.query);
    res.json({ success: true, data: vehicles });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/vehicles/:id/location', async (req, res) => {
  try {
    const vehicle = transportationManager.updateVehicleLocation(req.params.id, req.body);
    res.json({ success: true, data: vehicle });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Drivers
router.post('/drivers', async (req, res) => {
  try {
    const driver = transportationManager.addDriver(req.body);
    res.json({ success: true, data: driver });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/drivers', async (req, res) => {
  try {
    const drivers = transportationManager.getDrivers(req.query);
    res.json({ success: true, data: drivers });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Trips
router.post('/trips', async (req, res) => {
  try {
    const trip = transportationManager.scheduleTrip(req.body);
    res.json({ success: true, data: trip });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/trips', async (req, res) => {
  try {
    const trips = transportationManager.getTrips(req.query);
    res.json({ success: true, data: trips });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/trips/:id/start', async (req, res) => {
  try {
    const trip = transportationManager.startTrip(req.params.id);
    res.json({ success: true, data: trip });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/trips/:id/complete', async (req, res) => {
  try {
    const trip = transportationManager.completeTrip(req.params.id, req.body);
    res.json({ success: true, data: trip });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Maintenance
router.post('/maintenance', async (req, res) => {
  try {
    const maintenance = transportationManager.scheduleMaintenance(req.body.vehicleId, req.body);
    res.json({ success: true, data: maintenance });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Stats
router.get('/stats', async (req, res) => {
  try {
    const stats = transportationManager.getTransportationStats(
      req.query.startDate || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
      req.query.endDate || new Date().toISOString()
    );
    res.json({ success: true, data: stats });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
