/**
 * 📋 Treatment Plans Management Routes
 * مسارات إدارة الخطط العلاجية
 */

const express = require('express');
const router = express.Router();
const TreatmentPlan = (() => {
  try {
    return require('../models/TreatmentPlan');
  } catch (e) {
    return {
      findAll: async () => [],
      findByPk: async () => null,
      create: async data => ({ id: 'mock-id', ...data }),
      update: async () => [1],
      destroy: async () => 1,
    };
  }
})();
const PlanTemplate = (() => {
  try {
    return require('../models/PlanTemplate');
  } catch (e) {
    return {
      findAll: async () => [],
      findByPk: async () => null,
      create: async data => ({ id: 'mock-id', ...data }),
      update: async () => [1],
      destroy: async () => 1,
    };
  }
})();
const PlanActivity = (() => {
  try {
    return require('../models/PlanActivity');
  } catch (e) {
    return {
      findAll: async () => [],
      findByPk: async () => null,
      create: async data => ({ id: 'mock-id', ...data }),
      update: async () => [1],
      destroy: async () => 1,
    };
  }
})();
const authenticateToken = require('../middleware/authenticateToken');
const logger = require('../../shared/logging/logger');

// Real-time event emitter (if available)
let io = null;
try {
  const realtimeModule = require('../realtime');
  io = realtimeModule.io;
} catch (error) {
  // Real-time not available
}

/**
 * Emit real-time event
 */
function emitEvent(eventType, entityType, data) {
  if (io) {
    io.emit('treatmentPlans:update', {
      action: eventType,
      entityType: entityType,
      entityId: data.id,
      data: data,
    });
  }
}

// Apply authentication to all routes
router.use(authenticateToken);

/**
 * Treatment Plans Routes
 */
router.get('/', async (req, res) => {
  try {
    const plans = await TreatmentPlan.findAll({
      order: [['createdAt', 'DESC']],
      limit: 100,
    });
    res.json(plans);
  } catch (error) {
    logger.error('Error fetching treatment plans:', error);
    res.status(500).json({ error: 'خطأ في جلب الخطط العلاجية' });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const plan = await TreatmentPlan.findByPk(req.params.id);
    if (!plan) {
      return res.status(404).json({ error: 'الخطة العلاجية غير موجودة' });
    }
    res.json(plan);
  } catch (error) {
    logger.error('Error fetching treatment plan:', error);
    res.status(500).json({ error: 'خطأ في جلب الخطة العلاجية' });
  }
});

router.post('/', async (req, res) => {
  try {
    const plan = await TreatmentPlan.create(req.body);
    emitEvent('create', 'plan', plan);
    logger.info('Treatment plan created', { id: plan.id, name: plan.name });
    res.status(201).json(plan);
  } catch (error) {
    logger.error('Error creating treatment plan:', error);
    res.status(400).json({ error: 'خطأ في إضافة الخطة العلاجية' });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const [updated] = await TreatmentPlan.update(req.body, {
      where: { id: req.params.id },
    });
    if (updated) {
      const plan = await TreatmentPlan.findByPk(req.params.id);
      emitEvent('update', 'plan', plan);
      logger.info('Treatment plan updated', { id: plan.id });
      res.json(plan);
    } else {
      res.status(404).json({ error: 'الخطة العلاجية غير موجودة' });
    }
  } catch (error) {
    logger.error('Error updating treatment plan:', error);
    res.status(400).json({ error: 'خطأ في تحديث الخطة العلاجية' });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    const deleted = await TreatmentPlan.destroy({
      where: { id: req.params.id },
    });
    if (deleted) {
      // Also delete related activities
      await PlanActivity.destroy({ where: { planId: req.params.id } });
      emitEvent('delete', 'plan', { id: req.params.id });
      logger.info('Treatment plan deleted', { id: req.params.id });
      res.json({ message: 'تم حذف الخطة العلاجية بنجاح' });
    } else {
      res.status(404).json({ error: 'الخطة العلاجية غير موجودة' });
    }
  } catch (error) {
    logger.error('Error deleting treatment plan:', error);
    res.status(400).json({ error: 'خطأ في حذف الخطة العلاجية' });
  }
});

/**
 * Plan Templates Routes
 */
router.get('/templates', async (req, res) => {
  try {
    const templates = await PlanTemplate.findAll({
      order: [['name', 'ASC']],
    });
    res.json(templates);
  } catch (error) {
    logger.error('Error fetching plan templates:', error);
    res.status(500).json({ error: 'خطأ في جلب قوالب الخطط' });
  }
});

router.post('/templates', async (req, res) => {
  try {
    const template = await PlanTemplate.create(req.body);
    emitEvent('create', 'template', template);
    logger.info('Plan template created', { id: template.id, name: template.name });
    res.status(201).json(template);
  } catch (error) {
    logger.error('Error creating plan template:', error);
    res.status(400).json({ error: 'خطأ في إضافة قالب الخطة' });
  }
});

/**
 * Plan Activities Routes
 */
router.get('/activities', async (req, res) => {
  try {
    const activities = await PlanActivity.findAll({
      order: [['createdAt', 'DESC']],
    });
    res.json(activities);
  } catch (error) {
    logger.error('Error fetching plan activities:', error);
    res.status(500).json({ error: 'خطأ في جلب أنشطة الخطط' });
  }
});

router.post('/activities', async (req, res) => {
  try {
    const activity = await PlanActivity.create(req.body);
    emitEvent('create', 'activity', activity);
    logger.info('Plan activity created', { id: activity.id, planId: activity.planId });
    res.status(201).json(activity);
  } catch (error) {
    logger.error('Error creating plan activity:', error);
    res.status(400).json({ error: 'خطأ في إضافة نشاط الخطة' });
  }
});

module.exports = router;
