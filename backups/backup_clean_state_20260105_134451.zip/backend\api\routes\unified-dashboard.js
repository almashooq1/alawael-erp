/**
 * 🎯 Unified Dashboard Routes
 * API routes for unified dashboard statistics and data
 */

const express = require('express');
const router = express.Router();

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Dashboard Statistics ====================

router.get('/statistics', async (req, res) => {
  try {
    // Aggregate statistics from various sources
    const stats = {
      patients: 0,
      sessions: 0,
      therapists: 0,
      appointments: 0,
      activePrograms: 0,
      completedSessions: 0,
      pendingTasks: 0,
      alerts: 0,
      todaySessions: 0,
      thisWeekSessions: 0,
      thisMonthSessions: 0,
    };

    // TODO: Load actual data from databases
    // For now, return mock data structure
    res.json({ success: true, data: stats });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Recent Activities ====================

router.get('/activities', async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 10;
    const activities = [];

    // TODO: Load actual activities from various modules
    // For now, return empty array
    res.json({ success: true, data: activities.slice(0, limit) });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Upcoming Appointments ====================

router.get('/appointments', async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 5;
    const appointments = [];

    // TODO: Load actual appointments
    res.json({ success: true, data: appointments.slice(0, limit) });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Pending Tasks ====================

router.get('/tasks', async (req, res) => {
  try {
    const tasks = [];

    // TODO: Load actual tasks
    res.json({ success: true, data: tasks });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Alerts ====================

router.get('/alerts', async (req, res) => {
  try {
    const alerts = [];

    // TODO: Load actual alerts
    res.json({ success: true, data: alerts });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Charts Data ====================

router.get('/charts/sessions-by-type', async (req, res) => {
  try {
    const data = {
      labels: [],
      data: [],
    };

    // TODO: Load actual chart data
    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/charts/progress-trend', async (req, res) => {
  try {
    const data = {
      labels: [],
      data: [],
    };

    // TODO: Load actual chart data
    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
