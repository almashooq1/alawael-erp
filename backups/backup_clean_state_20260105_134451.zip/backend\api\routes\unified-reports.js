/**
 * 📄 Unified Reports Routes
 * API routes for unified reports system
 */

const express = require('express');
const router = express.Router();

// Mock data storage
const reports = [];
const templates = [];
const scheduledReports = [];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Reports ====================

router.get('/', async (req, res) => {
  try {
    res.json({ success: true, data: reports });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/', async (req, res) => {
  try {
    const report = {
      id: reports.length > 0 ? Math.max(...reports.map(r => r.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    reports.push(report);

    emitEvent('reports:update', {
      action: 'create',
      entityType: 'report',
      entityId: report.id,
      data: report,
    });

    res.status(201).json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const report = reports.find(r => r.id === parseInt(req.params.id));
    if (!report) {
      return res.status(404).json({ success: false, error: 'Report not found' });
    }
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const index = reports.findIndex(r => r.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Report not found' });
    }

    reports[index] = {
      ...reports[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    emitEvent('reports:update', {
      action: 'update',
      entityType: 'report',
      entityId: reports[index].id,
      data: reports[index],
    });

    res.json({ success: true, data: reports[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    const index = reports.findIndex(r => r.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Report not found' });
    }

    const deletedReport = reports[index];
    reports.splice(index, 1);

    emitEvent('reports:update', {
      action: 'delete',
      entityType: 'report',
      entityId: deletedReport.id,
    });

    res.json({ success: true, message: 'Report deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Generate Report ====================

router.post('/generate', async (req, res) => {
  try {
    const { type, params = {} } = req.body;

    // TODO: Generate actual report based on type and params
    const report = {
      id: reports.length > 0 ? Math.max(...reports.map(r => r.id)) + 1 : 1,
      type,
      params,
      status: 'completed',
      generatedAt: new Date().toISOString(),
      data: {},
    };

    reports.push(report);

    emitEvent('reports:update', {
      action: 'create',
      entityType: 'report',
      entityId: report.id,
      data: report,
    });

    res.status(201).json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Export Report ====================

router.get('/:id/export', async (req, res) => {
  try {
    const { format = 'pdf' } = req.query;
    const report = reports.find(r => r.id === parseInt(req.params.id));

    if (!report) {
      return res.status(404).json({ success: false, error: 'Report not found' });
    }

    // TODO: Generate actual file export
    res.json({
      success: true,
      message: `Report exported as ${format}`,
      downloadUrl: `/api/reports/${report.id}/download?format=${format}`,
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Schedule Report ====================

router.post('/schedule', async (req, res) => {
  try {
    const scheduled = {
      id: scheduledReports.length > 0 ? Math.max(...scheduledReports.map(s => s.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
    };
    scheduledReports.push(scheduled);

    res.status(201).json({ success: true, data: scheduled });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/scheduled', async (req, res) => {
  try {
    res.json({ success: true, data: scheduledReports });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
