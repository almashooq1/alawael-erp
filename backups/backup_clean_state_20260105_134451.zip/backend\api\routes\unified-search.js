/**
 * 🔍 Unified Search Routes
 * API routes for unified search across all systems
 */

const express = require('express');
const router = express.Router();

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Search ====================

router.post('/search', async (req, res) => {
  try {
    const { query, filters = {} } = req.body;

    if (!query || query.trim().length === 0) {
      return res.json({
        success: true,
        results: {},
        total: 0,
      });
    }

    const searchQuery = query.trim().toLowerCase();
    const results = {
      patients: [],
      sessions: [],
      appointments: [],
      documents: [],
      reports: [],
    };

    // TODO: Implement actual search across databases
    // For now, return empty results structure

    // Example: Search in patients
    // const patients = await db.query('SELECT * FROM patients WHERE name LIKE ? OR id LIKE ?',
    //   [`%${searchQuery}%`, `%${searchQuery}%`]);
    // results.patients = patients;

    const total = Object.values(results).reduce((sum, arr) => sum + arr.length, 0);

    res.json({
      success: true,
      results,
      total,
      query: searchQuery,
      filters,
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Search Suggestions ====================

router.get('/suggestions', async (req, res) => {
  try {
    const { q } = req.query;

    if (!q || q.trim().length === 0) {
      return res.json({ success: true, suggestions: [] });
    }

    const query = q.trim().toLowerCase();
    const suggestions = [];

    // TODO: Implement actual suggestions
    // Example: Get popular search terms, recent searches, etc.

    res.json({
      success: true,
      suggestions: suggestions.slice(0, 10),
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Search History ====================

router.get('/history', async (req, res) => {
  try {
    const { userId } = req.query;

    // TODO: Load search history for user
    const history = [];

    res.json({
      success: true,
      history: history.slice(0, 10),
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/history', async (req, res) => {
  try {
    const { userId, query } = req.body;

    // TODO: Save search to history
    // await db.query('INSERT INTO search_history (user_id, query, created_at) VALUES (?, ?, ?)',
    //   [userId, query, new Date()]);

    res.json({
      success: true,
      message: 'Search saved to history',
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
