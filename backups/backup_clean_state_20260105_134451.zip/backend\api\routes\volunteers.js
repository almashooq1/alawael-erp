/**
 * 🙋 Volunteers Management Routes
 * مسارات إدارة المتطوعين
 */

const express = require('express');
const router = express.Router();
const Volunteer = require('../models/Volunteer');
const VolunteerActivity = require('../models/VolunteerActivity');
const VolunteerHours = require('../models/VolunteerHours');
const authenticateToken = require('../middleware/authenticateToken');
const logger = require('../../shared/logging/logger');

// Real-time event emitter (if available)
let io = null;
try {
  const realtimeModule = require('../realtime');
  io = realtimeModule.io;
} catch (error) {
  // Real-time not available
}

/**
 * Emit real-time event
 */
function emitEvent(eventType, entityType, data) {
  if (io) {
    io.emit('volunteers:update', {
      action: eventType,
      entityType: entityType,
      entityId: data.id,
      data: data,
    });
  }
}

// Apply authentication to all routes
router.use(authenticateToken);

/**
 * Volunteers Routes
 */
router.get('/', async (req, res) => {
  try {
    const volunteers = await Volunteer.findAll({
      order: [['createdAt', 'DESC']],
    });
    res.json(volunteers);
  } catch (error) {
    logger.error('Error fetching volunteers:', error);
    res.status(500).json({ error: 'خطأ في جلب المتطوعين' });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const volunteer = await Volunteer.findByPk(req.params.id);
    if (!volunteer) {
      return res.status(404).json({ error: 'المتطوع غير موجود' });
    }
    res.json(volunteer);
  } catch (error) {
    logger.error('Error fetching volunteer:', error);
    res.status(500).json({ error: 'خطأ في جلب المتطوع' });
  }
});

router.post('/', async (req, res) => {
  try {
    const volunteer = await Volunteer.create(req.body);
    emitEvent('create', 'volunteer', volunteer);
    logger.info('Volunteer created', { id: volunteer.id, name: volunteer.name });
    res.status(201).json(volunteer);
  } catch (error) {
    logger.error('Error creating volunteer:', error);
    res.status(400).json({ error: 'خطأ في إضافة المتطوع' });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const [updated] = await Volunteer.update(req.body, {
      where: { id: req.params.id },
    });
    if (updated) {
      const volunteer = await Volunteer.findByPk(req.params.id);
      emitEvent('update', 'volunteer', volunteer);
      logger.info('Volunteer updated', { id: volunteer.id });
      res.json(volunteer);
    } else {
      res.status(404).json({ error: 'المتطوع غير موجود' });
    }
  } catch (error) {
    logger.error('Error updating volunteer:', error);
    res.status(400).json({ error: 'خطأ في تحديث المتطوع' });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    const deleted = await Volunteer.destroy({
      where: { id: req.params.id },
    });
    if (deleted) {
      // Also delete related hours and activities
      await VolunteerHours.destroy({ where: { volunteerId: req.params.id } });
      emitEvent('delete', 'volunteer', { id: req.params.id });
      logger.info('Volunteer deleted', { id: req.params.id });
      res.json({ message: 'تم حذف المتطوع بنجاح' });
    } else {
      res.status(404).json({ error: 'المتطوع غير موجود' });
    }
  } catch (error) {
    logger.error('Error deleting volunteer:', error);
    res.status(400).json({ error: 'خطأ في حذف المتطوع' });
  }
});

/**
 * Volunteer Activities Routes
 */
router.get('/activities', async (req, res) => {
  try {
    const activities = await VolunteerActivity.findAll({
      order: [['date', 'DESC']],
    });
    res.json(activities);
  } catch (error) {
    logger.error('Error fetching volunteer activities:', error);
    res.status(500).json({ error: 'خطأ في جلب الأنشطة التطوعية' });
  }
});

router.post('/activities', async (req, res) => {
  try {
    const activity = await VolunteerActivity.create(req.body);
    emitEvent('create', 'activity', activity);
    logger.info('Volunteer activity created', { id: activity.id, title: activity.title });
    res.status(201).json(activity);
  } catch (error) {
    logger.error('Error creating volunteer activity:', error);
    res.status(400).json({ error: 'خطأ في إضافة النشاط التطوعي' });
  }
});

router.put('/activities/:id', async (req, res) => {
  try {
    const [updated] = await VolunteerActivity.update(req.body, {
      where: { id: req.params.id },
    });
    if (updated) {
      const activity = await VolunteerActivity.findByPk(req.params.id);
      emitEvent('update', 'activity', activity);
      logger.info('Volunteer activity updated', { id: activity.id });
      res.json(activity);
    } else {
      res.status(404).json({ error: 'النشاط التطوعي غير موجود' });
    }
  } catch (error) {
    logger.error('Error updating volunteer activity:', error);
    res.status(400).json({ error: 'خطأ في تحديث النشاط التطوعي' });
  }
});

router.delete('/activities/:id', async (req, res) => {
  try {
    const deleted = await VolunteerActivity.destroy({
      where: { id: req.params.id },
    });
    if (deleted) {
      emitEvent('delete', 'activity', { id: req.params.id });
      logger.info('Volunteer activity deleted', { id: req.params.id });
      res.json({ message: 'تم حذف النشاط التطوعي بنجاح' });
    } else {
      res.status(404).json({ error: 'النشاط التطوعي غير موجود' });
    }
  } catch (error) {
    logger.error('Error deleting volunteer activity:', error);
    res.status(400).json({ error: 'خطأ في حذف النشاط التطوعي' });
  }
});

/**
 * Volunteer Hours Routes
 */
router.get('/hours', async (req, res) => {
  try {
    const hours = await VolunteerHours.findAll({
      order: [['date', 'DESC']],
      limit: 100,
    });
    res.json(hours);
  } catch (error) {
    logger.error('Error fetching volunteer hours:', error);
    res.status(500).json({ error: 'خطأ في جلب ساعات التطوع' });
  }
});

router.post('/hours', async (req, res) => {
  try {
    const hours = await VolunteerHours.create(req.body);
    emitEvent('create', 'hours', hours);
    logger.info('Volunteer hours recorded', { id: hours.id, volunteerId: hours.volunteerId });
    res.status(201).json(hours);
  } catch (error) {
    logger.error('Error creating volunteer hours:', error);
    res.status(400).json({ error: 'خطأ في تسجيل ساعات التطوع' });
  }
});

router.put('/hours/:id', async (req, res) => {
  try {
    const [updated] = await VolunteerHours.update(req.body, {
      where: { id: req.params.id },
    });
    if (updated) {
      const hours = await VolunteerHours.findByPk(req.params.id);
      emitEvent('update', 'hours', hours);
      logger.info('Volunteer hours updated', { id: hours.id });
      res.json(hours);
    } else {
      res.status(404).json({ error: 'ساعات التطوع غير موجودة' });
    }
  } catch (error) {
    logger.error('Error updating volunteer hours:', error);
    res.status(400).json({ error: 'خطأ في تحديث ساعات التطوع' });
  }
});

router.delete('/hours/:id', async (req, res) => {
  try {
    const deleted = await VolunteerHours.destroy({
      where: { id: req.params.id },
    });
    if (deleted) {
      emitEvent('delete', 'hours', { id: req.params.id });
      logger.info('Volunteer hours deleted', { id: req.params.id });
      res.json({ message: 'تم حذف ساعات التطوع بنجاح' });
    } else {
      res.status(404).json({ error: 'ساعات التطوع غير موجودة' });
    }
  } catch (error) {
    logger.error('Error deleting volunteer hours:', error);
    res.status(400).json({ error: 'خطأ في حذف ساعات التطوع' });
  }
});

module.exports = router;
