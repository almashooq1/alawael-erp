/**
 * 🔄 Workflow Management Routes
 * API routes for workflows, steps, approvals, and tasks
 */

const express = require('express');
const router = express.Router();

// Mock data storage
const workflows = [];
const steps = [];
const approvals = [];
const tasks = [];

// Get Socket.IO instance
let io = null;
function setIO(socketIO) {
  io = socketIO;
}

function emitEvent(eventName, data) {
  if (io) {
    io.emit(eventName, data);
  }
}

// ==================== Workflows ====================

router.get('/workflows', async (req, res) => {
  try {
    res.json({ success: true, data: workflows });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/workflows/:id', async (req, res) => {
  try {
    const workflow = workflows.find(w => w.id === parseInt(req.params.id));
    if (!workflow) {
      return res.status(404).json({ success: false, error: 'Workflow not found' });
    }
    res.json({ success: true, data: workflow });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/workflows', async (req, res) => {
  try {
    const workflow = {
      id: workflows.length > 0 ? Math.max(...workflows.map(w => w.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    workflows.push(workflow);

    emitEvent('workflow:update', {
      action: 'create',
      entityType: 'workflow',
      entityId: workflow.id,
      data: workflow,
    });

    res.status(201).json({ success: true, data: workflow });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/workflows/:id', async (req, res) => {
  try {
    const index = workflows.findIndex(w => w.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Workflow not found' });
    }

    workflows[index] = {
      ...workflows[index],
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    emitEvent('workflow:update', {
      action: 'update',
      entityType: 'workflow',
      entityId: workflows[index].id,
      data: workflows[index],
    });

    res.json({ success: true, data: workflows[index] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.delete('/workflows/:id', async (req, res) => {
  try {
    const index = workflows.findIndex(w => w.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Workflow not found' });
    }

    const deletedWorkflow = workflows[index];
    workflows.splice(index, 1);

    emitEvent('workflow:update', {
      action: 'delete',
      entityType: 'workflow',
      entityId: deletedWorkflow.id,
    });

    res.json({ success: true, message: 'Workflow deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Steps ====================

router.get('/steps', async (req, res) => {
  try {
    res.json({ success: true, data: steps });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/steps', async (req, res) => {
  try {
    const step = {
      id: steps.length > 0 ? Math.max(...steps.map(s => s.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    steps.push(step);

    emitEvent('workflow:update', {
      action: 'create',
      entityType: 'step',
      entityId: step.id,
      data: step,
    });

    res.status(201).json({ success: true, data: step });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Approvals ====================

router.get('/approvals', async (req, res) => {
  try {
    res.json({ success: true, data: approvals });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/approvals', async (req, res) => {
  try {
    const approval = {
      id: approvals.length > 0 ? Math.max(...approvals.map(a => a.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    approvals.push(approval);

    emitEvent('workflow:update', {
      action: 'create',
      entityType: 'approval',
      entityId: approval.id,
      data: approval,
    });

    res.status(201).json({ success: true, data: approval });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==================== Tasks ====================

router.get('/tasks', async (req, res) => {
  try {
    res.json({ success: true, data: tasks });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/tasks', async (req, res) => {
  try {
    const task = {
      id: tasks.length > 0 ? Math.max(...tasks.map(t => t.id)) + 1 : 1,
      ...req.body,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    tasks.push(task);

    emitEvent('workflow:update', {
      action: 'create',
      entityType: 'task',
      entityId: task.id,
      data: task,
    });

    res.status(201).json({ success: true, data: task });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = { router, setIO };
