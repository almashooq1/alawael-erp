const express = require('express');
const app = express();

// =======================
// Security Middleware
// =======================
const helmetConfig = require('../../shared/middleware/security/helmet-config');
const corsConfig = require('../../shared/middleware/security/cors-config');
const { apiLimiter } = require('../../shared/middleware/security/rate-limiter');
const securityHeaders = require('../../shared/middleware/security/security-headers');

app.use(helmetConfig);
app.use(corsConfig);
app.use(securityHeaders);
app.use('/api/', apiLimiter);

// =======================
// Body Parser
// =======================
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// =======================
// Monitoring Middleware
// =======================
const { requestLogger, errorLogger } = require('../../shared/utils/logger/logger-middleware');
const { metricsMiddleware } = require('../../shared/utils/metrics/prometheus');
const tracingMiddleware = require('../../shared/utils/tracing/tracing-middleware');

app.use(requestLogger);
app.use(metricsMiddleware);
app.use(tracingMiddleware);

// =======================
// Caching Middleware
// =======================
const { cacheMiddleware } = require('../../shared/utils/cache/cache-middleware');

// Apply caching to GET endpoints
// app.get('/api/*', cacheMiddleware({ ttl: 3600 }));

// =======================
// Routes
// =======================
// Add your routes here
// app.use('/api', routes);

// =======================
// Health Check
// =======================
const healthChecker = require('../../shared/utils/health/health-check');
const metricsRouter = require('../../shared/utils/metrics/metrics-endpoint');

app.use('/health', async (req, res) => {
  const health = await healthChecker.checkAll();
  res.status(health.status === 'healthy' ? 200 : 503).json(health);
});

app.use('/metrics', metricsRouter);

// =======================
// API Documentation
// =======================
const { swaggerSetup } = require('../../shared/docs/swagger-config');
swaggerSetup(app);

// =======================
// Error Handling
// =======================
const { errorHandler, notFoundHandler } = require('../../shared/middleware/error-handler');

// 404 handler (must be after all routes)
app.use(notFoundHandler);

// Error handler (must be last)
app.use(errorHandler);

// =======================
// Start Server
// =======================
const PORT = process.env.PORT || 3000;

if (process.env.NODE_ENV !== 'test') {
  app.listen(PORT, () => {
  console.log(`🚀 ${process.env.SERVICE_NAME || 'api'} running on port ${PORT}`);
}
  console.log(`📚 API Documentation: http://localhost:${PORT}/api-docs`);
  console.log(`📊 Metrics: http://localhost:${PORT}/metrics`);
  console.log(`💚 Health Check: http://localhost:${PORT}/health`);
}).on('error', (error) => {
  if (error.code === 'EADDRINUSE') {
    console.error(`❌ Port ${PORT} is already in use`);
    console.error('Please change the PORT in your .env file or stop the process using this port');
    process.exit(1);
  } else {
    console.error('❌ Server error:', error);
    process.exit(1);
  }
});

module.exports = app;
