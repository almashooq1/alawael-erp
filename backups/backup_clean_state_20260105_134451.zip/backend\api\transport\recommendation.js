// transport/recommendation.js
// توصية ذكية لأفضل وسيلة نقل لكل طالب
const { Bus, Route, Driver, StudentTransportAssignment } = require('../models');

/**
 * خوارزمية توصية مبسطة: تبحث عن أقرب حافلة متاحة لمسار الطالب مع مراعاة السعة
 * يمكن تطويرها لاحقاً لتشمل الذكاء الاصطناعي وتحليل أعمق
 */
async function recommendTransportAssignment({ student, buses, routes, drivers }) {
  // مثال: اختيار أقرب مسار بناءً على عنوان الطالب (مقارنة نصية بسيطة)
  let bestRoute = routes.find(r => student.address && r.stops && r.stops.includes(student.address));
  if (!bestRoute) bestRoute = routes[0];

  // اختيار حافلة متاحة على نفس المسار ولم تتجاوز السعة
  let bestBus = buses.find(b => b.routeId === bestRoute.id && b.capacity > b.assignedCount);
  if (!bestBus) bestBus = buses.find(b => b.capacity > b.assignedCount) || buses[0];

  // اختيار سائق متاح على نفس المسار
  const bestDriver = drivers.find(d => d.routeId === bestRoute.id) || drivers[0];

  return {
    busId: bestBus ? bestBus.id : null,
    routeId: bestRoute ? bestRoute.id : null,
    driverId: bestDriver ? bestDriver.id : null,
  };
}

module.exports = { recommendTransportAssignment };
