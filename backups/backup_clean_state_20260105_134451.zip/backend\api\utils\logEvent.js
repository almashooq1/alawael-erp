// Basic event logger utility
const logEvent = (event, details = {}) => {
  const timestamp = new Date().toISOString();
  console.log(`[${timestamp}] Event: ${event}`, details);
};

module.exports = logEvent;
