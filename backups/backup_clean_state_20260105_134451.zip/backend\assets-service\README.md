# assets-service

Asset lifecycle, preventive/corrective maintenance, and calibration.

## Endpoints

- GET /health
- GET /assets, POST /assets
- GET /work-orders, POST /work-orders, PATCH /work-orders/:id/status
- GET /maintenance-schedules, POST /maintenance-schedules
- GET /calibrations, POST /calibrations
- GET /intelligence/maintenance/predict

Port: 3052 (default)
