import { createServer } from '../src/server.js';

async function main() {
  const app = createServer();
  // asset
  const assetRes = await app.inject({
    method: 'POST',
    url: '/assets',
    payload: { name: 'Ultrasound Machine', type: 'medical' },
  });
  const assetId = JSON.parse(assetRes.body).id;
  // schedule
  await app.inject({
    method: 'POST',
    url: '/maintenance-schedules',
    payload: { assetId, type: 'PREVENTIVE', intervalDays: 90 },
  });
  // work order
  await app.inject({
    method: 'POST',
    url: '/work-orders',
    payload: { assetId, type: 'CORRECTIVE' },
  });
  // predict
  const pred = await app.inject({ method: 'GET', url: '/intelligence/maintenance/predict' });
  console.log('predict', pred.body);
  const health = await app.inject({ method: 'GET', url: '/health' });
  console.log('health', health.body);
}
main().catch(err => {
  console.error(err);
  process.exit(1);
});
