import { randomUUID } from 'crypto';

const assets = new Map(); // id -> { id, name, type, serial, status, location, commissionedAt }
const workOrders = new Map(); // id -> { id, assetId, type, dueAt, status }
const schedules = new Map(); // id -> { id, assetId, type, intervalDays, nextDueAt }
const calibrations = new Map(); // id -> { id, assetId, performedAt, dueAt, status }

export function listAssets() {
  return Array.from(assets.values());
}
export function createAsset(a) {
  const id = a.id || randomUUID();
  const doc = {
    id,
    name: a.name || 'Unnamed Device',
    type: a.type || 'medical',
    serial: a.serial || randomUUID().slice(0, 8),
    status: a.status || 'ACTIVE',
    location: a.location || 'main',
    commissionedAt: a.commissionedAt || new Date().toISOString(),
  };
  assets.set(id, doc);
  return doc;
}

export function listWorkOrders() {
  return Array.from(workOrders.values());
}
export function createWorkOrder(w) {
  const id = w.id || randomUUID();
  const doc = {
    id,
    assetId: w.assetId,
    type: w.type || 'PREVENTIVE',
    dueAt: w.dueAt || new Date(Date.now() + 7 * 86400000).toISOString(),
    status: 'OPEN',
  };
  workOrders.set(id, doc);
  return doc;
}
export function updateWorkOrderStatus(id, status) {
  const w = workOrders.get(id);
  if (!w) {
    return false;
  }
  w.status = status;
  return true;
}

export function listSchedules() {
  return Array.from(schedules.values());
}
export function createSchedule(s) {
  const id = s.id || randomUUID();
  const doc = {
    id,
    assetId: s.assetId,
    type: s.type || 'PREVENTIVE',
    intervalDays: s.intervalDays || 90,
    nextDueAt: s.nextDueAt || new Date(Date.now() + 90 * 86400000).toISOString(),
  };
  schedules.set(id, doc);
  return doc;
}

export function listCalibrations() {
  return Array.from(calibrations.values());
}
export function recordCalibration(c) {
  const id = c.id || randomUUID();
  const doc = {
    id,
    assetId: c.assetId,
    performedAt: c.performedAt || new Date().toISOString(),
    dueAt: c.dueAt || new Date(Date.now() + 365 * 86400000).toISOString(),
    status: 'OK',
  };
  calibrations.set(id, doc);
  return doc;
}

// Intelligence: predict maintenance by simple heuristic on status and due dates
export function predictMaintenance() {
  const alerts = [];
  const now = Date.now();
  for (const s of schedules.values()) {
    const due = new Date(s.nextDueAt).getTime();
    if (due - now < 14 * 86400000) {
      // due within 14 days
      const a = assets.get(s.assetId);
      alerts.push({
        assetId: s.assetId,
        assetName: a?.name,
        dueAt: s.nextDueAt,
        type: s.type,
        priority: 'MEDIUM',
      });
    }
  }
  for (const w of workOrders.values()) {
    if (w.status === 'OPEN') {
      const a = assets.get(w.assetId);
      alerts.push({
        assetId: w.assetId,
        assetName: a?.name,
        dueAt: w.dueAt,
        type: w.type,
        priority: 'HIGH',
      });
    }
  }
  return alerts;
}
