const Fastify = require('fastify');
// Security Middleware
const helmetConfig = require('../../shared/middleware/security/helmet-config');
const corsConfig = require('../../shared/middleware/security/cors-config');
const { apiLimiter } = require('../../shared/middleware/security/rate-limiter');
const securityHeaders = require('../../shared/middleware/security/security-headers');

const {
  sanitizeInputs,
  trackRequest,
  errorHandler,
} = require('../../shared/middleware/security-middleware-fastify');
// const { fileURLToPath } = require('url');
const { createRequire } = require('module');
const { createLogger } = require('../../shared/logging/index.js');
const { applySecurityHeaders, makeRouteRateLimiter } = require('../../shared/http/security.js');
const { buildReadyHandler } = require('../../shared/http/ready.js');
const { attachErrorHandler } = require('../../shared/http/errors.js');
const { EventBus } = require('../../shared/event-bus/index.js');
const { createEnvelope, withMeta } = require('../../shared/events/index.js');
const { initTracing, withSpan } = require('../../shared/otel/index.js');
const {
  listAssets,
  createAsset,
  listWorkOrders,
  createWorkOrder,
  updateWorkOrderStatus,
  listSchedules,
  createSchedule,
  listCalibrations,
  recordCalibration,
  predictMaintenance,
} = require('./repository.js');

const logger = createLogger();
initTracing({ serviceName: 'assets-service' });

function createServer() {
  const fastify = Fastify({ logger });
  fastify.addHook('onRequest', async req => {
    req.requestId = req.headers['x-request-id'] || 'req-' + Math.random().toString(36).slice(2);
    req.userId = req.headers['x-user-id'] || 'system';
  });

  const bus = new EventBus({ logger });
  let natsConn = null;
  async function ensureNats() {
    if (natsConn) {
      return natsConn;
    }
    const servers = process.env.NATS_SERVERS || process.env.NATS_URL;
    if (!servers) {
      return null;
    }
    try {
      const { connect, StringCodec } = await import('nats');
      natsConn = await connect({
        servers: servers
          .split(',')
          .map(s => s.trim())
          .filter(Boolean),
        timeout: 1500,
      });
      natsConn.__sc = StringCodec();
      logger.info({ servers }, 'assets.nats.connected');
    } catch (err) {
      logger.error({ err: String(err) }, 'assets.nats.connect.failed');
      natsConn = null;
    }
    return natsConn;
  }
  async function publishEvent(envelope) {
    try {
      await bus.publish({ topic: 'assets.events', event: envelope });
    } catch {}
    try {
      const nc = await ensureNats();
      if (nc) {
        nc.publish('assets.events', nc.__sc.encode(JSON.stringify(envelope)));
      }
    } catch (err) {
      logger.error({ err: String(err) }, 'assets.nats.publish.failed');
    }
  }

  if (process.env.METRICS_ENABLED === 'true') {
    try {
      const requireCJS =
        typeof __filename !== 'undefined'
          ? createRequire(__filename)
          : createRequire(process.cwd() + '/dummy.js');
      const prom = (globalThis.__promClient ||= requireCJS('prom-client'));
      if (process.env.METRICS_DEFAULTS === 'true' && !globalThis.__metricsDefaultsRegistered) {
        prom.collectDefaultMetrics({ prefix: process.env.METRICS_PREFIX || '' });
        globalThis.__metricsDefaultsRegistered = true;
      }
      const httpReqCounter = new prom.Counter({
        name: 'service_http_requests_total',
        help: 'Total HTTP requests',
        labelNames: ['service', 'method', 'route', 'status'],
      });
      fastify.addHook('onResponse', (req, reply, done) => {
        try {
          const route = (req.routeOptions && req.routeOptions.url) || req.url || 'unknown';
          httpReqCounter.inc({
            service: 'assets-service',
            method: req.method,
            route,
            status: String(reply.statusCode),
          });
        } catch {}
        done();
      });
      fastify.get('/metrics', async (_req, reply) => {
        try {
          reply.header('Content-Type', prom.register.contentType);
          reply.send(await prom.register.metrics());
        } catch (err) {
          reply.code(500).send({ error: 'metrics_error', details: String(err) });
        }
      });
    } catch (err) {
      fastify.log.warn({ err: String(err) }, 'metrics-registration-failed');
    }
  }

  applySecurityHeaders(fastify);
  const rateLimit = makeRouteRateLimiter({ windowMs: 60000, max: 80 });
  attachErrorHandler(fastify);

  fastify.get('/health', async () => ({ status: 'ok' }));
  fastify.get(
    '/ready',
    buildReadyHandler({
      serviceName: 'assets-service',
      checks: [
        {
          name: 'env',
          run: async () => ({ ok: true, node: process.version }),
        },
        {
          name: 'nats',
          run: async () => {
            const nc = await ensureNats();
            if (!nc) {
              return { ok: false, details: 'not-configured' };
            }
            return { ok: true };
          },
        },
        {
          name: 'workOrders',
          run: async () => {
            // Simple backlog heuristic: if more than 500 OPEN work orders -> degraded
            try {
              const backlog = listWorkOrders().filter(w => (w.status || 'OPEN') === 'OPEN').length;
              const forceFail = /^(true|1|yes)$/i.test(String(process.env.ASSETS_FORCE_FAIL || ''));
              if (forceFail) {
                return { ok: false, details: 'forced-fail' };
              }
              if (backlog > 500) {
                return { ok: false, details: 'backlog:' + backlog };
              }
              return { ok: true, details: 'backlog:' + backlog };
            } catch (err) {
              return { ok: false, details: 'error:' + String(err) };
            }
          },
        },
      ],
    })
  );

  // Assets
  fastify.get('/assets', async () => ({ data: listAssets() }));
  fastify.post('/assets', { preHandler: rateLimit }, async (request, reply) =>
    withSpan('assets.create', async () => {
      const doc = createAsset(request.body || {});
      const evt = createEnvelope({
        type: 'ASSET_CREATED',
        source: 'assets-service',
        payload: withMeta(doc, { requestId: request.requestId, userId: request.userId }),
      });
      publishEvent(evt);
      reply.code(201);
      return { id: doc.id };
    })
  );

  // Work orders
  fastify.get('/work-orders', async () => ({ data: listWorkOrders() }));
  fastify.post('/work-orders', { preHandler: rateLimit }, async (request, reply) =>
    withSpan('workorders.create', async () => {
      const doc = createWorkOrder(request.body || {});
      const evt = createEnvelope({
        type: 'WORK_ORDER_CREATED',
        source: 'assets-service',
        payload: withMeta(doc, { requestId: request.requestId, userId: request.userId }),
      });
      publishEvent(evt);
      reply.code(201);
      return { id: doc.id };
    })
  );
  fastify.patch('/work-orders/:id/status', { preHandler: rateLimit }, async (request, reply) =>
    withSpan('workorders.status', async () => {
      const ok = updateWorkOrderStatus(request.params.id, request.body?.status || 'OPEN');
      if (!ok) {
        return reply.code(404).send({ error: 'not_found' });
      }
      const evt = createEnvelope({
        type: 'WORK_ORDER_STATUS_UPDATED',
        source: 'assets-service',
        payload: withMeta(
          { id: request.params.id, status: request.body?.status },
          { requestId: request.requestId, userId: request.userId }
        ),
      });
      publishEvent(evt);
      return { updated: true };
    })
  );

  // Schedules
  fastify.get('/maintenance-schedules', async () => ({ data: listSchedules() }));
  fastify.post('/maintenance-schedules', { preHandler: rateLimit }, async (request, reply) =>
    withSpan('schedules.create', async () => {
      const doc = createSchedule(request.body || {});
      const evt = createEnvelope({
        type: 'MAINTENANCE_SCHEDULE_CREATED',
        source: 'assets-service',
        payload: withMeta(doc, { requestId: request.requestId, userId: request.userId }),
      });
      publishEvent(evt);
      reply.code(201);
      return { id: doc.id };
    })
  );

  // Calibration
  fastify.get('/calibrations', async () => ({ data: listCalibrations() }));
  fastify.post('/calibrations', { preHandler: rateLimit }, async (request, reply) =>
    withSpan('calibration.record', async () => {
      const doc = recordCalibration(request.body || {});
      const evt = createEnvelope({
        type: 'CALIBRATION_RECORDED',
        source: 'assets-service',
        payload: withMeta(doc, { requestId: request.requestId, userId: request.userId }),
      });
      publishEvent(evt);
      reply.code(201);
      return { id: doc.id };
    })
  );

  // Intelligence
  fastify.get('/intelligence/maintenance/predict', async () => ({ data: predictMaintenance() }));

  return fastify;
}

const isMain = process.argv[1] === __filename;
if (process.env.NODE_ENV !== 'test' && isMain) {
  const fastify = createServer();
  const port = Number(process.env.PORT || 3052);
  fastify
    .listen({ port, host: '0.0.0.0' })
    .then(() => logger.info(`assets-service listening on ${port}`))
    .catch(err => {
      logger.error({ err: String(err) }, 'server.failed.start');
      process.exit(1);
    });
}

// Error Handling
const { errorHandler, notFoundHandler } = require('../../shared/middleware/error-handler');

// 404 handler (must be after all routes)

// API Documentation
const { swaggerSetup } = require('../../shared/docs/swagger-config');
swaggerSetup(app);

app.use(notFoundHandler);

// Error handler (must be last)
app.use(errorHandler);
