import { createServer } from '../src/server.js';

describe('assets-service flow', () => {
  it('should create asset, schedule, work order, calibration and predict', async () => {
    const app = createServer();
    const aRes = await app.inject({
      method: 'POST',
      url: '/assets',
      payload: { name: 'MRI Scanner' },
    });
    expect(aRes.statusCode).toBe(201);
    const assetId = JSON.parse(aRes.body).id;

    const sch = await app.inject({
      method: 'POST',
      url: '/maintenance-schedules',
      payload: { assetId, intervalDays: 30 },
    });
    expect(sch.statusCode).toBe(201);

    const wo = await app.inject({
      method: 'POST',
      url: '/work-orders',
      payload: { assetId, type: 'CORRECTIVE' },
    });
    expect(wo.statusCode).toBe(201);

    const cal = await app.inject({ method: 'POST', url: '/calibrations', payload: { assetId } });
    expect(cal.statusCode).toBe(201);

    const pred = await app.inject({ method: 'GET', url: '/intelligence/maintenance/predict' });
    expect(pred.statusCode).toBe(200);
    const list = JSON.parse(pred.body).data;
    expect(Array.isArray(list)).toBe(true);
  });
});
