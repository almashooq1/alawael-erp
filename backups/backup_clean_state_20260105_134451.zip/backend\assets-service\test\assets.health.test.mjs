let createServer;
beforeAll(async () => {
  ({ createServer } = await import('../src/server.js'));
});

describe('assets-service health', () => {
  it('should return ok', async () => {
    const app = createServer();
    const res = await app.inject({ method: 'GET', url: '/health' });
    expect(res.statusCode).toBe(200);
    expect(JSON.parse(res.body)).toEqual({ status: 'ok' });
  });
});
