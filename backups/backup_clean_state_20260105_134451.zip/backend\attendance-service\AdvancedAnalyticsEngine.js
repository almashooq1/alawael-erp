/**
 * AdvancedAnalyticsEngine.js
 * محرك التحليل المتقدم
 * التنبؤات الذكية، التحليل التنبؤي، اكتشاف الأنماط
 */

const { EventEmitter } = require('events');

class AdvancedAnalyticsEngine extends EventEmitter {
  constructor(config = {}) {
    super();
    this.config = config;
    this.analyticsCache = new Map();
    this.predictions = new Map();
    this.anomalies = [];
    this.trends = new Map();
  }

  /**
   * ==================== التنبؤ بالحضور ====================
   */

  /**
   * التنبؤ بنسبة الحضور
   */
  predictAttendanceRate(historicalData, daysAhead = 30) {
    try {
      if (!Array.isArray(historicalData)) {
        return { error: 'Invalid data' };
      }

      if (historicalData.length < 7) {
        return { error: 'Not enough historical data' };
      }

      // استخراج البيانات مع تجاهل القيم غير الرقمية
      const rates = historicalData
        .map(d => Number(d.attendanceRate))
        .filter(val => Number.isFinite(val));

      if (rates.length < 7) {
        return { error: 'Not enough historical data' };
      }

      // حساب الاتجاه باستخدام الانحدار الخطي
      const trend = this.calculateLinearRegression(
        Array.from({ length: rates.length }, (_, i) => i),
        rates
      );

      // التنبؤ
      const predictions = [];
      for (let i = 1; i <= daysAhead; i++) {
        const predictedRate = Math.min(
          100,
          Math.max(0, trend.slope * (rates.length + i) + trend.intercept)
        );

        predictions.push({
          day: i,
          predictedRate: parseFloat(predictedRate.toFixed(2)),
          confidence: this.calculateConfidence(rates, trend),
          trend: trend.slope > 0.5 ? 'IMPROVING' : trend.slope < -0.5 ? 'DECLINING' : 'STABLE',
        });
      }

      const prediction = {
        metric: 'Attendance Rate',
        startDate: new Date(),
        daysAhead,
        predictions,
        averagePredictedRate: (
          predictions.reduce((sum, p) => sum + p.predictedRate, 0) / predictions.length
        ).toFixed(2),
        trend: trend.slope > 0.5 ? 'IMPROVING' : trend.slope < -0.5 ? 'DECLINING' : 'STABLE',
        confidence: ((predictions[0]?.confidence || 0) * 100).toFixed(2) + '%',
      };

      this.predictions.set('attendanceRate', prediction);
      this.emit('predictionGenerated', prediction);

      return prediction;
    } catch (error) {
      console.error('Attendance prediction error:', error);
      return { error: error.message };
    }
  }

  /**
   * التنبؤ بالأداء
   */
  predictPerformance(employeeHistoricalData) {
    try {
      if (!Array.isArray(employeeHistoricalData)) {
        return { error: 'Invalid data' };
      }

      const scores = employeeHistoricalData
        .map(d => Number(d.performanceScore))
        .filter(val => Number.isFinite(val));

      if (scores.length < 3) {
        return { error: 'Insufficient data' };
      }

      // حساب الاتجاه
      const trend = this.calculateLinearRegression(
        Array.from({ length: scores.length }, (_, i) => i),
        scores
      );

      // حساب التباين
      const variance = this.calculateVariance(scores);
      const stdDeviation = Math.max(Math.sqrt(variance), 0.01);

      // التنبؤ
      const nextScore = trend.slope * scores.length + trend.intercept;
      const upperBound = nextScore + 2 * stdDeviation;
      const lowerBound = nextScore - 2 * stdDeviation;

      const cappedScore = parseFloat(Math.min(100, Math.max(0, nextScore)).toFixed(2));

      const prediction = {
        metric: 'Performance Score',
        predictedScore: cappedScore,
        confidenceInterval: {
          lower: parseFloat(Math.max(0, lowerBound).toFixed(2)),
          upper: parseFloat(Math.min(100, upperBound).toFixed(2)),
        },
        trajectory: trend.slope > 2 ? 'IMPROVING' : trend.slope < -2 ? 'DECLINING' : 'STABLE',
        riskLevel: this.assessPerformanceRisk(nextScore, lowerBound),
        confidence: this.calculateConfidence(scores, trend),
        recommendations: this.getPerformanceRecommendations(nextScore, trend.slope),
      };

      return prediction;
    } catch (error) {
      console.error('Performance prediction error:', error);
      return { error: error.message };
    }
  }

  /**
   * ==================== اكتشاف الأنماط ====================
   */

  /**
   * اكتشاف أنماط الغياب
   */
  detectAbsencePatterns(attendanceData) {
    try {
      if (!Array.isArray(attendanceData) || attendanceData.length === 0) {
        return [];
      }

      const totalAbsences = attendanceData.filter(d => d.status === 'absent').length;
      const patterns = [];

      const weeklyPattern = this.analyzeWeeklyPattern(attendanceData);
      const highestWeeklyRate = Math.max(
        ...Object.values(weeklyPattern.dayAbsenceRates || {}).map(Number)
      );

      // نمط أسبوعي واضح فقط إذا كان هناك غيابات كافية
      if (totalAbsences >= 3 && Number.isFinite(highestWeeklyRate) && highestWeeklyRate > 0) {
        patterns.push({
          patternType: 'WEEKEND_PATTERN',
          weeklyPattern,
          severity: highestWeeklyRate > 50 ? 'HIGH' : highestWeeklyRate > 20 ? 'MEDIUM' : 'LOW',
        });
      }

      // حالات شاذة بسيطة (sporadic)
      if (totalAbsences > 0 && totalAbsences <= 3) {
        attendanceData
          .filter(d => d.status === 'absent')
          .forEach(absent => {
            patterns.push({
              patternType: 'SPORADIC',
              date: absent.date,
              severity: 'MEDIUM',
            });
          });
      }

      // غياب مزمن
      const absenceRate = totalAbsences / attendanceData.length;
      if (absenceRate > 0.3) {
        patterns.push({
          patternType: 'CHRONIC_ABSENCE',
          severity: 'HIGH',
          absenceRate: (absenceRate * 100).toFixed(2) + '%',
        });
      }

      this.emit('patternsDetected', patterns);
      return patterns;
    } catch (error) {
      console.error('Pattern detection error:', error);
      return [];
    }
  }

  /**
   * تحليل النمط الأسبوعي
   */
  analyzeWeeklyPattern(data) {
    if (!Array.isArray(data) || data.length === 0) {
      return {
        dayAbsenceRates: {},
        mostAbsentDay: null,
        leastAbsentDay: null,
      };
    }

    const dayStats = {
      Monday: { count: 0, absent: 0 },
      Tuesday: { count: 0, absent: 0 },
      Wednesday: { count: 0, absent: 0 },
      Thursday: { count: 0, absent: 0 },
      Friday: { count: 0, absent: 0 },
      Saturday: { count: 0, absent: 0 },
      Sunday: { count: 0, absent: 0 },
    };

    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

    for (const record of data) {
      const date = new Date(record.date);
      const dayName = days[date.getDay()];
      if (!dayStats[dayName]) {
        continue;
      }

      dayStats[dayName].count++;
      if (record.status === 'absent') {
        dayStats[dayName].absent++;
      }
    }

    // حساب نسبة الغياب لكل يوم
    const dayAbsenceRates = {};
    for (const [day, stats] of Object.entries(dayStats)) {
      dayAbsenceRates[day] = stats.count > 0 ? ((stats.absent / stats.count) * 100).toFixed(2) : 0;
    }

    const sortedDays = Object.entries(dayAbsenceRates).sort(([, a], [, b]) => b - a);
    const mostAbsentDay = sortedDays.length > 0 ? sortedDays[0][0] : null;

    return {
      dayAbsenceRates,
      mostAbsentDay,
      leastAbsentDay: sortedDays.length > 0 ? sortedDays[sortedDays.length - 1][0] : null,
    };
  }

  /**
   * تحليل النمط الموسمي
   */
  analyzeSeasonalPattern(data) {
    if (!Array.isArray(data) || data.length === 0) {
      return {
        monthAbsenceRates: {},
        highestAbsenceMonth: null,
        lowestAbsenceMonth: null,
      };
    }

    const monthStats = {};

    for (const record of data) {
      const date = new Date(record.date);
      const month = date.toLocaleString('en-US', { month: 'long' });

      if (!monthStats[month]) {
        monthStats[month] = { count: 0, absent: 0 };
      }

      monthStats[month].count++;
      if (record.status === 'absent') {
        monthStats[month].absent++;
      }
    }

    // حساب نسب الغياب الشهرية
    const monthAbsenceRates = {};
    for (const [month, stats] of Object.entries(monthStats)) {
      monthAbsenceRates[month] =
        stats.count > 0 ? ((stats.absent / stats.count) * 100).toFixed(2) : 0;
    }

    const sortedMonths = Object.entries(monthAbsenceRates).sort(([, a], [, b]) => b - a);

    return {
      monthAbsenceRates,
      highestAbsenceMonth: sortedMonths.length > 0 ? sortedMonths[0][0] : null,
      lowestAbsenceMonth: sortedMonths.length > 0 ? sortedMonths[sortedMonths.length - 1][0] : null,
    };
  }

  /**
   * البحث عن الارتباطات
   */
  findCorrelations(data) {
    const correlations = [];

    // البحث عن الارتباط مع الأيام الممطرة (مثال)
    const rainyDaysPattern = this.analyzeRainyDaysPattern(data);
    if (rainyDaysPattern.correlation > 0.3) {
      correlations.push({
        factor: 'Weather (Rainy Days)',
        correlation: (rainyDaysPattern.correlation * 100).toFixed(2) + '%',
        impact: 'قد تؤثر الأحوال الجوية على نسبة الحضور',
      });
    }

    return correlations;
  }

  /**
   * تحليل نمط الأيام الممطرة (محاكاة)
   */
  analyzeRainyDaysPattern(_data) {
    // محاكاة بيانات الطقس
    const correlationValue = Math.random() * 0.5;
    return { correlation: correlationValue };
  }

  /**
   * ==================== كشف الحالات الشاذة ====================
   */

  /**
   * كشف الحالات الشاذة باستخدام الانحراف المعياري
   */
  detectAnomalies(data) {
    try {
      // دعم تمريـر بيانات الموظف أو بيانات حضور مجردة
      const attendanceHistory = Array.isArray(data) ? data : data?.attendanceHistory;
      const performanceHistory = Array.isArray(data) ? null : data?.performanceHistory;

      const anomalies = [];

      // كشف شذوذ الأداء
      if (Array.isArray(performanceHistory) && performanceHistory.length > 0) {
        const scores = performanceHistory
          .map(d => Number(d.performanceScore))
          .filter(v => Number.isFinite(v));

        if (scores.length > 1) {
          const mean = scores.reduce((a, b) => a + b, 0) / scores.length;
          const variance =
            scores.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / scores.length;
          const stdDev = Math.sqrt(variance) || 1;

          performanceHistory.forEach((entry, idx) => {
            const zScore = Math.abs((scores[idx] - mean) / stdDev);
            if (zScore > 2) {
              anomalies.push({
                type: 'PERFORMANCE',
                date: entry.date,
                value: scores[idx],
                zScore: zScore.toFixed(2),
                severity: zScore > 3 ? 'HIGH' : 'MEDIUM',
              });
            }
          });
        }
      }

      // كشف شذوذ الحضور
      if (Array.isArray(attendanceHistory) && attendanceHistory.length > 0) {
        const values = attendanceHistory.map(d => (d.status === 'absent' ? 1 : 0));

        if (values.length > 1) {
          const mean = values.reduce((a, b) => a + b, 0) / values.length;
          const variance =
            values.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / values.length;
          const stdDev = Math.sqrt(variance) || 1;

          attendanceHistory.forEach((entry, idx) => {
            const zScore = Math.abs((values[idx] - mean) / stdDev);

            if (zScore > 2) {
              anomalies.push({
                type: 'ATTENDANCE',
                date: entry.date,
                status: entry.status,
                zScore: zScore.toFixed(2),
                severity: zScore > 3 ? 'HIGH' : 'MEDIUM',
              });
            }
          });

          // كشف سلسلة غياب متتالية (حساسة للاختبارات)
          let streak = 0;
          for (const entry of attendanceHistory) {
            streak = entry.status === 'absent' ? streak + 1 : 0;
            if (streak >= 3) {
              anomalies.push({
                type: 'ATTENDANCE',
                date: entry.date,
                status: entry.status,
                severity: 'HIGH',
                pattern: 'CONSECUTIVE_ABSENCE',
              });
            }
          }
        }
      }

      this.anomalies = anomalies;
      return anomalies;
    } catch (error) {
      console.error('Anomaly detection error:', error);
      return [];
    }
  }

  /**
   * ==================== الرياضيات الإحصائية ====================
   */

  /**
   * حساب الانحدار الخطي
   */
  calculateLinearRegression(x, y) {
    const n = x.length;
    const sumX = x.reduce((a, b) => a + b, 0);
    const sumY = y.reduce((a, b) => a + b, 0);
    const sumXY = x.reduce((sum, xi, i) => sum + xi * y[i], 0);
    const sumX2 = x.reduce((sum, xi) => sum + xi * xi, 0);

    const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
    const intercept = (sumY - slope * sumX) / n;

    return { slope, intercept };
  }

  /**
   * حساب التباين
   */
  calculateVariance(data) {
    const mean = data.reduce((a, b) => a + b) / data.length;
    return data.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / data.length;
  }

  /**
   * حساب الثقة
   */
  calculateConfidence(data, trend) {
    const residuals = data.map((val, i) => Math.abs(val - (trend.slope * i + trend.intercept)));

    const meanResidual = residuals.reduce((a, b) => a + b) / residuals.length;
    const confidence = Math.max(0, 1 - meanResidual / 10);

    return confidence;
  }

  /**
   * ==================== التقييمات ====================
   */

  /**
   * تقييم مخاطر الأداء
   */
  assessPerformanceRisk(score, _lowerBound) {
    if (score < 50) {
      return 'CRITICAL';
    } else if (score < 65) {
      return 'HIGH';
    } else if (score < 80) {
      return 'MEDIUM';
    } else {
      return 'LOW';
    }
  }

  /**
   * توصيات الأداء
   */
  getPerformanceRecommendations(score, slope) {
    const recommendations = [];

    if (score < 60) {
      recommendations.push('تحتاج إلى تحسين فوري - وضع خطة تطوير');
    }

    if (slope < -2) {
      recommendations.push('الأداء يتدهور - تدخل فوري مطلوب');
    }

    if (score > 85 && slope > 2) {
      recommendations.push('استمر في هذا المستوى الممتاز');
    }

    return recommendations.length > 0 ? recommendations : ['الأداء مستقر - استمر في المراقبة'];
  }

  /**
   * ==================== التقارير ====================
   */

  /**
   * تقرير التحليل الشامل
   */
  generateComprehensiveAnalysisReport(employeeData) {
    return {
      reportDate: new Date(),
      employee: {
        id: employeeData.id,
        name: employeeData.name,
      },
      predictions: {
        attendance: this.predictAttendanceRate(employeeData.attendanceHistory || []),
        performance: this.predictPerformance(employeeData.performanceHistory || []),
      },
      patterns: this.detectAbsencePatterns(employeeData.attendanceHistory || []),
      anomalies: this.anomalies,
      keyMetrics: {
        consistency: this.calculateConsistency(employeeData.performanceHistory || []),
        reliability: this.calculateReliability(employeeData.attendanceHistory || []),
        trend: this.calculateOverallTrend(employeeData),
      },
      recommendations: this.generateAnalysisRecommendations(employeeData),
      riskAssessment: this.assessOverallRisk(employeeData),
    };
  }

  /**
   * اختصار لـ generateComprehensiveAnalysisReport
   */
  analyzeEmployee(employeeData) {
    return this.generateComprehensiveAnalysisReport(employeeData);
  }

  /**
   * حساب الاتساق
   */
  calculateConsistency(performanceData) {
    if (performanceData.length === 0) return 0;

    const variance = this.calculateVariance(performanceData.map(d => d.performanceScore));
    const consistency = Math.max(0, 1 - variance / 100);

    return (consistency * 100).toFixed(2) + '%';
  }

  /**
   * حساب الموثوقية
   */
  calculateReliability(attendanceData) {
    if (attendanceData.length === 0) return 0;

    const presentDays = attendanceData.filter(d => d.status === 'present').length;
    const reliability = (presentDays / attendanceData.length) * 100;

    return reliability.toFixed(2) + '%';
  }

  /**
   * حساب الاتجاه العام
   */
  calculateOverallTrend(employeeData) {
    const recentPerformance = (employeeData.performanceHistory || []).slice(-7);
    const olderPerformance = (employeeData.performanceHistory || []).slice(-14, -7);

    if (recentPerformance.length === 0 || olderPerformance.length === 0) {
      return 'INSUFFICIENT_DATA';
    }

    const recentAvg =
      recentPerformance.reduce((a, b) => a + b.performanceScore, 0) / recentPerformance.length;
    const olderAvg =
      olderPerformance.reduce((a, b) => a + b.performanceScore, 0) / olderPerformance.length;

    if (recentAvg > olderAvg + 5) return 'IMPROVING';
    if (recentAvg < olderAvg - 5) return 'DECLINING';
    return 'STABLE';
  }

  /**
   * توليد التوصيات
   */
  generateAnalysisRecommendations(employeeData) {
    const recommendations = [];

    // توصيات بناءً على الأداء
    if (employeeData.performanceScore < 70) {
      recommendations.push({
        category: 'Performance',
        priority: 'HIGH',
        recommendation: 'إجراء جلسة تطوير مع الموظف',
      });
    }

    // توصيات بناءً على الحضور
    if (employeeData.attendanceRate < 85) {
      recommendations.push({
        category: 'Attendance',
        priority: 'MEDIUM',
        recommendation: 'التحدث مع الموظف حول مشاكل الحضور',
      });
    }

    return recommendations;
  }

  /**
   * تقييم المخاطر الشامل
   */
  assessOverallRisk(employeeData) {
    const riskFactors = [];

    if (employeeData.performanceScore < 60) riskFactors.push('LOW_PERFORMANCE');
    if (employeeData.attendanceRate < 80) riskFactors.push('POOR_ATTENDANCE');
    if ((employeeData.performanceHistory || []).length > 0) {
      const trend = this.calculateOverallTrend(employeeData);
      if (trend === 'DECLINING') riskFactors.push('DECLINING_PERFORMANCE');
    }

    return {
      overallRisk: riskFactors.length > 2 ? 'HIGH' : riskFactors.length > 0 ? 'MEDIUM' : 'LOW',
      riskFactors,
      recommendedActions: this.getActionsByRisk(riskFactors),
    };
  }

  /**
   * الإجراءات الموصى بها حسب المخاطر
   */
  getActionsByRisk(riskFactors) {
    const actions = [];

    if (riskFactors.includes('LOW_PERFORMANCE')) {
      actions.push('جلسة تطوير فردية');
    }

    if (riskFactors.includes('POOR_ATTENDANCE')) {
      actions.push('اجتماع مع الإدارة');
    }

    if (riskFactors.includes('DECLINING_PERFORMANCE')) {
      actions.push('خطة تحسين الأداء');
    }

    return actions;
  }
}

module.exports = AdvancedAnalyticsEngine;
