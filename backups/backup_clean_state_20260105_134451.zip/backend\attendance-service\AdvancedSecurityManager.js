/**
 * AdvancedSecurityManager.js
 * نظام الأمان المتقدم
 * المصادقة متعددة العوامل، التشفير، تدقيق الأمان
 */

const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const speakeasy = require('speakeasy');
const QRCode = require('qrcode');
const { EventEmitter } = require('events');

class AdvancedSecurityManager extends EventEmitter {
  constructor(config = {}) {
    super();
    this.config = {
      tokenExpiry: config.tokenExpiry || '7d',
      refreshTokenExpiry: config.refreshTokenExpiry || '30d',
      twoFactorExpiry: config.twoFactorExpiry || 300, // 5 minutes
      maxAttempts: config.maxAttempts || 5,
      lockoutDuration: config.lockoutDuration || 900, // 15 minutes
      encryptionAlgorithm: 'aes-256-cbc',
      ...config,
    };

    this.securityLog = [];
    this.failedAttempts = new Map();
    this.activeTokens = new Map();
    this.biometricProfiles = new Map();
  }

  /**
   * تفعيل المصادقة الثنائية (2FA)
   */
  async enable2FA(userId) {
    try {
      const secret = speakeasy.generateSecret({
        name: `Attendance System (${userId})`,
        issuer: 'Attendance System',
        length: 32,
      });

      const qrCode = await QRCode.toDataURL(secret.otpauth_url);

      this.logSecurityEvent({
        type: '2FA_ENABLED',
        userId,
        timestamp: new Date(),
        status: 'SUCCESS',
      });

      return {
        secret: secret.base32,
        qrCode,
        manualEntryKey: secret.base32,
        backupCodes: this.generateBackupCodes(userId, secret.base32),
      };
    } catch (error) {
      this.logSecurityEvent({
        type: '2FA_ENABLE_FAILED',
        userId,
        error: error.message,
        timestamp: new Date(),
      });
      throw error;
    }
  }

  /**
   * التحقق من رمز 2FA
   */
  verify2FAToken(secret, token, userId) {
    try {
      const verified = speakeasy.totp.verify({
        secret: secret,
        encoding: 'base32',
        token: token,
        window: 2, // السماح بنافذة ± 2
      });

      if (!verified) {
        this.logSecurityEvent({
          type: '2FA_VERIFICATION_FAILED',
          userId,
          timestamp: new Date(),
          reason: 'INVALID_TOKEN',
        });
        return false;
      }

      this.logSecurityEvent({
        type: '2FA_VERIFIED',
        userId,
        timestamp: new Date(),
        status: 'SUCCESS',
      });

      return true;
    } catch (error) {
      this.logSecurityEvent({
        type: '2FA_VERIFICATION_ERROR',
        userId,
        error: error.message,
        timestamp: new Date(),
      });
      return false;
    }
  }

  /**
   * إنشاء رموز النسخ الاحتياطية
   */
  generateBackupCodes(userId, secret, count = 10) {
    const backupCodes = [];

    for (let i = 0; i < count; i++) {
      const code = crypto.randomBytes(4).toString('hex').toUpperCase();
      backupCodes.push({
        code,
        used: false,
        createdAt: new Date(),
      });
    }

    // تخزين الرموز (مشفرة)
    const encrypted = this.encryptData(JSON.stringify(backupCodes), secret);
    this.activeTokens.set(`backup_${userId}`, encrypted);

    return backupCodes.map(b => b.code);
  }

  /**
   * التحقق من رمز النسخة الاحتياطية
   */
  verifyBackupCode(userId, code) {
    try {
      const encrypted = this.activeTokens.get(`backup_${userId}`);
      if (!encrypted) return false;

      const backupCodes = JSON.parse(this.decryptData(encrypted));
      const backupCode = backupCodes.find(b => b.code === code && !b.used);

      if (backupCode) {
        backupCode.used = true;
        backupCode.usedAt = new Date();

        // تحديث الرموز
        const updatedEncrypted = this.encryptData(JSON.stringify(backupCodes), userId);
        this.activeTokens.set(`backup_${userId}`, updatedEncrypted);

        this.logSecurityEvent({
          type: 'BACKUP_CODE_USED',
          userId,
          timestamp: new Date(),
        });

        return true;
      }

      return false;
    } catch (error) {
      console.error('Backup code verification error:', error);
      return false;
    }
  }

  /**
   * تسجيل البيانات البيومترية
   */
  async registerBiometric(userId, biometricData) {
    try {
      const hash = crypto.createHash('sha256').update(JSON.stringify(biometricData)).digest('hex');

      this.biometricProfiles.set(userId, {
        hash,
        type: biometricData.type, // fingerprint, face, iris
        registeredAt: new Date(),
        verifications: 0,
      });

      this.logSecurityEvent({
        type: 'BIOMETRIC_REGISTERED',
        userId,
        biometricType: biometricData.type,
        timestamp: new Date(),
        status: 'SUCCESS',
      });

      return {
        status: 'SUCCESS',
        message: 'تم تسجيل البيانات البيومترية بنجاح',
      };
    } catch (error) {
      this.logSecurityEvent({
        type: 'BIOMETRIC_REGISTRATION_FAILED',
        userId,
        error: error.message,
        timestamp: new Date(),
      });
      throw error;
    }
  }

  /**
   * التحقق من البيانات البيومترية
   */
  verifyBiometric(userId, biometricData) {
    try {
      const profile = this.biometricProfiles.get(userId);
      if (!profile) {
        this.logSecurityEvent({
          type: 'BIOMETRIC_VERIFICATION_FAILED',
          userId,
          reason: 'NO_PROFILE',
          timestamp: new Date(),
        });
        return false;
      }

      const hash = crypto.createHash('sha256').update(JSON.stringify(biometricData)).digest('hex');

      const verified = hash === profile.hash;

      if (verified) {
        profile.verifications++;
        profile.lastVerification = new Date();

        this.logSecurityEvent({
          type: 'BIOMETRIC_VERIFIED',
          userId,
          timestamp: new Date(),
          status: 'SUCCESS',
        });
      } else {
        this.logSecurityEvent({
          type: 'BIOMETRIC_VERIFICATION_FAILED',
          userId,
          reason: 'HASH_MISMATCH',
          timestamp: new Date(),
        });
      }

      return verified;
    } catch (error) {
      this.logSecurityEvent({
        type: 'BIOMETRIC_VERIFICATION_ERROR',
        userId,
        error: error.message,
        timestamp: new Date(),
      });
      return false;
    }
  }

  /**
   * تشفير البيانات
   */
  encryptData(data, key) {
    try {
      const iv = crypto.randomBytes(16);
      const hash = crypto.createHash('sha256').update(String(key)).digest();

      const cipher = crypto.createCipheriv(this.config.encryptionAlgorithm, hash, iv);

      let encrypted = cipher.update(data, 'utf8', 'hex');
      encrypted += cipher.final('hex');

      return `${iv.toString('hex')}:${encrypted}`;
    } catch (error) {
      console.error('Encryption error:', error);
      throw error;
    }
  }

  /**
   * فك تشفير البيانات
   */
  decryptData(encryptedData, key) {
    try {
      const [ivHex, encrypted] = encryptedData.split(':');
      const iv = Buffer.from(ivHex, 'hex');
      const hash = crypto.createHash('sha256').update(String(key)).digest();

      const decipher = crypto.createDecipheriv(this.config.encryptionAlgorithm, hash, iv);

      let decrypted = decipher.update(encrypted, 'hex', 'utf8');
      decrypted += decipher.final('utf8');

      return decrypted;
    } catch (error) {
      console.error('Decryption error:', error);
      throw error;
    }
  }

  /**
   * التحقق من محاولات تسجيل الدخول الفاشلة
   */
  checkLoginAttempts(userId) {
    const attempts = this.failedAttempts.get(userId) || {
      count: 0,
      lastAttempt: null,
      lockedUntil: null,
    };

    if (attempts.lockedUntil && attempts.lockedUntil > Date.now()) {
      return {
        allowed: false,
        reason: 'ACCOUNT_LOCKED',
        lockedUntil: new Date(attempts.lockedUntil),
        remainingTime: Math.floor((attempts.lockedUntil - Date.now()) / 1000),
      };
    }

    return {
      allowed: true,
      attemptsRemaining: this.config.maxAttempts - attempts.count,
    };
  }

  /**
   * تسجيل محاولة فاشلة
   */
  recordFailedAttempt(userId) {
    const attempts = this.failedAttempts.get(userId) || {
      count: 0,
      lastAttempt: null,
    };

    attempts.count++;
    attempts.lastAttempt = Date.now();

    if (attempts.count >= this.config.maxAttempts) {
      attempts.lockedUntil = Date.now() + this.config.lockoutDuration * 1000;

      this.logSecurityEvent({
        type: 'ACCOUNT_LOCKED',
        userId,
        reason: 'MAX_FAILED_ATTEMPTS',
        timestamp: new Date(),
      });

      this.emit('accountLocked', {
        userId,
        lockedUntil: new Date(attempts.lockedUntil),
      });
    }

    this.failedAttempts.set(userId, attempts);

    this.logSecurityEvent({
      type: 'LOGIN_ATTEMPT_FAILED',
      userId,
      attemptNumber: attempts.count,
      timestamp: new Date(),
    });
  }

  /**
   * مسح محاولات فاشلة عند النجاح
   */
  clearFailedAttempts(userId) {
    this.failedAttempts.delete(userId);

    this.logSecurityEvent({
      type: 'LOGIN_SUCCESS',
      userId,
      timestamp: new Date(),
    });
  }

  /**
   * إنشاء رموز الوصول الآمنة
   */
  generateSecureTokens(userId, role) {
    const accessToken = jwt.sign({ userId, role, type: 'access' }, process.env.JWT_SECRET, {
      expiresIn: this.config.tokenExpiry,
    });

    const refreshToken = jwt.sign(
      { userId, role, type: 'refresh' },
      process.env.JWT_REFRESH_SECRET,
      {
        expiresIn: this.config.refreshTokenExpiry,
      }
    );

    // تخزين الرمز
    this.activeTokens.set(`token_${userId}`, {
      accessToken,
      refreshToken,
      issuedAt: Date.now(),
      expiresAt: Date.now() + 7 * 24 * 60 * 60 * 1000, // 7 days
    });

    return { accessToken, refreshToken };
  }

  /**
   * الحصول على قائمة الأنشطة الأمنية المريبة
   */
  getSuspiciousActivities() {
    return this.securityLog
      .filter(log => log.type.includes('FAILED') || log.type.includes('LOCKED'))
      .slice(-50); // آخر 50 حدث
  }

  /**
   * تسجيل حدث أماني
   */
  logSecurityEvent(event) {
    const logEntry = {
      ...event,
      id: crypto.randomUUID(),
    };

    this.securityLog.push(logEntry);

    // إبقاء السجل محدوداً
    if (this.securityLog.length > 10000) {
      this.securityLog = this.securityLog.slice(-5000);
    }

    // إصدار حدث
    this.emit('securityEvent', logEntry);

    // طباعة الأحداث الحرجة
    if (['ACCOUNT_LOCKED', 'BIOMETRIC_FAILED', 'ENCRYPTION_ERROR'].includes(event.type)) {
      console.error(`🚨 SECURITY ALERT: ${event.type}`, event);
    }
  }

  /**
   * تقرير الأمان الشامل
   */
  getSecurityReport() {
    const suspiciousActivities = this.getSuspiciousActivities();
    const failedLogins = this.securityLog.filter(l => l.type === 'LOGIN_ATTEMPT_FAILED').length;
    const successfulLogins = this.securityLog.filter(l => l.type === 'LOGIN_SUCCESS').length;

    return {
      reportDate: new Date(),
      summary: {
        totalSecurityEvents: this.securityLog.length,
        suspiciousActivities: suspiciousActivities.length,
        failedLogins,
        successfulLogins,
        successRate: successfulLogins / (successfulLogins + failedLogins) || 0,
        lockedAccounts: Array.from(this.failedAttempts.entries())
          .filter(([, attempts]) => attempts.lockedUntil && attempts.lockedUntil > Date.now())
          .map(([userId]) => userId),
      },
      recentEvents: this.securityLog.slice(-20).reverse(),
      vulnerabilities: this.identifyVulnerabilities(),
      recommendations: this.getSecurityRecommendations(),
    };
  }

  /**
   * تحديد الثغرات الأمنية
   */
  identifyVulnerabilities() {
    const vulnerabilities = [];

    // الكشف عن محاولات دخول متكررة
    const frequentFailures = Array.from(this.failedAttempts.entries()).filter(
      ([, attempts]) => attempts.count > 2
    );

    if (frequentFailures.length > 0) {
      vulnerabilities.push({
        type: 'BRUTE_FORCE_ATTEMPT',
        severity: 'HIGH',
        affectedUsers: frequentFailures.map(([userId]) => userId),
        recommendation: 'تفعيل المصادقة متعددة العوامل',
      });
    }

    // الكشف عن الأنشطة غير العادية
    const unusualTime = this.securityLog.filter(l => {
      const hour = new Date(l.timestamp).getHours();
      return hour < 6 || hour > 23; // خارج ساعات العمل
    }).length;

    if (unusualTime > 5) {
      vulnerabilities.push({
        type: 'UNUSUAL_ACTIVITY_TIME',
        severity: 'MEDIUM',
        count: unusualTime,
        recommendation: 'مراقبة الأنشطة خارج ساعات العمل',
      });
    }

    return vulnerabilities;
  }

  /**
   * توصيات الأمان
   */
  getSecurityRecommendations() {
    return [
      {
        priority: 'CRITICAL',
        recommendation: 'تفعيل المصادقة الثنائية لجميع المستخدمين',
        estimatedImpact: 'تقليل المخاطر بنسبة 99%',
      },
      {
        priority: 'HIGH',
        recommendation: 'استخدام البيانات البيومترية للتحقق الإضافي',
        estimatedImpact: 'تحسين الأمان بنسبة 85%',
      },
      {
        priority: 'HIGH',
        recommendation: 'مراجعة سجلات الأمان أسبوعياً',
        estimatedImpact: 'الكشف المبكر عن المشاكل',
      },
      {
        priority: 'MEDIUM',
        recommendation: 'تدريب الموظفين على الأمان السيبراني',
        estimatedImpact: 'تقليل الأخطاء البشرية بنسبة 60%',
      },
    ];
  }
}

module.exports = AdvancedSecurityManager;
