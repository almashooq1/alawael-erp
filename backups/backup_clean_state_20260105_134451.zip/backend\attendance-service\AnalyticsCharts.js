/**
 * AnalyticsCharts.js
 * مكون الرسوم البيانية التفاعلية
 * عرض البيانات بطرق مرئية جذابة
 */

class AnalyticsCharts {
  constructor(config = {}) {
    this.config = {
      theme: config.theme || 'light',
      colors: config.colors || this.getDefaultColors(),
      responsiveSize: config.responsiveSize !== false,
      ...config,
    };

    this.charts = new Map();
  }

  /**
   * الألوان الافتراضية
   */
  getDefaultColors() {
    return {
      success: '#10B981',
      warning: '#F59E0B',
      danger: '#EF4444',
      info: '#3B82F6',
      primary: '#6366F1',
      secondary: '#8B5CF6',
      dark: '#1F2937',
      light: '#F3F4F6',
    };
  }

  /**
   * رسم بياني دائري للحضور والغياب
   */
  createAttendancePieChart(data) {
    return {
      type: 'pie',
      title: 'توزيع الحضور والغياب والتأخر',
      chartId: this.generateChartId(),
      data: {
        labels: ['الحضور', 'الغياب', 'التأخر'],
        datasets: [
          {
            data: [
              parseFloat(data.attendanceRate || 80),
              parseFloat(data.absenceRate || 10),
              parseFloat(data.lateRate || 10),
            ],
            backgroundColor: [
              this.config.colors.success,
              this.config.colors.danger,
              this.config.colors.warning,
            ],
            borderColor: '#ffffff',
            borderWidth: 2,
          },
        ],
      },
      options: {
        responsive: this.config.responsiveSize,
        maintainAspectRatio: true,
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              font: { size: 12, family: 'Arial, sans-serif' },
              color: this.config.theme === 'dark' ? '#ffffff' : '#000000',
            },
          },
          tooltip: {
            callbacks: {
              label: context => {
                const value = context.parsed;
                return `${context.label}: ${value.toFixed(1)}%`;
              },
            },
          },
        },
      },
    };
  }

  /**
   * رسم بياني خطي لاتجاه الحضور
   */
  createAttendanceTrendChart(data) {
    return {
      type: 'line',
      title: 'اتجاه معدل الحضور عبر الوقت',
      chartId: this.generateChartId(),
      data: {
        labels: data.dates || this.generateDateLabels(30),
        datasets: [
          {
            label: 'معدل الحضور',
            data: data.attendanceRates || [],
            borderColor: this.config.colors.success,
            backgroundColor: 'rgba(16, 185, 129, 0.1)',
            tension: 0.4,
            fill: true,
            borderWidth: 2,
            pointRadius: 4,
            pointBackgroundColor: this.config.colors.success,
          },
          {
            label: 'الهدف (90%)',
            data: Array(30).fill(90),
            borderColor: this.config.colors.info,
            borderDash: [5, 5],
            tension: 0,
            fill: false,
            borderWidth: 2,
            pointRadius: 0,
          },
        ],
      },
      options: {
        responsive: this.config.responsiveSize,
        maintainAspectRatio: true,
        plugins: {
          legend: {
            position: 'top',
            labels: {
              font: { size: 12 },
              usePointStyle: true,
            },
          },
          tooltip: {
            mode: 'index',
            intersect: false,
            backgroundColor: 'rgba(0, 0, 0, 0.8)',
            padding: 12,
            titleFont: { size: 13, weight: 'bold' },
            bodyFont: { size: 12 },
            borderColor: 'rgba(255, 255, 255, 0.2)',
            borderWidth: 1,
          },
        },
        scales: {
          y: {
            min: 0,
            max: 100,
            ticks: {
              callback: value => `${value}%`,
            },
          },
        },
      },
    };
  }

  /**
   * رسم بياني عمودي لمقارنة الأقسام
   */
  createDepartmentComparisonChart(data) {
    return {
      type: 'bar',
      title: 'مقارنة معدلات الحضور حسب القسم',
      chartId: this.generateChartId(),
      data: {
        labels: data.departments || [],
        datasets: [
          {
            label: 'معدل الحضور',
            data: data.attendanceRates || [],
            backgroundColor: this.config.colors.success,
            borderColor: this.config.colors.success,
            borderWidth: 1,
          },
          {
            label: 'معدل الغياب',
            data: data.absenceRates || [],
            backgroundColor: this.config.colors.danger,
            borderColor: this.config.colors.danger,
            borderWidth: 1,
          },
          {
            label: 'معدل التأخر',
            data: data.lateRates || [],
            backgroundColor: this.config.colors.warning,
            borderColor: this.config.colors.warning,
            borderWidth: 1,
          },
        ],
      },
      options: {
        responsive: this.config.responsiveSize,
        maintainAspectRatio: true,
        plugins: {
          legend: {
            position: 'top',
            labels: {
              font: { size: 11 },
              usePointStyle: true,
              padding: 15,
            },
          },
          tooltip: {
            callbacks: {
              label: context => {
                return `${context.dataset.label}: ${context.parsed.y.toFixed(1)}%`;
              },
            },
          },
        },
        scales: {
          y: {
            beginAtZero: true,
            max: 100,
            ticks: {
              callback: value => `${value}%`,
            },
          },
          x: {
            stacked: false,
          },
        },
      },
    };
  }

  /**
   * رسم بياني لأنماط يوم الأسبوع
   */
  createDayOfWeekPatternChart(data) {
    return {
      type: 'bar',
      title: 'أنماط الحضور حسب يوم الأسبوع',
      chartId: this.generateChartId(),
      data: {
        labels: ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'],
        datasets: [
          {
            label: 'معدل الحضور',
            data: data.dayPatterns || Array(7).fill(85),
            backgroundColor: this.config.colors.primary,
            borderColor: this.config.colors.primary,
            borderWidth: 2,
          },
        ],
      },
      options: {
        responsive: this.config.responsiveSize,
        maintainAspectRatio: true,
        plugins: {
          legend: {
            display: false,
          },
          tooltip: {
            callbacks: {
              label: context => `${context.parsed.y.toFixed(1)}%`,
            },
          },
        },
        scales: {
          y: {
            beginAtZero: true,
            max: 100,
            ticks: {
              callback: value => `${value}%`,
            },
          },
        },
      },
    };
  }

  /**
   * رسم بياني للتأخر الشهري
   */
  createMonthlyLateChart(data) {
    return {
      type: 'line',
      title: 'اتجاه التأخر خلال الشهر',
      chartId: this.generateChartId(),
      data: {
        labels: this.generateDayLabels(31),
        datasets: [
          {
            label: 'عدد الموظفين المتأخرين',
            data: data.dailyLateCount || [],
            borderColor: this.config.colors.warning,
            backgroundColor: 'rgba(245, 158, 11, 0.1)',
            tension: 0.3,
            fill: true,
            borderWidth: 2,
            pointRadius: 3,
            pointBackgroundColor: this.config.colors.warning,
          },
        ],
      },
      options: {
        responsive: this.config.responsiveSize,
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: 'rgba(0, 0, 0, 0.8)',
            callbacks: {
              label: context => `${context.parsed.y} موظفين`,
            },
          },
        },
        scales: {
          y: {
            beginAtZero: true,
            ticks: {
              callback: value => `${value}`,
            },
          },
        },
      },
    };
  }

  /**
   * مقياس القياس (Gauge Chart)
   */
  createPerformanceGaugeChart(data) {
    return {
      type: 'doughnut',
      title: `درجة الأداء الكلية: ${data.score}%`,
      chartId: this.generateChartId(),
      data: {
        labels: ['الأداء الفعلي', 'المتبقي'],
        datasets: [
          {
            data: [data.score || 75, 100 - (data.score || 75)],
            backgroundColor: [this.getGaugeColor(data.score), '#E5E7EB'],
            borderColor: '#ffffff',
            borderWidth: 2,
            circumference: 180,
            rotation: 270,
          },
        ],
      },
      options: {
        responsive: this.config.responsiveSize,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: { enabled: false },
        },
      },
    };
  }

  /**
   * رسم بياني للموازنة
   */
  createBalanceChart(data) {
    return {
      type: 'bar',
      title: 'موازنة الحضور والغياب والتأخر',
      chartId: this.generateChartId(),
      data: {
        labels: data.months || this.generateMonthLabels(6),
        datasets: [
          {
            label: 'الحضور',
            data: data.attendanceData || [],
            backgroundColor: this.config.colors.success,
            stack: 'Stack 0',
          },
          {
            label: 'الغياب',
            data: data.absenceData || [],
            backgroundColor: this.config.colors.danger,
            stack: 'Stack 0',
          },
          {
            label: 'التأخر',
            data: data.lateData || [],
            backgroundColor: this.config.colors.warning,
            stack: 'Stack 0',
          },
        ],
      },
      options: {
        responsive: this.config.responsiveSize,
        maintainAspectRatio: true,
        plugins: {
          legend: {
            position: 'top',
          },
        },
        scales: {
          x: {
            stacked: true,
          },
          y: {
            stacked: true,
            beginAtZero: true,
            max: 100,
            ticks: {
              callback: value => `${value}%`,
            },
          },
        },
      },
    };
  }

  /**
   * رسم بياني للتوزيع الزمني
   */
  createTimeDistributionChart(data) {
    return {
      type: 'radar',
      title: 'توزيع الحضور حسب فترات اليوم',
      chartId: this.generateChartId(),
      data: {
        labels: ['8:00-10:00', '10:00-12:00', '12:00-14:00', '14:00-16:00', '16:00-18:00'],
        datasets: [
          {
            label: 'معدل الحضور',
            data: data.timeDistribution || [85, 90, 88, 80, 75],
            borderColor: this.config.colors.primary,
            backgroundColor: 'rgba(99, 102, 241, 0.1)',
            pointBackgroundColor: this.config.colors.primary,
            pointBorderColor: '#fff',
            pointBorderWidth: 2,
          },
        ],
      },
      options: {
        responsive: this.config.responsiveSize,
        maintainAspectRatio: true,
        plugins: {
          legend: {
            display: false,
          },
        },
        scales: {
          r: {
            beginAtZero: true,
            max: 100,
            ticks: {
              callback: value => `${value}%`,
            },
          },
        },
      },
    };
  }

  /**
   * الحصول على لون المقياس
   */
  getGaugeColor(score) {
    if (score >= 90) return this.config.colors.success;
    if (score >= 80) return '#84CC16';
    if (score >= 70) return this.config.colors.warning;
    if (score >= 60) return '#F97316';
    return this.config.colors.danger;
  }

  /**
   * توليد تواريخ
   */
  generateDateLabels(days) {
    const labels = [];
    for (let i = 0; i < days; i++) {
      const date = new Date();
      date.setDate(date.getDate() - days + i);
      labels.push(date.toLocaleDateString('ar-SA', { month: 'short', day: 'numeric' }));
    }
    return labels;
  }

  /**
   * توليد أيام الشهر
   */
  generateDayLabels(days) {
    const labels = [];
    for (let i = 1; i <= days; i++) {
      labels.push(`${i}`);
    }
    return labels;
  }

  /**
   * توليد أشهر
   */
  generateMonthLabels(count) {
    const labels = [];
    const months = [
      'يناير',
      'فبراير',
      'مارس',
      'أبريل',
      'مايو',
      'يونيو',
      'يوليو',
      'أغسطس',
      'سبتمبر',
      'أكتوبر',
      'نوفمبر',
      'ديسمبر',
    ];

    const now = new Date();
    for (let i = count - 1; i >= 0; i--) {
      const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
      labels.push(months[date.getMonth()]);
    }
    return labels;
  }

  /**
   * توليد معرف الرسم البياني
   */
  generateChartId() {
    return `chart-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * حفظ الرسم البياني
   */
  saveChart(chart) {
    this.charts.set(chart.chartId, chart);
    return chart.chartId;
  }

  /**
   * الحصول على الرسم البياني
   */
  getChart(chartId) {
    return this.charts.get(chartId);
  }

  /**
   * حذف الرسم البياني
   */
  deleteChart(chartId) {
    return this.charts.delete(chartId);
  }

  /**
   * الحصول على جميع الرسوم البيانية
   */
  getAllCharts() {
    return Array.from(this.charts.values());
  }
}

module.exports = AnalyticsCharts;
