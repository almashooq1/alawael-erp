/**
 * AttendanceAnalytics.js
 * نظام التحليلات المتقدمة للحضور
 * تحليل الأنماط والرؤى والمؤشرات الرئيسية
 */

const EventEmitter = require('events');
const Logger = require('../shared/Logger');

class AttendanceAnalytics extends EventEmitter {
  constructor(config = {}) {
    super();

    this.config = {
      enabled: config.enabled !== false,
      cacheExpiry: config.cacheExpiry || 3600000, // ساعة واحدة
      ...config,
    };

    this.logger = new Logger('AttendanceAnalytics');
    this.analyticsCache = new Map();
  }

  /**
   * تحليل شامل للموظف
   */
  async analyzeEmployee(userId, records, period = 'month') {
    try {
      const analysis = {
        userId,
        period,
        timestamp: new Date(),
        overview: {},
        trends: {},
        patterns: {},
        comparisons: {},
        recommendations: [],
      };

      // الملخص العام
      analysis.overview = this.getEmployeeOverview(records);

      // تحليل الاتجاهات
      analysis.trends = this.analyzeTrends(records, period);

      // اكتشاف الأنماط
      analysis.patterns = this.detectPatterns(records);

      // المقارنات
      analysis.comparisons = this.getComparisons(records);

      // التوصيات
      analysis.recommendations = this.generateRecommendations(analysis);

      return {
        success: true,
        data: analysis,
      };
    } catch (error) {
      this.logger.error('خطأ في تحليل الموظف', error);
      return {
        success: false,
        message: error.message,
      };
    }
  }

  /**
   * الملخص العام للموظف
   */
  getEmployeeOverview(records) {
    let absences = 0;
    let lates = 0;
    let onTime = 0;
    let totalLateMinutes = 0;
    let hoursWorked = 0;

    for (const record of records) {
      if (record.status === 'ABSENT') {
        absences++;
      } else if (record.status === 'LATE') {
        lates++;
        totalLateMinutes += record.lateMinutes || 0;
      } else {
        onTime++;
      }

      if (record.hoursWorked) {
        hoursWorked += record.hoursWorked;
      }
    }

    const total = records.length;

    return {
      totalDays: total,
      absenceDays: absences,
      lateDays: lates,
      onTimeDays: onTime,
      absenceRate: ((absences / total) * 100).toFixed(2),
      lateRate: ((lates / total) * 100).toFixed(2),
      punctualityRate: ((onTime / total) * 100).toFixed(2),
      averageLateMinutes: lates > 0 ? (totalLateMinutes / lates).toFixed(1) : 0,
      totalHoursWorked: hoursWorked,
      averageHoursPerDay: (hoursWorked / total).toFixed(1),
    };
  }

  /**
   * تحليل الاتجاهات
   */
  analyzeTrends(records, _period) {
    const trends = {
      improvementTrend: 0,
      changePercentage: 0,
      direction: 'stable', // improving, declining, stable
      seasonalTrend: {},
    };

    if (records.length < 2) {
      return trends;
    }

    // تقسيم البيانات إلى نصين
    const midpoint = Math.floor(records.length / 2);
    const firstHalf = records.slice(0, midpoint);
    const secondHalf = records.slice(midpoint);

    const firstHalfAbsenceRate = (
      (firstHalf.filter(r => r.status === 'ABSENT').length / firstHalf.length) *
      100
    ).toFixed(2);

    const secondHalfAbsenceRate = (
      (secondHalf.filter(r => r.status === 'ABSENT').length / secondHalf.length) *
      100
    ).toFixed(2);

    // حساب التغيير
    trends.changePercentage = (secondHalfAbsenceRate - firstHalfAbsenceRate).toFixed(2);

    if (parseFloat(trends.changePercentage) < -2) {
      trends.direction = 'improving';
      trends.improvementTrend = Math.abs(parseFloat(trends.changePercentage));
    } else if (parseFloat(trends.changePercentage) > 2) {
      trends.direction = 'declining';
      trends.improvementTrend = -parseFloat(trends.changePercentage);
    }

    // الاتجاه الموسمي
    trends.seasonalTrend = this.analyzeSeasonalTrend(records);

    return trends;
  }

  /**
   * تحليل الاتجاه الموسمي
   */
  analyzeSeasonalTrend(records) {
    const seasonalTrend = {
      summer: { absenceRate: 0, records: 0 },
      winter: { absenceRate: 0, records: 0 },
      spring: { absenceRate: 0, records: 0 },
      autumn: { absenceRate: 0, records: 0 },
    };

    for (const record of records) {
      const month = new Date(record.date).getMonth();
      let season;

      if (month >= 5 && month <= 7) season = 'summer';
      else if (month >= 11 || month === 0 || month === 1) season = 'winter';
      else if (month >= 2 && month <= 4) season = 'spring';
      else season = 'autumn';

      seasonalTrend[season].records++;

      if (record.status === 'ABSENT') {
        seasonalTrend[season].absenceRate++;
      }
    }

    // حساب النسب المئوية
    for (const season in seasonalTrend) {
      if (seasonalTrend[season].records > 0) {
        seasonalTrend[season].absenceRate = (
          (seasonalTrend[season].absenceRate / seasonalTrend[season].records) *
          100
        ).toFixed(2);
      }
    }

    return seasonalTrend;
  }

  /**
   * كشف الأنماط السلوكية
   */
  detectPatterns(records) {
    const patterns = {
      dayOfWeekPatterns: this.getDayOfWeekPatterns(records),
      timeOfDayPatterns: this.getTimeOfDayPatterns(records),
      absencePatterns: this.getAbsencePatterns(records),
      latePatterns: this.getLatePatterns(records),
    };

    return patterns;
  }

  /**
   * أنماط حسب يوم الأسبوع
   */
  getDayOfWeekPatterns(records) {
    const daysOfWeek = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
    const patterns = {};

    for (const day of daysOfWeek) {
      patterns[day] = {
        total: 0,
        absences: 0,
        lates: 0,
        onTime: 0,
      };
    }

    for (const record of records) {
      const date = new Date(record.date);
      const day = daysOfWeek[date.getDay()];

      patterns[day].total++;

      if (record.status === 'ABSENT') patterns[day].absences++;
      else if (record.status === 'LATE') patterns[day].lates++;
      else patterns[day].onTime++;
    }

    // حساب النسب المئوية
    for (const day in patterns) {
      if (patterns[day].total > 0) {
        patterns[day].absenceRate = ((patterns[day].absences / patterns[day].total) * 100).toFixed(
          2
        );
        patterns[day].lateRate = ((patterns[day].lates / patterns[day].total) * 100).toFixed(2);
      }
    }

    return patterns;
  }

  /**
   * أنماط حسب وقت اليوم
   */
  getTimeOfDayPatterns(records) {
    const patterns = {
      morning: { total: 0, lates: 0 }, // قبل 11 صباحاً
      afternoon: { total: 0, lates: 0 }, // 11 صباحاً - 3 مساءً
      evening: { total: 0, lates: 0 }, // بعد 3 مساءً
    };

    for (const record of records) {
      if (!record.checkInTime) continue;

      const time = new Date(record.checkInTime);
      const hour = time.getHours();

      let period;
      if (hour < 11) period = 'morning';
      else if (hour < 15) period = 'afternoon';
      else period = 'evening';

      patterns[period].total++;

      if (record.status === 'LATE') {
        patterns[period].lates++;
      }
    }

    // حساب النسب
    for (const period in patterns) {
      if (patterns[period].total > 0) {
        patterns[period].lateRate = (
          (patterns[period].lates / patterns[period].total) *
          100
        ).toFixed(2);
      }
    }

    return patterns;
  }

  /**
   * أنماط الغياب
   */
  getAbsencePatterns(records) {
    const patterns = {
      singleAbsences: 0,
      doubleAbsences: 0,
      consecutiveAbsences: 0,
      maxConsecutiveDays: 0,
    };

    let consecutiveDays = 0;

    for (const record of records) {
      if (record.status === 'ABSENT') {
        consecutiveDays++;
      } else {
        if (consecutiveDays === 1) patterns.singleAbsences++;
        else if (consecutiveDays === 2) patterns.doubleAbsences++;
        else if (consecutiveDays > 2) patterns.consecutiveAbsences++;

        patterns.maxConsecutiveDays = Math.max(patterns.maxConsecutiveDays, consecutiveDays);
        consecutiveDays = 0;
      }
    }

    return patterns;
  }

  /**
   * أنماط التأخر
   */
  getLatePatterns(records) {
    const patterns = {
      frequencyPerMonth: 0,
      averageDelay: 0,
      peakHour: null,
      peakDay: null,
      maxDelay: 0,
    };

    let totalLateMinutes = 0;
    let lateCount = 0;
    const hourCount = {};
    const dayCount = {};

    for (const record of records) {
      if (record.status === 'LATE') {
        lateCount++;
        totalLateMinutes += record.lateMinutes || 0;
        patterns.maxDelay = Math.max(patterns.maxDelay, record.lateMinutes || 0);

        if (record.checkInTime) {
          const hour = new Date(record.checkInTime).getHours();
          hourCount[hour] = (hourCount[hour] || 0) + 1;
        }

        if (record.date) {
          const day = new Date(record.date).getDay();
          dayCount[day] = (dayCount[day] || 0) + 1;
        }
      }
    }

    patterns.frequencyPerMonth = (lateCount / records.length) * 100;
    patterns.averageDelay = lateCount > 0 ? totalLateMinutes / lateCount : 0;

    // إيجاد ساعة الذروة
    let maxHour = 0;
    for (const hour in hourCount) {
      if (hourCount[hour] > (hourCount[maxHour] || 0)) {
        maxHour = hour;
      }
    }
    patterns.peakHour = maxHour;

    // إيجاد يوم الذروة
    const daysOfWeek = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
    let maxDay = 0;
    for (const day in dayCount) {
      if (dayCount[day] > (dayCount[maxDay] || 0)) {
        maxDay = day;
      }
    }
    patterns.peakDay = daysOfWeek[maxDay];

    return patterns;
  }

  /**
   * المقارنات
   */
  getComparisons(records) {
    const comparisons = {
      benchmarks: {},
      performance: {},
    };

    const overview = this.getEmployeeOverview(records);

    // المعايير المقارنة
    comparisons.benchmarks = {
      absenceRate: {
        employee: parseFloat(overview.absenceRate),
        standard: 8, // 8% هو المعيار
        status: parseFloat(overview.absenceRate) <= 8 ? 'جيد' : 'سيء',
      },
      lateRate: {
        employee: parseFloat(overview.lateRate),
        standard: 10,
        status: parseFloat(overview.lateRate) <= 10 ? 'جيد' : 'سيء',
      },
      averageLateMinutes: {
        employee: parseFloat(overview.averageLateMinutes),
        standard: 15,
        status: parseFloat(overview.averageLateMinutes) <= 15 ? 'جيد' : 'سيء',
      },
    };

    return comparisons;
  }

  /**
   * توليد التوصيات
   */
  generateRecommendations(analysis) {
    const recommendations = [];

    const overview = analysis.overview;
    const absenceRate = parseFloat(overview.absenceRate);
    const lateRate = parseFloat(overview.lateRate);

    // التوصيات بناءً على معدل الغياب
    if (absenceRate > 15) {
      recommendations.push({
        priority: 'high',
        type: 'absence',
        message: 'معدل الغياب مرتفع جداً - يتطلب تدخل فوري',
        action: 'عقد اجتماع مع الموظف ومناقشة الأسباب',
      });
    } else if (absenceRate > 10) {
      recommendations.push({
        priority: 'medium',
        type: 'absence',
        message: 'معدل الغياب مرتفع',
        action: 'مراقبة مكثفة والتواصل مع الموظف',
      });
    }

    // التوصيات بناءً على معدل التأخر
    if (lateRate > 20) {
      recommendations.push({
        priority: 'high',
        type: 'late',
        message: 'معدل التأخر مرتفع جداً',
        action: 'إجراء تصحيحي مطلوب',
      });
    } else if (lateRate > 12) {
      recommendations.push({
        priority: 'medium',
        type: 'late',
        message: 'معدل التأخر أعلى من المعيار',
        action: 'توعية الموظف بأهمية الانضباط',
      });
    }

    // التوصيات بناءً على الاتجاهات
    if (analysis.trends.direction === 'declining') {
      recommendations.push({
        priority: 'high',
        type: 'trend',
        message: 'الأداء يتدهور بشكل ملحوظ',
        action: 'التحقق من الأسباب المحتملة (مشاكل صحية، شخصية، عملية)',
      });
    } else if (analysis.trends.direction === 'improving') {
      recommendations.push({
        priority: 'low',
        type: 'positive',
        message: 'الأداء يتحسن',
        action: 'تقدير الموظف على التحسن',
      });
    }

    return recommendations;
  }

  /**
   * مقارنة الموظفين
   */
  compareEmployees(employeesData) {
    try {
      const comparison = {
        timestamp: new Date(),
        employees: [],
        averages: {},
        topPerformers: [],
        bottomPerformers: [],
      };

      // تحليل كل موظف
      for (const employee of employeesData) {
        const overview = this.getEmployeeOverview(employee.records);
        comparison.employees.push({
          id: employee.id,
          name: employee.name,
          ...overview,
        });
      }

      // حساب المتوسطات
      const totalAbsenceRate = comparison.employees.reduce(
        (sum, emp) => sum + parseFloat(emp.absenceRate),
        0
      );
      const totalLateRate = comparison.employees.reduce(
        (sum, emp) => sum + parseFloat(emp.lateRate),
        0
      );

      comparison.averages = {
        absenceRate: (totalAbsenceRate / comparison.employees.length).toFixed(2),
        lateRate: (totalLateRate / comparison.employees.length).toFixed(2),
      };

      // أفضل الموظفين
      comparison.topPerformers = comparison.employees
        .sort((a, b) => parseFloat(a.absenceRate) - parseFloat(b.absenceRate))
        .slice(0, 3);

      // أسوأ الموظفين
      comparison.bottomPerformers = comparison.employees
        .sort((a, b) => parseFloat(b.absenceRate) - parseFloat(a.absenceRate))
        .slice(0, 3);

      return {
        success: true,
        data: comparison,
      };
    } catch (error) {
      this.logger.error('خطأ في مقارنة الموظفين', error);
      return {
        success: false,
        message: error.message,
      };
    }
  }

  /**
   * تقرير الأداء الشامل
   */
  generatePerformanceReport(records, period = 'month') {
    try {
      const report = {
        generatedAt: new Date(),
        period,
        overview: this.getEmployeeOverview(records),
        trends: this.analyzeTrends(records, period),
        patterns: this.detectPatterns(records),
        quality: this.assessQuality(records),
      };

      return {
        success: true,
        data: report,
      };
    } catch (error) {
      this.logger.error('خطأ في توليد التقرير', error);
      return {
        success: false,
        message: error.message,
      };
    }
  }

  /**
   * تقييم جودة الأداء
   */
  assessQuality(records) {
    const overview = this.getEmployeeOverview(records);

    let qualityScore = 100;

    // خصم لمعدل الغياب
    qualityScore -= parseFloat(overview.absenceRate) * 5;

    // خصم لمعدل التأخر
    qualityScore -= parseFloat(overview.lateRate) * 2;

    // إضافة للدقة
    qualityScore += parseFloat(overview.punctualityRate) * 0.5;

    qualityScore = Math.max(0, Math.min(100, qualityScore));

    return {
      score: Math.round(qualityScore),
      grade:
        qualityScore >= 90
          ? 'ممتاز'
          : qualityScore >= 80
            ? 'جيد جداً'
            : qualityScore >= 70
              ? 'جيد'
              : qualityScore >= 60
                ? 'مقبول'
                : 'ضعيف',
      details: {
        punctuality: parseFloat(overview.punctualityRate),
        reliability: 100 - parseFloat(overview.absenceRate),
        consistency: this.calculateConsistency(records),
      },
    };
  }

  /**
   * حساب الاستقرار
   */
  calculateConsistency(records) {
    if (records.length < 2) return 100;

    const statuses = records.map(r => r.status);
    const changes = statuses.filter((status, i) => status !== statuses[i - 1]).length;

    return 100 - (changes / records.length) * 50;
  }
}

module.exports = AttendanceAnalytics;
