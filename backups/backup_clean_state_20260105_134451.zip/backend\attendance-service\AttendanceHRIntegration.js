/**
 * AttendanceHRIntegration.js
 * نظام التكامل بين الحضور والموارد البشرية
 * تحديثات تقييمات الأداء وإدارة المواهب
 */

const { EventEmitter } = require('events');
const Logger = require('../utils/Logger');

class AttendanceHRIntegration extends EventEmitter {
  constructor(config = {}) {
    super();
    this.config = {
      performanceWeights: config.performanceWeights || {
        attendance: 0.4, // 40% وزن الحضور
        punctuality: 0.3, // 30% وزن الالتزام بالوقت
        consistency: 0.2, // 20% وزن الثبات
        other: 0.1, // 10% عوامل أخرى
      },
      promotionThreshold: config.promotionThreshold || 85, // درجة 85+ للترقية
      disciplinaryThreshold: config.disciplinaryThreshold || 40, // درجة أقل من 40 للإجراءات
      improvementPlan: config.improvementPlan || {
        threshold: 60,
        duration: 90, // 90 يوم
      },
      ...config,
    };

    this.logger = new Logger('AttendanceHRIntegration');
    this.performanceRatings = new Map();
    this.talentAssessments = new Map();
    this.disciplinaryActions = new Map();
  }

  /**
   * تحديث تقييم الأداء بناءً على الحضور
   */
  updatePerformanceRating(employeeId, attendanceAnalysis, otherMetrics = {}) {
    try {
      const weights = this.config.performanceWeights;

      // حساب درجات من التحليلات
      const attendanceScore = Math.min(100, (attendanceAnalysis.attendanceRate || 0) * 1.1);
      const punctualityScore = attendanceAnalysis.punctualityScore || 0;
      const consistencyScore = attendanceAnalysis.consistencyScore || 0;
      const otherScore = otherMetrics.behavioralScore || 75;

      // حساب الدرجة المرجحة
      const weightedScore =
        attendanceScore * weights.attendance +
        punctualityScore * weights.punctuality +
        consistencyScore * weights.consistency +
        otherScore * weights.other;

      const performanceRating = {
        employeeId,
        date: new Date().toISOString(),
        scores: {
          attendance: {
            value: attendanceScore,
            weight: weights.attendance,
            weighted: attendanceScore * weights.attendance,
            details: {
              attendanceRate: attendanceAnalysis.attendanceRate,
              absenceDays: attendanceAnalysis.absenceDays || 0,
              lateArrivalDays: attendanceAnalysis.lateArrivalDays || 0,
            },
          },
          punctuality: {
            value: punctualityScore,
            weight: weights.punctuality,
            weighted: punctualityScore * weights.punctuality,
            details: {
              onTimePercentage: attendanceAnalysis.onTimePercentage || 0,
              averageLateMinutes: attendanceAnalysis.averageLateMinutes || 0,
            },
          },
          consistency: {
            value: consistencyScore,
            weight: weights.consistency,
            weighted: consistencyScore * weights.consistency,
            details: {
              variance: attendanceAnalysis.variance || 0,
              stability: attendanceAnalysis.stability || 'stable',
            },
          },
          other: {
            value: otherScore,
            weight: weights.other,
            weighted: otherScore * weights.other,
            details: otherMetrics,
          },
        },
        overallScore: parseFloat(weightedScore.toFixed(2)),
        grade: this.getPerformanceGrade(weightedScore),
        classification: this.classifyPerformance(weightedScore),
        timestamp: new Date().toISOString(),
      };

      this.performanceRatings.set(employeeId, performanceRating);

      this.logger.info(
        `تم تحديث تقييم الأداء للموظف ${employeeId}: ${performanceRating.overallScore}/100`
      );

      this.emit('performance:updated', performanceRating);

      return performanceRating;
    } catch (error) {
      this.logger.error(`خطأ في تحديث تقييم الأداء للموظف ${employeeId}:`, error.message);
      throw error;
    }
  }

  /**
   * الحصول على درجة الأداء
   */
  getPerformanceGrade(score) {
    if (score >= 95) return 'ممتاز جداً';
    if (score >= 85) return 'ممتاز';
    if (score >= 75) return 'جيد جداً';
    if (score >= 60) return 'جيد';
    if (score >= 50) return 'مقبول';
    return 'ضعيف';
  }

  /**
   * تصنيف الأداء
   */
  classifyPerformance(score) {
    if (score >= this.config.promotionThreshold) {
      return {
        level: 'high_performer',
        category: 'موظف متميز',
        recommendation: 'مرشح للترقية',
        actions: ['مكافأة', 'فرص تطوير', 'مسؤوليات إضافية'],
      };
    } else if (score >= 70) {
      return {
        level: 'standard_performer',
        category: 'موظف عادي',
        recommendation: 'الحفاظ على الأداء',
        actions: ['تطوير مستمر', 'متابعة'],
      };
    } else if (score >= this.config.improvementPlan.threshold) {
      return {
        level: 'below_average_performer',
        category: 'موظف يحتاج تحسين',
        recommendation: 'خطة تحسين الأداء',
        actions: [
          'برنامج تدريب',
          'متابعة دقيقة',
          `خطة تحسين ${this.config.improvementPlan.duration} يوم`,
        ],
      };
    } else {
      return {
        level: 'poor_performer',
        category: 'موظف ضعيف الأداء',
        recommendation: 'إجراءات تأديبية',
        actions: ['إنذار رسمي', 'خطة تحسين مكثفة', 'مراجعة العقد'],
      };
    }
  }

  /**
   * اقتراح الترقيات
   */
  suggestPromotions(employeeData, performanceRating) {
    try {
      const { employeeId, name, currentPosition, currentDepartment, yearsOfService } = employeeData;

      const promotionCandidate = {
        employeeId,
        name,
        eligible: performanceRating.overallScore >= this.config.promotionThreshold,
        currentRole: {
          position: currentPosition,
          department: currentDepartment,
          yearsInPosition: yearsOfService,
        },
        performanceScore: performanceRating.overallScore,
        grade: performanceRating.grade,
        classification: performanceRating.classification,
      };

      if (promotionCandidate.eligible) {
        promotionCandidate.recommendation = {
          eligible: true,
          suggestedPositions: this.suggestNextPositions(currentPosition, currentDepartment),
          benefits: {
            salaryIncrease: '15-20%',
            responsibilities: 'تحديد في العرض الرسمي',
            developmentPlan: 'برنامج تطوير قيادي',
          },
          timeline: {
            recommendedDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toLocaleDateString(
              'ar-SA'
            ),
            probationPeriod: '6 أشهر',
          },
          notes: 'الموظف متميز وجاهز للترقية',
        };

        this.emit('promotion:suggested', promotionCandidate);

        this.logger.info(
          `اقتراح ترقية للموظف ${employeeId}: ${currentPosition} → ${promotionCandidate.recommendation.suggestedPositions[0]}`
        );
      } else {
        promotionCandidate.recommendation = {
          eligible: false,
          reason: 'درجة الأداء أقل من الحد الأدنى المطلوب',
          requiredScore: this.config.promotionThreshold,
          currentScore: performanceRating.overallScore,
          gap: (this.config.promotionThreshold - performanceRating.overallScore).toFixed(2),
          suggestedActions: [
            'تحسين الأداء الحالي',
            'المشاركة في برامج التطوير',
            'تحسين الحضور والالتزام',
          ],
          reviewDate: new Date(Date.now() + 180 * 24 * 60 * 60 * 1000).toLocaleDateString('ar-SA'),
        };
      }

      this.talentAssessments.set(employeeId, promotionCandidate);

      return promotionCandidate;
    } catch (error) {
      this.logger.error(`خطأ في اقتراح الترقيات للموظف ${employeeData.employeeId}:`, error.message);
      throw error;
    }
  }

  /**
   * اقتراح المناصب التالية
   */
  suggestNextPositions(currentPosition, _department) {
    const positionProgression = {
      'موظف استقبال': ['كبير موظفي استقبال', 'منسق الاستقبال'],
      'كبير موظفي استقبال': ['منسق الاستقبال', 'مدير الاستقبال'],
      'منسق الاستقبال': ['مدير الاستقبال', 'مدير العمليات'],
      محاسب: ['كبير محاسب', 'منسق محاسبة'],
      'كبير محاسب': ['منسق محاسبة', 'مدير المالية'],
      'منسق محاسبة': ['مدير المالية', 'مدير الإدارة'],
      'موظف مبيعات': ['كبير موظفي المبيعات', 'منسق المبيعات'],
      'كبير موظفي المبيعات': ['منسق المبيعات', 'مدير المبيعات'],
      'منسق المبيعات': ['مدير المبيعات', 'مدير العمليات'],
    };

    return positionProgression[currentPosition] || ['منسق', 'مدير قسم', 'مدير إدارة'];
  }

  /**
   * اقتراح إجراءات تأديبية
   */
  suggestDisciplinaryAction(employeeData, performanceRating, attendanceHistory) {
    try {
      const { employeeId, name, department, previousActions = [] } = employeeData;

      const actionSuggestion = {
        employeeId,
        name,
        department,
        performanceScore: performanceRating.overallScore,
        grade: performanceRating.grade,
        status: 'pending',
        timestamp: new Date().toISOString(),
      };

      if (performanceRating.overallScore < this.config.disciplinaryThreshold) {
        const consecutiveAbsences = attendanceHistory.consecutiveAbsences || 0;
        const absenceRate = attendanceHistory.absenceRate || 0;

        // تحديد مستوى الإجراء
        let actionLevel = 'warning';
        const actionDescription = [];

        if (consecutiveAbsences >= 3 || absenceRate > 15) {
          actionLevel = 'formal_warning';
          actionDescription.push('غياب متكرر أو متتالي');
        }

        if (previousActions.length > 0) {
          actionLevel = 'suspension';
          actionDescription.push('سابقة إجراءات تأديبية');
        }

        if (performanceRating.overallScore < 30) {
          actionLevel = 'termination';
          actionDescription.push('أداء حرج جداً');
        }

        actionSuggestion.recommended = {
          level: actionLevel,
          description: actionDescription,
          actions: this.getActionsByLevel(actionLevel),
          duration: this.getActionDuration(actionLevel),
          review: {
            date: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toLocaleDateString('ar-SA'),
            condition: 'تحسن الأداء والحضور',
          },
        };

        this.disciplinaryActions.set(employeeId, actionSuggestion);

        this.emit('disciplinary:suggested', actionSuggestion);

        this.logger.warn(`إجراء تأديبي مقترح للموظف ${employeeId}: ${actionLevel}`);
      } else {
        actionSuggestion.recommended = {
          level: 'none',
          description: ['الأداء مقبول'],
          actions: ['المتابعة العادية', 'التشجيع المستمر'],
        };
      }

      return actionSuggestion;
    } catch (error) {
      this.logger.error(
        `خطأ في اقتراح إجراء تأديبي للموظف ${employeeData.employeeId}:`,
        error.message
      );
      throw error;
    }
  }

  /**
   * الحصول على الإجراءات حسب المستوى
   */
  getActionsByLevel(level) {
    const actions = {
      warning: ['تنبيه شفهي من المدير', 'مناقشة الأسباب', 'تحديد هدف التحسن', 'متابعة أسبوعية'],
      formal_warning: [
        'إنذار رسمي كتابي',
        'توثيق الملف الشخصي',
        'خطة تحسين 30 يوم',
        'متابعة يومية',
        'حسم 50% من المكافأة',
      ],
      suspension: [
        'إيقاف مؤقت عن العمل',
        'مراجعة شاملة للملف',
        'فرصة أخيرة للتحسن',
        'خطة تحسين مكثفة 60 يوم',
        'عدم منح مكافآت',
      ],
      termination: ['فصل من الخدمة', 'تسليم المستحقات', 'إجراءات نهائية', 'توثيق الأسباب'],
      none: ['المتابعة العادية', 'التشجيع والتحفيز', 'فرص تطوير إضافية'],
    };

    return actions[level] || actions.none;
  }

  /**
   * مدة الإجراء التأديبي
   */
  getActionDuration(level) {
    const durations = {
      warning: { days: 7, description: 'تنبيه لمدة أسبوع' },
      formal_warning: { days: 30, description: 'إنذار رسمي لمدة 30 يوم' },
      suspension: { days: 60, description: 'إيقاف مؤقت لمدة 60 يوم' },
      termination: { days: 0, description: 'فصل فوري' },
      none: { days: null, description: 'لا توجد مدة محددة' },
    };

    return durations[level] || durations.none;
  }

  /**
   * توليد تقرير المواهب الشامل
   */
  generateTalentReport(departmentData) {
    try {
      const { departmentId, departmentName, employees } = departmentData;

      // تصنيف الموظفين
      const highPerformers = [];
      const standardPerformers = [];
      const improvementNeeded = [];
      const poorPerformers = [];

      employees.forEach(emp => {
        const rating = this.performanceRatings.get(emp.employeeId);
        if (!rating) return;

        if (rating.overallScore >= this.config.promotionThreshold) {
          highPerformers.push(emp);
        } else if (rating.overallScore >= 70) {
          standardPerformers.push(emp);
        } else if (rating.overallScore >= 60) {
          improvementNeeded.push(emp);
        } else {
          poorPerformers.push(emp);
        }
      });

      const report = {
        header: {
          title: 'تقرير تقييم المواهب بالقسم',
          department: departmentName,
          departmentId,
          generatedDate: new Date().toLocaleDateString('ar-SA'),
        },
        summary: {
          totalEmployees: employees.length,
          highPerformers: highPerformers.length,
          standardPerformers: standardPerformers.length,
          improvementNeeded: improvementNeeded.length,
          poorPerformers: poorPerformers.length,
        },
        distribution: {
          highPerformersPercent: ((highPerformers.length / employees.length) * 100).toFixed(2),
          standardPercent: ((standardPerformers.length / employees.length) * 100).toFixed(2),
          improvementPercent: ((improvementNeeded.length / employees.length) * 100).toFixed(2),
          poorPercent: ((poorPerformers.length / employees.length) * 100).toFixed(2),
        },
        talents: {
          promotionCandidates: highPerformers.map(emp => ({
            name: emp.name,
            currentRole: emp.position,
            score: this.performanceRatings.get(emp.employeeId)?.overallScore,
          })),
          developmentCandidates: standardPerformers.map(emp => ({
            name: emp.name,
            currentRole: emp.position,
            score: this.performanceRatings.get(emp.employeeId)?.overallScore,
          })),
          improvementPlan: improvementNeeded.map(emp => ({
            name: emp.name,
            currentRole: emp.position,
            score: this.performanceRatings.get(emp.employeeId)?.overallScore,
            action: 'خطة تحسين',
          })),
          disciplinaryReview: poorPerformers.map(emp => ({
            name: emp.name,
            currentRole: emp.position,
            score: this.performanceRatings.get(emp.employeeId)?.overallScore,
            action: 'إجراء تأديبي',
          })),
        },
        recommendations: {
          immediate: [
            `ترقية ${highPerformers.length} موظف(ة) متميز`,
            `تطوير ${standardPerformers.length} موظف(ة) عادي`,
            `متابعة ${improvementNeeded.length} موظف(ة) يحتاج تحسن`,
            `إجراء ${poorPerformers.length} موظف(ة) ضعيف الأداء`,
          ],
          strategic: [
            'تطوير برامج تدريب شاملة',
            'تعزيز الحضور والالتزام',
            'بناء ثقافة الأداء العالي',
            'تحسين بيئة العمل',
          ],
        },
        timestamp: new Date().toISOString(),
      };

      this.logger.info(`تم توليد تقرير المواهب للقسم ${departmentName}`);

      return report;
    } catch (error) {
      this.logger.error('خطأ في توليد تقرير المواهب:', error.message);
      throw error;
    }
  }

  /**
   * تحديث ملف الموظف
   */
  updateEmployeeFile(employeeId, updateData) {
    try {
      const currentRating = this.performanceRatings.get(employeeId);

      const updatedFile = {
        employeeId,
        lastUpdated: new Date().toISOString(),
        performanceRating: currentRating,
        ...updateData,
      };

      this.performanceRatings.set(employeeId, updatedFile);

      this.emit('employee-file:updated', { employeeId, data: updatedFile });

      this.logger.info(`تم تحديث ملف الموظف ${employeeId}`);

      return updatedFile;
    } catch (error) {
      this.logger.error(`خطأ في تحديث ملف الموظف ${employeeId}:`, error.message);
      throw error;
    }
  }

  /**
   * الحصول على ملخص الموارد البشرية
   */
  getHRSummary() {
    try {
      const allRatings = Array.from(this.performanceRatings.values());
      const allAssessments = Array.from(this.talentAssessments.values());
      const allActions = Array.from(this.disciplinaryActions.values());

      const avgPerformance =
        allRatings.reduce((sum, r) => sum + (r.overallScore || 0), 0) / allRatings.length;

      return {
        summary: {
          totalEmployees: allRatings.length,
          averagePerformance: parseFloat(avgPerformance.toFixed(2)),
          promotionCandidates: allAssessments.filter(a => a.eligible).length,
          improvementPlans: allActions.filter(a => a.recommended?.level === 'formal_warning')
            .length,
          disciplinaryActions: allActions.filter(
            a => a.recommended?.level === 'suspension' || a.recommended?.level === 'termination'
          ).length,
        },
        distribution: {
          highPerformers: allRatings.filter(r => r.overallScore >= this.config.promotionThreshold)
            .length,
          standardPerformers: allRatings.filter(
            r => r.overallScore >= 70 && r.overallScore < this.config.promotionThreshold
          ).length,
          improvementNeeded: allRatings.filter(r => r.overallScore >= 60 && r.overallScore < 70)
            .length,
          poorPerformers: allRatings.filter(r => r.overallScore < 60).length,
        },
        generatedAt: new Date().toISOString(),
      };
    } catch (error) {
      this.logger.error('خطأ في الحصول على ملخص الموارد البشرية:', error.message);
      return null;
    }
  }
}

module.exports = AttendanceHRIntegration;
