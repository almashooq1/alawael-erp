/**
 * AttendancePayrollIntegration.js
 * نظام التكامل بين الحضور والرواتب
 * حساب الخصومات والتأثير المالي التلقائي
 */

const { EventEmitter } = require('events');
const Logger = require('../utils/Logger');

class AttendancePayrollIntegration extends EventEmitter {
  constructor(config = {}) {
    super();
    this.config = {
      dailySalary: config.dailySalary || 300,
      dailyWorkHours: config.dailyWorkHours || 8,
      hourlyRate: config.hourlyRate || 37.5,
      absenceDeductionPercent: config.absenceDeductionPercent || 100, // 100% من الراتب اليومي
      lateDeductionRate: config.lateDeductionRate || 5, // 5% من الراتب الساعي لكل ساعة
      maxLateHoursDeduction: config.maxLateHoursDeduction || 4, // أقصى 4 ساعات خصم يومياً
      bonusDeductionPercent: config.bonusDeductionPercent || 50, // 50% من المكافأة الشهرية
      ...config,
    };

    this.logger = new Logger('AttendancePayrollIntegration');
    this.payrollRecords = new Map();
    this.deductionHistory = new Map();
  }

  /**
   * حساب خصم الغياب
   */
  calculateAbsenceDeduction(employeeId, absenceRecords, salary) {
    try {
      const deductionAmount = absenceRecords.length * this.config.dailySalary;
      const deductionPercent = (deductionAmount / salary.monthlyBase) * 100;

      const result = {
        employeeId,
        type: 'absence',
        absenceDays: absenceRecords.length,
        deductionAmount,
        deductionPercent,
        details: {
          rate: `${this.config.dailySalary} ج.م لكل يوم`,
          formula: `${absenceRecords.length} أيام × ${this.config.dailySalary} = ${deductionAmount}`,
          breakdown: absenceRecords.map((rec, idx) => ({
            day: idx + 1,
            date: rec.date,
            deduction: this.config.dailySalary,
            reason: rec.reason || 'غياب بدون إذن',
          })),
        },
        impact: {
          beforeDeduction: salary.monthlyBase,
          afterDeduction: salary.monthlyBase - deductionAmount,
          percentageOfSalary: deductionPercent.toFixed(2),
        },
        timestamp: new Date().toISOString(),
      };

      this.logger.info(`حساب خصم الغياب للموظف ${employeeId}: ${deductionAmount} ج.م`);

      return result;
    } catch (error) {
      this.logger.error(`خطأ في حساب خصم الغياب للموظف ${employeeId}:`, error.message);
      throw error;
    }
  }

  /**
   * حساب خصم التأخر
   */
  calculateLatenessDeduction(employeeId, lateRecords, salary) {
    try {
      const totalLateMinutes = lateRecords.reduce((sum, rec) => sum + rec.minutes, 0);
      const totalLateHours = Math.ceil(totalLateMinutes / 60);
      const cappedLateHours = Math.min(totalLateHours, this.config.maxLateHoursDeduction);

      const deductionAmount = cappedLateHours * this.config.hourlyRate;
      const deductionPercent = (deductionAmount / salary.monthlyBase) * 100;

      const result = {
        employeeId,
        type: 'lateness',
        totalLateMinutes,
        totalLateHours,
        cappedLateHours,
        deductionAmount,
        deductionPercent,
        details: {
          rate: `${this.config.hourlyRate} ج.م لكل ساعة`,
          formula: `${cappedLateHours} ساعات × ${this.config.hourlyRate} = ${deductionAmount}`,
          breakdown: lateRecords.map((rec, idx) => ({
            day: idx + 1,
            date: rec.date,
            lateMinutes: rec.minutes,
            lateHours: (rec.minutes / 60).toFixed(2),
            deduction: (rec.minutes / 60) * this.config.hourlyRate,
          })),
          note:
            cappedLateHours < totalLateHours
              ? `تم تحديد الخصم بـ ${this.config.maxLateHoursDeduction} ساعات (الحد الأقصى)`
              : null,
        },
        impact: {
          beforeDeduction: salary.monthlyBase,
          afterDeduction: salary.monthlyBase - deductionAmount,
          percentageOfSalary: deductionPercent.toFixed(2),
        },
        timestamp: new Date().toISOString(),
      };

      this.logger.info(`حساب خصم التأخر للموظف ${employeeId}: ${deductionAmount} ج.م`);

      return result;
    } catch (error) {
      this.logger.error(`خطأ في حساب خصم التأخر للموظف ${employeeId}:`, error.message);
      throw error;
    }
  }

  /**
   * حساب تأثير الغياب على المكافأة
   */
  calculateBonusImpact(employeeId, absenceRecords, attendanceAnalysis, bonusAmount) {
    try {
      const absenceRate = (absenceRecords.length / 20) * 100; // نسبة من 20 يوم عمل
      let bonusDeduction = 0;

      if (absenceRate > 5) {
        // أكثر من 5 أيام غياب
        bonusDeduction = (bonusAmount * this.config.bonusDeductionPercent) / 100;
      } else if (absenceRate > 2) {
        // من 2-5 أيام
        bonusDeduction = (bonusAmount * 25) / 100;
      }

      const result = {
        employeeId,
        type: 'bonus_impact',
        absenceDays: absenceRecords.length,
        absenceRate: absenceRate.toFixed(2),
        originalBonus: bonusAmount,
        deduction: bonusDeduction,
        finalBonus: bonusAmount - bonusDeduction,
        deductionPercent: ((bonusDeduction / bonusAmount) * 100).toFixed(2),
        criteria: {
          absenceRate_gt_5: absenceRate > 5,
          absenceRate_gt_2: absenceRate > 2,
          deductionApplied: bonusDeduction > 0,
        },
        impact: {
          lossPercentage: ((bonusDeduction / bonusAmount) * 100).toFixed(2),
          lossAmount: bonusDeduction,
          note: 'في حالة الغياب بنسبة أكثر من 5%، يتم خصم 50% من المكافأة',
        },
        timestamp: new Date().toISOString(),
      };

      this.logger.info(`حساب تأثير المكافأة للموظف ${employeeId}: خصم ${bonusDeduction} ج.م`);

      return result;
    } catch (error) {
      this.logger.error(`خطأ في حساب تأثير المكافأة للموظف ${employeeId}:`, error.message);
      throw error;
    }
  }

  /**
   * حساب التأثير الشهري الكامل
   */
  calculateMonthlyImpact(employeeId, monthlyData) {
    try {
      const {
        absenceRecords = [],
        lateRecords = [],
        salary = {},
        bonus = 0,
        attendanceAnalysis = {},
      } = monthlyData;

      // حساب الخصومات الفردية
      const absenceDeduction = this.calculateAbsenceDeduction(employeeId, absenceRecords, salary);

      const latenessDeduction = this.calculateLatenessDeduction(employeeId, lateRecords, salary);

      const bonusImpact = this.calculateBonusImpact(
        employeeId,
        absenceRecords,
        attendanceAnalysis,
        bonus
      );

      // الحسابات الإجمالية
      const totalDeductions = absenceDeduction.deductionAmount + latenessDeduction.deductionAmount;
      const grossSalary = salary.monthlyBase;
      const netSalary = grossSalary - totalDeductions;
      const finalBonus = bonusImpact.finalBonus;
      const totalPayment = netSalary + finalBonus;

      const result = {
        employeeId,
        month: monthlyData.month || new Date().toLocaleDateString('ar-SA'),
        salary: {
          gross: grossSalary,
          absenceDeduction: -absenceDeduction.deductionAmount,
          latenessDeduction: -latenessDeduction.deductionAmount,
          net: netSalary,
        },
        bonus: {
          original: bonus,
          deduction: -bonusImpact.deduction,
          final: finalBonus,
        },
        summary: {
          totalDeductions,
          totalDeductionPercent: ((totalDeductions / grossSalary) * 100).toFixed(2),
          netSalary,
          finalBonus,
          totalPayment,
        },
        breakdown: {
          absenceDeduction,
          latenessDeduction,
          bonusImpact,
        },
        performance: {
          attendanceRate: attendanceAnalysis.attendanceRate || 0,
          punctualityScore: attendanceAnalysis.punctualityScore || 0,
          consistencyScore: attendanceAnalysis.consistencyScore || 0,
          overallPerformance: attendanceAnalysis.overallPerformance || 0,
        },
        financialSummary: {
          baseSalary: grossSalary,
          totalDeductions,
          netSalary,
          bonus: finalBonus,
          totalEarnings: totalPayment,
          savingsOpportunity: this.calculateSavingsOpportunity(absenceRecords, lateRecords),
        },
        timestamp: new Date().toISOString(),
      };

      this.logger.info(`حساب التأثير الشهري للموظف ${employeeId}: صافي ${netSalary} ج.م`);

      this.payrollRecords.set(`${employeeId}_${result.month}`, result);

      return result;
    } catch (error) {
      this.logger.error(`خطأ في حساب التأثير الشهري للموظف ${employeeId}:`, error.message);
      throw error;
    }
  }

  /**
   * حساب فرص الادخار (ما يمكن للموظف توفيره إذا حسّن حضوره)
   */
  calculateSavingsOpportunity(absenceRecords, lateRecords) {
    try {
      const preventableAbsenceDeduction = absenceRecords.length * this.config.dailySalary;
      const preventableLateDeduction =
        ((lateRecords.length * 60) / this.config.dailyWorkHours) * this.config.hourlyRate;
      const totalOpportunity = preventableAbsenceDeduction + preventableLateDeduction;

      return {
        fromAbsences: preventableAbsenceDeduction,
        fromLateness: preventableLateDeduction,
        total: totalOpportunity,
        message: `يمكن للموظف توفير ${totalOpportunity.toFixed(2)} ج.م بتحسين حضوره`,
      };
    } catch (error) {
      this.logger.error('خطأ في حساب فرص الادخار:', error.message);
      return {
        fromAbsences: 0,
        fromLateness: 0,
        total: 0,
      };
    }
  }

  /**
   * توليد تقرير قسيمة الراتب
   */
  generatePayslipReport(employeeData, monthlyImpact) {
    try {
      const { name, department, position, employeeId } = employeeData;

      const { month, salary, bonus, summary, performance, breakdown } = monthlyImpact;

      const report = {
        header: {
          title: 'قسيمة الراتب الشهرية',
          month,
          date: new Date().toLocaleDateString('ar-SA'),
        },
        employee: {
          name,
          employeeId,
          department,
          position,
        },
        salary_breakdown: {
          gross_salary: {
            amount: salary.gross,
            description: 'الراتب الأساسي',
          },
          deductions: {
            absence: {
              amount: Math.abs(salary.absenceDeduction),
              reason: `غياب: ${breakdown.absenceDeduction.absenceDays} أيام`,
              details: breakdown.absenceDeduction.details,
            },
            lateness: {
              amount: Math.abs(salary.latenessDeduction),
              reason: `تأخر: ${breakdown.latenessDeduction.totalLateHours} ساعات`,
              details: breakdown.latenessDeduction.details,
            },
          },
          net_salary: {
            amount: salary.net,
            description: 'الراتب الصافي بعد الخصومات',
          },
        },
        bonus_breakdown: {
          original_bonus: bonus.original,
          bonus_deduction: Math.abs(bonus.deduction),
          final_bonus: bonus.final,
          reason: breakdown.bonusImpact.impact.note,
        },
        totals: {
          total_deductions: summary.totalDeductions,
          net_salary: summary.netSalary,
          final_bonus: summary.finalBonus,
          total_payment: summary.totalPayment,
        },
        performance_metrics: {
          attendance_rate: `${performance.attendanceRate.toFixed(2)}%`,
          punctuality_score: `${performance.punctualityScore}/100`,
          consistency_score: `${performance.consistencyScore}/100`,
          overall_performance: `${performance.overallPerformance}/100`,
        },
        recommendations: this.generatePayslipRecommendations(monthlyImpact),
        notes: {
          calculation_date: new Date().toISOString(),
          currency: 'ج.م (جنيه مصري)',
          legal_notice: 'هذه القسيمة توضح الخصومات المتعلقة بالحضور والمكافآت المستحقة',
        },
      };

      this.logger.info(`تم توليد قسيمة راتب للموظف ${employeeId}`);

      return report;
    } catch (error) {
      this.logger.error('خطأ في توليد قسيمة الراتب:', error.message);
      throw error;
    }
  }

  /**
   * توليد التوصيات من قسيمة الراتب
   */
  generatePayslipRecommendations(monthlyImpact) {
    const recommendations = [];
    const { breakdown, summary, performance } = monthlyImpact;

    // توصيات الحضور
    if (breakdown.absenceDeduction.absenceDays > 3) {
      recommendations.push({
        priority: 'high',
        category: 'attendance',
        message: `الغياب المتكرر يؤثر على الراتب. تم خصم ${breakdown.absenceDeduction.deductionAmount} ج.م`,
        action: 'تحسين الانتظام في الحضور',
      });
    }

    // توصيات التأخر
    if (breakdown.latenessDeduction.totalLateHours > 5) {
      recommendations.push({
        priority: 'medium',
        category: 'punctuality',
        message: `التأخر المتكرر يؤثر على الراتب. تم خصم ${breakdown.latenessDeduction.deductionAmount} ج.م`,
        action: 'المحاولة في الوصول في الوقت المحدد',
      });
    }

    // توصيات المكافأة
    if (breakdown.bonusImpact.deduction > 0) {
      recommendations.push({
        priority: 'high',
        category: 'bonus',
        message: `تأثير الغياب على المكافأة: خصم ${breakdown.bonusImpact.deduction} ج.م`,
        action: 'تحسين السجل الحضوري لضمان الحصول على المكافأة الكاملة',
      });
    }

    // توصيات الأداء
    if (performance.overallPerformance < 70) {
      recommendations.push({
        priority: 'high',
        category: 'performance',
        message: `درجة الأداء منخفضة: ${performance.overallPerformance}/100`,
        action: 'العمل على تحسين مستوى الأداء والالتزام',
      });
    }

    // فرص الادخار
    if (summary.financialSummary.savingsOpportunity.total > 0) {
      recommendations.push({
        priority: 'medium',
        category: 'savings',
        message: summary.financialSummary.savingsOpportunity.message,
        action: 'تحسين الحضور والالتزام لزيادة الراتب',
        amount: summary.financialSummary.savingsOpportunity.total,
      });
    }

    return recommendations;
  }

  /**
   * تحديث سجلات الرواتب
   */
  updatePayslipRecords(employeeId, month, payslipData) {
    try {
      const key = `${employeeId}_${month}`;

      this.deductionHistory.set(key, {
        employeeId,
        month,
        ...payslipData,
        updatedAt: new Date().toISOString(),
      });

      this.emit('payslip:updated', { employeeId, month, data: payslipData });

      this.logger.info(`تم تحديث سجل الراتب للموظف ${employeeId} في ${month}`);

      return this.deductionHistory.get(key);
    } catch (error) {
      this.logger.error(`خطأ في تحديث سجل الراتب للموظف ${employeeId}:`, error.message);
      throw error;
    }
  }

  /**
   * الحصول على سجل الراتب الشهري
   */
  getMonthlyPayrollRecord(employeeId, month) {
    const key = `${employeeId}_${month}`;
    return this.payrollRecords.get(key) || null;
  }

  /**
   * الحصول على سجل الخصومات
   */
  getDeductionHistory(employeeId, months = 12) {
    const history = [];
    const iterator = this.deductionHistory.entries();

    for (const [key, record] of iterator) {
      if (key.startsWith(employeeId)) {
        history.push(record);
      }
      if (history.length >= months) break;
    }

    return history.sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));
  }

  /**
   * إنشاء تنبيه للخصومات الكبيرة
   */
  createDeductionAlert(employeeId, monthlyImpact) {
    try {
      const { summary, breakdown } = monthlyImpact;
      const totalDeductionPercent = parseFloat(summary.totalDeductionPercent);

      if (totalDeductionPercent > 15) {
        const alert = {
          level: 'warning',
          employeeId,
          message: `خصومات كبيرة هذا الشهر: ${summary.totalDeductions} ج.م (${summary.totalDeductionPercent}%)`,
          details: {
            absenceImpact: breakdown.absenceDeduction.deductionAmount,
            latenessImpact: breakdown.latenessDeduction.deductionAmount,
            totalImpact: summary.totalDeductions,
          },
          recommendations: [
            'تحسين الحضور في الأشهر القادمة',
            'التواصل مع المدير لبحث أسباب الغياب',
            'التخطيط لتحسين الأداء',
          ],
          timestamp: new Date().toISOString(),
        };

        this.emit('alert:deduction_warning', alert);
        this.logger.warn(`تنبيه خصومات للموظف ${employeeId}:`, alert.message);

        return alert;
      }

      return null;
    } catch (error) {
      this.logger.error('خطأ في إنشاء تنبيه الخصومات:', error.message);
      return null;
    }
  }

  /**
   * تحليل الاتجاهات المالية
   */
  analyzePaidTrends(employeeId, months = 6) {
    try {
      const history = this.getDeductionHistory(employeeId, months);

      if (history.length === 0) {
        return null;
      }

      const salaries = history.map(rec => rec.salary?.net || 0);
      const bonuses = history.map(rec => rec.bonus?.final || 0);
      const deductions = history.map(rec => rec.summary?.totalDeductions || 0);

      const avgSalary = salaries.reduce((a, b) => a + b, 0) / salaries.length;
      const avgBonus = bonuses.reduce((a, b) => a + b, 0) / bonuses.length;
      const avgDeductions = deductions.reduce((a, b) => a + b, 0) / deductions.length;

      const trend = {
        period: months,
        salary: {
          average: avgSalary,
          trend: salaries[0] > avgSalary ? 'improving' : 'declining',
        },
        bonus: {
          average: avgBonus,
          trend: bonuses[0] > avgBonus ? 'improving' : 'declining',
        },
        deductions: {
          average: avgDeductions,
          trend: deductions[0] < avgDeductions ? 'improving' : 'declining',
        },
        overall: {
          income: avgSalary + avgBonus,
          trend: salaries[0] + bonuses[0] > avgSalary + avgBonus ? 'positive' : 'negative',
        },
      };

      this.logger.info(`تحليل اتجاهات الرواتب للموظف ${employeeId}: ${JSON.stringify(trend)}`);

      return trend;
    } catch (error) {
      this.logger.error('خطأ في تحليل اتجاهات الرواتب:', error.message);
      return null;
    }
  }
}

module.exports = AttendancePayrollIntegration;
