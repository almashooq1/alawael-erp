/**
 * AttendancePredictionEngine.js
 * محرك التنبؤ بالذكاء الاصطناعي
 * توقع الغياب والتأخر والأنماط السلوكية
 */

const EventEmitter = require('events');
const Logger = require('../shared/Logger');

class AttendancePredictionEngine extends EventEmitter {
  constructor(config = {}) {
    super();

    this.config = {
      enabled: config.enabled !== false,
      modelType: config.modelType || 'simple', // simple, advanced, neural
      minDataPoints: config.minDataPoints || 20, // الحد الأدنى للبيانات التاريخية
      predictionHorizon: config.predictionHorizon || 30, // عدد الأيام للتنبؤ
      confidenceThreshold: config.confidenceThreshold || 0.6, // 60%
      ...config,
    };

    this.logger = new Logger('AttendancePredictionEngine');
    this.models = new Map(); // userId -> model
    this.historicalData = new Map(); // userId -> attendance history
    this.predictions = new Map(); // userId -> predictions
  }

  /**
   * تدريب النموذج على بيانات الموظف التاريخية
   */
  async trainModel(userId, historicalRecords) {
    try {
      if (historicalRecords.length < this.config.minDataPoints) {
        return {
          success: false,
          message: `بيانات غير كافية. المطلوب ${this.config.minDataPoints} سجلات على الأقل`,
          recordsProvided: historicalRecords.length,
        };
      }

      // تخزين البيانات التاريخية
      this.historicalData.set(userId, historicalRecords);

      // بناء النموذج
      const model = this.buildModel(userId, historicalRecords);

      this.models.set(userId, model);

      this.logger.info(`تم تدريب النموذج للموظف ${userId}`);

      return {
        success: true,
        message: 'تم تدريب النموذج بنجاح',
        modelStats: {
          recordsUsed: historicalRecords.length,
          patterns: Object.keys(model.patterns).length,
          accuracy: model.accuracy,
        },
      };
    } catch (error) {
      this.logger.error('خطأ في تدريب النموذج', error);
      return {
        success: false,
        message: error.message,
      };
    }
  }

  /**
   * بناء النموذج التنبؤي
   */
  buildModel(userId, records) {
    const patterns = this.extractPatterns(records);
    const statistics = this.calculateStatistics(records);
    const riskFactors = this.identifyRiskFactors(records);

    const model = {
      userId,
      trainedAt: new Date(),
      recordsCount: records.length,
      patterns,
      statistics,
      riskFactors,
      accuracy: this.calculateModelAccuracy(patterns, statistics),
    };

    return model;
  }

  /**
   * استخراج الأنماط من البيانات التاريخية
   */
  extractPatterns(records) {
    const patterns = {
      dayOfWeekPatterns: {}, // أيام الأسبوع
      monthPatterns: {}, // الأشهر
      timePatterns: {}, // الفترات الزمنية
      sequencePatterns: [], // الأنماط المتسلسلة
    };

    // تحليل حسب يوم الأسبوع
    for (const record of records) {
      const date = new Date(record.date);
      const dayOfWeek = date.toLocaleDateString('ar-SA', { weekday: 'long' });

      patterns.dayOfWeekPatterns[dayOfWeek] = patterns.dayOfWeekPatterns[dayOfWeek] || {
        absent: 0,
        late: 0,
        onTime: 0,
        total: 0,
      };

      patterns.dayOfWeekPatterns[dayOfWeek].total++;

      if (record.status === 'ABSENT') {
        patterns.dayOfWeekPatterns[dayOfWeek].absent++;
      } else if (record.status === 'LATE') {
        patterns.dayOfWeekPatterns[dayOfWeek].late++;
      } else {
        patterns.dayOfWeekPatterns[dayOfWeek].onTime++;
      }
    }

    // تحليل حسب الشهر
    for (const record of records) {
      const date = new Date(record.date);
      const month = date.toLocaleDateString('ar-SA', { month: 'long' });

      patterns.monthPatterns[month] = patterns.monthPatterns[month] || {
        absenceRate: 0,
        lateRate: 0,
        count: 0,
      };
      patterns.monthPatterns[month].count++;
    }

    // تحديد الأنماط المتسلسلة
    patterns.sequencePatterns = this.findSequencePatterns(records);

    return patterns;
  }

  /**
   * إيجاد الأنماط المتسلسلة (مثل الغياب قبل العطل)
   */
  findSequencePatterns(records) {
    const patterns = {
      absent_before_weekend: 0,
      absent_after_weekend: 0,
      consecutive_lates: 0,
      pattern_absent_thursday: 0, // يوم الخميس قبل العطلة
    };

    for (let i = 0; i < records.length - 1; i++) {
      const current = records[i];
      const next = records[i + 1];
      const currentDate = new Date(current.date);

      // الغياب قبل العطلة (الخميس/الجمعة)
      if (
        current.status === 'ABSENT' &&
        (currentDate.getDay() === 4 || currentDate.getDay() === 5)
      ) {
        patterns.absent_before_weekend++;
      }

      // الغياب بعد العطلة (السبت/الأحد)
      if (
        current.status === 'ABSENT' &&
        (currentDate.getDay() === 0 || currentDate.getDay() === 6)
      ) {
        patterns.absent_after_weekend++;
      }

      // تأخر متكرر
      if (current.status === 'LATE' && next.status === 'LATE') {
        patterns.consecutive_lates++;
      }
    }

    return patterns;
  }

  /**
   * حساب الإحصائيات من البيانات
   */
  calculateStatistics(records) {
    const stats = {
      totalRecords: records.length,
      absenceRate: 0,
      lateRate: 0,
      onTimeRate: 0,
      averageLateMinutes: 0,
      consecutiveAbsenceMax: 0,
      seasonalTrend: {},
    };

    let absences = 0;
    let lates = 0;
    let onTime = 0;
    let totalLateMinutes = 0;
    let lateCount = 0;
    let consecutiveDays = 0;
    let maxConsecutive = 0;

    for (const record of records) {
      if (record.status === 'ABSENT') {
        absences++;
        consecutiveDays++;
      } else if (record.status === 'LATE') {
        lates++;
        totalLateMinutes += record.lateMinutes || 0;
        lateCount++;
        consecutiveDays = 0;
      } else {
        onTime++;
        consecutiveDays = 0;
      }

      maxConsecutive = Math.max(maxConsecutive, consecutiveDays);
    }

    stats.absenceRate = (absences / records.length) * 100;
    stats.lateRate = (lates / records.length) * 100;
    stats.onTimeRate = (onTime / records.length) * 100;
    stats.averageLateMinutes = lateCount > 0 ? totalLateMinutes / lateCount : 0;
    stats.consecutiveAbsenceMax = maxConsecutive;

    return stats;
  }

  /**
   * تحديد عوامل الخطر
   */
  identifyRiskFactors(records) {
    const riskFactors = {
      highAbsenceRisk: false,
      highLateRisk: false,
      weekendPattern: false,
      seasonalRisk: false,
      riskScore: 0,
    };

    const stats = this.calculateStatistics(records);

    if (stats.absenceRate > 15) riskFactors.highAbsenceRisk = true;
    if (stats.lateRate > 20) riskFactors.highLateRisk = true;

    // التحقق من نمط العطلة
    const patterns = this.extractPatterns(records);
    if (
      patterns.sequencePatterns.absent_before_weekend > records.length * 0.1 ||
      patterns.sequencePatterns.absent_after_weekend > records.length * 0.1
    ) {
      riskFactors.weekendPattern = true;
    }

    // حساب درجة الخطر
    riskFactors.riskScore = this.calculateRiskScore(stats, patterns);

    return riskFactors;
  }

  /**
   * حساب درجة الخطر (0-100)
   */
  calculateRiskScore(stats, patterns) {
    let score = 0;

    // 40% من معدل الغياب
    score += (stats.absenceRate / 25) * 40; // أقصى 25% = 40 نقطة

    // 30% من معدل التأخر
    score += (stats.lateRate / 30) * 30; // أقصى 30% = 30 نقطة

    // 20% من الأنماط
    score += (patterns.sequencePatterns.absent_before_weekend / 10) * 20;

    // 10% إضافية للغياب المتتالي
    score += Math.min(stats.consecutiveAbsenceMax / 10, 1) * 10;

    return Math.min(score, 100);
  }

  /**
   * حساب دقة النموذج
   */
  calculateModelAccuracy(patterns, statistics) {
    // درجة بسيطة بناءً على اكتمال البيانات
    let accuracy = 0.5; // 50% كحد أساسي

    if (Object.keys(patterns.dayOfWeekPatterns).length >= 5) accuracy += 0.15;
    if (Object.keys(patterns.monthPatterns).length >= 6) accuracy += 0.15;
    if (patterns.sequencePatterns.length > 0) accuracy += 0.15;
    if (statistics.totalRecords >= 100) accuracy += 0.05;

    return Math.min(accuracy, 0.95);
  }

  /**
   * التنبؤ بالغياب لتاريخ معين
   */
  predictAbsence(userId, date) {
    try {
      const model = this.models.get(userId);
      if (!model) {
        return {
          success: false,
          message: 'لم يتم تدريب نموذج لهذا الموظف',
        };
      }

      const targetDate = new Date(date);
      const dayOfWeek = targetDate.toLocaleDateString('ar-SA', { weekday: 'long' });
      const month = targetDate.toLocaleDateString('ar-SA', { month: 'long' });

      // جمع عوامل الخطر
      const riskFactors = {
        dayOfWeekFactor: this.getDayOfWeekRiskFactor(model, dayOfWeek),
        monthFactor: this.getMonthRiskFactor(model, month),
        weekendProximity: this.getWeekendProximityFactor(targetDate),
        seasonalFactor: this.getSeasonalFactor(targetDate),
        historicalRate: model.statistics.absenceRate,
      };

      // حساب درجة الخطر
      const absenceRiskScore = this.calculateAbsenceRiskScore(riskFactors);

      return {
        success: true,
        date: date,
        riskScore: absenceRiskScore,
        likelihood: absenceRiskScore > 60 ? 'عالية' : absenceRiskScore > 30 ? 'متوسطة' : 'منخفضة',
        confidence: model.accuracy,
        riskFactors,
        recommendation:
          absenceRiskScore > 60
            ? 'تحضير خطة بديلة'
            : absenceRiskScore > 30
              ? 'مراقبة الموظف'
              : 'وضع عادي',
      };
    } catch (error) {
      this.logger.error('خطأ في التنبؤ بالغياب', error);
      return {
        success: false,
        message: error.message,
      };
    }
  }

  /**
   * التنبؤ بالتأخر
   */
  predictLate(userId, date) {
    try {
      const model = this.models.get(userId);
      if (!model) {
        return {
          success: false,
          message: 'لم يتم تدريب نموذج لهذا الموظف',
        };
      }

      const targetDate = new Date(date);
      const dayOfWeek = targetDate.toLocaleDateString('ar-SA', { weekday: 'long' });

      const lateRiskScore = this.calculateLateRiskScore(model, dayOfWeek);

      return {
        success: true,
        date: date,
        riskScore: lateRiskScore,
        likelihood: lateRiskScore > 50 ? 'عالية' : lateRiskScore > 25 ? 'متوسطة' : 'منخفضة',
        confidence: model.accuracy,
        expectedLateMinutes:
          lateRiskScore > 30 ? Math.round(model.statistics.averageLateMinutes) : 0,
      };
    } catch (error) {
      this.logger.error('خطأ في التنبؤ بالتأخر', error);
      return {
        success: false,
        message: error.message,
      };
    }
  }

  /**
   * توقع الأداء الشهري
   */
  predictMonthlyPerformance(userId, month) {
    try {
      const model = this.models.get(userId);
      if (!model) {
        return {
          success: false,
          message: 'لم يتم تدريب نموذج لهذا الموظف',
        };
      }

      // حساب عدد أيام الشهر
      const daysInMonth = 20; // تقريباً 20 يوم عمل في الشهر

      let predictedAbsences = 0;
      let predictedLates = 0;

      // التنبؤ لكل يوم في الشهر
      for (let day = 1; day <= daysInMonth; day++) {
        const date = new Date(month.getFullYear(), month.getMonth(), day);
        const absencePrediction = this.predictAbsence(userId, date);
        const latePrediction = this.predictLate(userId, date);

        if (absencePrediction.riskScore > 60) predictedAbsences++;
        if (latePrediction.riskScore > 50) predictedLates++;
      }

      const predictedAttendanceRate = ((daysInMonth - predictedAbsences) / daysInMonth) * 100;

      return {
        success: true,
        month: month.toLocaleDateString('ar-SA', { year: 'numeric', month: 'long' }),
        predictedAttendanceRate: Math.round(predictedAttendanceRate),
        predictedAbsences,
        predictedLates,
        performanceRating: this.getPerformanceRating(predictedAttendanceRate),
        recommendation: this.getMonthlyRecommendation(predictedAbsences, daysInMonth),
      };
    } catch (error) {
      this.logger.error('خطأ في التنبؤ بالأداء الشهري', error);
      return {
        success: false,
        message: error.message,
      };
    }
  }

  /**
   * الحصول على عامل خطر يوم الأسبوع
   */
  getDayOfWeekRiskFactor(model, dayOfWeek) {
    const patterns = model.patterns.dayOfWeekPatterns[dayOfWeek];
    if (!patterns) return 0.5;

    return (patterns.absent / patterns.total) * 100;
  }

  /**
   * الحصول على عامل خطر الشهر
   */
  getMonthRiskFactor(model, month) {
    const patterns = model.patterns.monthPatterns[month];
    if (!patterns) return 0.5;

    return patterns.absenceRate || 0;
  }

  /**
   * عامل القرب من العطلة (الأسبوع نهاية)
   */
  getWeekendProximityFactor(date) {
    const dayOfWeek = date.getDay();

    // الخميس والجمعة (أيام قريبة من العطلة)
    if (dayOfWeek === 4 || dayOfWeek === 5) {
      return 20; // خطر إضافي 20%
    }

    // الأحد الأول من الأسبوع
    if (dayOfWeek === 0) {
      return 10; // خطر إضافي 10%
    }

    return 0;
  }

  /**
   * عامل الموسمية
   */
  getSeasonalFactor(date) {
    const month = date.getMonth();

    // الصيف (أعلى غياب بسبب الإجازات)
    if (month >= 5 && month <= 8) {
      return 25;
    }

    // الشتاء (أمراض موسمية)
    if (month === 11 || month === 0 || month === 1) {
      return 15;
    }

    return 0;
  }

  /**
   * حساب درجة خطر الغياب
   */
  calculateAbsenceRiskScore(riskFactors) {
    return (
      riskFactors.dayOfWeekFactor * 0.3 +
      riskFactors.monthFactor * 0.2 +
      riskFactors.weekendProximity * 0.2 +
      riskFactors.seasonalFactor * 0.15 +
      riskFactors.historicalRate * 0.15
    );
  }

  /**
   * حساب درجة خطر التأخر
   */
  calculateLateRiskScore(model, dayOfWeek) {
    const patterns = model.patterns.dayOfWeekPatterns[dayOfWeek];
    if (!patterns) return 25;

    return (patterns.late / patterns.total) * 100;
  }

  /**
   * الحصول على تقييم الأداء
   */
  getPerformanceRating(attendanceRate) {
    if (attendanceRate >= 95) return 'ممتاز';
    if (attendanceRate >= 85) return 'جيد جداً';
    if (attendanceRate >= 75) return 'جيد';
    if (attendanceRate >= 60) return 'مقبول';
    return 'ضعيف';
  }

  /**
   * التوصية الشهرية
   */
  getMonthlyRecommendation(predictedAbsences, daysInMonth) {
    const absencePercentage = (predictedAbsences / daysInMonth) * 100;

    if (absencePercentage > 20) {
      return 'تنبيه حرج - يجب إجراء مقابلة مع الموظف';
    } else if (absencePercentage > 10) {
      return 'مراقبة مكثفة - متابعة قريبة مطلوبة';
    } else if (absencePercentage > 5) {
      return 'مراقبة عادية';
    } else {
      return 'أداء جيد - لا إجراء مطلوب';
    }
  }

  /**
   * التنبؤ بفترة زمنية كاملة
   */
  predictPeriod(userId, startDate, endDate) {
    try {
      const predictions = [];
      const current = new Date(startDate);

      while (current <= endDate) {
        const absencePred = this.predictAbsence(userId, current);
        const latePred = this.predictLate(userId, current);

        if (absencePred.success && latePred.success) {
          predictions.push({
            date: new Date(current),
            absenceRisk: absencePred.riskScore,
            lateRisk: latePred.riskScore,
            overallRisk: Math.max(absencePred.riskScore, latePred.riskScore),
          });
        }

        current.setDate(current.getDate() + 1);
      }

      return {
        success: true,
        period: `من ${startDate} إلى ${endDate}`,
        predictions,
        summary: {
          highRiskDays: predictions.filter(p => p.overallRisk > 60).length,
          mediumRiskDays: predictions.filter(p => p.overallRisk > 30 && p.overallRisk <= 60).length,
          lowRiskDays: predictions.filter(p => p.overallRisk <= 30).length,
        },
      };
    } catch (error) {
      this.logger.error('خطأ في التنبؤ بفترة زمنية', error);
      return {
        success: false,
        message: error.message,
      };
    }
  }
}

module.exports = AttendancePredictionEngine;
