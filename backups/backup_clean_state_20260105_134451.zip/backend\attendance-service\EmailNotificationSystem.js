/**
 * EmailNotificationSystem.js
 * نظام الإشعارات البريدية الشامل
 * إرسال إشعارات فورية لجميع الأحداث المهمة
 */

const nodemailer = require('nodemailer');
const EventEmitter = require('events');

class EmailNotificationSystem extends EventEmitter {
  constructor(config = {}) {
    super();

    this.config = {
      service: config.service || 'gmail',
      email: process.env.NOTIFICATION_EMAIL || 'noreply@company.com',
      password: process.env.NOTIFICATION_PASSWORD || '',
      host: config.host || 'smtp.gmail.com',
      port: config.port || 587,
      secure: config.secure || false,
    };

    this.transporter = nodemailer.createTransport({
      service: this.config.service,
      host: this.config.host,
      port: this.config.port,
      secure: this.config.secure,
      auth: {
        user: this.config.email,
        pass: this.config.password,
      },
    });

    this.templates = this.initializeTemplates();
    this.retryPolicy = {
      maxRetries: 3,
      retryDelay: 5000, // 5 seconds
    };
  }

  /**
   * نماذج البريد الإلكتروني المختلفة
   */
  initializeTemplates() {
    return {
      absenceAlert: {
        subject: 'تنبيه: غياب موظف',
        template: data => `
          <h2>تنبيه غياب</h2>
          <p>الموظف: <strong>${data.employeeName}</strong></p>
          <p>التاريخ: ${data.date}</p>
          <p>هذا هو الغياب رقم <strong>${data.absenceCount}</strong> هذا الشهر</p>
          <p>الإجراء المقترح: ${data.suggestedAction}</p>
        `,
      },

      latenessAlert: {
        subject: 'تنبيه: تأخر متكرر',
        template: data => `
          <h2>تنبيه تأخر</h2>
          <p>الموظف: <strong>${data.employeeName}</strong></p>
          <p>التاريخ: ${data.date}</p>
          <p>وقت التأخر: ${data.minutes} دقيقة</p>
          <p>إجمالي ساعات التأخر هذا الشهر: ${data.totalLateHours} ساعات</p>
          <p>التأثير على الراتب: -${data.salaryImpact} ج.م</p>
        `,
      },

      payslipNotification: {
        subject: 'قسيمة الراتب الشهرية',
        template: data => `
          <h2>قسيمة الراتب</h2>
          <p>الموظف: <strong>${data.employeeName}</strong></p>
          <p>الشهر: ${data.month}</p>
          <table border="1" cellpadding="10">
            <tr>
              <th>البيان</th>
              <th>المبلغ</th>
            </tr>
            <tr>
              <td>الراتب الأساسي</td>
              <td>${data.baseSalary} ج.م</td>
            </tr>
            <tr>
              <td>استقطاع الغياب</td>
              <td>-${data.absenceDeduction} ج.م</td>
            </tr>
            <tr>
              <td>استقطاع التأخر</td>
              <td>-${data.latenessDeduction} ج.م</td>
            </tr>
            <tr style="font-weight: bold;">
              <td>صافي الراتب</td>
              <td>${data.netSalary} ج.م</td>
            </tr>
          </table>
        `,
      },

      performanceRating: {
        subject: 'تقرير تقييم الأداء',
        template: data => `
          <h2>تقييم الأداء</h2>
          <p>الموظف: <strong>${data.employeeName}</strong></p>
          <p>الفترة: ${data.period}</p>
          <p style="font-size: 18px; color: green;"><strong>الدرجة: ${data.grade}</strong></p>
          <p>النقاط: ${data.score}/100</p>
          <h3>مكونات التقييم:</h3>
          <ul>
            <li>الحضور: ${data.attendanceScore}</li>
            <li>الانضباط: ${data.disciplineScore}</li>
            <li>الإنتاجية: ${data.productivityScore}</li>
            <li>التعاون: ${data.teamworkScore}</li>
          </ul>
          <p>${data.comments}</p>
        `,
      },

      promotionOffer: {
        subject: 'عرض ترقية',
        template: data => `
          <h2>تهانينا! عرض ترقية</h2>
          <p>الموظف: <strong>${data.employeeName}</strong></p>
          <p>الوظيفة الحالية: ${data.currentPosition}</p>
          <p>الوظيفة المقترحة: <strong>${data.newPosition}</strong></p>
          <p>الراتب الجديد: ${data.newSalary} ج.م</p>
          <p>سبب الترقية: ${data.reason}</p>
          <p>يرجى الاتصال بقسم الموارد البشرية لمناقشة التفاصيل.</p>
        `,
      },

      disciplinaryAction: {
        subject: 'إجراء تأديبي',
        template: data => `
          <h2>إجراء تأديبي</h2>
          <p>الموظف: <strong>${data.employeeName}</strong></p>
          <p>نوع الإجراء: <strong>${data.actionType}</strong></p>
          <p>السبب: ${data.reason}</p>
          <p>التفاصيل: ${data.details}</p>
          <p>تاريخ الإجراء: ${data.date}</p>
          <p>للاستفسار: يرجى التواصل مع قسم الموارد البشرية</p>
        `,
      },

      leaveApproval: {
        subject: 'الموافقة على الإجازة',
        template: data => `
          <h2>إشعار الموافقة على الإجازة</h2>
          <p>الموظف: <strong>${data.employeeName}</strong></p>
          <p>نوع الإجازة: ${data.leaveType}</p>
          <p>من: ${data.startDate}</p>
          <p>إلى: ${data.endDate}</p>
          <p>الحالة: <strong style="color: green;">موافق عليه</strong></p>
          <p>الموافق: ${data.approverName}</p>
        `,
      },

      leaveRejection: {
        subject: 'رفض الإجازة',
        template: data => `
          <h2>إشعار رفض الإجازة</h2>
          <p>الموظف: <strong>${data.employeeName}</strong></p>
          <p>نوع الإجازة: ${data.leaveType}</p>
          <p>من: ${data.startDate}</p>
          <p>إلى: ${data.endDate}</p>
          <p>الحالة: <strong style="color: red;">مرفوضة</strong></p>
          <p>السبب: ${data.reason}</p>
          <p>المسؤول عن الرفض: ${data.rejectorName}</p>
        `,
      },

      riskWarning: {
        subject: 'تحذير: موظف في خطر',
        template: data => `
          <h2>تحذير مؤشرات خطر</h2>
          <p>الموظف: <strong>${data.employeeName}</strong></p>
          <p>مستوى الخطر: <strong style="color: red;">${data.riskLevel}</strong></p>
          <p>المؤشرات:</p>
          <ul>
            ${data.indicators.map(ind => `<li>${ind}</li>`).join('')}
          </ul>
          <p>الإجراء المقترح: ${data.suggestedAction}</p>
          <p>يرجى التواصل مع الموظف للتأكد من حالته.</p>
        `,
      },

      monthlyReport: {
        subject: 'التقرير الشهري',
        template: data => `
          <h2>التقرير الشهري - ${data.month}</h2>
          <p>القسم: ${data.department}</p>
          <h3>الإحصائيات:</h3>
          <ul>
            <li>إجمالي الموظفين: ${data.totalEmployees}</li>
            <li>متوسط الحضور: ${data.averageAttendance}%</li>
            <li>متوسط الأداء: ${data.averagePerformance}/100</li>
            <li>إجمالي الاستقطاعات: ${data.totalDeductions} ج.م</li>
            <li>عدد التنبيهات: ${data.alertCount}</li>
          </ul>
          <p>للتفاصيل الكاملة، يرجى زيارة لوحة التحكم.</p>
        `,
      },
    };
  }

  /**
   * إرسال إشعار تنبيه الغياب
   */
  async sendAbsenceAlert(employeeEmail, data) {
    const template = this.templates.absenceAlert;
    return this.sendEmail({
      to: employeeEmail,
      subject: template.subject,
      html: template.template(data),
      cc: data.managerEmail,
    });
  }

  /**
   * إرسال إشعار التأخر
   */
  async sendLatenessAlert(employeeEmail, data) {
    const template = this.templates.latenessAlert;
    return this.sendEmail({
      to: employeeEmail,
      subject: template.subject,
      html: template.template(data),
      cc: data.managerEmail,
    });
  }

  /**
   * إرسال قسيمة الراتب
   */
  async sendPayslip(employeeEmail, data) {
    const template = this.templates.payslipNotification;
    return this.sendEmail({
      to: employeeEmail,
      subject: template.subject,
      html: template.template(data),
      attachments: data.attachments || [],
    });
  }

  /**
   * إرسال إشعار تقييم الأداء
   */
  async sendPerformanceRating(employeeEmail, data) {
    const template = this.templates.performanceRating;
    return this.sendEmail({
      to: employeeEmail,
      subject: template.subject,
      html: template.template(data),
    });
  }

  /**
   * إرسال عرض ترقية
   */
  async sendPromotionOffer(employeeEmail, data) {
    const template = this.templates.promotionOffer;
    return this.sendEmail({
      to: employeeEmail,
      subject: template.subject,
      html: template.template(data),
      cc: data.hrManagerEmail,
    });
  }

  /**
   * إرسال إجراء تأديبي
   */
  async sendDisciplinaryAction(employeeEmail, data) {
    const template = this.templates.disciplinaryAction;
    return this.sendEmail({
      to: employeeEmail,
      subject: template.subject,
      html: template.template(data),
      cc: [data.managerEmail, data.hrManagerEmail],
    });
  }

  /**
   * إرسال الموافقة على الإجازة
   */
  async sendLeaveApproval(employeeEmail, data) {
    const template = this.templates.leaveApproval;
    return this.sendEmail({
      to: employeeEmail,
      subject: template.subject,
      html: template.template(data),
    });
  }

  /**
   * إرسال رفض الإجازة
   */
  async sendLeaveRejection(employeeEmail, data) {
    const template = this.templates.leaveRejection;
    return this.sendEmail({
      to: employeeEmail,
      subject: template.subject,
      html: template.template(data),
    });
  }

  /**
   * إرسال تحذير الخطر
   */
  async sendRiskWarning(managerEmail, data) {
    const template = this.templates.riskWarning;
    return this.sendEmail({
      to: managerEmail,
      subject: template.subject,
      html: template.template(data),
      cc: data.hrManagerEmail,
    });
  }

  /**
   * إرسال التقرير الشهري
   */
  async sendMonthlyReport(recipients, data) {
    const template = this.templates.monthlyReport;
    return this.sendEmail({
      to: recipients.join(','),
      subject: template.subject,
      html: template.template(data),
    });
  }

  /**
   * الدالة الأساسية لإرسال البريد
   */
  async sendEmail(mailOptions, retryCount = 0) {
    try {
      const mailConfig = {
        from: `"نظام الحضور" <${this.config.email}>`,
        ...mailOptions,
      };

      const info = await this.transporter.sendMail(mailConfig);

      console.log(`✅ تم إرسال بريد إلى: ${mailOptions.to}`);

      this.emit('emailSent', {
        to: mailOptions.to,
        subject: mailOptions.subject,
        messageId: info.messageId,
        timestamp: new Date(),
      });

      return { success: true, messageId: info.messageId };
    } catch (error) {
      console.error(`❌ خطأ في إرسال البريد: ${error.message}`);

      // إعادة المحاولة
      if (retryCount < this.retryPolicy.maxRetries) {
        console.log(`🔄 إعادة محاولة (${retryCount + 1}/${this.retryPolicy.maxRetries})...`);
        await this.delay(this.retryPolicy.retryDelay);
        return this.sendEmail(mailOptions, retryCount + 1);
      }

      this.emit('emailFailed', {
        to: mailOptions.to,
        subject: mailOptions.subject,
        error: error.message,
        timestamp: new Date(),
      });

      throw new Error(
        `فشل إرسال البريد بعد ${this.retryPolicy.maxRetries} محاولات: ${error.message}`
      );
    }
  }

  /**
   * إرسال بريد مخصص
   */
  async sendCustomEmail(to, subject, html, options = {}) {
    return this.sendEmail({
      to,
      subject,
      html,
      ...options,
    });
  }

  /**
   * إرسال رسائل جماعية
   */
  async sendBatchEmails(recipients, subject, htmlTemplate, dataArray) {
    const results = [];

    for (let i = 0; i < recipients.length; i++) {
      try {
        const result = await this.sendEmail({
          to: recipients[i],
          subject,
          html: htmlTemplate(dataArray[i]),
        });
        results.push({ recipient: recipients[i], success: true, messageId: result.messageId });
      } catch (error) {
        results.push({ recipient: recipients[i], success: false, error: error.message });
      }

      // تأخير بين الرسائل لتجنب تجاوز حد المعدل
      if (i < recipients.length - 1) {
        await this.delay(500);
      }
    }

    return results;
  }

  /**
   * التحقق من الاتصال مع خادم البريد
   */
  async verifyConnection() {
    try {
      await this.transporter.verify();
      console.log('✅ تم التحقق من الاتصال مع خادم البريد');
      return true;
    } catch (error) {
      console.error('❌ فشل الاتصال مع خادم البريد:', error.message);
      return false;
    }
  }

  // Helper Methods
  delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

module.exports = EmailNotificationSystem;
