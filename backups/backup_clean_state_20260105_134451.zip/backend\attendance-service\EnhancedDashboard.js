/**
 * EnhancedDashboard.js
 * لوحة تحكم متقدمة تجمع كل المعلومات والإحصائيات
 * مع رسوم بيانية فورية وبيانات محدثة في الوقت الفعلي
 */

class EnhancedDashboard {
  constructor(attendanceService, payrollService, hrService, analyticsService) {
    this.attendanceService = attendanceService;
    this.payrollService = payrollService;
    this.hrService = hrService;
    this.analyticsService = analyticsService;
    this.cacheManager = new Map();
    this.cacheExpiry = 5 * 60 * 1000; // 5 دقائق
  }

  /**
   * الحصول على لوحة تحكم موظف (Employee Dashboard)
   * عرض بيانات شخصية: الراتب، الحضور، الأداء
   */
  async getEmployeeDashboard(employeeId) {
    try {
      const cacheKey = `employee_${employeeId}`;
      if (this.cacheManager.has(cacheKey)) {
        const cached = this.cacheManager.get(cacheKey);
        if (Date.now() - cached.timestamp < this.cacheExpiry) {
          return { data: cached.data, source: 'CACHE' };
        }
      }

      const [payslip, attendance, performance, predictions] = await Promise.all([
        this.payrollService.getLatestPayslip(employeeId),
        this.attendanceService.getMonthlyAttendance(employeeId),
        this.hrService.getPerformanceRating(employeeId),
        this.analyticsService.predictAbsence(employeeId),
      ]);

      const dashboard = {
        header: {
          employeeId,
          name: payslip.employeeName,
          department: payslip.department,
          position: payslip.position,
          lastUpdated: new Date().toISOString(),
        },

        // قسم الراتب والاستقطاعات
        payroll: {
          monthlyBase: payslip.monthlyBase,
          latestDeduction: payslip.totalDeduction,
          deductionBreakdown: {
            absence: payslip.absenceDeduction,
            lateness: payslip.latenessDeduction,
            other: payslip.otherDeductions,
          },
          netSalary: payslip.netSalary,
          trend: {
            previousMonth: payslip.previousMonthDeduction,
            changePercent: this.calculateChange(
              payslip.previousMonthDeduction,
              payslip.totalDeduction
            ),
          },
        },

        // قسم الحضور
        attendance: {
          totalDays: attendance.totalWorkingDays,
          presentDays: attendance.presentDays,
          absentDays: attendance.absentDays,
          lateDays: attendance.lateDays,
          presentPercentage: ((attendance.presentDays / attendance.totalWorkingDays) * 100).toFixed(
            2
          ),
          absenceRisk: predictions.absenceRisk,
          riskLevel: predictions.riskLevel, // HIGH, MEDIUM, LOW
          lateRiskScore: predictions.lateRiskScore,
        },

        // قسم الأداء
        performance: {
          currentRating: performance.rating,
          score: performance.score,
          grade: performance.grade, // ممتاز، جيد جداً، جيد، مقبول، ضعيف
          components: {
            attendanceScore: performance.attendanceScore,
            punctualityScore: performance.punctualityScore,
            consistencyScore: performance.consistencyScore,
          },
          trend: performance.trend, // UP, STABLE, DOWN
        },

        // قسم التنبيهات
        alerts: {
          warningCount: attendance.warningCount || 0,
          criticalCount: attendance.criticalCount || 0,
          activeAlerts: attendance.activeAlerts || [],
        },

        // معلومات إجازة
        leaves: {
          annualRemaining: attendance.annualLeavesRemaining || 21,
          sickRemaining: attendance.sickLeavesRemaining || 15,
          personalRemaining: attendance.personalLeavesRemaining || 5,
          totalTaken: attendance.totalLeavesUsed || 0,
        },

        // توصيات شخصية
        recommendations: this.generateEmployeeRecommendations(
          payslip,
          attendance,
          performance,
          predictions
        ),
      };

      // حفظ في cache
      this.cacheManager.set(cacheKey, {
        data: dashboard,
        timestamp: Date.now(),
      });

      return { data: dashboard, source: 'LIVE' };
    } catch (error) {
      console.error('خطأ في الحصول على لوحة التحكم:', error);
      throw new Error(`فشل في حساب لوحة التحكم: ${error.message}`);
    }
  }

  /**
   * لوحة تحكم المدير (Manager Dashboard)
   * عرض فريق الموظفين والإحصائيات الجماعية
   */
  async getManagerDashboard(managerId, departmentId) {
    try {
      const cacheKey = `manager_${managerId}`;
      if (this.cacheManager.has(cacheKey)) {
        const cached = this.cacheManager.get(cacheKey);
        if (Date.now() - cached.timestamp < this.cacheExpiry) {
          return { data: cached.data, source: 'CACHE' };
        }
      }

      const [teamMembers, teamStats, alerts, predictions] = await Promise.all([
        this.attendanceService.getTeamMembers(departmentId),
        this.analyticsService.analyzeTeam(departmentId),
        this.attendanceService.getTeamAlerts(departmentId),
        this.analyticsService.predictTeamPerformance(departmentId),
      ]);

      const dashboard = {
        header: {
          managerId,
          departmentId,
          teamSize: teamMembers.length,
          lastUpdated: new Date().toISOString(),
        },

        // ملخص فريق
        teamSummary: {
          totalMembers: teamMembers.length,
          averageAttendance: teamStats.averageAttendance,
          averageLateness: teamStats.averageLatenessHours,
          averagePerformance: teamStats.averagePerformanceScore,
          healthScore: this.calculateTeamHealth(teamStats),
        },

        // توزيع الأداء
        performanceDistribution: {
          excellent: teamMembers.filter(m => m.rating === 'ممتاز جداً').length,
          good: teamMembers.filter(m => m.rating === 'جيد جداً').length,
          average: teamMembers.filter(m => m.rating === 'جيد').length,
          needsImprovement: teamMembers.filter(m => m.rating === 'ضعيف').length,
        },

        // أعضاء الفريق الأفضل والأسوأ أداءً
        topPerformers: this.getTopPerformers(teamMembers, 5),
        needsAttention: this.getNeedsAttention(teamMembers, 5),

        // التنبيهات
        alerts: {
          criticalCount: alerts.critical?.length || 0,
          warningCount: alerts.warning?.length || 0,
          recentAlerts: alerts.recent || [],
        },

        // التنبؤات
        predictions: {
          riskEmployees: predictions.atRisk || [],
          likelyAbsences: predictions.predictedAbsences || [],
          performanceTrend: predictions.trend,
        },

        // الإجازات
        leavesOverview: {
          pendingApprovals: teamStats.pendingLeaveApprovals || 0,
          usedThisMonth: teamStats.monthlyLeaveUsage || 0,
          upcomingLeaves: teamStats.upcomingLeaves || [],
        },

        // الرواتب
        payrollOverview: {
          totalMonthlyPayroll: teamStats.totalMonthlyPayroll || 0,
          totalDeductions: teamStats.totalMonthlyDeductions || 0,
          averageDeduction: (teamStats.totalMonthlyDeductions / teamMembers.length).toFixed(2),
          deductionTrend: teamStats.deductionTrend,
        },
      };

      this.cacheManager.set(cacheKey, {
        data: dashboard,
        timestamp: Date.now(),
      });

      return { data: dashboard, source: 'LIVE' };
    } catch (error) {
      console.error('خطأ في لوحة تحكم المدير:', error);
      throw new Error(`فشل في حساب لوحة التحكم: ${error.message}`);
    }
  }

  /**
   * لوحة تحكم إدارة الموارد البشرية (HR Dashboard)
   * عرض إحصائيات الشركة كاملة
   */
  async getHRDashboard() {
    try {
      const cacheKey = 'hr_dashboard';
      if (this.cacheManager.has(cacheKey)) {
        const cached = this.cacheManager.get(cacheKey);
        if (Date.now() - cached.timestamp < this.cacheExpiry) {
          return { data: cached.data, source: 'CACHE' };
        }
      }

      const [companyStats, departmentBreakdown, performanceAnalysis, alerts, trends] =
        await Promise.all([
          this.analyticsService.getCompanyStatistics(),
          this.analyticsService.analyzeByDepartment(),
          this.hrService.getPerformanceAnalysis(),
          this.attendanceService.getAllAlerts(),
          this.analyticsService.getTrends('6months'),
        ]);

      const dashboard = {
        header: {
          company: 'الشركة',
          totalEmployees: companyStats.totalEmployees,
          departments: companyStats.departmentCount,
          lastUpdated: new Date().toISOString(),
        },

        // ملخص الشركة
        companySummary: {
          totalEmployees: companyStats.totalEmployees,
          activeEmployees: companyStats.activeEmployees,
          inactiveEmployees: companyStats.inactiveEmployees,
          averageAttendance: companyStats.averageAttendance,
          averagePerformance: companyStats.averagePerformance,
          companyHealthScore: this.calculateCompanyHealth(companyStats),
        },

        // توزيع بالأقسام
        departmentMetrics: departmentBreakdown.map(dept => ({
          name: dept.name,
          headCount: dept.employeeCount,
          attendanceRate: dept.attendanceRate,
          performanceScore: dept.averagePerformance,
          healthScore: dept.healthScore,
        })),

        // توزيع الأداء
        performanceDistribution: {
          excellent: performanceAnalysis.excellent || 0,
          good: performanceAnalysis.good || 0,
          average: performanceAnalysis.average || 0,
          needsImprovement: performanceAnalysis.poor || 0,
          percentageDistribution: performanceAnalysis.distribution,
        },

        // الأزمات والتنبيهات
        criticalIssues: {
          highTurnoverRisk: alerts.turnoverRisk || [],
          disciplinaryActions: alerts.disciplinary || [],
          performanceIssues: alerts.performanceIssues || [],
          attendanceProblems: alerts.attendanceProblems || [],
        },

        // الاتجاهات
        trends: {
          attendanceTrend: trends.attendance,
          performanceTrend: trends.performance,
          turnoveTrend: trends.turnover,
          deductionTrend: trends.deductions,
          period: '6 شهور',
        },

        // الرواتب والميزانية
        payrollBudget: {
          monthlyPayroll: companyStats.monthlyPayroll,
          totalDeductions: companyStats.totalDeductions,
          netPayroll: companyStats.monthlyPayroll - companyStats.totalDeductions,
          budgetUtilization:
            ((companyStats.totalDeductions / companyStats.monthlyPayroll) * 100).toFixed(2) + '%',
        },
      };

      this.cacheManager.set(cacheKey, {
        data: dashboard,
        timestamp: Date.now(),
      });

      return { data: dashboard, source: 'LIVE' };
    } catch (error) {
      console.error('خطأ في لوحة تحكم HR:', error);
      throw new Error(`فشل في حساب لوحة التحكم: ${error.message}`);
    }
  }

  // ─────────────────────────────────────────────────────────────
  // Helper Methods
  // ─────────────────────────────────────────────────────────────

  calculateChange(previous, current) {
    if (previous === 0) return current > 0 ? 100 : 0;
    return (((current - previous) / previous) * 100).toFixed(2);
  }

  generateEmployeeRecommendations(payslip, attendance, performance, predictions) {
    const recommendations = [];

    // توصيات بناءً على الحضور
    if (attendance.absentDays > 5) {
      recommendations.push({
        type: 'ATTENDANCE',
        severity: 'HIGH',
        message: 'لديك غياب متكرر. يرجى تحسين حضورك.',
        action: 'عرض تقرير الغياب',
      });
    }

    if (attendance.lateDays > 10) {
      recommendations.push({
        type: 'LATENESS',
        severity: 'MEDIUM',
        message: 'تأخرك بشكل متكرر قد يؤثر على راتبك.',
        action: 'خطة التحسين',
      });
    }

    // توصيات بناءً على الأداء
    if (performance.grade === 'ضعيف') {
      recommendations.push({
        type: 'PERFORMANCE',
        severity: 'HIGH',
        message: 'أدائك يحتاج إلى تحسين فوري.',
        action: 'الحصول على تدريب',
      });
    }

    // توصيات بناءً على التنبؤات
    if (predictions.riskLevel === 'HIGH') {
      recommendations.push({
        type: 'RISK',
        severity: 'HIGH',
        message: 'هناك مؤشرات لقد تؤدي إلى غياب قريب.',
        action: 'التحدث مع المدير',
      });
    }

    // توصيات مالية
    if (payslip.totalDeduction > payslip.monthlyBase * 0.2) {
      recommendations.push({
        type: 'FINANCIAL',
        severity: 'MEDIUM',
        message: 'الاستقطاعات من راتبك عالية جداً.',
        action: 'عرض تفاصيل الاستقطاعات',
      });
    }

    return recommendations;
  }

  getTopPerformers(teamMembers, count) {
    return teamMembers
      .sort((a, b) => (b.performanceScore || 0) - (a.performanceScore || 0))
      .slice(0, count)
      .map(member => ({
        id: member.id,
        name: member.name,
        score: member.performanceScore,
        rating: member.rating,
      }));
  }

  getNeedsAttention(teamMembers, count) {
    return teamMembers
      .filter(m => m.rating === 'ضعيف' || m.attendanceRate < 80)
      .sort((a, b) => a.performanceScore - b.performanceScore)
      .slice(0, count)
      .map(member => ({
        id: member.id,
        name: member.name,
        issues: this.identifyIssues(member),
      }));
  }

  identifyIssues(member) {
    const issues = [];
    if (member.attendanceRate < 80) issues.push('حضور منخفض');
    if (member.lateCount > 10) issues.push('تأخر متكرر');
    if (member.performanceScore < 50) issues.push('أداء ضعيف');
    if (member.warningCount > 0) issues.push('تحذيرات');
    return issues;
  }

  calculateTeamHealth(stats) {
    let health = 100;
    health -= Math.min(stats.absenteeism * 10, 30);
    health -= Math.min(stats.latenessRate * 10, 20);
    health -= Math.min((100 - stats.averagePerformance) / 2, 30);
    return Math.max(health, 0).toFixed(2);
  }

  calculateCompanyHealth(stats) {
    let health = 100;
    health -= Math.min(stats.turnoverRate, 20);
    health -= Math.min(stats.absenteeism * 5, 20);
    health -= Math.min((100 - stats.averagePerformance) / 2, 30);
    health -= Math.min((stats.issuesCount / 100) * 20, 20);
    return Math.max(health, 0).toFixed(2);
  }

  // تنظيف الـ cache القديم
  clearExpiredCache() {
    const now = Date.now();
    for (const [key, value] of this.cacheManager.entries()) {
      if (now - value.timestamp > this.cacheExpiry) {
        this.cacheManager.delete(key);
      }
    }
  }
}

module.exports = EnhancedDashboard;
