/**
 * ExternalIntegrationManager.js
 * نظام التكاملات الخارجية
 * SAP, Salesforce, Google Workspace, Slack/Teams
 */

const axios = require('axios');
const { EventEmitter } = require('events');

class ExternalIntegrationManager extends EventEmitter {
  constructor(config = {}) {
    super();
    this.config = {
      sapBaseUrl: config.sapBaseUrl || process.env.SAP_BASE_URL,
      sapUsername: config.sapUsername || process.env.SAP_USERNAME,
      sapPassword: config.sapPassword || process.env.SAP_PASSWORD,

      salesforceBaseUrl: config.salesforceBaseUrl || process.env.SALESFORCE_BASE_URL,
      salesforceToken: config.salesforceToken || process.env.SALESFORCE_TOKEN,

      googleWorkspaceCredentials:
        config.googleWorkspaceCredentials || process.env.GOOGLE_CREDENTIALS,

      slackWebhook: config.slackWebhook || process.env.SLACK_WEBHOOK,
      teamsWebhook: config.teamsWebhook || process.env.TEAMS_WEBHOOK,

      ...config,
    };

    this.integrationStatus = new Map();
    this.syncLog = [];
    this.retryConfig = {
      maxAttempts: 3,
      delayMs: 1000,
      backoffMultiplier: 2,
    };
  }

  /**
   * ==================== SAP Integration ====================
   */

  /**
   * مزامنة بيانات الموظفين مع SAP
   */
  async syncEmployeesToSAP(employees) {
    try {
      console.log('📤 بدء مزامنة الموظفين إلى SAP...');
      const results = [];

      for (const employee of employees) {
        try {
          const response = await this.retryRequest(async () =>
            this.createOrUpdateSAPEmployee(employee)
          );

          results.push({
            employeeId: employee._id,
            status: 'SUCCESS',
            sapId: response.data.ID,
            syncedAt: new Date(),
          });

          this.logSyncEvent('SAP_EMPLOYEE_SYNC', 'SUCCESS', employee._id);
        } catch (error) {
          results.push({
            employeeId: employee._id,
            status: 'FAILED',
            error: error.message,
          });

          this.logSyncEvent('SAP_EMPLOYEE_SYNC', 'FAILED', employee._id, error.message);
        }
      }

      this.updateIntegrationStatus('SAP', 'CONNECTED', results);
      this.emit('sapSync', results);

      return {
        totalProcessed: employees.length,
        successful: results.filter(r => r.status === 'SUCCESS').length,
        failed: results.filter(r => r.status === 'FAILED').length,
        results,
      };
    } catch (error) {
      this.updateIntegrationStatus('SAP', 'ERROR', error.message);
      this.emit('sapSyncError', error);
      throw error;
    }
  }

  /**
   * إنشاء أو تحديث موظف في SAP
   */
  async createOrUpdateSAPEmployee(employee) {
    const sapPayload = {
      EMPLOYEE_ID: employee.employeeId,
      FIRST_NAME: employee.firstName,
      LAST_NAME: employee.lastName,
      EMAIL: employee.email,
      DEPARTMENT: employee.department,
      POSITION: employee.position,
      HIRE_DATE: employee.hireDate,
      STATUS: employee.status === 'active' ? 'E' : 'T',
      SALARY: employee.salary,
      CURRENCY: 'SAR', // أو العملة المناسبة
    };

    const response = await axios.post(`${this.config.sapBaseUrl}/api/employees`, sapPayload, {
      auth: {
        username: this.config.sapUsername,
        password: this.config.sapPassword,
      },
      headers: {
        'Content-Type': 'application/json',
      },
    });

    return response;
  }

  /**
   * جلب بيانات الموظفين من SAP
   */
  async fetchEmployeesFromSAP() {
    try {
      console.log('📥 جلب بيانات الموظفين من SAP...');

      const response = await this.retryRequest(async () =>
        axios.get(`${this.config.sapBaseUrl}/api/employees`, {
          auth: {
            username: this.config.sapUsername,
            password: this.config.sapPassword,
          },
        })
      );

      const employees = response.data.map(emp => ({
        externalId: emp.EMPLOYEE_ID,
        firstName: emp.FIRST_NAME,
        lastName: emp.LAST_NAME,
        email: emp.EMAIL,
        department: emp.DEPARTMENT,
        position: emp.POSITION,
        salary: emp.SALARY,
        source: 'SAP',
      }));

      this.logSyncEvent(
        'SAP_EMPLOYEE_FETCH',
        'SUCCESS',
        null,
        `Retrieved ${employees.length} employees`
      );

      return employees;
    } catch (error) {
      this.logSyncEvent('SAP_EMPLOYEE_FETCH', 'FAILED', null, error.message);
      throw error;
    }
  }

  /**
   * ==================== Google Workspace Integration ====================
   */

  /**
   * مزامنة الموظفين إلى Google Workspace
   */
  async syncEmployeesToGoogleWorkspace(employees) {
    try {
      console.log('📧 بدء مزامنة الموظفين إلى Google Workspace...');

      const results = [];

      for (const employee of employees) {
        try {
          // إنشاء حساب Google
          const googleUser = await this.createGoogleWorkspaceUser(employee);

          // إضافة إلى مجموعات
          await this.addUserToGoogleGroups(googleUser.id, employee.department);

          results.push({
            employeeId: employee._id,
            status: 'SUCCESS',
            googleEmail: googleUser.primaryEmail,
            syncedAt: new Date(),
          });

          this.logSyncEvent('GOOGLE_WORKSPACE_SYNC', 'SUCCESS', employee._id);
        } catch (error) {
          results.push({
            employeeId: employee._id,
            status: 'FAILED',
            error: error.message,
          });

          this.logSyncEvent('GOOGLE_WORKSPACE_SYNC', 'FAILED', employee._id, error.message);
        }
      }

      this.updateIntegrationStatus('Google Workspace', 'CONNECTED', results);
      this.emit('googleWorkspaceSync', results);

      return {
        totalProcessed: employees.length,
        successful: results.filter(r => r.status === 'SUCCESS').length,
        failed: results.filter(r => r.status === 'FAILED').length,
        results,
      };
    } catch (error) {
      this.updateIntegrationStatus('Google Workspace', 'ERROR', error.message);
      throw error;
    }
  }

  /**
   * إنشاء حساب Google Workspace
   */
  async createGoogleWorkspaceUser(employee) {
    const userEmail = `${employee.firstName.toLowerCase()}.${employee.lastName.toLowerCase()}@company.com`;

    const payload = {
      primaryEmail: userEmail,
      firstName: employee.firstName,
      lastName: employee.lastName,
      password: this.generateTemporaryPassword(),
      changePasswordAtNextLogin: true,
      emails: [
        {
          address: employee.email,
          type: 'personal',
        },
      ],
      phones: [
        {
          value: employee.phone,
          type: 'work',
        },
      ],
      organizations: [
        {
          name: employee.department,
          title: employee.position,
          description: employee.position,
        },
      ],
    };

    const response = await axios.post(
      'https://www.googleapis.com/admin/directory/v1/users',
      payload,
      {
        headers: {
          Authorization: `Bearer ${this.config.googleWorkspaceCredentials}`,
          'Content-Type': 'application/json',
        },
      }
    );

    return response.data;
  }

  /**
   * إضافة مستخدم إلى مجموعات Google
   */
  async addUserToGoogleGroups(userId, department) {
    const groupEmail = `${department.toLowerCase()}@company.com`;

    try {
      await axios.post(
        `https://www.googleapis.com/admin/directory/v1/groups/${groupEmail}/members`,
        {
          email: userId,
          role: 'MEMBER',
        },
        {
          headers: {
            Authorization: `Bearer ${this.config.googleWorkspaceCredentials}`,
          },
        }
      );
    } catch (error) {
      console.warn(`Could not add user to group ${groupEmail}:`, error.message);
    }
  }

  /**
   * ==================== Slack/Teams Integration ====================
   */

  /**
   * إرسال إشعار إلى Slack
   */
  async sendSlackNotification(message) {
    try {
      const payload = {
        blocks: [
          {
            type: 'header',
            text: {
              type: 'plain_text',
              text: message.title || '⚙️ Notification',
            },
          },
          {
            type: 'section',
            text: {
              type: 'mrkdwn',
              text: message.content,
            },
          },
          {
            type: 'context',
            elements: [
              {
                type: 'mrkdwn',
                text: `_${new Date().toLocaleString('ar-SA')}_`,
              },
            ],
          },
        ],
      };

      await axios.post(this.config.slackWebhook, payload);

      this.logSyncEvent('SLACK_NOTIFICATION', 'SUCCESS', null, message.title);
      return { status: 'SUCCESS' };
    } catch (error) {
      this.logSyncEvent('SLACK_NOTIFICATION', 'FAILED', null, error.message);
      throw error;
    }
  }

  /**
   * إرسال إشعار إلى Microsoft Teams
   */
  async sendTeamsNotification(message) {
    try {
      const payload = {
        '@type': 'MessageCard',
        '@context': 'https://schema.org/extensions',
        summary: message.title || 'Notification',
        themeColor: message.color || '0078D4',
        title: message.title,
        sections: [
          {
            activityTitle: message.subtitle || 'Attendance System',
            activitySubtitle: new Date().toLocaleString('ar-SA'),
            text: message.content,
            facts: message.facts || [],
          },
        ],
      };

      await axios.post(this.config.teamsWebhook, payload);

      this.logSyncEvent('TEAMS_NOTIFICATION', 'SUCCESS', null, message.title);
      return { status: 'SUCCESS' };
    } catch (error) {
      this.logSyncEvent('TEAMS_NOTIFICATION', 'FAILED', null, error.message);
      throw error;
    }
  }

  /**
   * ==================== Salesforce Integration ====================
   */

  /**
   * مزامنة بيانات الأداء إلى Salesforce
   */
  async syncPerformanceToSalesforce(performanceData) {
    try {
      console.log('💼 بدء مزامنة بيانات الأداء إلى Salesforce...');

      const results = [];

      for (const record of performanceData) {
        try {
          const sfPayload = {
            Employee_ID__c: record.employeeId,
            Name: record.employeeName,
            Performance_Score__c: record.performanceScore,
            Attendance_Rate__c: record.attendanceRate,
            Review_Date__c: record.reviewDate,
            Rating__c: record.rating,
            Comments__c: record.comments,
          };

          const response = await axios.post(
            `${this.config.salesforceBaseUrl}/services/data/v57.0/sobjects/Custom_Performance_Record__c`,
            sfPayload,
            {
              headers: {
                Authorization: `Bearer ${this.config.salesforceToken}`,
                'Content-Type': 'application/json',
              },
            }
          );

          results.push({
            employeeId: record.employeeId,
            status: 'SUCCESS',
            sfId: response.data.id,
            syncedAt: new Date(),
          });

          this.logSyncEvent('SALESFORCE_PERFORMANCE_SYNC', 'SUCCESS', record.employeeId);
        } catch (error) {
          results.push({
            employeeId: record.employeeId,
            status: 'FAILED',
            error: error.message,
          });

          this.logSyncEvent(
            'SALESFORCE_PERFORMANCE_SYNC',
            'FAILED',
            record.employeeId,
            error.message
          );
        }
      }

      this.updateIntegrationStatus('Salesforce', 'CONNECTED', results);
      this.emit('salesforceSync', results);

      return {
        totalProcessed: performanceData.length,
        successful: results.filter(r => r.status === 'SUCCESS').length,
        failed: results.filter(r => r.status === 'FAILED').length,
        results,
      };
    } catch (error) {
      this.updateIntegrationStatus('Salesforce', 'ERROR', error.message);
      throw error;
    }
  }

  /**
   * ==================== Utility Methods ====================
   */

  /**
   * إعادة محاولة الطلب مع Exponential Backoff
   */
  async retryRequest(requestFn) {
    let lastError;

    for (let attempt = 1; attempt <= this.retryConfig.maxAttempts; attempt++) {
      try {
        return await requestFn();
      } catch (error) {
        lastError = error;

        if (attempt < this.retryConfig.maxAttempts) {
          const delay =
            this.retryConfig.delayMs * Math.pow(this.retryConfig.backoffMultiplier, attempt - 1);
          console.log(`⏳ إعادة محاولة بعد ${delay}ms...`);
          await this.sleep(delay);
        }
      }
    }

    throw lastError;
  }

  /**
   * الانتظار
   */
  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  /**
   * توليد كلمة مرور مؤقتة
   */
  generateTemporaryPassword() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*';
    let password = '';
    for (let i = 0; i < 12; i++) {
      password += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return password;
  }

  /**
   * تسجيل حدث مزامنة
   */
  logSyncEvent(eventType, status, resourceId, details = '') {
    const logEntry = {
      timestamp: new Date(),
      eventType,
      status,
      resourceId,
      details,
    };

    this.syncLog.push(logEntry);

    // الحفاظ على حد أقصى للسجل
    if (this.syncLog.length > 5000) {
      this.syncLog = this.syncLog.slice(-2500);
    }

    console.log(`[${status}] ${eventType}${resourceId ? ` - ${resourceId}` : ''}`);
  }

  /**
   * تحديث حالة التكامل
   */
  updateIntegrationStatus(service, status, details) {
    this.integrationStatus.set(service, {
      status,
      lastUpdate: new Date(),
      details,
    });

    this.emit('integrationStatusChanged', {
      service,
      status,
      timestamp: new Date(),
    });
  }

  /**
   * الحصول على حالة جميع التكاملات
   */
  getIntegrationStatus() {
    const status = {};

    for (const [service, data] of this.integrationStatus.entries()) {
      status[service] = data;
    }

    return {
      timestamp: new Date(),
      integrations: status,
      overallHealth: this.calculateOverallHealth(),
    };
  }

  /**
   * حساب الصحة العامة
   */
  calculateOverallHealth() {
    const statuses = Array.from(this.integrationStatus.values());

    if (statuses.length === 0) return 'UNKNOWN';

    const connectedCount = statuses.filter(s => s.status === 'CONNECTED').length;
    const percentage = (connectedCount / statuses.length) * 100;

    if (percentage === 100) return 'HEALTHY';
    if (percentage >= 75) return 'DEGRADED';
    return 'CRITICAL';
  }

  /**
   * تقرير التكاملات الشامل
   */
  getIntegrationReport() {
    return {
      reportDate: new Date(),
      integrationStatus: this.getIntegrationStatus(),
      recentSyncEvents: this.syncLog.slice(-20).reverse(),
      successRate: this.calculateSyncSuccessRate(),
      recommendations: this.getIntegrationRecommendations(),
    };
  }

  /**
   * حساب نسبة نجاح المزامنة
   */
  calculateSyncSuccessRate() {
    const successful = this.syncLog.filter(l => l.status === 'SUCCESS').length;
    const total = this.syncLog.length;

    return total > 0 ? ((successful / total) * 100).toFixed(2) + '%' : '0%';
  }

  /**
   * توصيات التكاملات
   */
  getIntegrationRecommendations() {
    const recommendations = [];

    // الكشف عن الخدمات المعطلة
    for (const [service, data] of this.integrationStatus.entries()) {
      if (data.status !== 'CONNECTED') {
        recommendations.push({
          service,
          priority: 'HIGH',
          recommendation: `إعادة الاتصال بـ ${service}`,
          action: `تحقق من بيانات الاعتماد والاتصال بـ ${service}`,
        });
      }
    }

    // تحسينات عامة
    recommendations.push({
      service: 'All',
      priority: 'MEDIUM',
      recommendation: 'إعداد رصد تلقائي للمزامنة',
      action: 'فعّل التنبيهات الفورية لأخطاء المزامنة',
    });

    return recommendations;
  }
}

module.exports = ExternalIntegrationManager;
