/**
 * LeaveManagementSystem.js
 * نظام إدارة الإجازات والإذن
 * طلب الإجازة والموافقة وحساب الرصيد
 */

const EventEmitter = require('events');
const Logger = require('../shared/Logger');
const NotificationService = require('./src/utils/NotificationService');

class LeaveManagementSystem extends EventEmitter {
  constructor(config = {}) {
    super();

    this.config = {
      enabled: config.enabled !== true,
      fiscalYear: config.fiscalYear || 'january', // بداية السنة المالية
      ...config,
    };

    this.logger = new Logger('LeaveManagementSystem');
    this.notificationService = new NotificationService();

    // أنواع الإجازات وأرصدتها السنوية
    this.leaveTypes = {
      ANNUAL: {
        name: 'إجازة سنوية',
        annualQuota: 21,
        carryOver: 5, // الأيام التي يمكن نقلها للسنة التالية
        paidType: true,
        requiresApproval: true,
      },
      SICK: {
        name: 'إجازة مرضية',
        annualQuota: 15,
        carryOver: 0,
        paidType: true,
        requiresApproval: false,
        maxConsecutiveDays: 3, // بدون شهادة طبية
      },
      PERSONAL: {
        name: 'إجازة شخصية',
        annualQuota: 5,
        carryOver: 0,
        paidType: true,
        requiresApproval: true,
        maxPerMonth: 2,
      },
      MATERNITY: {
        name: 'إجازة أمومة',
        annualQuota: 60,
        carryOver: 0,
        paidType: true,
        requiresApproval: true,
        oneTimeOnly: true,
      },
      UNPAID: {
        name: 'إجازة بدون راتب',
        annualQuota: null, // غير محدود
        carryOver: 0,
        paidType: false,
        requiresApproval: true,
      },
      COMPASSIONATE: {
        name: 'إجازة رحيل',
        annualQuota: null,
        carryOver: 0,
        paidType: true,
        requiresApproval: false,
        maxDays: 3,
      },
    };

    this.requests = new Map(); // id -> request
    this.balances = new Map(); // userId -> balances
  }

  /**
   * طلب إجازة جديدة
   */
  async requestLeave(userId, leaveData) {
    try {
      // التحقق من البيانات
      this.validateLeaveRequest(userId, leaveData);

      // حساب عدد الأيام
      const duration = this.calculateBusinessDays(leaveData.startDate, leaveData.endDate);

      // التحقق من الرصيد
      const leaveType = this.leaveTypes[leaveData.type];
      const currentBalance = await this.getBalance(userId, leaveData.type);

      if (leaveType.annualQuota && currentBalance < duration) {
        return {
          success: false,
          message: `الرصيد غير كافي. الرصيد الحالي: ${currentBalance} أيام`,
          balance: currentBalance,
        };
      }

      // التحقق من القيود الإضافية
      const restrictionCheck = await this.checkLeaveRestrictions(userId, leaveData, duration);
      if (!restrictionCheck.allowed) {
        return {
          success: false,
          message: restrictionCheck.reason,
        };
      }

      // إنشاء طلب الإجازة
      const request = {
        id: this.generateRequestId(),
        userId,
        type: leaveData.type,
        startDate: new Date(leaveData.startDate),
        endDate: new Date(leaveData.endDate),
        duration,
        reason: leaveData.reason || '',
        attachments: leaveData.attachments || [],
        status: 'PENDING',
        createdAt: new Date(),
        updatedAt: new Date(),
        history: [
          {
            action: 'CREATED',
            timestamp: new Date(),
            by: userId,
            comment: 'تم إنشاء الطلب',
          },
        ],
      };

      // حفظ الطلب
      this.requests.set(request.id, request);
      this.logger.info(`طلب إجازة جديد: ${request.id} للموظف ${userId}`);

      // إرسال للموافقة إذا كانت مطلوبة
      if (leaveType.requiresApproval) {
        await this.sendForApproval(request);
      } else {
        // موافقة تلقائية للإجازات المرضية
        await this.approveLeave(request.id, 'SYSTEM', 'موافقة تلقائية');
      }

      this.emit('leave-requested', request);

      return {
        success: true,
        requestId: request.id,
        message: 'تم تقديم الطلب بنجاح',
        status: request.status,
      };
    } catch (error) {
      this.logger.error('خطأ في طلب الإجازة', error);
      return {
        success: false,
        message: error.message,
      };
    }
  }

  /**
   * الموافقة على طلب الإجازة
   */
  async approveLeave(requestId, approverId, comment = '') {
    try {
      const request = this.requests.get(requestId);
      if (!request) {
        throw new Error('طلب الإجازة غير موجود');
      }

      if (request.status !== 'PENDING') {
        throw new Error('لا يمكن الموافقة على طلب في حالة ' + request.status);
      }

      // تحديث الطلب
      request.status = 'APPROVED';
      request.approvedBy = approverId;
      request.approvedAt = new Date();
      request.approvalComment = comment;
      request.updatedAt = new Date();

      // إضافة للسجل
      request.history.push({
        action: 'APPROVED',
        timestamp: new Date(),
        by: approverId,
        comment,
      });

      // خصم من الرصيد
      if (this.leaveTypes[request.type].paidType) {
        await this.deductBalance(request.userId, request.type, request.duration);
      }

      // تحديث التقويم
      await this.updateCalendar(request.userId, request);

      // إرسال إشعار للموظف
      await this.notificationService.sendEmail(request.userId, {
        subject: 'تمت الموافقة على طلب الإجازة',
        template: 'leave-approved',
        data: request,
      });

      this.logger.info(`تمت الموافقة على الإجازة: ${requestId}`);
      this.emit('leave-approved', request);

      return {
        success: true,
        message: 'تمت الموافقة على الطلب',
        request,
      };
    } catch (error) {
      this.logger.error('خطأ في الموافقة على الإجازة', error);
      throw error;
    }
  }

  /**
   * رفض طلب الإجازة
   */
  async rejectLeave(requestId, approverId, reason) {
    try {
      const request = this.requests.get(requestId);
      if (!request) {
        throw new Error('طلب الإجازة غير موجود');
      }

      if (request.status !== 'PENDING') {
        throw new Error('لا يمكن رفض طلب في حالة ' + request.status);
      }

      request.status = 'REJECTED';
      request.rejectedBy = approverId;
      request.rejectedAt = new Date();
      request.rejectionReason = reason;
      request.updatedAt = new Date();

      request.history.push({
        action: 'REJECTED',
        timestamp: new Date(),
        by: approverId,
        comment: reason,
      });

      // إرسال إشعار للموظف
      await this.notificationService.sendEmail(request.userId, {
        subject: 'تم رفض طلب الإجازة',
        template: 'leave-rejected',
        data: request,
      });

      this.logger.info(`تم رفض الإجازة: ${requestId}`);
      this.emit('leave-rejected', request);

      return {
        success: true,
        message: 'تم رفض الطلب',
        request,
      };
    } catch (error) {
      this.logger.error('خطأ في رفض الإجازة', error);
      throw error;
    }
  }

  /**
   * الحصول على رصيد الإجازة
   */
  async getBalance(userId, leaveType = null) {
    try {
      let balances = this.balances.get(userId);

      if (!balances) {
        // تهيئة الأرصدة من قاعدة البيانات
        balances = await this.initializeBalances(userId);
        this.balances.set(userId, balances);
      }

      if (leaveType) {
        return balances[leaveType] || 0;
      }

      return balances;
    } catch (error) {
      this.logger.error('خطأ في الحصول على الرصيد', error);
      return {};
    }
  }

  /**
   * تهيئة الأرصدة للموظف
   */
  async initializeBalances(userId) {
    const balances = {};

    for (const [type, config] of Object.entries(this.leaveTypes)) {
      if (config.annualQuota) {
        balances[type] = config.annualQuota;
      } else {
        balances[type] = config.maxDays || 0;
      }
    }

    // يمكن تحميل الأرصدة المحفوظة من قاعدة البيانات
    // const dbBalances = await LeaveBalance.findOne({ userId });
    // if (dbBalances) {
    //   Object.assign(balances, dbBalances.toObject());
    // }

    return balances;
  }

  /**
   * خصم من الرصيد
   */
  async deductBalance(userId, leaveType, days) {
    try {
      const balances = await this.getBalance(userId);

      if (!balances[leaveType]) {
        throw new Error(`نوع الإجازة ${leaveType} غير موجود`);
      }

      balances[leaveType] -= days;

      // حفظ في قاعدة البيانات
      // await LeaveBalance.updateOne(
      //   { userId },
      //   { [leaveType]: balances[leaveType] }
      // );

      this.balances.set(userId, balances);
      this.logger.info(`تم خصم ${days} أيام من رصيد ${leaveType} للموظف ${userId}`);

      return balances;
    } catch (error) {
      this.logger.error('خطأ في خصم الرصيد', error);
      throw error;
    }
  }

  /**
   * التحقق من قيود الإجازة
   */
  async checkLeaveRestrictions(userId, leaveData, duration) {
    const leaveType = this.leaveTypes[leaveData.type];

    // التحقق من عدم الإجازة المتزامنة
    const conflictingRequests = await this.getConflictingRequests(
      userId,
      leaveData.startDate,
      leaveData.endDate
    );

    if (conflictingRequests.length > 0) {
      return {
        allowed: false,
        reason: 'يوجد إجازة أخرى في نفس الفترة',
      };
    }

    // التحقق من قيود محددة النوع
    if (leaveType.maxConsecutiveDays && duration > leaveType.maxConsecutiveDays) {
      return {
        allowed: false,
        reason: `لا يمكن أخذ أكثر من ${leaveType.maxConsecutiveDays} أيام متتالية`,
      };
    }

    if (leaveType.maxPerMonth) {
      const monthRequests = await this.getMonthRequests(userId, leaveData.startDate);
      if (monthRequests.length >= leaveType.maxPerMonth) {
        return {
          allowed: false,
          reason: `حد أقصى ${leaveType.maxPerMonth} طلبات في الشهر`,
        };
      }
    }

    if (leaveType.oneTimeOnly) {
      const previousRequests = await this.getPreviousRequests(userId, leaveData.type);
      if (previousRequests.some(r => r.status === 'APPROVED')) {
        return {
          allowed: false,
          reason: 'يمكنك الحصول على هذه الإجازة مرة واحدة فقط',
        };
      }
    }

    return { allowed: true };
  }

  /**
   * حساب أيام العمل (تجاهل عطل نهاية الأسبوع)
   */
  calculateBusinessDays(startDate, endDate) {
    let count = 0;
    const currentDate = new Date(startDate);

    while (currentDate <= endDate) {
      const dayOfWeek = currentDate.getDay();
      // تجاهل الجمعة والسبت (5 و 6)
      if (dayOfWeek !== 5 && dayOfWeek !== 6) {
        count++;
      }
      currentDate.setDate(currentDate.getDate() + 1);
    }

    return count;
  }

  /**
   * إرسال الطلب للموافقة
   */
  async sendForApproval(request) {
    const approvers = await this.getApprovers(request.userId);

    for (const approver of approvers) {
      await this.notificationService.sendEmail(approver.id, {
        subject: `طلب إجازة من ${request.userId}`,
        template: 'leave-approval-request',
        data: {
          request,
          approverName: approver.name,
          approvalLink: `${process.env.APP_URL}/approvals/${request.id}`,
        },
      });
    }
  }

  /**
   * الحصول على الطلبات المتضاربة
   */
  async getConflictingRequests(userId, startDate, endDate) {
    const approvedRequests = Array.from(this.requests.values()).filter(
      r =>
        r.userId === userId &&
        r.status === 'APPROVED' &&
        r.startDate <= new Date(endDate) &&
        r.endDate >= new Date(startDate)
    );

    return approvedRequests;
  }

  /**
   * الحصول على طلبات الشهر
   */
  async getMonthRequests(userId, startDate) {
    const date = new Date(startDate);
    const monthStart = new Date(date.getFullYear(), date.getMonth(), 1);
    const monthEnd = new Date(date.getFullYear(), date.getMonth() + 1, 0);

    const monthRequests = Array.from(this.requests.values()).filter(
      r =>
        r.userId === userId &&
        r.startDate >= monthStart &&
        r.startDate <= monthEnd &&
        r.status === 'PENDING'
    );

    return monthRequests;
  }

  /**
   * الحصول على الطلبات السابقة
   */
  async getPreviousRequests(userId, leaveType) {
    return Array.from(this.requests.values()).filter(
      r => r.userId === userId && r.type === leaveType
    );
  }

  /**
   * الحصول على الموظفين المسؤولين عن الموافقة
   */
  async getApprovers(userId) {
    // يجب تنفيذ هذا مع نظام HR
    return [
      { id: 'manager-' + userId, name: 'المدير المباشر' },
      { id: 'hr@company.com', name: 'قسم الموارد البشرية' },
    ];
  }

  /**
   * تحديث التقويم
   */
  async updateCalendar(userId, request) {
    // يجب تنفيذ هذا مع نظام التقويم
    this.logger.info(`تم تحديث التقويم للموظف ${userId}`);
  }

  /**
   * التحقق من البيانات المدخلة
   */
  validateLeaveRequest(userId, leaveData) {
    if (!leaveData.type || !this.leaveTypes[leaveData.type]) {
      throw new Error('نوع الإجازة غير صحيح');
    }

    if (!leaveData.startDate || !leaveData.endDate) {
      throw new Error('يجب تحديد تاريخ البداية والنهاية');
    }

    const startDate = new Date(leaveData.startDate);
    const endDate = new Date(leaveData.endDate);

    if (startDate > endDate) {
      throw new Error('تاريخ البداية يجب أن يكون قبل تاريخ النهاية');
    }

    if (startDate < new Date()) {
      throw new Error('لا يمكن تقديم طلب إجازة لتاريخ ماضي');
    }
  }

  /**
   * توليد معرف الطلب
   */
  generateRequestId() {
    return `LEAVE-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * الحصول على طلب الإجازة
   */
  getRequest(requestId) {
    return this.requests.get(requestId);
  }

  /**
   * الحصول على طلبات الموظف
   */
  getEmployeeRequests(userId, status = null) {
    let requests = Array.from(this.requests.values()).filter(r => r.userId === userId);

    if (status) {
      requests = requests.filter(r => r.status === status);
    }

    return requests.sort((a, b) => b.createdAt - a.createdAt);
  }

  /**
   * الحصول على الطلبات المعلقة
   */
  getPendingRequests(managerId = null) {
    let requests = Array.from(this.requests.values()).filter(r => r.status === 'PENDING');

    if (managerId) {
      requests = requests.filter(r => r.userId === managerId);
    }

    return requests;
  }

  /**
   * الحصول على إحصائيات الإجازات
   */
  async getLeaveStatistics(userId) {
    const balances = await this.getBalance(userId);
    const allRequests = this.getEmployeeRequests(userId);

    const stats = {
      balances,
      totalRequests: allRequests.length,
      approvedRequests: allRequests.filter(r => r.status === 'APPROVED').length,
      pendingRequests: allRequests.filter(r => r.status === 'PENDING').length,
      rejectedRequests: allRequests.filter(r => r.status === 'REJECTED').length,
    };

    return stats;
  }
}

module.exports = LeaveManagementSystem;
