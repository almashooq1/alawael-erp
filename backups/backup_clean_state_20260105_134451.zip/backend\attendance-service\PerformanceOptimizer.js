/**
 * PerformanceOptimizer.js
 * نظام تحسين الأداء المتقدم
 * معايير صناعية، Caching ذكي، تحسينات قاعدة البيانات
 */

const redis = require('redis');
const { performance } = require('perf_hooks');

class PerformanceOptimizer {
  constructor(redisClient = null) {
    this.redisClient = redisClient || redis.createClient();
    this.metrics = new Map();
    this.cacheStats = {
      hits: 0,
      misses: 0,
      total: 0,
    };
    this.industryBenchmarks = this.initializeBenchmarks();
  }

  /**
   * معايير الصناعة المرجعية
   */
  initializeBenchmarks() {
    return {
      attendance: {
        excellent: { min: 95, max: 100 },
        good: { min: 85, max: 94 },
        average: { min: 75, max: 84 },
        poor: { min: 0, max: 74 },
      },
      performance: {
        excellent: { min: 90, max: 100 },
        good: { min: 75, max: 89 },
        average: { min: 60, max: 74 },
        poor: { min: 0, max: 59 },
      },
      productivity: {
        excellent: { min: 95, max: 100 },
        good: { min: 80, max: 94 },
        average: { min: 65, max: 79 },
        poor: { min: 0, max: 64 },
      },
      lateness: {
        excellent: { min: 0, max: 2 }, // ساعات شهرياً
        good: { min: 3, max: 5 },
        average: { min: 6, max: 10 },
        poor: { min: 11, max: 999 },
      },
    };
  }

  /**
   * نظام Caching ذكي متعدد المستويات
   */
  async getCachedData(key, fetchFunction, ttl = 300) {
    try {
      // محاولة الحصول من Redis
      const cachedData = await this.redisClient.get(key);

      if (cachedData) {
        this.cacheStats.hits++;
        console.log(`✅ Cache HIT: ${key}`);
        return JSON.parse(cachedData);
      }

      this.cacheStats.misses++;
      console.log(`❌ Cache MISS: ${key}`);

      // جلب البيانات الجديدة
      const freshData = await fetchFunction();

      // تخزين في Cache
      await this.redisClient.setEx(key, ttl, JSON.stringify(freshData));

      this.cacheStats.total++;
      return freshData;
    } catch (error) {
      console.error('Cache error:', error);
      return await fetchFunction();
    }
  }

  /**
   * مسح Cache انتقائي
   */
  async invalidateCache(pattern) {
    try {
      const keys = await this.redisClient.keys(pattern);
      if (keys.length > 0) {
        await this.redisClient.del(keys);
        console.log(`✅ تم مسح ${keys.length} عنصر من الـ cache`);
      }
    } catch (error) {
      console.error('Cache invalidation error:', error);
    }
  }

  /**
   * قياس الأداء
   */
  measurePerformance(label, fn) {
    const start = performance.now();
    const result = fn();
    const end = performance.now();
    const duration = end - start;

    this.metrics.set(label, {
      duration,
      timestamp: new Date(),
      status: duration < 100 ? 'EXCELLENT' : duration < 500 ? 'GOOD' : 'SLOW',
    });

    console.log(`⏱️ ${label}: ${duration.toFixed(2)}ms (${this.metrics.get(label).status})`);
    return result;
  }

  /**
   * تحسين الاستعلامات - استخدام Aggregation Pipeline
   */
  getOptimizedAggregationPipeline(filters = {}) {
    return [
      // Stage 1: التصفية
      {
        $match: {
          ...filters,
          deletedAt: { $exists: false },
        },
      },
      // Stage 2: الربط مع جداول أخرى
      {
        $lookup: {
          from: 'employees',
          localField: 'employeeId',
          foreignField: '_id',
          as: 'employeeDetails',
        },
      },
      // Stage 3: التجميع
      {
        $group: {
          _id: '$employeeId',
          totalDays: { $sum: 1 },
          presentDays: {
            $sum: { $cond: [{ $eq: ['$status', 'present'] }, 1, 0] },
          },
          absentDays: {
            $sum: { $cond: [{ $eq: ['$status', 'absent'] }, 1, 0] },
          },
          lateDays: {
            $sum: { $cond: [{ $eq: ['$status', 'late'] }, 1, 0] },
          },
          averageLateHours: { $avg: '$lateHours' },
        },
      },
      // Stage 4: الحساب
      {
        $project: {
          _id: 1,
          totalDays: 1,
          presentDays: 1,
          absentDays: 1,
          lateDays: 1,
          attendanceRate: {
            $multiply: [{ $divide: ['$presentDays', '$totalDays'] }, 100],
          },
          averageLateHours: { $round: ['$averageLateHours', 2] },
        },
      },
      // Stage 5: الترتيب
      {
        $sort: { attendanceRate: -1 },
      },
    ];
  }

  /**
   * مؤشرات الأداء الرئيسية
   */
  calculateKPIs(_data) {
    return {
      responseTime: this.calculateAverageMetric('duration'),
      cacheHitRate:
        ((this.cacheStats.hits / (this.cacheStats.hits + this.cacheStats.misses)) * 100).toFixed(
          2
        ) + '%',
      totalCacheOperations: this.cacheStats.total,
      slowQueries: Array.from(this.metrics.entries())
        .filter(([, metric]) => metric.status === 'SLOW')
        .map(([label]) => label),
    };
  }

  /**
   * المقارنة مع معايير الصناعة
   */
  compareToBenchmark(metric, value, category) {
    const benchmark = this.industryBenchmarks[category]?.[metric];

    if (!benchmark) return null;

    const percentile = this.calculatePercentile(value, benchmark);

    return {
      value,
      benchmark,
      percentile,
      rating: this.getRating(value, benchmark),
      recommendation: this.getRecommendation(metric, value, benchmark),
    };
  }

  /**
   * تقييم الأداء
   */
  getRating(value, benchmark) {
    if (value >= benchmark.min && value <= benchmark.max) {
      return 'On Track';
    } else if (value > benchmark.max) {
      return 'Exceeding';
    } else {
      return 'Needs Improvement';
    }
  }

  /**
   * توصيات التحسين
   */
  getRecommendation(metric, value, benchmark) {
    const gap = benchmark.min - value;

    if (gap <= 0) {
      return 'الأداء جيد - استمر هكذا';
    } else if (gap <= 5) {
      return 'يحتاج تحسين بسيط';
    } else if (gap <= 15) {
      return 'يحتاج تحسين متوسط';
    } else {
      return 'يحتاج تحسين عاجل';
    }
  }

  /**
   * حساب النسبة المئوية
   */
  calculatePercentile(value, benchmark) {
    const range = benchmark.max - benchmark.min;
    const adjusted = Math.max(0, Math.min(range, value - benchmark.min));
    return ((adjusted / range) * 100).toFixed(2) + '%';
  }

  /**
   * تحليل الاتجاهات
   */
  analyzeTrends(historicalData) {
    if (historicalData.length < 2) return null;

    const recent = historicalData.slice(-7); // آخر 7 أيام
    const previous = historicalData.slice(-14, -7); // 7 أيام قبلها

    const recentAvg = recent.reduce((a, b) => a + b, 0) / recent.length;
    const previousAvg = previous.reduce((a, b) => a + b, 0) / previous.length;

    const change = recentAvg - previousAvg;
    const percentChange = ((change / previousAvg) * 100).toFixed(2);

    return {
      trend: change > 0 ? 'IMPROVING' : change < 0 ? 'DECLINING' : 'STABLE',
      changePercent: percentChange,
      direction: change > 0 ? '↑' : change < 0 ? '↓' : '→',
      recommendation: this.getTrendRecommendation(change, percentChange),
    };
  }

  /**
   * توصيات الاتجاهات
   */
  getTrendRecommendation(change, percentChange) {
    if (change > 0 && parseFloat(percentChange) > 5) {
      return 'الأداء يتحسن - استمر في المسار الحالي';
    } else if (change < 0 && parseFloat(percentChange) < -5) {
      return 'الأداء يتدهور - يحتاج تدخل فوري';
    } else {
      return 'الأداء مستقر - راقب التطورات';
    }
  }

  /**
   * تقرير الأداء الشامل
   */
  generatePerformanceReport(employeeData) {
    return {
      employeeId: employeeData.id,
      generatedAt: new Date(),
      metrics: {
        attendance: {
          current: employeeData.attendanceRate,
          benchmark: this.compareToBenchmark(
            'excellent',
            employeeData.attendanceRate,
            'attendance'
          ),
        },
        performance: {
          current: employeeData.performanceScore,
          benchmark: this.compareToBenchmark(
            'excellent',
            employeeData.performanceScore,
            'performance'
          ),
        },
        productivity: {
          current: employeeData.productivityScore,
          benchmark: this.compareToBenchmark(
            'excellent',
            employeeData.productivityScore,
            'productivity'
          ),
        },
        lateness: {
          current: employeeData.monthlyLateHours,
          benchmark: this.compareToBenchmark(
            'excellent',
            employeeData.monthlyLateHours,
            'lateness'
          ),
        },
      },
      trends: {
        attendance: this.analyzeTrends(employeeData.attendanceHistory || []),
        performance: this.analyzeTrends(employeeData.performanceHistory || []),
      },
      overallRating: this.calculateOverallRating(employeeData),
      recommendations: this.generateRecommendations(employeeData),
    };
  }

  /**
   * التقييم الإجمالي
   */
  calculateOverallRating(data) {
    const ratings = [
      this.compareToBenchmark('excellent', data.attendanceRate, 'attendance')?.percentile,
      this.compareToBenchmark('excellent', data.performanceScore, 'performance')?.percentile,
      this.compareToBenchmark('excellent', data.productivityScore, 'productivity')?.percentile,
    ].filter(r => r);

    const avg = ratings.reduce((a, b) => a + parseFloat(b), 0) / ratings.length;

    if (avg >= 80) return 'ممتاز';
    if (avg >= 65) return 'جيد جداً';
    if (avg >= 50) return 'جيد';
    if (avg >= 35) return 'مقبول';
    return 'ضعيف';
  }

  /**
   * توليد التوصيات
   */
  generateRecommendations(data) {
    const recommendations = [];

    // توصية الحضور
    if (data.attendanceRate < 85) {
      recommendations.push({
        category: 'Attendance',
        priority: 'HIGH',
        message: 'تحسين نسبة الحضور إلى 90% على الأقل',
        action: 'زيادة الحضور بمعدل 1% أسبوعياً',
      });
    }

    // توصية الأداء
    if (data.performanceScore < 75) {
      recommendations.push({
        category: 'Performance',
        priority: 'HIGH',
        message: 'تحسين درجة الأداء من خلال التدريب',
        action: 'برنامج تطوير مخصص',
      });
    }

    // توصية التأخر
    if (data.monthlyLateHours > 5) {
      recommendations.push({
        category: 'Punctuality',
        priority: 'MEDIUM',
        message: 'تقليل ساعات التأخر',
        action: 'التحدث مع الموظف وفهم الأسباب',
      });
    }

    return recommendations;
  }

  /**
   * إحصائيات الـ Cache
   */
  getCacheStats() {
    const total = this.cacheStats.hits + this.cacheStats.misses;
    return {
      hits: this.cacheStats.hits,
      misses: this.cacheStats.misses,
      total,
      hitRate: total > 0 ? ((this.cacheStats.hits / total) * 100).toFixed(2) + '%' : '0%',
      missRate: total > 0 ? ((this.cacheStats.misses / total) * 100).toFixed(2) + '%' : '0%',
    };
  }

  /**
   * متوسط المقياس
   */
  calculateAverageMetric(metricName) {
    const values = Array.from(this.metrics.values()).map(m => m[metricName] || 0);

    return values.length > 0 ? (values.reduce((a, b) => a + b, 0) / values.length).toFixed(2) : 0;
  }

  /**
   * تنظيف الـ Cache المنتهي الصلاحية
   */
  async cleanupExpiredCache() {
    try {
      console.log('🧹 تنظيف الـ cache المنتهي الصلاحية...');
      // Redis يتعامل تلقائياً مع المفاتيح المنتهية الصلاحية
      console.log('✅ اكتمل التنظيف');
    } catch (error) {
      console.error('Cleanup error:', error);
    }
  }
}

module.exports = PerformanceOptimizer;
