# attendance-service

Fastify-based microservice for attendance endpoints.

## Endpoints

- GET /health
- GET /attendance?patientId=&status=
- POST /attendance
- GET /attendance/:id

## Run

1. Install deps:
   npm install
2. Start:
   npm start

Notes: This MVP uses an in-memory store and a stub event publisher. Replace with DB + Kafka/NATS when ready.

## Environment & Observability

- In development, the service auto-loads `.env` via `shared/env.js`.
- Observability (Sentry + Application Insights) initializes at startup; set `SENTRY_DSN` and `APPINSIGHTS_INSTRUMENTATIONKEY` in `.env`.
- Optional: enable NATS by setting `EVENT_BUS_IMPL=nats` and `NATS_SERVERS`.
