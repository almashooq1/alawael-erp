/**
 * ReportExporter.js
 * تصدير التقارير إلى PDF و Excel بصيغة احترافية
 * مع تنسيق جميل ورسوم بيانية
 */

const PDFDocument = require('pdfkit');
const ExcelJS = require('exceljs');
const fs = require('fs');
const path = require('path');

class ReportExporter {
  constructor(outputDirectory = './reports') {
    this.outputDirectory = outputDirectory;
    this.ensureDirectoryExists();
  }

  ensureDirectoryExists() {
    if (!fs.existsSync(this.outputDirectory)) {
      fs.mkdirSync(this.outputDirectory, { recursive: true });
    }
  }

  /**
   * تصدير تقرير الراتب إلى PDF
   */
  async exportPayslipToPDF(payslipData, fileName) {
    return new Promise((resolve, reject) => {
      try {
        const doc = new PDFDocument({ margin: 50 });
        const filePath = path.join(this.outputDirectory, `${fileName}.pdf`);
        const stream = fs.createWriteStream(filePath);

        doc.pipe(stream);

        // الرأس
        this.addPDFHeader(doc, 'قسيمة الراتب الشهرية');

        // معلومات الموظف
        doc.fontSize(12).font('Helvetica-Bold').text('بيانات الموظف:', { underline: true });
        doc.fontSize(10).font('Helvetica');
        doc.text(`الاسم: ${payslipData.employeeName}`);
        doc.text(`رقم الموظف: ${payslipData.employeeId}`);
        doc.text(`القسم: ${payslipData.department}`);
        doc.text(`الوظيفة: ${payslipData.position}`);
        doc.text(`الشهر: ${payslipData.month}`);

        doc.moveDown();

        // جدول الراتب
        this.addPayslipTable(doc, payslipData);

        doc.moveDown();

        // تفاصيل الاستقطاعات
        this.addDeductionDetails(doc, payslipData);

        doc.moveDown();

        // التوقيع
        this.addSignature(doc);

        // اغلق الملف
        doc.end();

        stream.on('finish', () => resolve(filePath));
      } catch (error) {
        reject(new Error(`خطأ في تصدير PDF: ${error.message}`));
      }
    });
  }

  /**
   * تصدير تقرير الحضور إلى PDF
   */
  async exportAttendanceReportToPDF(reportData, fileName) {
    return new Promise((resolve, reject) => {
      try {
        const doc = new PDFDocument({ margin: 50, size: 'A4' });
        const filePath = path.join(this.outputDirectory, `${fileName}.pdf`);
        const stream = fs.createWriteStream(filePath);

        doc.pipe(stream);

        this.addPDFHeader(doc, 'تقرير الحضور الشهري');

        // ملخص الحضور
        doc.fontSize(12).font('Helvetica-Bold').text('ملخص الحضور:', { underline: true });
        doc.fontSize(10).font('Helvetica');
        doc.text(`إجمالي أيام العمل: ${reportData.totalWorkingDays}`);
        doc.text(`أيام حضور: ${reportData.presentDays}`);
        doc.text(`أيام غياب: ${reportData.absentDays}`);
        doc.text(`أيام تأخر: ${reportData.lateDays}`);
        doc.text(
          `نسبة الحضور: ${((reportData.presentDays / reportData.totalWorkingDays) * 100).toFixed(2)}%`
        );

        doc.moveDown();

        // جدول التفاصيل
        if (reportData.details && reportData.details.length > 0) {
          this.addAttendanceTable(doc, reportData.details);
        }

        doc.moveDown();

        // التنبيهات والملاحظات
        if (reportData.alerts && reportData.alerts.length > 0) {
          doc.fontSize(12).font('Helvetica-Bold').text('التنبيهات:', { underline: true });
          doc.fontSize(10).font('Helvetica');
          reportData.alerts.forEach(alert => {
            doc.text(`• ${alert.type}: ${alert.message}`, { align: 'right' });
          });
        }

        // تاريخ الطباعة
        this.addFooter(doc);

        doc.end();

        stream.on('finish', () => resolve(filePath));
      } catch (error) {
        reject(new Error(`خطأ في تصدير PDF: ${error.message}`));
      }
    });
  }

  /**
   * تصدير تقرير الأداء إلى PDF
   */
  async exportPerformanceReportToPDF(performanceData, fileName) {
    return new Promise((resolve, reject) => {
      try {
        const doc = new PDFDocument({ margin: 50 });
        const filePath = path.join(this.outputDirectory, `${fileName}.pdf`);
        const stream = fs.createWriteStream(filePath);

        doc.pipe(stream);

        this.addPDFHeader(doc, 'تقرير تقييم الأداء');

        // بيانات الموظف
        doc.fontSize(12).font('Helvetica-Bold').text('بيانات الموظف:', { underline: true });
        doc.fontSize(10).font('Helvetica');
        doc.text(`الاسم: ${performanceData.employeeName}`);
        doc.text(`الوظيفة: ${performanceData.position}`);
        doc.text(`القسم: ${performanceData.department}`);
        doc.text(`الفترة: ${performanceData.period}`);

        doc.moveDown();

        // التقييم الإجمالي
        doc.fontSize(12).font('Helvetica-Bold').text('التقييم الإجمالي:', { underline: true });
        doc
          .fontSize(11)
          .font('Helvetica-Bold')
          .fillColor('darkgreen')
          .text(`الدرجة: ${performanceData.grade}`, { align: 'center' });
        doc
          .fillColor('black')
          .font('Helvetica')
          .text(`النقاط: ${performanceData.score}/100`, { align: 'center' });

        doc.moveDown();

        // مكونات التقييم
        doc.fontSize(12).font('Helvetica-Bold').text('مكونات التقييم:', { underline: true });
        doc.fontSize(10).font('Helvetica');

        const components = performanceData.components || {};
        this.addScoreBar(doc, 'الحضور والانصراف', components.attendance || 0);
        this.addScoreBar(doc, 'الانضباط والالتزام', components.discipline || 0);
        this.addScoreBar(doc, 'الإنتاجية', components.productivity || 0);
        this.addScoreBar(doc, 'العمل الجماعي', components.teamwork || 0);
        this.addScoreBar(doc, 'التطور المهني', components.development || 0);

        doc.moveDown();

        // التعليقات والتوصيات
        if (performanceData.comments) {
          doc.fontSize(12).font('Helvetica-Bold').text('التعليقات:', { underline: true });
          doc.fontSize(10).font('Helvetica').text(performanceData.comments);
        }

        doc.moveDown();

        if (performanceData.recommendations) {
          doc.fontSize(12).font('Helvetica-Bold').text('التوصيات:', { underline: true });
          doc.fontSize(10).font('Helvetica').text(performanceData.recommendations);
        }

        this.addFooter(doc);

        doc.end();

        stream.on('finish', () => resolve(filePath));
      } catch (error) {
        reject(new Error(`خطأ في تصدير PDF: ${error.message}`));
      }
    });
  }

  /**
   * تصدير تقرير الحضور إلى Excel
   */
  async exportAttendanceToExcel(attendanceData, fileName) {
    try {
      const workbook = new ExcelJS.Workbook();
      const worksheet = workbook.addWorksheet('الحضور');

      // تنسيق الرأس
      worksheet.columns = [
        { header: 'التاريخ', key: 'date', width: 15 },
        { header: 'الوقت (الحضور)', key: 'checkIn', width: 15 },
        { header: 'الوقت (الانصراف)', key: 'checkOut', width: 15 },
        { header: 'الحالة', key: 'status', width: 15 },
        { header: 'الملاحظات', key: 'notes', width: 30 },
      ];

      // تنسيق رأس الجدول
      worksheet.getRow(1).fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: '366092' },
      };

      worksheet.getRow(1).font = {
        bold: true,
        color: { argb: 'FFFFFF' },
      };

      // إضافة البيانات
      attendanceData.records.forEach(record => {
        worksheet.addRow({
          date: record.date,
          checkIn: record.checkInTime,
          checkOut: record.checkOutTime,
          status: this.getStatusInArabic(record.status),
          notes: record.notes || '',
        });
      });

      // تنسيق الصفوف
      worksheet.eachRow((row, rowNumber) => {
        if (rowNumber > 1) {
          row.eachCell(cell => {
            cell.border = {
              top: { style: 'thin' },
              left: { style: 'thin' },
              bottom: { style: 'thin' },
              right: { style: 'thin' },
            };
            cell.alignment = { horizontal: 'center', vertical: 'center' };
          });
        }
      });

      // إضافة ملخص
      const summaryRow = attendanceData.records.length + 3;
      worksheet.getCell(`A${summaryRow}`).value = 'الملخص:';
      worksheet.getCell(`A${summaryRow}`).font = { bold: true };

      worksheet.getCell(`A${summaryRow + 1}`).value = 'إجمالي الأيام:';
      worksheet.getCell(`B${summaryRow + 1}`).value = attendanceData.totalDays;

      worksheet.getCell(`A${summaryRow + 2}`).value = 'أيام الحضور:';
      worksheet.getCell(`B${summaryRow + 2}`).value = attendanceData.presentDays;

      worksheet.getCell(`A${summaryRow + 3}`).value = 'أيام الغياب:';
      worksheet.getCell(`B${summaryRow + 3}`).value = attendanceData.absentDays;

      const filePath = path.join(this.outputDirectory, `${fileName}.xlsx`);
      await workbook.xlsx.writeFile(filePath);

      return filePath;
    } catch (error) {
      throw new Error(`خطأ في تصدير Excel: ${error.message}`);
    }
  }

  /**
   * تصدير تقرير الرواتب إلى Excel
   */
  async exportPayrollToExcel(payrollData, fileName) {
    try {
      const workbook = new ExcelJS.Workbook();
      const worksheet = workbook.addWorksheet('الرواتب');

      // الأعمدة
      worksheet.columns = [
        { header: 'رقم الموظف', key: 'employeeId', width: 12 },
        { header: 'اسم الموظف', key: 'employeeName', width: 20 },
        { header: 'الراتب الأساسي', key: 'baseSalary', width: 12 },
        { header: 'استقطاع الغياب', key: 'absenceDeduction', width: 12 },
        { header: 'استقطاع التأخر', key: 'latenessDeduction', width: 12 },
        { header: 'إجمالي الاستقطاع', key: 'totalDeduction', width: 12 },
        { header: 'الراتب الصافي', key: 'netSalary', width: 12 },
      ];

      // تنسيق الرأس
      worksheet.getRow(1).fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: '366092' },
      };

      worksheet.getRow(1).font = {
        bold: true,
        color: { argb: 'FFFFFF' },
      };

      // إضافة بيانات الموظفين
      payrollData.employees.forEach(emp => {
        worksheet.addRow({
          employeeId: emp.id,
          employeeName: emp.name,
          baseSalary: emp.baseSalary,
          absenceDeduction: emp.absenceDeduction,
          latenessDeduction: emp.latenessDeduction,
          totalDeduction: emp.totalDeduction,
          netSalary: emp.netSalary,
        });
      });

      // إجمالي الشركة
      const totalRow = payrollData.employees.length + 3;
      worksheet.getCell(`A${totalRow}`).value = 'الإجمالي:';
      worksheet.getCell(`A${totalRow}`).font = { bold: true };

      const totalBaseSalary = payrollData.employees.reduce((sum, e) => sum + e.baseSalary, 0);
      const totalAbsenceDeduction = payrollData.employees.reduce(
        (sum, e) => sum + e.absenceDeduction,
        0
      );
      const totalLatenessDeduction = payrollData.employees.reduce(
        (sum, e) => sum + e.latenessDeduction,
        0
      );
      const totalDeduction = payrollData.employees.reduce((sum, e) => sum + e.totalDeduction, 0);
      const totalNetSalary = payrollData.employees.reduce((sum, e) => sum + e.netSalary, 0);

      worksheet.getCell(`C${totalRow}`).value = totalBaseSalary;
      worksheet.getCell(`D${totalRow}`).value = totalAbsenceDeduction;
      worksheet.getCell(`E${totalRow}`).value = totalLatenessDeduction;
      worksheet.getCell(`F${totalRow}`).value = totalDeduction;
      worksheet.getCell(`G${totalRow}`).value = totalNetSalary;

      // تنسيق الأرقام
      worksheet.eachRow((row, rowNumber) => {
        if (rowNumber > 1) {
          for (let col = 3; col <= 7; col++) {
            const cell = row.getCell(col);
            cell.numFmt = '#,##0.00';
            cell.alignment = { horizontal: 'right' };
          }
        }
      });

      const filePath = path.join(this.outputDirectory, `${fileName}.xlsx`);
      await workbook.xlsx.writeFile(filePath);

      return filePath;
    } catch (error) {
      throw new Error(`خطأ في تصدير Excel: ${error.message}`);
    }
  }

  // ─────────────────────────────────────────────────────────────
  // Helper Methods
  // ─────────────────────────────────────────────────────────────

  addPDFHeader(doc, title) {
    doc.fontSize(20).font('Helvetica-Bold').text(title, { align: 'center' });
    doc.fontSize(10).font('Helvetica').text('الشركة', { align: 'center' });
    doc.text(`التاريخ: ${new Date().toLocaleDateString('ar-EG')}`, { align: 'center' });
    doc.moveDown();
  }

  addPayslipTable(doc, data) {
    const table = {
      headers: ['البيان', 'المبلغ'],
      rows: [
        ['الراتب الأساسي', `${data.monthlyBase} ج.م`],
        ['استقطاع الغياب', `-${data.absenceDeduction} ج.م`],
        ['استقطاع التأخر', `-${data.latenessDeduction} ج.م`],
        ['استقطاعات أخرى', `-${data.otherDeductions} ج.م`],
        ['صافي الراتب', `${data.netSalary} ج.م`],
      ],
    };

    this.drawTable(doc, table);
  }

  addDeductionDetails(doc, data) {
    doc.fontSize(12).font('Helvetica-Bold').text('تفاصيل الاستقطاعات:', { underline: true });
    doc.fontSize(10).font('Helvetica');
    doc.text(`أيام الغياب: ${data.absentDays} أيام = ${data.absenceDeduction} ج.م`);
    doc.text(`ساعات التأخر: ${data.lateHours} ساعات = ${data.latenessDeduction} ج.م`);
    if (data.bonusImpact) {
      doc.text(`تأثير المكافأة: -${data.bonusImpact} ج.م`);
    }
  }

  addAttendanceTable(doc, details) {
    doc.fontSize(12).font('Helvetica-Bold').text('جدول الحضور:', { underline: true });

    const table = {
      headers: ['التاريخ', 'الحضور', 'الانصراف', 'الحالة'],
      rows: details
        .slice(0, 10)
        .map(d => [
          d.date,
          d.checkInTime || '-',
          d.checkOutTime || '-',
          this.getStatusInArabic(d.status),
        ]),
    };

    this.drawTable(doc, table);
  }

  addSignature(doc) {
    doc.moveDown(2);
    doc.fontSize(10).text('المدير المالي:', { align: 'right' });
    doc.text('________________', { align: 'right' });
    doc.text('التاريخ: ________________', { align: 'right' });
  }

  addFooter(doc) {
    doc
      .fontSize(8)
      .text(
        `تم الطباعة في: ${new Date().toLocaleDateString('ar-EG')} - ${new Date().toLocaleTimeString('ar-EG')}`,
        {
          align: 'center',
          color: '#999999',
        }
      );
  }

  addScoreBar(doc, label, score) {
    doc.text(`${label}: ${score}/100`, { width: 200, continued: true });
    doc.rect(300, doc.y - 12, 100, 12).stroke();
    doc.rect(300, doc.y - 12, (score / 100) * 100, 12).fillAndStroke('green', 'green');
    doc.moveDown();
  }

  drawTable(doc, table) {
    const x = 50;
    let y = doc.y;
    const colWidth = 250;

    // رسم الرأس
    doc.fontSize(10).font('Helvetica-Bold').fillColor('lightgrey');
    table.headers.forEach((header, i) => {
      doc.rect(x + i * colWidth, y, colWidth, 25).fill();
    });

    // كتابة الرأس
    doc.fillColor('black').font('Helvetica-Bold');
    table.headers.forEach((header, i) => {
      doc.text(header, x + 10 + i * colWidth, y + 5, { width: colWidth - 20 });
    });

    y += 25;

    // رسم الصفوف
    doc.font('Helvetica').fontSize(9);
    table.rows.forEach(row => {
      row.forEach((cell, i) => {
        doc.text(cell, x + 10 + i * colWidth, y + 5, { width: colWidth - 20 });
      });
      y += 20;
    });
  }

  getStatusInArabic(status) {
    const statusMap = {
      present: 'حاضر',
      absent: 'غائب',
      late: 'متأخر',
      leave: 'إجازة',
      'on-duty': 'مأمورية',
    };
    return statusMap[status] || status;
  }
}

module.exports = ReportExporter;
