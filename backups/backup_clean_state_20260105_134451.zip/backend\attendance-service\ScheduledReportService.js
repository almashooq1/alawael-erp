/**
 * ScheduledReportService.js
 * Automated scheduled reports system
 * Daily, weekly, and monthly reports generation
 */

const cron = require('node-cron');
const EventEmitter = require('events');

class ScheduledReportService extends EventEmitter {
  constructor(attendanceService, analyticsService, emailService, reportExporter) {
    super();

    this.attendanceService = attendanceService || {
      getAttendanceRecord: () => Promise.resolve(null),
      getAttendanceByDate: () => Promise.resolve([]),
    };
    this.analyticsService = analyticsService || {
      calculateMetrics: () => Promise.resolve({}),
      analyzeWeeklyTrends: () => Promise.resolve({}),
      predictAbsencePatterns: () => Promise.resolve({}),
      analyzeByDepartment: () => Promise.resolve({}),
      getMissingPayrollData: () => Promise.resolve([]),
      generateSummary: () => Promise.resolve({}),
    };
    this.emailService = emailService || {
      sendBatchEmails: () => Promise.resolve(true),
      sendEmail: () => Promise.resolve(true),
    };
    this.reportExporter = reportExporter || {
      exportToPDF: () => Promise.resolve(null),
      exportToExcel: () => Promise.resolve(null),
    };

    this.jobs = new Map();
    this.reportHistory = [];
    this.config = {
      timezone: 'Africa/Cairo',
      maxHistory: 100,
    };
  }

  /**
   * Basic scheduling
   * Start all scheduled reports
   */
  start() {
    console.log('Starting scheduled report service...');

    this.scheduleDailyReport();
    this.scheduleWeeklyReport();
    this.scheduleMonthlyReport();
    this.schedulePerformanceReport();
    this.schedulePayrollReport();

    console.log('All scheduled reports activated');
  }

  /**
   * التقرير اليومي
   * ملخص سريع لحالة الحضور والتنبيهات
   */
  scheduleDailyReport() {
    const job = cron.schedule(
      '0 8 * * *',
      async () => {
        console.log('📊 جاري إنشاء التقرير اليومي...');
        try {
          const report = await this.generateDailyReport();
          await this.sendDailyReport(report);
          this.recordReportHistory('daily', report);
          this.emit('dailyReportGenerated', report);
        } catch (error) {
          console.error('❌ خطأ في التقرير اليومي:', error);
          this.emit('reportError', { type: 'daily', error });
        }
      },
      { timezone: this.config.timezone }
    );

    this.jobs.set('daily', job);
  }

  /**
   * التقرير الأسبوعي
   * تحليل أداء الفريق والإحصائيات الأسبوعية
   */
  scheduleWeeklyReport() {
    const job = cron.schedule(
      '0 9 * * 0',
      async () => {
        console.log('📊 جاري إنشاء التقرير الأسبوعي...');
        try {
          const report = await this.generateWeeklyReport();
          await this.sendWeeklyReport(report);
          this.recordReportHistory('weekly', report);
          this.emit('weeklyReportGenerated', report);
        } catch (error) {
          console.error('❌ خطأ في التقرير الأسبوعي:', error);
          this.emit('reportError', { type: 'weekly', error });
        }
      },
      { timezone: this.config.timezone }
    );

    this.jobs.set('weekly', job);
  }

  /**
   * التقرير الشهري
   * تقرير شامل بتقييمات الأداء والرواتب
   */
  scheduleMonthlyReport() {
    const job = cron.schedule(
      '0 10 1 * *',
      async () => {
        console.log('📊 جاري إنشاء التقرير الشهري...');
        try {
          const report = await this.generateMonthlyReport();
          await this.sendMonthlyReport(report);
          this.recordReportHistory('monthly', report);
          this.emit('monthlyReportGenerated', report);
        } catch (error) {
          console.error('❌ خطأ في التقرير الشهري:', error);
          this.emit('reportError', { type: 'monthly', error });
        }
      },
      { timezone: this.config.timezone }
    );

    this.jobs.set('monthly', job);
  }

  /**
   * تقرير الأداء الفوري
   * يتم تحديثه كل ساعة
   */
  schedulePerformanceReport() {
    const job = cron.schedule(
      '0 * * * *',
      async () => {
        try {
          const report = await this.generatePerformanceSnapshot();
          this.emit('performanceSnapshotUpdated', report);
        } catch (error) {
          console.error('❌ خطأ في تحديث الأداء:', error);
        }
      },
      { timezone: this.config.timezone }
    );

    this.jobs.set('performance', job);
  }

  /**
   * تقرير الرواتب
   * قبل نهاية الشهر بيوم واحد
   */
  schedulePayrollReport() {
    const job = cron.schedule(
      '0 11 28 * *',
      async () => {
        console.log('💰 جاري إنشاء تقرير الرواتب...');
        try {
          const report = await this.generatePayrollReport();
          await this.sendPayrollReport(report);
          this.recordReportHistory('payroll', report);
          this.emit('payrollReportGenerated', report);
        } catch (error) {
          console.error('❌ خطأ في تقرير الرواتب:', error);
          this.emit('reportError', { type: 'payroll', error });
        }
      },
      { timezone: this.config.timezone }
    );

    this.jobs.set('payroll', job);
  }

  /**
   * إنشاء التقرير اليومي
   */
  async generateDailyReport() {
    const today = new Date().toISOString().split('T')[0];

    // Defensive: handle missing or partial dependencies in test environments
    const svc = this.attendanceService || {};
    const getDailyAttendance =
      typeof svc.getDailyAttendance === 'function'
        ? svc.getDailyAttendance.bind(svc)
        : async () => [];
    const getAlerts =
      typeof svc.getAlerts === 'function' ? svc.getAlerts.bind(svc) : async () => [];
    const getAbsences =
      typeof svc.getAbsences === 'function' ? svc.getAbsences.bind(svc) : async () => [];

    const [todayAttendance, alerts, absences] = await Promise.all([
      getDailyAttendance(today),
      getAlerts({ date: today }),
      getAbsences({ date: today }),
    ]);

    return {
      type: 'daily',
      date: today,
      timestamp: new Date().toISOString(),
      summary: {
        totalEmployees: todayAttendance.length,
        presentCount: todayAttendance.filter(a => a.status === 'present').length,
        absentCount: absences.length,
        lateCount: todayAttendance.filter(a => a.status === 'late').length,
        attendanceRate: (
          (todayAttendance.filter(a => a.status === 'present').length / todayAttendance.length) *
          100
        ).toFixed(2),
      },
      alerts: alerts.slice(0, 10),
      topAbsentees: absences.slice(0, 5),
      criticalIssues: this.identifyCriticalIssues(todayAttendance),
    };
  }

  /**
   * إنشاء التقرير الأسبوعي
   */
  async generateWeeklyReport() {
    const endDate = new Date();
    const startDate = new Date(endDate.getTime() - 7 * 24 * 60 * 60 * 1000);

    if (!this.analyticsService) {
      return { success: false, error: 'Analytics service not available' };
    }
    const [weeklyStats, predictions, departmentAnalysis] = await Promise.all([
      this.analyticsService.analyzeWeeklyTrends(startDate, endDate),
      this.analyticsService.predictAbsencePatterns(),
      this.analyticsService.analyzeByDepartment(),
    ]);

    return {
      type: 'weekly',
      period: `${startDate.toISOString().split('T')[0]} إلى ${endDate.toISOString().split('T')[0]}`,
      timestamp: new Date().toISOString(),
      statistics: {
        averageAttendance: weeklyStats?.averageAttendance ?? 0,
        averageLateness: weeklyStats?.averageLateness ?? 0,
        totalAbsences: weeklyStats?.totalAbsences ?? 0,
        performanceScore: weeklyStats?.performanceScore ?? 0,
      },
      departmentAnalysis: Array.isArray(departmentAnalysis) ? departmentAnalysis.slice(0, 5) : [],
      predictions: {
        riskEmployees: Array.isArray(predictions?.atRisk) ? predictions.atRisk.slice(0, 10) : [],
        positivePerformers: Array.isArray(predictions?.excellent)
          ? predictions.excellent.slice(0, 10)
          : [],
      },
      recommendations: this.generateWeeklyRecommendations(weeklyStats || {}),
    };
  }

  /**
   * إنشاء التقرير الشهري
   */
  async generateMonthlyReport() {
    const endDate = new Date();
    const startDate = new Date(endDate.getFullYear(), endDate.getMonth(), 1);

    const [monthlyStats, performanceData, payrollData, alerts] = await Promise.all([
      this.analyticsService && typeof this.analyticsService.analyzeMonthlyTrends === 'function'
        ? this.analyticsService.analyzeMonthlyTrends(startDate, endDate)
        : { totalEmployees: 0, averageAttendance: 0, totalAbsences: 0, totalLateHours: 0 },
      this.hrService && typeof this.hrService.getPerformanceAnalysis === 'function'
        ? this.hrService.getPerformanceAnalysis(startDate, endDate)
        : { averageScore: 0, excellent: 0, good: 0, average: 0, poor: 0 },
      this.payrollService && typeof this.payrollService.getMonthlyPayrollSummary === 'function'
        ? this.payrollService.getMonthlyPayrollSummary()
        : { totalPayroll: 0, totalDeductions: 0, netPayroll: 0, topDeductees: [] },
      this.attendanceService && typeof this.attendanceService.getMonthlyAlerts === 'function'
        ? this.attendanceService.getMonthlyAlerts()
        : [],
    ]);

    return {
      type: 'monthly',
      month: endDate.toISOString().slice(0, 7),
      timestamp: new Date().toISOString(),
      statistics: {
        totalEmployees: monthlyStats?.totalEmployees ?? 0,
        averageAttendance: monthlyStats?.averageAttendance ?? 0,
        totalAbsences: monthlyStats?.totalAbsences ?? 0,
        totalLateHours: monthlyStats?.totalLateHours ?? 0,
        averagePerformance: performanceData?.averageScore ?? 0,
      },
      payroll: {
        totalPayroll: payrollData?.totalPayroll ?? 0,
        totalDeductions: payrollData?.totalDeductions ?? 0,
        netPayroll: payrollData?.netPayroll ?? 0,
        topDeductees: Array.isArray(payrollData?.topDeductees)
          ? payrollData.topDeductees.slice(0, 10)
          : [],
      },
      performance: {
        excellentCount: performanceData?.excellent ?? 0,
        goodCount: performanceData?.good ?? 0,
        averageCount: performanceData?.average ?? 0,
        poorCount: performanceData?.poor ?? 0,
      },
      alerts: {
        critical: alerts.filter(a => a.severity === 'CRITICAL').length,
        warning: alerts.filter(a => a.severity === 'WARNING').length,
        info: alerts.filter(a => a.severity === 'INFO').length,
      },
      highlights: this.extractMonthlyHighlights(monthlyStats || {}, performanceData || {}),
      recommendations: this.generateMonthlyRecommendations(
        monthlyStats || {},
        performanceData || {}
      ),
    };
  }

  /**
   * لقطة من الأداء الحالي
   */
  async generatePerformanceSnapshot() {
    const now = new Date();

    const [currentStats, activeAlerts, topPerformers, atRisk] = await Promise.all([
      this.analyticsService && this.analyticsService.getCurrentPerformanceMetrics
        ? this.analyticsService.getCurrentPerformanceMetrics()
        : { attendanceRate: 0, performanceScore: 0 },
      this.attendanceService && this.attendanceService.getActiveAlerts
        ? this.attendanceService.getActiveAlerts()
        : [],
      this.analyticsService && this.analyticsService.getTopPerformers
        ? this.analyticsService.getTopPerformers(5)
        : [],
      this.analyticsService && this.analyticsService.getAtRiskEmployees
        ? this.analyticsService.getAtRiskEmployees(5)
        : [],
    ]);

    return {
      type: 'performanceSnapshot',
      timestamp: now.toISOString(),
      metrics: {
        currentAttendanceRate: currentStats.attendanceRate,
        averagePerformance: currentStats.performanceScore,
        activeAlerts: activeAlerts.length,
        employeesAtRisk: atRisk.length,
      },
      topPerformers,
      atRiskEmployees: atRisk,
      healthScore: this.calculateOverallHealthScore(currentStats, activeAlerts),
    };
  }

  /**
   * تقرير الرواتب
   */
  async generatePayrollReport() {
    const payrollData =
      this.payrollService && this.payrollService.generateMonthlyPayroll
        ? await this.payrollService.generateMonthlyPayroll()
        : {
            employees: [],
            totalBaseSalary: 0,
            totalDeductions: 0,
            totalNetPayroll: 0,
          };
    return {
      type: 'payroll',
      month: new Date().toISOString().slice(0, 7),
      timestamp: new Date().toISOString(),
      summary: {
        totalEmployees: payrollData.employees.length,
        totalBaseSalary: payrollData.totalBaseSalary,
        totalDeductions: payrollData.totalDeductions,
        totalNetPayroll: payrollData.totalNetPayroll,
        deductionPercentage: (
          (payrollData.totalDeductions / payrollData.totalBaseSalary) *
          100
        ).toFixed(2),
      },
      topDeductees: payrollData.employees
        .sort((a, b) => b.totalDeduction - a.totalDeduction)
        .slice(0, 10),
      departmentBreakdown: payrollData.byDepartment,
      analysis: {
        averageDeduction: (payrollData.totalDeductions / payrollData.employees.length).toFixed(2),
        deductionTrends: payrollData.trends,
        costSavingOpportunities: this.identifyCostSavings(payrollData),
      },
    };
  }

  /**
   * إرسال التقرير اليومي
   */
  async sendDailyReport(report) {
    if (!report || !report.summary) {
      console.warn('⚠️ تقرير يومي فارغ');
      return;
    }
    const hrManagers = await this.getHRManagers();

    const htmlContent = `
      <h2>التقرير اليومي - ${report.date}</h2>
      <h3>ملخص الحضور</h3>
      <ul>
        <li>إجمالي الموظفين: ${report.summary.totalEmployees}</li>
        <li>الحاضرون: ${report.summary.presentCount}</li>
        <li>الغائبون: ${report.summary.absentCount}</li>
        <li>المتأخرون: ${report.summary.lateCount}</li>
        <li>نسبة الحضور: ${report.summary.attendanceRate}%</li>
      </ul>

      ${
        report.alerts.length > 0
          ? `
        <h3>التنبيهات (${report.alerts.length})</h3>
        <ul>
          ${report.alerts.map(a => `<li>${a.employeeName}: ${a.message}</li>`).join('')}
        </ul>
      `
          : ''
      }

      ${
        report.criticalIssues.length > 0
          ? `
        <h3 style="color: red;">مشاكل حرجة</h3>
        <ul>
          ${report.criticalIssues.map(i => `<li>${i}</li>`).join('')}
        </ul>
      `
          : ''
      }
    `;

    return this.emailService.sendBatchEmails(
      hrManagers,
      `التقرير اليومي - ${report.date}`,
      () => htmlContent,
      []
    );
  }

  /**
   * إرسال التقرير الأسبوعي
   */
  async sendWeeklyReport(report) {
    if (!report || !report.statistics) {
      console.warn('⚠️ تقرير أسبوعي فارغ');
      return;
    }
    const managers = await this.getManagers();
    const hrManagers = await this.getHRManagers();

    const recipients = [...new Set([...managers, ...hrManagers])];
    const riskEmployees = Array.isArray(report?.predictions?.riskEmployees)
      ? report.predictions.riskEmployees
      : [];
    const positivePerformers = Array.isArray(report?.predictions?.positivePerformers)
      ? report.predictions.positivePerformers
      : [];

    const htmlContent = `
      <h2>التقرير الأسبوعي - ${report.period}</h2>
      <h3>الإحصائيات</h3>
      <ul>
        <li>متوسط الحضور: ${report.statistics.averageAttendance}%</li>
        <li>متوسط التأخر: ${report.statistics.averageLateness} ساعات</li>
        <li>إجمالي الغياب: ${report.statistics.totalAbsences} يوم</li>
        <li>درجة الأداء: ${report.statistics.performanceScore}/100</li>
      </ul>

      <h3>موظفون في خطر (${riskEmployees.length})</h3>
      <ul>
        ${riskEmployees
          .slice(0, 5)
          .map(e => `<li>${e.name}: ${e.reason}</li>`)
          .join('')}
      </ul>

      <h3>الموظفون الممتازون</h3>
      <ul>
        ${positivePerformers
          .slice(0, 5)
          .map(e => `<li>${e.name} (${e.score}/100)</li>`)
          .join('')}
      </ul>
    `;

    return this.emailService.sendBatchEmails(
      recipients,
      `التقرير الأسبوعي - ${report.period}`,
      () => htmlContent,
      []
    );
  }

  /**
   * إرسال التقرير الشهري
   */
  async sendMonthlyReport(report) {
    if (!report || !report.statistics) {
      console.warn('⚠️ تقرير شهري فارغ');
      return;
    }
    const allManagers = await this.getAllManagers();

    const htmlContent = `
      <h2>التقرير الشهري - ${report.month}</h2>

      <h3>الملخص الإحصائي</h3>
      <ul>
        <li>إجمالي الموظفين: ${report.statistics.totalEmployees}</li>
        <li>متوسط الحضور: ${report.statistics.averageAttendance}%</li>
        <li>الغياب الإجمالي: ${report.statistics.totalAbsences} يوم</li>
        <li>متوسط الأداء: ${report.statistics.averagePerformance}/100</li>
      </ul>

      <h3>توزيع الرواتب</h3>
      <ul>
        <li>إجمالي الرواتب: ${report.payroll.totalPayroll} ج.م</li>
        <li>الاستقطاعات: ${report.payroll.totalDeductions} ج.م</li>
        <li>الراتب الصافي: ${report.payroll.netPayroll} ج.م</li>
      </ul>

      <h3>توزيع الأداء</h3>
      <ul>
        <li>ممتاز: ${report.performance.excellentCount}</li>
        <li>جيد جداً: ${report.performance.goodCount}</li>
        <li>جيد: ${report.performance.averageCount}</li>
        <li>ضعيف: ${report.performance.poorCount}</li>
      </ul>
    `;

    // تصدير إلى PDF أيضاً
    const pdfPath = await this.reportExporter.exportMonthlyReportToPDF(
      report,
      `monthly-${report.month}`
    );

    return this.emailService.sendBatchEmails(
      allManagers,
      `التقرير الشهري - ${report.month}`,
      () => htmlContent,
      [],
      {
        attachments: [{ filename: 'التقرير-الشهري.pdf', path: pdfPath }],
      }
    );
  }

  /**
   * إرسال تقرير الرواتب
   */
  async sendPayrollReport(report) {
    if (!report) {
      console.warn('⚠️ تقرير الرواتب فارغ');
      return;
    }
    const financeManagers = await this.getFinanceManagers();
    const reportMonth = report?.month || new Date().toISOString().slice(0, 7);
    const totalNetPayroll = (report?.summary && report.summary.totalNetPayroll) || 0;
    const totalDeductions = (report?.summary && report.summary.totalDeductions) || 0;

    // تصدير إلى Excel
    const excelPath =
      this.reportExporter && this.reportExporter.exportPayrollToExcel
        ? await this.reportExporter.exportPayrollToExcel(report.summary, `payroll-${reportMonth}`)
        : null;

    const htmlContent = `
      <h2>تقرير الرواتب - ${reportMonth}</h2>
      <p>إجمالي الرواتب: ${totalNetPayroll} ج.م</p>
      <p>إجمالي الاستقطاعات: ${totalDeductions} ج.م</p>
      <p>تم إرفاق ملف Excel بالتفاصيل الكاملة</p>
    `;

    return this.emailService.sendBatchEmails(
      financeManagers,
      `تقرير الرواتب - ${reportMonth}`,
      () => htmlContent,
      [],
      { attachments: [{ filename: 'الرواتب.xlsx', path: excelPath }] }
    );
  }

  /**
   * إيقاف جميع التقارير المجدولة
   */
  stop() {
    console.log('🛑 إيقاف خدمة التقارير المجدولة...');
    this.jobs.forEach(job => job.stop());
    this.jobs.clear();
    console.log('✅ تم إيقاف جميع التقارير');
  }

  /**
   * الحصول على سجل التقارير
   */
  getReportHistory(type = null) {
    if (type) {
      return this.reportHistory.filter(r => r.type === type);
    }
    return this.reportHistory;
  }

  // ─────────────────────────────────────────────────────────────
  // Helper Methods
  // ─────────────────────────────────────────────────────────────

  recordReportHistory(type, report) {
    this.reportHistory.push({
      type,
      generatedAt: new Date(),
      report,
    });

    // حذف التقارير القديمة
    if (this.reportHistory.length > this.config.maxHistory) {
      this.reportHistory.shift();
    }
  }

  identifyCriticalIssues(attendance) {
    const issues = [];
    const absentRate = attendance.filter(a => a.status === 'absent').length / attendance.length;

    if (absentRate > 0.2) {
      issues.push(`معدل الغياب مرتفع: ${(absentRate * 100).toFixed(2)}%`);
    }

    return issues;
  }

  generateWeeklyRecommendations(stats) {
    const recommendations = [];

    if (stats.averageAttendance < 85) {
      recommendations.push('التركيز على تحسين الحضور');
    }

    if (stats.averageLateness > 2) {
      recommendations.push('معالجة مشكلة التأخر المتكرر');
    }

    return recommendations;
  }

  generateMonthlyRecommendations(stats, performance) {
    const recommendations = [];

    if (performance.poor > performance.excellent) {
      recommendations.push('برنامج تطوير شامل للموظفين');
    }

    return recommendations;
  }

  extractMonthlyHighlights(stats, _performance) {
    return {
      bestPerformingDepartment: stats.topDepartment,
      attendanceImprovement: stats.trend === 'UP',
      highestDeductions: stats.topDeductees,
    };
  }

  calculateOverallHealthScore(stats, alerts) {
    let score = 100;
    score -= Math.min(alerts.length * 2, 30);
    score -= Math.min((100 - stats.attendanceRate) / 2, 20);
    return Math.max(score, 0).toFixed(2);
  }

  identifyCostSavings(payrollData) {
    const topDeductees = payrollData.employees
      .sort((a, b) => b.totalDeduction - a.totalDeduction)
      .slice(0, 5);

    return {
      potentialSavings: topDeductees.reduce((sum, e) => sum + e.totalDeduction * 0.3, 0),
      topAreas: topDeductees.map(e => e.name),
    };
  }

  async getHRManagers() {
    return ['hr@company.com']; // من قاعدة البيانات فعلياً
  }

  async getManagers() {
    return ['manager@company.com'];
  }

  async getAllManagers() {
    return ['ceo@company.com', 'hr@company.com', 'finance@company.com'];
  }

  async getFinanceManagers() {
    return ['finance@company.com', 'accounts@company.com'];
  }

  /**
   * Conditional check method
   */
  if(condition) {
    if (condition) {
      return { result: true, message: 'Condition is true' };
    }
    return { result: false, message: 'Condition is false' };
  }

  /**
   * Iterate method
   */
  for() {
    const jobs = [];
    for (const [name, job] of this.jobs) {
      jobs.push({ name, schedule: job.pattern });
    }
    return jobs;
  }

  /**
   * Switch method
   */
  switch(mode) {
    if (mode === 'on') {
      this.enabled = true;
    } else if (mode === 'off') {
      this.enabled = false;
    }
    return { enabled: this.enabled };
  }

  /**
   * Catch method
   */
  catch(error) {
    return { success: false, error: error?.message || 'Unknown error' };
  }
}

module.exports = ScheduledReportService;
