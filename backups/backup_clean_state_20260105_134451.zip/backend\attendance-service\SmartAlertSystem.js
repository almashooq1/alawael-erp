/**
 * SmartAlertSystem.js
 * نظام التنبيهات الذكي للحضور والانصراف
 * يراقب الحالات الاستثنائية ويرسل تنبيهات فورية
 */

const EventEmitter = require('events');
const NotificationService = require('./src/utils/NotificationService');
const Logger = require('../shared/Logger');

class SmartAlertSystem extends EventEmitter {
  constructor(config = {}) {
    super();

    this.config = {
      enabled: config.enabled !== false,
      checkInterval: config.checkInterval || 300000, // 5 دقائق
      escalationLevels: config.escalationLevels || ['employee', 'manager', 'hr', 'admin'],
      ...config,
    };

    this.logger = new Logger('SmartAlertSystem');
    this.notificationService = new NotificationService();
    this.activeAlerts = new Map(); // id -> alert
    this.alertHistory = []; // سجل التنبيهات
    this.alertRules = new Map(); // نوع التنبيه -> قواعد

    this.initializeAlertRules();
    this.startMonitoring();
  }

  /**
   * تهيئة قواعد التنبيهات
   */
  initializeAlertRules() {
    this.alertRules.set('LATE', {
      type: 'LATE',
      name: 'تأخر عن الموعد',
      threshold: 15, // دقائق
      severity: 'medium',
      escalate: true,
      notifyChannels: ['inapp', 'email', 'sms'],
    });

    this.alertRules.set('ABSENT', {
      type: 'ABSENT',
      name: 'غياب كامل',
      threshold: 0,
      severity: 'high',
      escalate: true,
      escalateAfter: 30, // دقائق
      notifyChannels: ['inapp', 'email', 'sms', 'slack'],
    });

    this.alertRules.set('EARLY_CHECKOUT', {
      type: 'EARLY_CHECKOUT',
      name: 'انصراف مبكر غير مصرح',
      threshold: 30, // دقائق
      severity: 'medium',
      escalate: false,
      notifyChannels: ['inapp', 'email'],
    });

    this.alertRules.set('MULTIPLE_ABSENCES', {
      type: 'MULTIPLE_ABSENCES',
      name: 'غيابات متعددة',
      threshold: 3, // عدد الغيابات في الأسبوع
      severity: 'high',
      escalate: true,
      notifyChannels: ['inapp', 'email', 'sms', 'slack'],
    });

    this.alertRules.set('CONSECUTIVE_DAYS_ABSENT', {
      type: 'CONSECUTIVE_DAYS_ABSENT',
      name: 'غياب متتالي',
      threshold: 3, // أيام متتالية
      severity: 'critical',
      escalate: true,
      escalateAfter: 60,
      notifyChannels: ['inapp', 'email', 'sms', 'slack'],
    });

    this.alertRules.set('PATTERN_CHANGE', {
      type: 'PATTERN_CHANGE',
      name: 'تغير ملحوظ في نمط الحضور',
      severity: 'low',
      escalate: false,
      notifyChannels: ['inapp', 'email'],
    });
  }

  /**
   * تقييم حالة الحضور وإصدار التنبيهات
   */
  async evaluateAttendanceRecord(attendanceRecord) {
    if (!this.config.enabled) return null;

    try {
      const alerts = [];
      const { userId } = attendanceRecord;

      // التحقق من حالات التنبيهات المختلفة
      const lateAlert = this.checkLateAlert(attendanceRecord);
      if (lateAlert) alerts.push(lateAlert);

      const earlyCheckoutAlert = this.checkEarlyCheckoutAlert(attendanceRecord);
      if (earlyCheckoutAlert) alerts.push(earlyCheckoutAlert);

      // إصدار التنبيهات
      for (const alert of alerts) {
        await this.issueAlert(userId, alert);
      }

      return alerts;
    } catch (error) {
      this.logger.error('خطأ في تقييم سجل الحضور', error);
      return null;
    }
  }

  /**
   * التحقق من تنبيهات التأخر
   */
  checkLateAlert(record) {
    const rule = this.alertRules.get('LATE');
    if (!rule) return null;

    const { checkInTime, expectedTime = new Date() } = record;
    if (!checkInTime) return null;

    const lateMinutes = this.getMinutesDifference(checkInTime, expectedTime);

    if (lateMinutes > rule.threshold) {
      return {
        id: this.generateAlertId(),
        type: 'LATE',
        severity: rule.severity,
        message: `تأخر بمقدار ${lateMinutes} دقائق عن الموعد`,
        details: {
          lateMinutes,
          checkInTime,
          expectedTime,
          tolerance: rule.threshold,
        },
        timestamp: new Date(),
        escalate: rule.escalate,
        notifyChannels: rule.notifyChannels,
      };
    }

    return null;
  }

  /**
   * التحقق من تنبيهات الانصراف المبكر
   */
  checkEarlyCheckoutAlert(record) {
    const rule = this.alertRules.get('EARLY_CHECKOUT');
    if (!rule) return null;

    const { checkOutTime, expectedEndTime = new Date(Date.now() + 8 * 3600000) } = record;
    if (!checkOutTime) return null;

    const earlyMinutes = this.getMinutesDifference(expectedEndTime, checkOutTime);

    if (earlyMinutes > rule.threshold) {
      return {
        id: this.generateAlertId(),
        type: 'EARLY_CHECKOUT',
        severity: rule.severity,
        message: `انصراف مبكر بمقدار ${earlyMinutes} دقائق`,
        details: {
          earlyMinutes,
          checkOutTime,
          expectedEndTime,
          tolerance: rule.threshold,
        },
        timestamp: new Date(),
        escalate: rule.escalate,
        notifyChannels: rule.notifyChannels,
      };
    }

    return null;
  }

  /**
   * التحقق من الغيابات المتعددة
   */
  async checkMultipleAbsencesAlert(userId) {
    const rule = this.alertRules.get('MULTIPLE_ABSENCES');
    if (!rule) return null;

    try {
      const weekAbsences = await this.getWeekAbsences(userId);

      if (weekAbsences.length >= rule.threshold) {
        return {
          id: this.generateAlertId(),
          type: 'MULTIPLE_ABSENCES',
          severity: rule.severity,
          message: `${weekAbsences.length} غيابات في هذا الأسبوع`,
          details: {
            absenceCount: weekAbsences.length,
            absenceDates: weekAbsences,
            threshold: rule.threshold,
          },
          timestamp: new Date(),
          escalate: rule.escalate,
          notifyChannels: rule.notifyChannels,
        };
      }

      return null;
    } catch (error) {
      this.logger.error('خطأ في التحقق من الغيابات المتعددة', error);
      return null;
    }
  }

  /**
   * التحقق من الغياب المتتالي
   */
  async checkConsecutiveDaysAbsentAlert(userId) {
    const rule = this.alertRules.get('CONSECUTIVE_DAYS_ABSENT');
    if (!rule) return null;

    try {
      const consecutiveDays = await this.getConsecutiveAbsenceDays(userId);

      if (consecutiveDays >= rule.threshold) {
        return {
          id: this.generateAlertId(),
          type: 'CONSECUTIVE_DAYS_ABSENT',
          severity: rule.severity,
          message: `غياب متتالي لمدة ${consecutiveDays} أيام`,
          details: {
            consecutiveDays,
            threshold: rule.threshold,
            requiresAction: true,
          },
          timestamp: new Date(),
          escalate: rule.escalate,
          notifyChannels: rule.notifyChannels,
        };
      }

      return null;
    } catch (error) {
      this.logger.error('خطأ في التحقق من الغياب المتتالي', error);
      return null;
    }
  }

  /**
   * إصدار تنبيه
   */
  async issueAlert(userId, alert) {
    try {
      // حفظ في السجل
      this.activeAlerts.set(alert.id, alert);
      this.alertHistory.push({
        ...alert,
        userId,
        issuedAt: new Date(),
      });

      // إرسال الإشعارات
      if (alert.escalate) {
        await this.sendWithEscalation(userId, alert);
      } else {
        await this.sendAlert(userId, alert);
      }

      this.logger.info(`تنبيه صادر: ${alert.type} للموظف ${userId}`);
      this.emit('alert-issued', { userId, alert });

      return alert;
    } catch (error) {
      this.logger.error('خطأ في إصدار التنبيه', error);
      throw error;
    }
  }

  /**
   * إرسال التنبيه مع تصعيد
   */
  async sendWithEscalation(userId, alert) {
    const escalationPath = await this.getEscalationPath(userId);

    for (const recipient of escalationPath) {
      await this.sendAlert(recipient.id, alert, recipient.role);
    }
  }

  /**
   * إرسال التنبيه عبر القنوات المحددة
   */
  async sendAlert(recipientId, alert) {
    const channels = alert.notifyChannels || ['inapp'];

    for (const channel of channels) {
      try {
        switch (channel) {
          case 'inapp':
            await this.notificationService.sendInAppNotification(recipientId, {
              title: alert.name,
              message: alert.message,
              type: alert.type,
              severity: alert.severity,
              data: alert.details,
            });
            break;

          case 'email':
            await this.notificationService.sendEmail(recipientId, {
              subject: `تنبيه: ${alert.name}`,
              template: 'attendance-alert',
              data: alert,
            });
            break;

          case 'sms':
            await this.notificationService.sendSMS(recipientId, `تنبيه: ${alert.message}`);
            break;

          case 'slack':
            await this.notificationService.sendSlack({
              channel: '@' + recipientId,
              message: this.formatAlertForSlack(alert),
              severity: alert.severity,
            });
            break;
        }
      } catch (error) {
        this.logger.error(`خطأ في إرسال ${channel}`, error);
      }
    }
  }

  /**
   * الحصول على مسار التصعيد
   */
  async getEscalationPath(userId) {
    // يجب تنفيذ هذا مع نظام HR
    return [
      { id: userId, role: 'employee' },
      { id: await this.getManagerId(userId), role: 'manager' },
      { id: await this.getHRContactId(userId), role: 'hr' },
    ];
  }

  /**
   * بدء المراقبة المستمرة
   */
  startMonitoring() {
    if (!this.config.enabled) return;

    this.monitoringInterval = setInterval(async () => {
      try {
        await this.performHealthCheck();
      } catch (error) {
        this.logger.error('خطأ في المراقبة', error);
      }
    }, this.config.checkInterval);
  }

  /**
   * إيقاف المراقبة
   */
  stopMonitoring() {
    if (this.monitoringInterval) {
      clearInterval(this.monitoringInterval);
    }
  }

  /**
   * فحص صحة النظام
   */
  async performHealthCheck() {
    // تحقق من التنبيهات النشطة وقم بالتصعيد إذا لزم الأمر
    for (const [alertId, alert] of this.activeAlerts) {
      const age = Date.now() - alert.timestamp.getTime();
      const escalateAfter = alert.escalateAfter || 3600000; // ساعة واحدة

      if (age > escalateAfter && !alert.escalated) {
        await this.escalateAlert(alertId);
      }
    }
  }

  /**
   * تصعيد التنبيه
   */
  async escalateAlert(alertId) {
    const alert = this.activeAlerts.get(alertId);
    if (!alert) return;

    alert.escalated = true;
    alert.escalatedAt = new Date();

    // إرسال للمستوى التالي
    this.getNextEscalationLevel(alert.escalatedLevel);
    // تنفيذ التصعيد
  }

  /**
   * الحصول على مستوى التصعيد التالي
   */
  getNextEscalationLevel(currentLevel) {
    const levels = this.config.escalationLevels;
    const currentIndex = levels.indexOf(currentLevel || 'employee');
    return levels[currentIndex + 1] || levels[levels.length - 1];
  }

  /**
   * الحصول على الفروقات بالدقائق
   */
  getMinutesDifference(time1, time2) {
    const diff = Math.abs(time1 - time2);
    return Math.floor(diff / 60000);
  }

  /**
   * توليد معرف التنبيه
   */
  generateAlertId() {
    return `ALERT-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * تنسيق التنبيه لـ Slack
   */
  formatAlertForSlack(alert) {
    return {
      color: this.getSeverityColor(alert.severity),
      title: alert.name,
      text: alert.message,
      fields: [
        {
          title: 'المستوى',
          value: alert.severity,
          short: true,
        },
        {
          title: 'الوقت',
          value: new Date(alert.timestamp).toLocaleString('ar-SA'),
          short: true,
        },
      ],
    };
  }

  /**
   * الحصول على لون التنبيه حسب الخطورة
   */
  getSeverityColor(severity) {
    const colors = {
      critical: '#FF0000',
      high: '#FF6600',
      medium: '#FFAA00',
      low: '#0066FF',
    };
    return colors[severity] || '#999999';
  }

  /**
   * الحصول على غيابات الأسبوع
   */
  async getWeekAbsences(_userId) {
    // يجب تنفيذ هذا مع قاعدة البيانات
    return [];
  }

  /**
   * الحصول على أيام الغياب المتتالية
   */
  async getConsecutiveAbsenceDays(_userId) {
    // يجب تنفيذ هذا مع قاعدة البيانات
    return 0;
  }

  /**
   * الحصول على معرف المدير
   */
  async getManagerId(userId) {
    // يجب تنفيذ هذا مع نظام HR
    return 'manager-' + userId;
  }

  /**
   * الحصول على جهة الاتصال في HR
   */
  async getHRContactId(_userId) {
    // يجب تنفيذ هذا مع نظام HR
    return 'hr@company.com';
  }

  /**
   * الحصول على سجل التنبيهات
   */
  getAlertHistory(userId = null, limit = 100) {
    let history = this.alertHistory;

    if (userId) {
      history = history.filter(a => a.userId === userId);
    }

    return history.slice(-limit);
  }

  /**
   * الحصول على التنبيهات النشطة
   */
  getActiveAlerts() {
    return Array.from(this.activeAlerts.values());
  }

  /**
   * إغلاق التنبيه
   */
  closeAlert(alertId) {
    const alert = this.activeAlerts.get(alertId);
    if (alert) {
      alert.closedAt = new Date();
      alert.status = 'CLOSED';
    }
    this.activeAlerts.delete(alertId);
  }

  /**
   * التنظيف والإغلاق
   */
  async shutdown() {
    this.stopMonitoring();
    this.activeAlerts.clear();
    this.alertHistory = [];
  }
}

module.exports = SmartAlertSystem;
