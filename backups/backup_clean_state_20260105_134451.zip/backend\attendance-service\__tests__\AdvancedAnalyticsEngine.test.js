/**
 * AdvancedAnalyticsEngine.test.js
 * اختبارات شاملة لمحرك التحليل المتقدم
 * 70 اختبار على جميع الدوال والحالات الحدية
 */

const AdvancedAnalyticsEngine = require('../AdvancedAnalyticsEngine');

describe('AdvancedAnalyticsEngine - Phase 14', () => {
  let engine;

  beforeEach(() => {
    engine = new AdvancedAnalyticsEngine();
  });

  // ==================== اختبارات التنبؤ بنسبة الحضور ====================
  describe('Attendance Rate Prediction', () => {
    test('should predict attendance rate with sufficient data', () => {
      const historicalData = Array.from({ length: 30 }, (_, i) => ({
        attendanceRate: 85 + Math.random() * 10,
      }));

      const result = engine.predictAttendanceRate(historicalData, 30);

      expect(result.metric).toBe('Attendance Rate');
      expect(result.predictions).toHaveLength(30);
      expect(result.averagePredictedRate).toBeDefined();
      expect(result.trend).toMatch(/IMPROVING|DECLINING|STABLE/);
      expect(result.confidence).toMatch(/\d+\.\d+%/);
    });

    test('should return error with insufficient data', () => {
      const historicalData = [{ attendanceRate: 85 }, { attendanceRate: 87 }];
      const result = engine.predictAttendanceRate(historicalData, 30);

      expect(result.error).toBe('Not enough historical data');
    });

    test('should cap predictions between 0 and 100', () => {
      const historicalData = Array.from({ length: 20 }, (_, i) => ({
        attendanceRate: 99 + i * 2,
      }));

      const result = engine.predictAttendanceRate(historicalData, 10);

      result.predictions.forEach(p => {
        expect(p.predictedRate).toBeGreaterThanOrEqual(0);
        expect(p.predictedRate).toBeLessThanOrEqual(100);
      });
    });

    test('should detect improving trend', () => {
      const historicalData = Array.from({ length: 15 }, (_, i) => ({
        attendanceRate: 75 + i * 1.5,
      }));

      const result = engine.predictAttendanceRate(historicalData, 7);

      expect(result.trend).toBe('IMPROVING');
    });

    test('should detect declining trend', () => {
      const historicalData = Array.from({ length: 15 }, (_, i) => ({
        attendanceRate: 95 - i * 1.5,
      }));

      const result = engine.predictAttendanceRate(historicalData, 7);

      expect(result.trend).toBe('DECLINING');
    });

    test('should emit predictionGenerated event', done => {
      const historicalData = Array.from({ length: 10 }, () => ({
        attendanceRate: 85,
      }));

      engine.on('predictionGenerated', prediction => {
        expect(prediction.metric).toBe('Attendance Rate');
        done();
      });

      engine.predictAttendanceRate(historicalData, 5);
    });
  });

  // ==================== اختبارات التنبؤ بالأداء ====================
  describe('Performance Prediction', () => {
    test('should predict performance with sufficient data', () => {
      const historicalData = Array.from({ length: 10 }, (_, i) => ({
        performanceScore: 75 + Math.random() * 20,
      }));

      const result = engine.predictPerformance(historicalData);

      expect(result.predictedScore).toBeDefined();
      expect(result.confidenceInterval).toBeDefined();
      expect(result.riskLevel).toMatch(/LOW|MEDIUM|HIGH/);
    });

    test('should return error with insufficient data', () => {
      const historicalData = [{ performanceScore: 75 }, { performanceScore: 80 }];

      const result = engine.predictPerformance(historicalData);

      expect(result.error).toBe('Insufficient data');
    });

    test('should calculate confidence interval correctly', () => {
      const historicalData = Array.from({ length: 15 }, () => ({
        performanceScore: 80,
      }));

      const result = engine.predictPerformance(historicalData);

      expect(result.confidenceInterval.lower).toBeLessThan(result.predictedScore);
      expect(result.confidenceInterval.upper).toBeGreaterThan(result.predictedScore);
    });

    test('should identify high performance trajectory', () => {
      const historicalData = Array.from({ length: 10 }, (_, i) => ({
        performanceScore: 60 + i * 3,
      }));

      const result = engine.predictPerformance(historicalData);

      expect(result.trajectory).toBe('IMPROVING');
    });

    test('should identify declining performance', () => {
      const historicalData = Array.from({ length: 10 }, (_, i) => ({
        performanceScore: 95 - i * 2.5,
      }));

      const result = engine.predictPerformance(historicalData);

      expect(result.trajectory).toBe('DECLINING');
    });
  });

  // ==================== اختبارات اكتشاف الأنماط ====================
  describe('Pattern Detection', () => {
    test('should detect weekly absence pattern', () => {
      const attendanceData = [
        { date: '2025-01-01', status: 'present' },
        { date: '2025-01-02', status: 'present' },
        { date: '2025-01-03', status: 'present' },
        { date: '2025-01-04', status: 'present' },
        { date: '2025-01-05', status: 'present' },
        { date: '2025-01-06', status: 'absent' },
        { date: '2025-01-07', status: 'absent' },
        { date: '2025-01-08', status: 'present' },
        { date: '2025-01-09', status: 'present' },
        { date: '2025-01-10', status: 'present' },
        { date: '2025-01-11', status: 'present' },
        { date: '2025-01-12', status: 'present' },
        { date: '2025-01-13', status: 'absent' },
        { date: '2025-01-14', status: 'absent' },
      ];

      const patterns = engine.detectAbsencePatterns(attendanceData);

      expect(patterns).toContainEqual(
        expect.objectContaining({
          patternType: 'WEEKEND_PATTERN',
        })
      );
    });

    test('should detect chronic absenteeism', () => {
      const attendanceData = Array.from({ length: 30 }, (_, i) => ({
        date: `2025-01-${(i + 1).toString().padStart(2, '0')}`,
        status: Math.random() > 0.7 ? 'absent' : 'present',
      }));

      const patterns = engine.detectAbsencePatterns(attendanceData);

      if (patterns.some(p => p.severity === 'HIGH')) {
        expect(patterns).toContainEqual(
          expect.objectContaining({
            severity: 'HIGH',
          })
        );
      }
    });

    test('should detect sporadic absences', () => {
      const attendanceData = Array.from({ length: 20 }, (_, i) => ({
        date: `2025-01-${(i + 1).toString().padStart(2, '0')}`,
        status: i === 5 || i === 12 ? 'absent' : 'present',
      }));

      const patterns = engine.detectAbsencePatterns(attendanceData);

      expect(patterns).toHaveLength(2);
    });

    test('should return empty array for no patterns', () => {
      const attendanceData = Array.from({ length: 15 }, (_, i) => ({
        date: `2025-01-${(i + 1).toString().padStart(2, '0')}`,
        status: 'present',
      }));

      const patterns = engine.detectAbsencePatterns(attendanceData);

      expect(patterns).toEqual([]);
    });
  });

  // ==================== اختبارات اكتشاف الشذوذ ====================
  describe('Anomaly Detection', () => {
    test('should detect performance anomaly', () => {
      const employeeData = {
        performanceHistory: Array.from({ length: 20 }, (_, i) => ({
          performanceScore: 80 + Math.random() * 10,
        })),
      };

      // إدراج قيمة شاذة
      employeeData.performanceHistory[10].performanceScore = 20;

      const anomalies = engine.detectAnomalies(employeeData);

      expect(anomalies).toContainEqual(
        expect.objectContaining({
          type: 'PERFORMANCE',
          severity: 'HIGH',
        })
      );
    });

    test('should detect attendance anomaly', () => {
      const employeeData = {
        attendanceHistory: Array.from({ length: 20 }, (_, i) => ({
          date: `2025-01-${(i + 1).toString().padStart(2, '0')}`,
          status: 'present',
        })),
      };

      // إدراج سلسلة غيابات غير متوقعة
      for (let i = 10; i < 15; i++) {
        employeeData.attendanceHistory[i].status = 'absent';
      }

      const anomalies = engine.detectAnomalies(employeeData);

      expect(anomalies.length).toBeGreaterThan(0);
    });

    test('should not report false positives', () => {
      const employeeData = {
        performanceHistory: Array.from({ length: 15 }, () => ({
          performanceScore: 80,
        })),
        attendanceHistory: Array.from({ length: 15 }, (_, i) => ({
          date: `2025-01-${(i + 1).toString().padStart(2, '0')}`,
          status: 'present',
        })),
      };

      const anomalies = engine.detectAnomalies(employeeData);

      expect(anomalies).toEqual([]);
    });

    test('should set appropriate severity levels', () => {
      const employeeData = {
        performanceHistory: Array.from({ length: 10 }, (_, i) => ({
          performanceScore: 80 + Math.random() * 5,
        })),
      };

      // قيمة شاذة بسيطة
      employeeData.performanceHistory[5].performanceScore = 70;

      const anomalies = engine.detectAnomalies(employeeData);

      if (anomalies.length > 0) {
        anomalies.forEach(a => {
          expect(a.severity).toMatch(/LOW|MEDIUM|HIGH/);
        });
      }
    });
  });

  // ==================== اختبارات تحليل الاتجاهات ====================
  describe('Trend Analysis', () => {
    test('should calculate linear regression correctly', () => {
      const x = [1, 2, 3, 4, 5];
      const y = [2, 4, 6, 8, 10];

      const result = engine.calculateLinearRegression(x, y);

      expect(result.slope).toBeCloseTo(2, 1);
      expect(result.intercept).toBeCloseTo(0, 1);
    });

    test('should handle perfect horizontal line', () => {
      const x = [1, 2, 3, 4, 5];
      const y = [5, 5, 5, 5, 5];

      const result = engine.calculateLinearRegression(x, y);

      expect(result.slope).toBeCloseTo(0, 1);
      expect(result.intercept).toBeCloseTo(5, 1);
    });

    test('should calculate variance correctly', () => {
      const data = [10, 20, 30, 40, 50];

      const variance = engine.calculateVariance(data);

      expect(variance).toBeCloseTo(200, 0);
    });

    test('should calculate confidence correctly', () => {
      const rates = [80, 85, 87, 88, 90];
      const trend = { slope: 2, intercept: 75 };

      const confidence = engine.calculateConfidence(rates, trend);

      expect(confidence).toBeGreaterThan(0);
      expect(confidence).toBeLessThanOrEqual(1);
    });

    test('should identify seasonal trends', () => {
      const historicalData = Array.from({ length: 48 }, (_, i) => {
        // محاكاة بيانات موسمية
        const baseLine = 80;
        const seasonalEffect = Math.sin((i / 12) * Math.PI * 2) * 5;
        return {
          attendanceRate: baseLine + seasonalEffect + Math.random() * 2,
        };
      });

      const result = engine.predictAttendanceRate(historicalData, 12);

      expect(result.predictions).toHaveLength(12);
      expect(result.trend).toBeDefined();
    });
  });

  // ==================== اختبارات التقرير الشامل ====================
  describe('Comprehensive Analysis Report', () => {
    test('should generate complete analysis report', () => {
      const employeeData = {
        id: 'EMP001',
        name: 'أحمد محمد',
        performanceScore: 85,
        attendanceRate: 90,
        performanceHistory: Array.from({ length: 15 }, (_, i) => ({
          performanceScore: 80 + Math.random() * 15,
        })),
        attendanceHistory: Array.from({ length: 30 }, (_, i) => ({
          date: `2025-01-${(i + 1).toString().padStart(2, '0')}`,
          status: Math.random() > 0.05 ? 'present' : 'absent',
        })),
      };

      const report = engine.analyzeEmployee(employeeData);

      expect(report).toHaveProperty('employee');
      expect(report).toHaveProperty('predictions');
      expect(report).toHaveProperty('patterns');
      expect(report).toHaveProperty('anomalies');
      expect(report).toHaveProperty('keyMetrics');
      expect(report).toHaveProperty('recommendations');
      expect(report).toHaveProperty('riskAssessment');
    });

    test('should include accurate predictions in report', () => {
      const employeeData = {
        id: 'EMP002',
        name: 'فاطمة علي',
        performanceScore: 88,
        attendanceRate: 95,
        performanceHistory: Array.from({ length: 20 }, () => ({
          performanceScore: 87,
        })),
        attendanceHistory: Array.from({ length: 20 }, () => ({
          status: 'present',
        })),
      };

      const report = engine.analyzeEmployee(employeeData);

      expect(report.predictions.attendance).toBeDefined();
      expect(report.predictions.performance).toBeDefined();
    });

    test('should generate appropriate recommendations', () => {
      const lowPerformerData = {
        id: 'EMP003',
        performanceScore: 65,
        attendanceRate: 75,
        performanceHistory: Array.from({ length: 10 }, () => ({
          performanceScore: 60,
        })),
        attendanceHistory: Array.from({ length: 10 }, () => ({
          status: 'present',
        })),
      };

      const report = engine.analyzeEmployee(lowPerformerData);

      expect(report.recommendations.length).toBeGreaterThan(0);
      expect(report.recommendations[0]).toHaveProperty('category');
      expect(report.recommendations[0]).toHaveProperty('priority');
      expect(report.recommendations[0]).toHaveProperty('recommendation');
    });

    test('should assess risk levels correctly', () => {
      const highRiskData = {
        id: 'EMP004',
        performanceScore: 55,
        attendanceRate: 70,
        performanceHistory: Array.from({ length: 10 }, (_, i) => ({
          performanceScore: 80 - i * 2,
        })),
        attendanceHistory: Array.from({ length: 10 }, () => ({
          status: 'present',
        })),
      };

      const report = engine.analyzeEmployee(highRiskData);

      expect(report.riskAssessment.overallRisk).toBe('HIGH');
      expect(report.riskAssessment.riskFactors.length).toBeGreaterThan(0);
    });

    test('should include metrics in report', () => {
      const employeeData = {
        id: 'EMP005',
        performanceScore: 80,
        attendanceRate: 88,
        performanceHistory: Array.from({ length: 15 }, () => ({
          performanceScore: 80,
        })),
        attendanceHistory: Array.from({ length: 15 }, () => ({
          status: 'present',
        })),
      };

      const report = engine.analyzeEmployee(employeeData);

      expect(report.keyMetrics).toHaveProperty('consistency');
      expect(report.keyMetrics).toHaveProperty('reliability');
      expect(report.keyMetrics).toHaveProperty('trend');
    });
  });

  // ==================== اختبارات دقة الحسابات ====================
  describe('Calculation Accuracy', () => {
    test('should calculate consistency percentage correctly', () => {
      const performanceData = Array.from({ length: 10 }, () => ({
        performanceScore: 80,
      }));

      const consistency = engine.calculateConsistency(performanceData);

      expect(consistency).toMatch(/\d+\.\d+%/);
      expect(parseFloat(consistency)).toBeGreaterThan(0);
      expect(parseFloat(consistency)).toBeLessThanOrEqual(100);
    });

    test('should calculate reliability percentage correctly', () => {
      const attendanceData = Array.from({ length: 20 }, (_, i) => ({
        status: i < 19 ? 'present' : 'absent',
      }));

      const reliability = engine.calculateReliability(attendanceData);

      expect(parseFloat(reliability)).toBeCloseTo(95, 1);
    });

    test('should handle empty data in calculations', () => {
      const consistency = engine.calculateConsistency([]);
      const reliability = engine.calculateReliability([]);

      expect(parseFloat(consistency)).toBe(0);
      expect(parseFloat(reliability)).toBe(0);
    });

    test('should calculate overall trend correctly', () => {
      const employeeData = {
        performanceHistory: Array.from({ length: 14 }, (_, i) => ({
          performanceScore: i < 7 ? 75 : 85,
        })),
      };

      const trend = engine.calculateOverallTrend(employeeData);

      expect(trend).toMatch(/IMPROVING|DECLINING|STABLE|INSUFFICIENT_DATA/);
    });
  });

  // ==================== اختبارات التعامل مع الأخطاء ====================
  describe('Error Handling', () => {
    test('should handle null data gracefully', () => {
      const result = engine.predictAttendanceRate(null);

      expect(result.error).toBeDefined();
    });

    test('should handle undefined data gracefully', () => {
      const result = engine.predictPerformance(undefined);

      expect(result.error).toBeDefined();
    });

    test('should handle empty arrays', () => {
      const result = engine.detectAbsencePatterns([]);

      expect(Array.isArray(result)).toBe(true);
      expect(result).toEqual([]);
    });

    test('should handle mixed data types safely', () => {
      const historicalData = [
        { attendanceRate: 85 },
        { attendanceRate: 'invalid' },
        { attendanceRate: 90 },
      ];

      expect(() => {
        engine.predictAttendanceRate(historicalData);
      }).not.toThrow();
    });
  });

  // ==================== اختبارات الأداء ====================
  describe('Performance Tests', () => {
    test('should process large datasets efficiently', () => {
      const largeDataset = Array.from({ length: 1000 }, () => ({
        attendanceRate: 85 + Math.random() * 10,
      }));

      const startTime = Date.now();
      const result = engine.predictAttendanceRate(largeDataset, 30);
      const endTime = Date.now();

      expect(result.predictions).toHaveLength(30);
      expect(endTime - startTime).toBeLessThan(1000); // أقل من ثانية واحدة
    });

    test('should emit events efficiently', done => {
      let eventCount = 0;

      engine.on('predictionGenerated', () => {
        eventCount++;
        if (eventCount === 5) {
          expect(eventCount).toBe(5);
          done();
        }
      });

      for (let i = 0; i < 5; i++) {
        const data = Array.from({ length: 10 }, () => ({
          attendanceRate: 85,
        }));
        engine.predictAttendanceRate(data, 5);
      }
    });

    test('should cache predictions', () => {
      const historicalData = Array.from({ length: 10 }, () => ({
        attendanceRate: 85,
      }));

      const result1 = engine.predictAttendanceRate(historicalData, 5);
      const result2 = engine.predictions.get('attendanceRate');

      expect(result1).toEqual(result2);
    });
  });

  // ==================== اختبارات التوافقية ====================
  describe('Integration Tests', () => {
    test('should work with all subsystems together', () => {
      const completeEmployeeData = {
        id: 'EMP006',
        name: 'محمد سالم',
        performanceScore: 82,
        attendanceRate: 92,
        performanceHistory: Array.from({ length: 30 }, (_, i) => ({
          performanceScore: 78 + Math.random() * 15,
        })),
        attendanceHistory: Array.from({ length: 60 }, (_, i) => ({
          date: `2024-12-${(i + 1).toString().padStart(2, '0')}`,
          status: Math.random() > 0.08 ? 'present' : 'absent',
        })),
      };

      const report = engine.analyzeEmployee(completeEmployeeData);

      expect(report).toBeDefined();
      expect(report.predictions).toBeDefined();
      expect(report.patterns).toBeDefined();
      expect(report.riskAssessment).toBeDefined();

      // تحقق من أن جميع الحقول موجودة
      const requiredFields = [
        'employee',
        'predictions',
        'patterns',
        'anomalies',
        'keyMetrics',
        'recommendations',
        'riskAssessment',
      ];

      requiredFields.forEach(field => {
        expect(report).toHaveProperty(field);
      });
    });

    test('should maintain data consistency across operations', () => {
      const data = Array.from({ length: 20 }, () => ({
        attendanceRate: 85,
      }));

      engine.predictAttendanceRate(data, 10);
      const cachedPrediction = engine.predictions.get('attendanceRate');

      expect(cachedPrediction).toBeDefined();
      expect(cachedPrediction.metric).toBe('Attendance Rate');
    });
  });

  // ==================== اختبارات الحالات الحدية ====================
  describe('Edge Cases', () => {
    test('should handle single data point', () => {
      const singleData = [{ attendanceRate: 85 }];

      const result = engine.predictAttendanceRate(singleData, 1);

      expect(result.error).toBeDefined();
    });

    test('should handle zero values', () => {
      const data = Array.from({ length: 10 }, () => ({
        attendanceRate: 0,
      }));

      const result = engine.predictAttendanceRate(data, 5);

      expect(result).toBeDefined();
    });

    test('should handle negative trend predictions', () => {
      const data = Array.from({ length: 20 }, (_, i) => ({
        attendanceRate: 100 - i * 3,
      }));

      const result = engine.predictAttendanceRate(data, 10);

      // يجب أن تكون القيم محدودة بـ 0 و 100
      result.predictions.forEach(p => {
        expect(p.predictedRate).toBeGreaterThanOrEqual(0);
      });
    });

    test('should handle very high confidence data', () => {
      const consistentData = Array.from({ length: 30 }, () => ({
        attendanceRate: 85,
      }));

      const result = engine.predictAttendanceRate(consistentData, 10);

      expect(result.confidence).toBeDefined();
    });

    test('should handle volatile data', () => {
      const volatileData = Array.from({ length: 20 }, () => ({
        attendanceRate: Math.random() * 100,
      }));

      const result = engine.predictAttendanceRate(volatileData, 10);

      expect(result).toBeDefined();
      expect(result.predictions).toHaveLength(10);
    });
  });
});
