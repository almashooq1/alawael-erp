module.exports = {
  testEnvironment: 'node',
  transform: {
    '^.+\\.[jt]sx?$': 'babel-jest',
  },
  extensionsToTreatAsEsm: ['.js'],
  moduleFileExtensions: ['js', 'mjs', 'cjs', 'json'],
  transformIgnorePatterns: [],
};
