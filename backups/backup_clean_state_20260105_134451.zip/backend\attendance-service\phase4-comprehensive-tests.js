/**
 * phase4-comprehensive-tests.js
 * اختبارات شاملة للميزات الإضافية (Phase 4)
 * تشمل Dashboard، PDF/Excel Export، Email Notifications، Scheduled Reports
 */

const assert = require('assert');
const EnhancedDashboard = require('../EnhancedDashboard');
const ReportExporter = require('../ReportExporter');
const EmailNotificationSystem = require('../EmailNotificationSystem');
const ScheduledReportService = require('../ScheduledReportService');

describe('Phase 4: Enhanced Features Tests', () => {
  let dashboard, exporter, emailService, reportScheduler;
  let mockAttendanceService, mockPayrollService, mockHRService, mockAnalyticsService;

  beforeEach(() => {
    // Initialize mock services
    mockAttendanceService = {
      getTeamMembers: async () => [{ id: 1, name: 'Ahmed', rating: 'excellent' }],
      getTeamAlerts: async () => [],
      getMonthlyAttendance: async () => ({ totalWorkingDays: 22, presentDays: 20, absentDays: 2 }),
      getDailyAttendance: async () => [],
      getAlerts: async () => [],
      getAbsences: async () => [],
      getMonthlyAlerts: async () => [],
      getActiveAlerts: async () => [],
      getAllAlerts: async () => [],
    };

    mockPayrollService = {
      getLatestPayslip: async () => ({
        employeeId: 1,
        employeeName: 'Ahmed Ali',
        monthlyBase: 5000,
        totalDeduction: 500,
        netSalary: 4500,
      }),
      getMonthlyPayrollSummary: async () => ({
        totalPayroll: 500000,
        totalDeductions: 50000,
        netPayroll: 450000,
        topDeductees: [],
      }),
      generateMonthlyPayroll: async () => ({
        employees: [{ name: 'Ahmed', totalDeduction: 500 }],
        totalBaseSalary: 500000,
        totalDeductions: 50000,
        totalNetPayroll: 450000,
      }),
    };

    mockHRService = {
      getPerformanceRating: async () => ({
        rating: 'excellent',
        score: 90,
        grade: 'A',
        attendanceScore: 95,
        disciplineScore: 85,
        productivityScore: 90,
      }),
      getPerformanceAnalysis: async () => ({
        averageScore: 80,
        excellent: 5,
        good: 10,
        average: 8,
        poor: 2,
      }),
    };

    mockAnalyticsService = {
      analyzeTeam: async () => ({
        averageAttendance: 90,
        averageLatenessHours: 2,
        averagePerformanceScore: 85,
      }),
      analyzeByDepartment: async () => [{ name: 'IT', employeeCount: 10 }],
      predictTeamPerformance: async () => ({
        atRisk: [],
        predictedAbsences: [],
      }),
      predictAbsence: async () => ({
        absenceRisk: 'low',
        riskLevel: 'LOW',
        lateRiskScore: 20,
      }),
      getCompanyStatistics: async () => ({
        totalEmployees: 100,
        departmentCount: 5,
        activeEmployees: 95,
        inactiveEmployees: 5,
        averageAttendance: 88,
        averagePerformance: 82,
      }),
    };

    dashboard = new EnhancedDashboard(
      mockAttendanceService,
      mockPayrollService,
      mockHRService,
      mockAnalyticsService
    );

    exporter = new ReportExporter('./test-reports');
    emailService = new EmailNotificationSystem({});
    reportScheduler = new ScheduledReportService(
      mockAttendanceService,
      mockAnalyticsService,
      emailService
    );
  });

  // ═══════════════════════════════════════════════════════════════
  // Enhanced Dashboard Tests
  // ═══════════════════════════════════════════════════════════════

  describe('EnhancedDashboard', () => {
    it('should create employee dashboard', async () => {
      const dashboardData = await dashboard.getEmployeeDashboard(1);

      assert(dashboardData, 'Dashboard data should be returned');
      assert(dashboardData.data, 'Should have data property');
      assert.strictEqual(dashboardData.data.header.employeeId, 1);
      assert(dashboardData.data.payroll, 'Should have payroll section');
      assert(dashboardData.data.attendance, 'Should have attendance section');
      assert(dashboardData.data.performance, 'Should have performance section');
    });

    it('should include payroll information in employee dashboard', async () => {
      const dashboardData = await dashboard.getEmployeeDashboard(1);
      const payroll = dashboardData.data.payroll;

      assert(payroll.monthlyBase, 'Should have monthly base salary');
      assert(payroll.latestDeduction !== undefined, 'Should have deduction amount');
      assert(payroll.netSalary, 'Should have net salary');
      assert(payroll.deductionBreakdown, 'Should have deduction breakdown');
    });

    it('should calculate attendance percentage correctly', async () => {
      const dashboardData = await dashboard.getEmployeeDashboard(1);
      const attendance = dashboardData.data.attendance;

      const expectedPercentage = ((20 / 22) * 100).toFixed(2);
      assert.strictEqual(attendance.presentPercentage, expectedPercentage);
    });

    it('should include performance rating in dashboard', async () => {
      const dashboardData = await dashboard.getEmployeeDashboard(1);
      const performance = dashboardData.data.performance;

      assert(performance.currentRating, 'Should have rating');
      assert(performance.score !== undefined, 'Should have score');
      assert(performance.grade, 'Should have grade');
      assert(performance.components, 'Should have component scores');
    });

    it('should generate recommendations based on data', async () => {
      const dashboardData = await dashboard.getEmployeeDashboard(1);
      const recommendations = dashboardData.data.recommendations;

      assert(Array.isArray(recommendations), 'Recommendations should be an array');
    });

    it('should return cached data on subsequent calls', async () => {
      const first = await dashboard.getEmployeeDashboard(1);
      const second = await dashboard.getEmployeeDashboard(1);

      assert.strictEqual(first.source, 'LIVE', 'First call should be LIVE');
      assert.strictEqual(second.source, 'CACHE', 'Second call should be CACHED');
    });

    it('should create manager dashboard for team overview', async () => {
      const dashboardData = await dashboard.getManagerDashboard(1, 'IT');

      assert(dashboardData.data.teamSummary, 'Should have team summary');
      assert(dashboardData.data.topPerformers, 'Should have top performers');
      assert(dashboardData.data.needsAttention, 'Should have employees needing attention');
    });

    it('should create HR dashboard with company statistics', async () => {
      const dashboardData = await dashboard.getHRDashboard();

      assert(dashboardData.data.companySummary, 'Should have company summary');
      assert(dashboardData.data.departmentMetrics, 'Should have department metrics');
      assert(dashboardData.data.performanceDistribution, 'Should have performance distribution');
    });
  });

  // ═══════════════════════════════════════════════════════════════
  // Report Exporter Tests
  // ═══════════════════════════════════════════════════════════════

  describe('ReportExporter', () => {
    it('should export payslip to PDF', async () => {
      const payslipData = {
        employeeName: 'Ahmed Ali',
        employeeId: 1,
        department: 'IT',
        position: 'Developer',
        month: '2025-12',
        monthlyBase: 5000,
        absenceDeduction: 200,
        latenessDeduction: 150,
        otherDeductions: 0,
        netSalary: 4650,
        absentDays: 2,
        lateHours: 6,
        bonusImpact: 0,
      };

      const filePath = await exporter.exportPayslipToPDF(payslipData, 'test-payslip');

      assert(filePath, 'Should return file path');
      assert(filePath.endsWith('.pdf'), 'Should be PDF file');
    });

    it('should export attendance report to PDF', async () => {
      const reportData = {
        totalWorkingDays: 22,
        presentDays: 20,
        absentDays: 2,
        lateDays: 1,
        details: [
          { date: '2025-12-01', checkInTime: '08:00', checkOutTime: '17:00', status: 'present' },
        ],
      };

      const filePath = await exporter.exportAttendanceReportToPDF(reportData, 'test-attendance');

      assert(filePath, 'Should return file path');
      assert(filePath.endsWith('.pdf'), 'Should be PDF file');
    });

    it('should export performance report to PDF', async () => {
      const performanceData = {
        employeeName: 'Ahmed Ali',
        position: 'Developer',
        department: 'IT',
        period: '2025-12',
        grade: 'A',
        score: 90,
        components: {
          attendance: 95,
          discipline: 85,
          productivity: 90,
        },
        comments: 'Great performance',
        recommendations: 'Continue good work',
      };

      const filePath = await exporter.exportPerformanceReportToPDF(
        performanceData,
        'test-performance'
      );

      assert(filePath, 'Should return file path');
      assert(filePath.endsWith('.pdf'), 'Should be PDF file');
    });

    it('should export attendance to Excel', async () => {
      const attendanceData = {
        totalDays: 22,
        presentDays: 20,
        absentDays: 2,
        records: [
          { date: '2025-12-01', checkInTime: '08:00', checkOutTime: '17:00', status: 'present' },
        ],
      };

      const filePath = await exporter.exportAttendanceToExcel(attendanceData, 'test-attendance');

      assert(filePath, 'Should return file path');
      assert(filePath.endsWith('.xlsx'), 'Should be Excel file');
    });

    it('should export payroll to Excel', async () => {
      const payrollData = {
        employees: [
          {
            id: 1,
            name: 'Ahmed',
            baseSalary: 5000,
            absenceDeduction: 200,
            latenessDeduction: 150,
            totalDeduction: 350,
            netSalary: 4650,
          },
        ],
      };

      const filePath = await exporter.exportPayrollToExcel(payrollData, 'test-payroll');

      assert(filePath, 'Should return file path');
      assert(filePath.endsWith('.xlsx'), 'Should be Excel file');
    });
  });

  // ═══════════════════════════════════════════════════════════════
  // Email Notification Tests
  // ═══════════════════════════════════════════════════════════════

  describe('EmailNotificationSystem', () => {
    it('should have absence alert template', () => {
      assert(emailService.templates.absenceAlert, 'Should have absence alert template');
      assert(emailService.templates.absenceAlert.subject, 'Template should have subject');
      assert(
        typeof emailService.templates.absenceAlert.template === 'function',
        'Template should be a function'
      );
    });

    it('should have lateness alert template', () => {
      assert(emailService.templates.latenessAlert, 'Should have lateness alert template');
    });

    it('should have payslip notification template', () => {
      assert(emailService.templates.payslipNotification, 'Should have payslip template');
    });

    it('should have performance rating template', () => {
      assert(emailService.templates.performanceRating, 'Should have performance rating template');
    });

    it('should have promotion offer template', () => {
      assert(emailService.templates.promotionOffer, 'Should have promotion template');
    });

    it('should have disciplinary action template', () => {
      assert(emailService.templates.disciplinaryAction, 'Should have disciplinary template');
    });

    it('should have leave approval template', () => {
      assert(emailService.templates.leaveApproval, 'Should have leave approval template');
    });

    it('should have leave rejection template', () => {
      assert(emailService.templates.leaveRejection, 'Should have leave rejection template');
    });

    it('should generate HTML content from absence alert template', () => {
      const data = {
        employeeName: 'Ahmed',
        date: '2025-12-01',
        absenceCount: 3,
        suggestedAction: 'Warning',
      };

      const html = emailService.templates.absenceAlert.template(data);

      assert(html, 'Should generate HTML');
      assert(html.includes('Ahmed'), 'Should include employee name');
      assert(html.includes('2025-12-01'), 'Should include date');
    });

    it('should generate HTML content from payslip template', () => {
      const data = {
        employeeName: 'Ahmed',
        month: '2025-12',
        baseSalary: 5000,
        absenceDeduction: 200,
        latenessDeduction: 150,
        netSalary: 4650,
      };

      const html = emailService.templates.payslipNotification.template(data);

      assert(html, 'Should generate HTML');
      assert(html.includes('Ahmed'), 'Should include employee name');
      assert(html.includes('5000'), 'Should include base salary');
      assert(html.includes('4650'), 'Should include net salary');
    });
  });

  // ═══════════════════════════════════════════════════════════════
  // Scheduled Report Service Tests
  // ═══════════════════════════════════════════════════════════════

  describe('ScheduledReportService', () => {
    it('should have all report jobs defined', () => {
      assert(reportScheduler.start, 'Should have start method');
      assert(reportScheduler.stop, 'Should have stop method');
      assert(reportScheduler.getReportHistory, 'Should have getReportHistory method');
    });

    it('should generate daily report data', async () => {
      const report = await reportScheduler.generateDailyReport();

      assert.strictEqual(report.type, 'daily', 'Should be daily report');
      assert(report.summary, 'Should have summary');
      assert(report.summary.totalEmployees !== undefined, 'Should have employee count');
      assert(report.alerts, 'Should have alerts');
    });

    it('should generate weekly report data', async () => {
      const report = await reportScheduler.generateWeeklyReport();

      assert.strictEqual(report.type, 'weekly', 'Should be weekly report');
      assert(report.statistics, 'Should have statistics');
      assert(report.recommendations, 'Should have recommendations');
    });

    it('should generate monthly report data', async () => {
      const report = await reportScheduler.generateMonthlyReport();

      assert.strictEqual(report.type, 'monthly', 'Should be monthly report');
      assert(report.statistics, 'Should have statistics');
      assert(report.payroll, 'Should have payroll section');
      assert(report.performance, 'Should have performance section');
    });

    it('should generate performance snapshot', async () => {
      const snapshot = await reportScheduler.generatePerformanceSnapshot();

      assert.strictEqual(snapshot.type, 'performanceSnapshot');
      assert(snapshot.metrics, 'Should have metrics');
      assert(snapshot.metrics.currentAttendanceRate !== undefined);
      assert(snapshot.healthScore !== undefined);
    });

    it('should generate payroll report', async () => {
      const report = await reportScheduler.generatePayrollReport();

      assert.strictEqual(report.type, 'payroll');
      assert(report.summary, 'Should have summary');
      assert(report.summary.totalEmployees !== undefined);
      assert(report.analysis, 'Should have analysis');
    });

    it('should record report in history', () => {
      const testReport = { type: 'test', data: 'test' };
      reportScheduler.recordReportHistory('test', testReport);

      const history = reportScheduler.getReportHistory('test');
      assert(history.length > 0, 'Should have recorded report');
      assert.strictEqual(history[0].report.type, 'test');
    });

    it('should limit report history size', () => {
      reportScheduler.config.maxHistory = 5;

      for (let i = 0; i < 10; i++) {
        reportScheduler.recordReportHistory('test', { id: i });
      }

      const history = reportScheduler.getReportHistory();
      assert(history.length <= 5, 'Should not exceed max history size');
    });
  });

  // ═══════════════════════════════════════════════════════════════
  // Integration Tests
  // ═══════════════════════════════════════════════════════════════

  describe('Phase 4 Integration', () => {
    it('should work with dashboard and export together', async () => {
      const dashboardData = await dashboard.getEmployeeDashboard(1);
      const payslipData = {
        employeeName: dashboardData.data.header.name,
        employeeId: 1,
        monthlyBase: dashboardData.data.payroll.monthlyBase,
        netSalary: dashboardData.data.payroll.netSalary,
        department: dashboardData.data.header.department,
        position: dashboardData.data.header.position,
        month: '2025-12',
        absenceDeduction: dashboardData.data.payroll.deductionBreakdown.absence,
        latenessDeduction: dashboardData.data.payroll.deductionBreakdown.lateness,
        otherDeductions: 0,
      };

      const pdfPath = await exporter.exportPayslipToPDF(payslipData, 'integration-test');

      assert(pdfPath, 'Should export dashboard data to PDF');
      assert(pdfPath.includes('integration-test'), 'Should use provided filename');
    });

    it('should combine email notification with report data', () => {
      const reportData = {
        employeeName: 'Ahmed',
        date: '2025-12-01',
        absenceCount: 3,
        suggestedAction: 'Warning',
        managerEmail: 'manager@company.com',
      };

      const html = emailService.templates.absenceAlert.template(reportData);
      assert(html.includes(reportData.employeeName), 'Should use report data in email');
    });
  });
});

// Summary Report
console.log(`
═══════════════════════════════════════════════════════════════
 Phase 4: Comprehensive Features Testing Complete
═══════════════════════════════════════════════════════════════

✅ Features Tested:
  1. Enhanced Dashboard (Employee, Manager, HR)
  2. Report Exporter (PDF, Excel)
  3. Email Notification System (10+ templates)
  4. Scheduled Report Service (Daily, Weekly, Monthly)
  5. Integration between all components

✅ Test Coverage:
  - Dashboard functionality and caching
  - Export to multiple formats
  - Email templates and content generation
  - Scheduled report generation
  - Data integration and flow

═══════════════════════════════════════════════════════════════
`);

module.exports = {
  EnhancedDashboard,
  ReportExporter,
  EmailNotificationSystem,
  ScheduledReportService,
};
