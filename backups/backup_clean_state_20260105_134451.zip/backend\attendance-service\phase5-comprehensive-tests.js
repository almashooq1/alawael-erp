/**
 * phase5-comprehensive-tests.js
 * اختبارات Phase 5 الشاملة
 * اختبار جميع الميزات الجديدة
 */

const PerformanceOptimizer = require('../PerformanceOptimizer');
const AdvancedSecurityManager = require('../AdvancedSecurityManager');
const ExternalIntegrationManager = require('../ExternalIntegrationManager');
const MobileAppArchitecture = require('../MobileAppArchitecture');
const AdvancedAnalyticsEngine = require('../AdvancedAnalyticsEngine');

describe('Phase 5 - Advanced Features', () => {
  let performanceOptimizer;
  let securityManager;
  let integrationManager;
  let mobileApp;
  let analyticsEngine;

  beforeEach(() => {
    performanceOptimizer = new PerformanceOptimizer();
    securityManager = new AdvancedSecurityManager();
    integrationManager = new ExternalIntegrationManager();
    mobileApp = new MobileAppArchitecture();
    analyticsEngine = new AdvancedAnalyticsEngine();
  });

  describe('PerformanceOptimizer Tests', () => {
    test('should initialize benchmarks correctly', () => {
      expect(performanceOptimizer.industryBenchmarks).toBeDefined();
      expect(performanceOptimizer.industryBenchmarks.attendance).toBeDefined();
      expect(performanceOptimizer.industryBenchmarks.performance).toBeDefined();
    });

    test('should cache data successfully', async () => {
      const mockFn = jest.fn().mockResolvedValue({ data: 'test' });
      const result = await performanceOptimizer.getCachedData('test-key', mockFn);

      expect(result).toEqual({ data: 'test' });
      expect(mockFn).toHaveBeenCalledTimes(1);
      expect(performanceOptimizer.cacheStats.misses).toBe(1);
    });

    test('should return cached data on second call', async () => {
      const mockFn = jest.fn().mockResolvedValue({ data: 'test' });

      await performanceOptimizer.getCachedData('test-key-2', mockFn);
      await performanceOptimizer.getCachedData('test-key-2', mockFn);

      expect(mockFn).toHaveBeenCalledTimes(1); // Called only once
      expect(performanceOptimizer.cacheStats.hits).toBe(1);
    });

    test('should compare data to benchmark', () => {
      const comparison = performanceOptimizer.compareToBenchmark('excellent', 95, 'attendance');

      expect(comparison).toBeDefined();
      expect(comparison.value).toBe(95);
      expect(comparison.rating).toBe('On Track');
    });

    test('should generate performance report', () => {
      const employeeData = {
        id: 'EMP001',
        attendanceRate: 92,
        performanceScore: 85,
        productivityScore: 88,
        monthlyLateHours: 2,
        attendanceHistory: [90, 91, 92, 93, 92, 91, 92],
        performanceHistory: [80, 82, 84, 85, 85, 86],
      };

      const report = performanceOptimizer.generatePerformanceReport(employeeData);

      expect(report).toBeDefined();
      expect(report.employeeId).toBe('EMP001');
      expect(report.metrics).toBeDefined();
      expect(report.overallRating).toBeDefined();
    });

    test('should analyze trends correctly', () => {
      const historicalData = [70, 75, 80, 82, 85, 88, 90];
      const trends = performanceOptimizer.analyzeTrends(historicalData);

      expect(trends).toBeDefined();
      expect(trends.trend).toBe('IMPROVING');
      expect(trends.direction).toBe('↑');
    });

    test('should measure performance', () => {
      const result = performanceOptimizer.measurePerformance('test-metric', () => 42);

      expect(result).toBe(42);
      expect(performanceOptimizer.metrics.has('test-metric')).toBe(true);
      expect(performanceOptimizer.metrics.get('test-metric').duration).toBeGreaterThanOrEqual(0);
    });

    test('should get cache statistics', () => {
      const stats = performanceOptimizer.getCacheStats();

      expect(stats).toBeDefined();
      expect(stats.hits).toBeGreaterThanOrEqual(0);
      expect(stats.misses).toBeGreaterThanOrEqual(0);
      expect(stats.hitRate).toBeDefined();
    });
  });

  describe('AdvancedSecurityManager Tests', () => {
    test('should enable 2FA successfully', async () => {
      const result = await securityManager.enable2FA('user123');

      expect(result).toBeDefined();
      expect(result.secret).toBeDefined();
      expect(result.qrCode).toBeDefined();
      expect(result.backupCodes).toBeDefined();
      expect(result.backupCodes.length).toBe(10);
    });

    test('should verify 2FA token', () => {
      const secret = 'JBSWY3DPEBLW64TMMQ======'; // Sample secret
      // Note: In real tests, use proper mocking
      const verified = securityManager.verify2FAToken(secret, '000000', 'user123');

      expect(typeof verified).toBe('boolean');
    });

    test('should register biometric data', async () => {
      const result = await securityManager.registerBiometric('user123', {
        type: 'fingerprint',
        data: Buffer.from('biometric-data'),
      });

      expect(result.status).toBe('SUCCESS');
      expect(securityManager.biometricProfiles.has('user123')).toBe(true);
    });

    test('should verify biometric data', async () => {
      await securityManager.registerBiometric('user123', {
        type: 'fingerprint',
        data: Buffer.from('biometric-data'),
      });

      const verified = securityManager.verifyBiometric('user123', {
        type: 'fingerprint',
        data: Buffer.from('biometric-data'),
      });

      expect(verified).toBe(true);
    });

    test('should encrypt and decrypt data', () => {
      const originalData = 'sensitive information';
      const encrypted = securityManager.encryptData(originalData, 'password123');

      expect(encrypted).not.toBe(originalData);
      expect(encrypted).toContain(':');

      const decrypted = securityManager.decryptData(encrypted, 'password123');
      expect(decrypted).toBe(originalData);
    });

    test('should track failed login attempts', () => {
      const checkResult1 = securityManager.checkLoginAttempts('user123');
      expect(checkResult1.allowed).toBe(true);

      securityManager.recordFailedAttempt('user123');
      const checkResult2 = securityManager.checkLoginAttempts('user123');
      expect(checkResult2.allowed).toBe(true);
      expect(checkResult2.attemptsRemaining).toBeLessThan(5);
    });

    test('should generate secure tokens', () => {
      const tokens = securityManager.generateSecureTokens('user123', 'admin');

      expect(tokens).toBeDefined();
      expect(tokens.accessToken).toBeDefined();
      expect(tokens.refreshToken).toBeDefined();
    });

    test('should log security events', () => {
      securityManager.logSecurityEvent({
        type: 'LOGIN_SUCCESS',
        userId: 'user123',
        timestamp: new Date(),
      });

      expect(securityManager.securityLog.length).toBeGreaterThan(0);
    });

    test('should generate security report', () => {
      securityManager.logSecurityEvent({
        type: 'LOGIN_ATTEMPT_FAILED',
        userId: 'user123',
        timestamp: new Date(),
      });

      const report = securityManager.getSecurityReport();

      expect(report).toBeDefined();
      expect(report.summary).toBeDefined();
      expect(report.vulnerabilities).toBeDefined();
      expect(report.recommendations).toBeDefined();
    });
  });

  describe('ExternalIntegrationManager Tests', () => {
    test('should update integration status', () => {
      integrationManager.updateIntegrationStatus('SAP', 'CONNECTED', {});

      const status = integrationManager.getIntegrationStatus();
      expect(status.integrations.SAP.status).toBe('CONNECTED');
    });

    test('should calculate overall health', () => {
      integrationManager.updateIntegrationStatus('SAP', 'CONNECTED', {});
      integrationManager.updateIntegrationStatus('Salesforce', 'CONNECTED', {});

      const health = integrationManager.calculateOverallHealth();
      expect(['HEALTHY', 'DEGRADED', 'CRITICAL', 'UNKNOWN']).toContain(health);
    });

    test('should log sync events', () => {
      integrationManager.logSyncEvent('SAP_SYNC', 'SUCCESS', 'emp123', 'Test sync');

      expect(integrationManager.syncLog.length).toBeGreaterThan(0);
      expect(integrationManager.syncLog[0].status).toBe('SUCCESS');
    });

    test('should calculate sync success rate', () => {
      integrationManager.logSyncEvent('SAP_SYNC', 'SUCCESS', 'emp1');
      integrationManager.logSyncEvent('SAP_SYNC', 'SUCCESS', 'emp2');
      integrationManager.logSyncEvent('SAP_SYNC', 'FAILED', 'emp3');

      const successRate = integrationManager.calculateSyncSuccessRate();
      expect(successRate).toContain('%');
    });

    test('should generate integration report', () => {
      const report = integrationManager.getIntegrationReport();

      expect(report).toBeDefined();
      expect(report.reportDate).toBeDefined();
      expect(report.integrationStatus).toBeDefined();
      expect(report.recommendations).toBeDefined();
    });

    test('should generate temporary password', () => {
      const password = integrationManager.generateTemporaryPassword();

      expect(password).toBeDefined();
      expect(password.length).toBe(12);
    });
  });

  describe('MobileAppArchitecture Tests', () => {
    test('should register device successfully', async () => {
      const result = await mobileApp.registerDevice({
        userId: 'user123',
        platform: 'iOS',
        osVersion: '15.0',
        appVersion: '1.0.0',
        deviceModel: 'iPhone 13',
        fcmToken: 'fcm-token-123',
        biometric: true,
      });

      expect(result.success).toBe(true);
      expect(result.deviceId).toBeDefined();
      expect(result.sessionToken).toBeDefined();
    });

    test('should save offline data', async () => {
      const result = await mobileApp.saveOfflineData('user123', 'checkIn', {
        location: 'Office',
        timestamp: new Date(),
      });

      expect(result.success).toBe(true);
      expect(result.recordId).toBeDefined();
    });

    test('should sync offline data when online', async () => {
      await mobileApp.saveOfflineData('user123', 'checkIn', {
        location: 'Office',
        timestamp: new Date(),
      });

      const result = await mobileApp.syncOfflineData('user123', true);

      expect(result.synced).toBeGreaterThanOrEqual(0);
    });

    test('should register push notifications', async () => {
      const deviceResult = await mobileApp.registerDevice({
        userId: 'user123',
        platform: 'iOS',
        osVersion: '15.0',
        appVersion: '1.0.0',
        deviceModel: 'iPhone 13',
        fcmToken: 'fcm-token-456',
      });

      const pushResult = await mobileApp.registerPushNotifications(
        deviceResult.deviceId,
        'fcm-token-456'
      );

      expect(pushResult.success).toBe(true);
    });

    test('should send push notification', async () => {
      const deviceResult = await mobileApp.registerDevice({
        userId: 'user123',
        platform: 'iOS',
        osVersion: '15.0',
        appVersion: '1.0.0',
        deviceModel: 'iPhone 13',
        fcmToken: 'fcm-token-789',
      });

      await mobileApp.registerPushNotifications(deviceResult.deviceId, 'fcm-token-789');

      const result = await mobileApp.sendPushNotification(deviceResult.deviceId, {
        title: 'Test Notification',
        message: 'This is a test',
        type: 'attendance',
        action: 'checkIn',
      });

      expect(result.sent).toBe(true);
    });

    test('should broadcast notification', async () => {
      const device1 = await mobileApp.registerDevice({
        userId: 'user1',
        platform: 'iOS',
        osVersion: '15.0',
        appVersion: '1.0.0',
        deviceModel: 'iPhone 13',
        fcmToken: 'token-1',
      });

      await mobileApp.registerPushNotifications(device1.deviceId, 'token-1');

      const result = await mobileApp.broadcastNotification(['user1'], {
        title: 'Broadcast',
        message: 'Testing broadcast',
        type: 'system',
      });

      expect(result.totalDevices).toBeGreaterThanOrEqual(0);
    });

    test('should get employee dashboard', () => {
      const dashboard = mobileApp.getEmployeeDashboard({
        id: 'emp123',
        name: 'أحمد محمد',
        department: 'IT',
        position: 'Software Engineer',
        photo: 'photo-url',
        todayStatus: 'checkedIn',
        checkInTime: '08:00',
        attendanceRate: 92,
      });

      expect(dashboard).toBeDefined();
      expect(dashboard.profile).toBeDefined();
      expect(dashboard.today).toBeDefined();
      expect(dashboard.thisMonth).toBeDefined();
      expect(dashboard.actions).toBeDefined();
    });

    test('should get manager dashboard', () => {
      const dashboard = mobileApp.getManagerDashboard({
        total: 10,
        present: 8,
        absent: 1,
        onLeave: 1,
        attendanceRate: 80,
        topPerformers: [],
        needsAttention: [],
        todaySchedule: [],
        alerts: [],
        pendingLeaves: 3,
      });

      expect(dashboard).toBeDefined();
      expect(dashboard.teamSummary).toBeDefined();
      expect(dashboard.quickActions).toBeDefined();
    });

    test('should check for app update', () => {
      const mobileAppWithVersion = new MobileAppArchitecture({
        appVersion: '1.2.0',
      });

      const updateInfo = mobileAppWithVersion.checkForAppUpdate('1.0.0');

      expect(updateInfo).toBeDefined();
      expect(updateInfo.updateAvailable).toBe(true);
    });

    test('should generate mobile app health report', () => {
      const report = mobileApp.getMobileAppHealthReport();

      expect(report).toBeDefined();
      expect(report.reportDate).toBeDefined();
      expect(report.devices).toBeDefined();
      expect(report.syncStatus).toBeDefined();
      expect(report.recommendations).toBeDefined();
    });
  });

  describe('AdvancedAnalyticsEngine Tests', () => {
    test('should predict attendance rate', () => {
      const historicalData = Array.from({ length: 30 }, (_, i) => ({
        date: new Date(Date.now() - (30 - i) * 24 * 60 * 60 * 1000),
        attendanceRate: 85 + Math.random() * 10,
      }));

      const prediction = analyticsEngine.predictAttendanceRate(historicalData, 7);

      expect(prediction).toBeDefined();
      expect(prediction.metric).toBe('Attendance Rate');
      expect(prediction.predictions).toBeDefined();
      expect(prediction.predictions.length).toBe(7);
    });

    test('should predict performance', () => {
      const historicalData = [75, 78, 80, 82, 85, 87, 88];

      const prediction = analyticsEngine.predictPerformance(historicalData);

      expect(prediction).toBeDefined();
      expect(prediction.metric).toBe('Performance Score');
      expect(prediction.nextPredictedScore).toBeDefined();
      expect(prediction.confidence).toBeDefined();
    });

    test('should detect absence patterns', () => {
      const attendanceData = Array.from({ length: 30 }, (_, i) => ({
        date: new Date(Date.now() - (30 - i) * 24 * 60 * 60 * 1000),
        status: Math.random() > 0.9 ? 'absent' : 'present',
      }));

      const patterns = analyticsEngine.detectAbsencePatterns(attendanceData);

      expect(patterns).toBeDefined();
      expect(patterns.weeklyPattern).toBeDefined();
      expect(patterns.anomalies).toBeDefined();
    });

    test('should detect anomalies', () => {
      const data = Array.from({ length: 20 }, (_, i) => ({
        status: i === 10 ? 'absent' : 'present',
      }));

      const anomalies = analyticsEngine.detectAnomalies(data);

      expect(Array.isArray(anomalies)).toBe(true);
    });

    test('should generate comprehensive analysis report', () => {
      const employeeData = {
        id: 'emp123',
        name: 'أحمد محمد',
        performanceScore: 85,
        attendanceRate: 92,
        attendanceHistory: [{ status: 'present' }, { status: 'present' }, { status: 'present' }],
        performanceHistory: [
          { performanceScore: 80 },
          { performanceScore: 82 },
          { performanceScore: 85 },
        ],
      };

      const report = analyticsEngine.generateComprehensiveAnalysisReport(employeeData);

      expect(report).toBeDefined();
      expect(report.reportDate).toBeDefined();
      expect(report.predictions).toBeDefined();
      expect(report.patterns).toBeDefined();
      expect(report.keyMetrics).toBeDefined();
      expect(report.recommendations).toBeDefined();
      expect(report.riskAssessment).toBeDefined();
    });

    test('should calculate consistency', () => {
      const performanceData = [75, 80, 78, 85, 82, 86, 84];

      const consistency = analyticsEngine.calculateConsistency(performanceData);

      expect(consistency).toBeDefined();
      expect(consistency).toContain('%');
    });

    test('should calculate reliability', () => {
      const attendanceData = [
        { status: 'present' },
        { status: 'present' },
        { status: 'absent' },
        { status: 'present' },
      ];

      const reliability = analyticsEngine.calculateReliability(attendanceData);

      expect(reliability).toBeDefined();
      expect(reliability).toContain('%');
    });

    test('should assess overall risk', () => {
      const employeeData = {
        performanceScore: 55,
        attendanceRate: 75,
        performanceHistory: [
          { performanceScore: 70 },
          { performanceScore: 65 },
          { performanceScore: 55 },
        ],
      };

      const riskAssessment = analyticsEngine.assessOverallRisk(employeeData);

      expect(riskAssessment).toBeDefined();
      expect(riskAssessment.overallRisk).toMatch(/HIGH|MEDIUM|LOW/);
      expect(riskAssessment.riskFactors).toBeDefined();
      expect(riskAssessment.recommendedActions).toBeDefined();
    });
  });

  describe('Integration Tests', () => {
    test('should integrate all modules together', async () => {
      // Register device
      const device = await mobileApp.registerDevice({
        userId: 'user123',
        platform: 'iOS',
        osVersion: '15.0',
        appVersion: '1.0.0',
        deviceModel: 'iPhone 13',
        fcmToken: 'fcm-token',
      });

      // Enable security
      const twoFactor = await securityManager.enable2FA('user123');

      // Register push notifications
      await mobileApp.registerPushNotifications(device.deviceId, 'fcm-token');

      // Get performance report
      const perfReport = performanceOptimizer.generatePerformanceReport({
        id: 'user123',
        attendanceRate: 92,
        performanceScore: 85,
        productivityScore: 88,
        monthlyLateHours: 2,
      });

      // Generate analytics
      const analyticsReport = analyticsEngine.generateComprehensiveAnalysisReport({
        id: 'user123',
        name: 'أحمد',
        performanceScore: 85,
        attendanceRate: 92,
      });

      expect(device.success).toBe(true);
      expect(twoFactor.secret).toBeDefined();
      expect(perfReport.overallRating).toBeDefined();
      expect(analyticsReport.predictions).toBeDefined();
    });

    test('should handle offline sync with security', async () => {
      // Register device
      const device = await mobileApp.registerDevice({
        userId: 'user123',
        platform: 'Android',
        osVersion: '11.0',
        appVersion: '1.0.0',
        deviceModel: 'Samsung Galaxy',
        fcmToken: 'fcm-android',
      });

      // Save offline data
      await mobileApp.saveOfflineData('user123', 'checkIn', {
        location: 'Office',
        timestamp: new Date(),
      });

      // Encrypt sensitive data
      const encrypted = securityManager.encryptData('sensitive data', 'key');

      // Sync when online
      const syncResult = await mobileApp.syncOfflineData('user123', true);

      expect(device.success).toBe(true);
      expect(encrypted).not.toBe('sensitive data');
      expect(syncResult.synced).toBeGreaterThanOrEqual(0);
    });
  });
});
