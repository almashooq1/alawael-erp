/**
 * LeaveRequest.model.js
 * نموذج قاعدة البيانات لطلبات الإجازة
 * Mongoose Schema for Leave Requests
 */

const mongoose = require('mongoose');
const { Schema } = mongoose;

// استخدام الفترة الزمنية
const dateRangeSchema = new Schema(
  {
    startDate: {
      type: Date,
      required: [true, 'تاريخ البداية مطلوب'],
      validate: {
        validator: function (value) {
          return value >= new Date();
        },
        message: 'تاريخ البداية يجب أن يكون في المستقبل',
      },
    },
    endDate: {
      type: Date,
      required: [true, 'تاريخ النهاية مطلوب'],
      validate: {
        validator: function (value) {
          return value >= this.startDate;
        },
        message: 'تاريخ النهاية يجب أن يكون بعد تاريخ البداية',
      },
    },
  },
  { _id: false }
);

// مستندات الدعم
const attachmentSchema = new Schema(
  {
    id: String,
    fileName: String,
    fileType: String, // PDF, Image, etc.
    fileSize: Number,
    uploadedAt: {
      type: Date,
      default: Date.now,
    },
    url: String,
  },
  { _id: false }
);

// سجل التغييرات
const historySchema = new Schema(
  {
    action: {
      type: String,
      enum: ['CREATED', 'APPROVED', 'REJECTED', 'CANCELLED', 'UPDATED'],
      required: true,
    },
    timestamp: {
      type: Date,
      default: Date.now,
    },
    by: String, // userId of the person who made the action
    comment: String,
    changes: {
      field: String,
      oldValue: mongoose.Schema.Types.Mixed,
      newValue: mongoose.Schema.Types.Mixed,
    },
  },
  { _id: false }
);

// بيانات الموافقة
const approvalSchema = new Schema(
  {
    approver: String, // userId
    approverName: String,
    approverRole: {
      type: String,
      enum: ['manager', 'hr', 'admin'],
    },
    status: {
      type: String,
      enum: ['PENDING', 'APPROVED', 'REJECTED'],
      default: 'PENDING',
    },
    comment: String,
    timestamp: Date,
    level: Number, // مستوى التصعيد
  },
  { _id: false }
);

// النموذج الرئيسي
const leaveRequestSchema = new Schema(
  {
    // المعرف الفريد
    leaveRequestId: {
      type: String,
      unique: true,
      required: true,
      index: true,
    },

    // بيانات الموظف
    employeeId: {
      type: Schema.Types.ObjectId,
      ref: 'Employee',
      required: [true, 'معرف الموظف مطلوب'],
      index: true,
    },
    employeeName: String,
    employeeEmail: String,
    department: String,
    manager: {
      type: Schema.Types.ObjectId,
      ref: 'Employee',
    },

    // نوع الإجازة
    leaveType: {
      type: String,
      enum: ['ANNUAL', 'SICK', 'PERSONAL', 'MATERNITY', 'UNPAID', 'COMPASSIONATE'],
      required: [true, 'نوع الإجازة مطلوب'],
      index: true,
    },

    // الفترة الزمنية
    dateRange: dateRangeSchema,
    duration: {
      value: {
        type: Number,
        required: true,
      },
      unit: {
        type: String,
        enum: ['DAYS', 'HOURS'],
        default: 'DAYS',
      },
    },

    // الحالة
    status: {
      type: String,
      enum: ['DRAFT', 'PENDING', 'APPROVED', 'REJECTED', 'CANCELLED', 'PARTIALLY_APPROVED'],
      default: 'PENDING',
      index: true,
    },

    // التفاصيل
    reason: {
      type: String,
      maxlength: 1000,
    },
    remarks: String,
    attachments: [attachmentSchema],

    // المعالجة
    approvalChain: {
      required: true,
      type: [approvalSchema],
      default: [],
    },
    currentApprovalLevel: {
      type: Number,
      default: 0,
    },

    // معلومات الموافقة/الرفض
    approvedBy: {
      type: Schema.Types.ObjectId,
      ref: 'Employee',
    },
    approvedDate: Date,
    rejectedBy: {
      type: Schema.Types.ObjectId,
      ref: 'Employee',
    },
    rejectedDate: Date,
    rejectionReason: String,

    // الرصيد المتبقي
    balanceDeducted: Boolean,
    remainingBalance: {
      [String]: Number, // نوع الإجازة -> الرصيد المتبقي
    },

    // المواصفات الإضافية
    requiresMedicalCertificate: Boolean,
    medicalCertificateProvided: Boolean,
    certificateDate: Date,

    // البدل والرواتب
    isPaid: Boolean,
    amountDeducted: Number,
    currency: {
      type: String,
      default: 'SAR',
    },

    // المراجع
    referenceNumber: String,
    correlationId: String,

    // السجل
    history: [historySchema],
    createdAt: {
      type: Date,
      default: Date.now,
      index: true,
    },
    updatedAt: {
      type: Date,
      default: Date.now,
    },
    createdBy: String,
    updatedBy: String,

    // السياق
    context: {
      ipAddress: String,
      userAgent: String,
      deviceInfo: String,
    },

    // البيانات الوصفية
    metadata: {
      estimatedReturnDate: Date,
      coverPerson: Schema.Types.ObjectId,
      handoverDone: Boolean,
      handoverDate: Date,
      notes: String,
    },
  },
  {
    timestamps: true,
    collection: 'leave_requests',
  }
);

// الفهارس
leaveRequestSchema.index({ employeeId: 1, status: 1 });
leaveRequestSchema.index({ employeeId: 1, leaveType: 1 });
leaveRequestSchema.index({ 'dateRange.startDate': 1, 'dateRange.endDate': 1 });
leaveRequestSchema.index({ manager: 1, status: 1 });
leaveRequestSchema.index({ createdAt: -1 });

// الخوارزميات الافتراضية
leaveRequestSchema.set('toJSON', {
  virtuals: true,
  transform(doc, ret) {
    delete ret.__v;
    return ret;
  },
});

// الخصائص المحسوبة
leaveRequestSchema.virtual('daysRemaining').get(function () {
  if (this.duration && this.remainingBalance) {
    return (this.remainingBalance[this.leaveType] || 0) - this.duration.value;
  }
  return null;
});

leaveRequestSchema.virtual('isApproved').get(function () {
  return this.status === 'APPROVED';
});

leaveRequestSchema.virtual('isPending').get(function () {
  return this.status === 'PENDING';
});

leaveRequestSchema.virtual('isExpired').get(function () {
  return this.dateRange && this.dateRange.endDate < new Date();
});

// الدوال المخصصة
leaveRequestSchema.methods.approve = function (approverId, comment = '') {
  this.status = 'APPROVED';
  this.approvedBy = approverId;
  this.approvedDate = new Date();

  this.history.push({
    action: 'APPROVED',
    by: approverId,
    comment,
  });

  return this.save();
};

leaveRequestSchema.methods.reject = function (rejecterId, reason) {
  this.status = 'REJECTED';
  this.rejectedBy = rejecterId;
  this.rejectedDate = new Date();
  this.rejectionReason = reason;

  this.history.push({
    action: 'REJECTED',
    by: rejecterId,
    comment: reason,
  });

  return this.save();
};

leaveRequestSchema.methods.cancel = function (cancelledBy, reason = '') {
  this.status = 'CANCELLED';

  this.history.push({
    action: 'CANCELLED',
    by: cancelledBy,
    comment: reason,
  });

  return this.save();
};

leaveRequestSchema.methods.addApproval = function (approval) {
  this.approvalChain.push(approval);
  this.currentApprovalLevel = this.approvalChain.length;
  return this.save();
};

// الإحصائيات
leaveRequestSchema.statics.getEmployeeStatistics = async function (employeeId) {
  const stats = await this.aggregate([
    { $match: { employeeId: mongoose.Types.ObjectId(employeeId) } },
    {
      $group: {
        _id: '$leaveType',
        total: { $sum: 1 },
        approved: {
          $sum: {
            $cond: [{ $eq: ['$status', 'APPROVED'] }, 1, 0],
          },
        },
        rejected: {
          $sum: {
            $cond: [{ $eq: ['$status', 'REJECTED'] }, 1, 0],
          },
        },
        pending: {
          $sum: {
            $cond: [{ $eq: ['$status', 'PENDING'] }, 1, 0],
          },
        },
        totalDays: {
          $sum: {
            $cond: [{ $eq: ['$status', 'APPROVED'] }, '$duration.value', 0],
          },
        },
      },
    },
  ]);

  return stats;
};

// Middleware
leaveRequestSchema.pre('save', function (next) {
  this.updatedAt = new Date();
  next();
});

module.exports = mongoose.model('LeaveRequest', leaveRequestSchema);
