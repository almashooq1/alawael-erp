// Attendance repository with Postgres or in-memory fallback
import { Pool } from 'pg';
import { SafeDBHelper } from '../../shared/database/safe-db-helper-es6.js';

function toDb(record) {
  return {
    id: record.id,
    patient_id: record.patientId,
    therapist_id: record.therapistId,
    scheduled_session_id: record.scheduledSessionId,
    status: record.status,
    check_in_at: record.checkInAt,
    check_out_at: record.checkOutAt,
    branch_id: record.branchId,
    tags: JSON.stringify(record.tags || []),
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };
}

function fromDb(row) {
  return {
    id: row.id,
    patientId: row.patient_id,
    therapistId: row.therapist_id,
    scheduledSessionId: row.scheduled_session_id,
    status: row.status,
    checkInAt: row.check_in_at,
    checkOutAt: row.check_out_at,
    branchId: row.branch_id,
    tags: Array.isArray(row.tags)
      ? row.tags
      : (() => {
          try {
            return JSON.parse(row.tags || '[]');
          } catch {
            return [];
          }
        })(),
  };
}

// Table creation removed; rely on SQL migrations.

function createPgRepo({ logger }) {
  const pool = new Pool({ connectionString: process.env.DATABASE_URL });
  const dbHelper = new SafeDBHelper(pool);
  let ready = false;
  async function init() {
    if (!ready) {
      // Assume schema is created via migrations; optionally validate existence
      ready = true;
      logger.info?.('attendance repo: connected to Postgres');
    }
  }
  return {
    async create(record) {
      await init();
      const dbrec = toDb(record);
      const fields = Object.keys(dbrec);
      const values = Object.values(dbrec);
      const placeholders = fields.map((_, i) => `$${i + 1}`).join(',');
      const sql = `INSERT INTO attendance(${fields.join(',')}) VALUES (${placeholders})`;
      await pool.query(sql, values);
      return record.id;
    },
    async list({ patientId, status } = {}) {
      await init();
      const conds = [];
      const args = [];
      if (patientId) {
        args.push(patientId);
        conds.push(`patient_id = $${args.length}`);
      }
      if (status) {
        args.push(status);
        conds.push(`status = $${args.length}`);
      }
      const where = conds.length ? `WHERE ${conds.join(' AND ')}` : '';
      const res = await pool.query(
        `SELECT * FROM attendance ${where} ORDER BY check_in_at DESC LIMIT 200`,
        args
      );
      return res.rows.map(fromDb);
    },
    async getById(id) {
      await init();
      const rows = await dbHelper.safeSelect('attendance', {
        where: { id },
        limit: 1,
      });
      if (!rows[0]) {
        return null;
      }
      return fromDb(rows[0]);
    },
  };
}

function createMemoryRepo() {
  const store = new Map();
  return {
    async create(record) {
      store.set(record.id, record);
      return record.id;
    },
    async list({ patientId, status } = {}) {
      return Array.from(store.values()).filter(r => {
        if (patientId && r.patientId !== patientId) {
          return false;
        }
        if (status && r.status !== status) {
          return false;
        }
        return true;
      });
    },
    async getById(id) {
      return store.get(id) || null;
    },
  };
}

export function createAttendanceRepo({ logger = console } = {}) {
  if (process.env.DATABASE_URL) {
    return createPgRepo({ logger });
  }
  return createMemoryRepo();
}
