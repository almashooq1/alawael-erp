/**
 * hrRoutes.js
 * مسارات API لتكامل الموارد البشرية
 */

const express = require('express');
const router = express.Router();
const unifiedAuth = require('../../../../shared/auth/unified-auth');
const validateJWT = unifiedAuth.authenticate();
const validateRole = (...roles) => unifiedAuth.authorize(...roles);
const Logger = require('../utils/Logger');
const AttendanceHRIntegration = require('../AttendanceHRIntegration');

const logger = new Logger('hrRoutes');
const hrIntegration = new AttendanceHRIntegration();

/**
 * POST /api/hr/update-performance-rating
 * تحديث تقييم الأداء بناءً على الحضور
 */
router.post(
  '/update-performance-rating',
  validateJWT,
  validateRole(['admin', 'hr']),
  async (req, res) => {
    try {
      const { employeeId, attendanceAnalysis, otherMetrics } = req.body;

      if (!employeeId || !attendanceAnalysis) {
        return res.status(400).json({
          success: false,
          message: 'معرف الموظف وبيانات الحضور مطلوبة',
          errors: ['employeeId', 'attendanceAnalysis'],
        });
      }

      const performanceRating = hrIntegration.updatePerformanceRating(
        employeeId,
        attendanceAnalysis,
        otherMetrics || {}
      );

      res.status(200).json({
        success: true,
        message: 'تم تحديث تقييم الأداء بنجاح',
        data: performanceRating,
      });

      logger.info(`تحديث تقييم الأداء للموظف ${employeeId} بواسطة ${req.user.id}`);
    } catch (error) {
      logger.error('خطأ في تحديث تقييم الأداء:', error.message);
      res.status(500).json({
        success: false,
        message: 'خطأ في تحديث تقييم الأداء',
        error: error.message,
      });
    }
  }
);

/**
 * GET /api/hr/performance-rating/:employeeId
 * الحصول على تقييم أداء الموظف
 */
router.get(
  '/performance-rating/:employeeId',
  validateJWT,
  validateRole(['admin', 'hr', 'manager', 'employee']),
  async (req, res) => {
    try {
      const { employeeId } = req.params;

      // التحقق من الصلاحيات
      if (req.user.role === 'employee' && req.user.id !== employeeId) {
        return res.status(403).json({
          success: false,
          message: 'لا يمكنك الوصول لتقييم موظف آخر',
        });
      }

      const rating = hrIntegration.performanceRatings.get(employeeId);

      if (!rating) {
        return res.status(404).json({
          success: false,
          message: 'لم يتم العثور على تقييم أداء',
        });
      }

      res.status(200).json({
        success: true,
        message: 'تم استرجاع تقييم الأداء',
        data: rating,
      });

      logger.info(`استرجاع تقييم الأداء للموظف ${employeeId} بواسطة ${req.user.id}`);
    } catch (error) {
      logger.error('خطأ في استرجاع تقييم الأداء:', error.message);
      res.status(500).json({
        success: false,
        message: 'خطأ في استرجاع تقييم الأداء',
        error: error.message,
      });
    }
  }
);

/**
 * POST /api/hr/suggest-promotion
 * اقتراح ترقية للموظف
 */
router.post('/suggest-promotion', validateJWT, validateRole(['admin', 'hr']), async (req, res) => {
  try {
    const { employeeData, performanceRating } = req.body;

    if (!employeeData || !performanceRating) {
      return res.status(400).json({
        success: false,
        message: 'بيانات الموظف وتقييم الأداء مطلوبة',
      });
    }

    const promotionSuggestion = hrIntegration.suggestPromotions(employeeData, performanceRating);

    res.status(201).json({
      success: true,
      message: 'تم اقتراح الترقية',
      data: promotionSuggestion,
    });

    logger.info(`اقتراح ترقية للموظف ${employeeData.employeeId} بواسطة ${req.user.id}`);
  } catch (error) {
    logger.error('خطأ في اقتراح الترقية:', error.message);
    res.status(500).json({
      success: false,
      message: 'خطأ في اقتراح الترقية',
      error: error.message,
    });
  }
});

/**
 * GET /api/hr/promotion-candidates
 * الحصول على قائمة مرشحي الترقية
 */
router.get(
  '/promotion-candidates',
  validateJWT,
  validateRole(['admin', 'hr']),
  async (req, res) => {
    try {
      const candidates = Array.from(hrIntegration.talentAssessments.values()).filter(
        a => a.eligible
      );

      res.status(200).json({
        success: true,
        message: 'تم استرجاع مرشحي الترقية',
        data: {
          totalCandidates: candidates.length,
          candidates,
        },
      });

      logger.info(`استرجاع مرشحي الترقية بواسطة ${req.user.id}`);
    } catch (error) {
      logger.error('خطأ في استرجاع مرشحي الترقية:', error.message);
      res.status(500).json({
        success: false,
        message: 'خطأ في استرجاع مرشحي الترقية',
        error: error.message,
      });
    }
  }
);

/**
 * POST /api/hr/suggest-disciplinary-action
 * اقتراح إجراء تأديبي
 */
router.post(
  '/suggest-disciplinary-action',
  validateJWT,
  validateRole(['admin', 'hr', 'manager']),
  async (req, res) => {
    try {
      const { employeeData, performanceRating, attendanceHistory } = req.body;

      if (!employeeData || !performanceRating) {
        return res.status(400).json({
          success: false,
          message: 'بيانات الموظف وتقييم الأداء مطلوبة',
        });
      }

      const actionSuggestion = hrIntegration.suggestDisciplinaryAction(
        employeeData,
        performanceRating,
        attendanceHistory || {}
      );

      res.status(201).json({
        success: true,
        message: 'تم اقتراح الإجراء التأديبي',
        data: actionSuggestion,
      });

      logger.info(`اقتراح إجراء تأديبي للموظف ${employeeData.employeeId} بواسطة ${req.user.id}`);
    } catch (error) {
      logger.error('خطأ في اقتراح الإجراء التأديبي:', error.message);
      res.status(500).json({
        success: false,
        message: 'خطأ في اقتراح الإجراء التأديبي',
        error: error.message,
      });
    }
  }
);

/**
 * GET /api/hr/disciplinary-actions
 * الحصول على الإجراءات التأديبية
 */
router.get(
  '/disciplinary-actions',
  validateJWT,
  validateRole(['admin', 'hr']),
  async (req, res) => {
    try {
      const actions = Array.from(hrIntegration.disciplinaryActions.values()).filter(
        a => a.recommended?.level !== 'none'
      );

      const grouped = {
        warnings: actions.filter(a => a.recommended.level === 'warning'),
        formal_warnings: actions.filter(a => a.recommended.level === 'formal_warning'),
        suspensions: actions.filter(a => a.recommended.level === 'suspension'),
        terminations: actions.filter(a => a.recommended.level === 'termination'),
      };

      res.status(200).json({
        success: true,
        message: 'تم استرجاع الإجراءات التأديبية',
        data: {
          total: actions.length,
          breakdown: {
            warnings: grouped.warnings.length,
            formal_warnings: grouped.formal_warnings.length,
            suspensions: grouped.suspensions.length,
            terminations: grouped.terminations.length,
          },
          actions: grouped,
        },
      });

      logger.info(`استرجاع الإجراءات التأديبية بواسطة ${req.user.id}`);
    } catch (error) {
      logger.error('خطأ في استرجاع الإجراءات:', error.message);
      res.status(500).json({
        success: false,
        message: 'خطأ في استرجاع الإجراءات',
        error: error.message,
      });
    }
  }
);

/**
 * POST /api/hr/generate-talent-report
 * توليد تقرير المواهب
 */
router.post(
  '/generate-talent-report',
  validateJWT,
  validateRole(['admin', 'hr']),
  async (req, res) => {
    try {
      const { departmentData } = req.body;

      if (!departmentData) {
        return res.status(400).json({
          success: false,
          message: 'بيانات القسم مطلوبة',
        });
      }

      const talentReport = hrIntegration.generateTalentReport(departmentData);

      res.status(201).json({
        success: true,
        message: 'تم توليد تقرير المواهب',
        data: talentReport,
      });

      logger.info(
        `توليد تقرير المواهب للقسم ${departmentData.departmentName} بواسطة ${req.user.id}`
      );
    } catch (error) {
      logger.error('خطأ في توليد تقرير المواهب:', error.message);
      res.status(500).json({
        success: false,
        message: 'خطأ في توليد تقرير المواهب',
        error: error.message,
      });
    }
  }
);

/**
 * GET /api/hr/summary
 * ملخص الموارد البشرية
 */
router.get('/summary', validateJWT, validateRole(['admin', 'hr']), async (req, res) => {
  try {
    const summary = hrIntegration.getHRSummary();

    if (!summary) {
      return res.status(404).json({
        success: false,
        message: 'لا توجد بيانات كافية',
      });
    }

    res.status(200).json({
      success: true,
      message: 'تم استرجاع الملخص',
      data: summary,
    });

    logger.info(`استرجاع ملخص الموارد البشرية بواسطة ${req.user.id}`);
  } catch (error) {
    logger.error('خطأ في استرجاع الملخص:', error.message);
    res.status(500).json({
      success: false,
      message: 'خطأ في استرجاع الملخص',
      error: error.message,
    });
  }
});

/**
 * POST /api/hr/update-employee-file
 * تحديث ملف الموظف
 */
router.post(
  '/update-employee-file',
  validateJWT,
  validateRole(['admin', 'hr']),
  async (req, res) => {
    try {
      const { employeeId, updateData } = req.body;

      if (!employeeId) {
        return res.status(400).json({
          success: false,
          message: 'معرف الموظف مطلوب',
        });
      }

      const updatedFile = hrIntegration.updateEmployeeFile(employeeId, updateData || {});

      res.status(200).json({
        success: true,
        message: 'تم تحديث ملف الموظف',
        data: updatedFile,
      });

      logger.info(`تحديث ملف الموظف ${employeeId} بواسطة ${req.user.id}`);
    } catch (error) {
      logger.error('خطأ في تحديث ملف الموظف:', error.message);
      res.status(500).json({
        success: false,
        message: 'خطأ في تحديث ملف الموظف',
        error: error.message,
      });
    }
  }
);

/**
 * GET /api/hr/health
 * فحص صحة الخدمة
 */
router.get('/health', (req, res) => {
  res.status(200).json({
    success: true,
    message: 'خدمة الموارد البشرية تعمل بشكل سليم',
    timestamp: new Date().toISOString(),
  });
});

module.exports = router;
