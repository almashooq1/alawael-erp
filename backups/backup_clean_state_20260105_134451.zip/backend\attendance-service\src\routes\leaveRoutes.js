/**
 * leaveRoutes.js
 * المسارات والـ API endpoints لنظام إدارة الإجازات
 */

const express = require('express');
const router = express.Router();
const LeaveManagementSystem = require('../../LeaveManagementSystem');
const LeaveRequest = require('./models/LeaveRequest');
const unifiedAuth = require('../../../../shared/auth/unified-auth');
const authenticate = unifiedAuth.authenticate();
const authorize = (...roles) => unifiedAuth.authorize(...roles);
const { validate } = require('../middleware/validation');

// تهيئة نظام الإجازات
const leaveSystem = new LeaveManagementSystem();

// ============================================
// 🎫 طلبات الإجازة - Employee Routes
// ============================================

/**
 * POST /api/leave/request
 * تقديم طلب إجازة جديد
 */
router.post('/request', authenticate, validate('leaveRequest'), async (req, res) => {
  try {
    const { type, startDate, endDate, reason, attachments } = req.body;
    const userId = req.user.id;

    const result = await leaveSystem.requestLeave(userId, {
      type,
      startDate,
      endDate,
      reason,
      attachments,
    });

    if (result.success) {
      res.status(201).json({
        success: true,
        message: result.message,
        data: {
          requestId: result.requestId,
          status: result.status,
        },
      });
    } else {
      res.status(400).json({
        success: false,
        message: result.message,
        balance: result.balance,
      });
    }
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'فشل تقديم الطلب',
      error: error.message,
    });
  }
});

/**
 * GET /api/leave/requests
 * الحصول على طلبات الإجازة للموظف الحالي
 */
router.get('/requests', authenticate, async (req, res) => {
  try {
    const { status } = req.query;
    const userId = req.user.id;

    const requests = leaveSystem.getEmployeeRequests(userId, status);

    res.json({
      success: true,
      data: requests,
      count: requests.length,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'فشل الحصول على الطلبات',
      error: error.message,
    });
  }
});

/**
 * GET /api/leave/balance
 * الحصول على رصيد الإجازة الحالي
 */
router.get('/balance', authenticate, async (req, res) => {
  try {
    const userId = req.user.id;
    const balances = await leaveSystem.getBalance(userId);

    res.json({
      success: true,
      data: balances,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'فشل الحصول على الرصيد',
      error: error.message,
    });
  }
});

/**
 * GET /api/leave/statistics
 * الحصول على إحصائيات الإجازات
 */
router.get('/statistics', authenticate, async (req, res) => {
  try {
    const userId = req.user.id;
    const stats = await leaveSystem.getLeaveStatistics(userId);

    res.json({
      success: true,
      data: stats,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'فشل الحصول على الإحصائيات',
      error: error.message,
    });
  }
});

/**
 * GET /api/leave/request/:requestId
 * الحصول على تفاصيل طلب إجازة محدد
 */
router.get('/request/:requestId', authenticate, async (req, res) => {
  try {
    const { requestId } = req.params;
    const request = leaveSystem.getRequest(requestId);

    if (!request) {
      return res.status(404).json({
        success: false,
        message: 'الطلب غير موجود',
      });
    }

    // التحقق من صلاحية الوصول
    if (request.userId !== req.user.id && req.user.role !== 'manager' && req.user.role !== 'hr') {
      return res.status(403).json({
        success: false,
        message: 'ليس لديك صلاحية للوصول لهذا الطلب',
      });
    }

    res.json({
      success: true,
      data: request,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'فشل الحصول على الطلب',
      error: error.message,
    });
  }
});

/**
 * PUT /api/leave/request/:requestId/cancel
 * إلغاء طلب إجازة
 */
router.put('/request/:requestId/cancel', authenticate, async (req, res) => {
  try {
    const { requestId } = req.params;
    const { reason } = req.body;
    const userId = req.user.id;

    const request = leaveSystem.getRequest(requestId);

    if (!request) {
      return res.status(404).json({
        success: false,
        message: 'الطلب غير موجود',
      });
    }

    if (request.userId !== userId) {
      return res.status(403).json({
        success: false,
        message: 'لا يمكنك إلغاء طلب موظف آخر',
      });
    }

    if (request.status === 'APPROVED') {
      return res.status(400).json({
        success: false,
        message: 'لا يمكن إلغاء طلب موافق عليه',
      });
    }

    request.status = 'CANCELLED';
    request.history.push({
      action: 'CANCELLED',
      timestamp: new Date(),
      by: userId,
      comment: reason,
    });

    res.json({
      success: true,
      message: 'تم إلغاء الطلب',
      data: request,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'فشل إلغاء الطلب',
      error: error.message,
    });
  }
});

// ============================================
// ✅ الموافقة على الطلبات - Manager/HR Routes
// ============================================

/**
 * GET /api/leave/pending
 * الحصول على الطلبات المعلقة (للمديرين و HR)
 */
router.get('/pending', authenticate, authorize(['manager', 'hr', 'admin']), async (req, res) => {
  try {
    const { department } = req.query;
    const managerId = req.user.role === 'manager' ? req.user.id : null;

    const pendingRequests = leaveSystem.getPendingRequests(managerId);

    res.json({
      success: true,
      data: pendingRequests,
      count: pendingRequests.length,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'فشل الحصول على الطلبات المعلقة',
      error: error.message,
    });
  }
});

/**
 * POST /api/leave/request/:requestId/approve
 * الموافقة على طلب إجازة
 */
router.post(
  '/request/:requestId/approve',
  authenticate,
  authorize(['manager', 'hr', 'admin']),
  validate('approveLeave'),
  async (req, res) => {
    try {
      const { requestId } = req.params;
      const { comment } = req.body;
      const approverId = req.user.id;

      const result = await leaveSystem.approveLeave(requestId, approverId, comment);

      if (result.success) {
        res.json({
          success: true,
          message: result.message,
          data: result.request,
        });
      } else {
        res.status(400).json({
          success: false,
          message: result.message,
        });
      }
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'فشل الموافقة على الطلب',
        error: error.message,
      });
    }
  }
);

/**
 * POST /api/leave/request/:requestId/reject
 * رفض طلب إجازة
 */
router.post(
  '/request/:requestId/reject',
  authenticate,
  authorize(['manager', 'hr', 'admin']),
  validate('rejectLeave'),
  async (req, res) => {
    try {
      const { requestId } = req.params;
      const { reason } = req.body;
      const rejecterId = req.user.id;

      const result = await leaveSystem.rejectLeave(requestId, rejecterId, reason);

      if (result.success) {
        res.json({
          success: true,
          message: result.message,
          data: result.request,
        });
      } else {
        res.status(400).json({
          success: false,
          message: result.message,
        });
      }
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'فشل رفض الطلب',
        error: error.message,
      });
    }
  }
);

// ============================================
// 📊 التقارير والإحصائيات - Admin Routes
// ============================================

/**
 * GET /api/leave/reports/department
 * تقرير الإجازات حسب القسم
 */
router.get('/reports/department', authenticate, authorize(['hr', 'admin']), async (req, res) => {
  try {
    const { department, month } = req.query;

    // يجب تنفيذ هذا مع قاعدة البيانات
    const report = await LeaveRequest.aggregate([
      {
        $match: {
          status: 'APPROVED',
          ...(department && { department }),
        },
      },
      {
        $group: {
          _id: '$leaveType',
          totalDays: { $sum: '$duration.value' },
          employeeCount: { $sum: 1 },
        },
      },
    ]);

    res.json({
      success: true,
      data: report,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'فشل الحصول على التقرير',
      error: error.message,
    });
  }
});

/**
 * GET /api/leave/reports/employee/:employeeId
 * تقرير الإجازات للموظف
 */
router.get(
  '/reports/employee/:employeeId',
  authenticate,
  authorize(['manager', 'hr', 'admin']),
  async (req, res) => {
    try {
      const { employeeId } = req.params;

      const stats = await LeaveRequest.getEmployeeStatistics(employeeId);

      res.json({
        success: true,
        data: stats,
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'فشل الحصول على التقرير',
        error: error.message,
      });
    }
  }
);

/**
 * GET /api/leave/reports/compliance
 * تقرير الامتثال
 */
router.get('/reports/compliance', authenticate, authorize(['hr', 'admin']), async (req, res) => {
  try {
    const { startDate, endDate } = req.query;

    // يجب تنفيذ هذا مع قاعدة البيانات
    const report = {
      totalRequests: 0,
      approvedRequests: 0,
      rejectedRequests: 0,
      pendingRequests: 0,
      approvalRate: 0,
      averageApprovalTime: 0,
    };

    res.json({
      success: true,
      data: report,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'فشل الحصول على التقرير',
      error: error.message,
    });
  }
});

// ============================================
// ⚙️ الإدارة - Admin Only Routes
// ============================================

/**
 * POST /api/leave/config/update
 * تحديث إعدادات الإجازات
 */
router.post('/config/update', authenticate, authorize(['admin']), async (req, res) => {
  try {
    const { leaveType, config } = req.body;

    if (leaveSystem.leaveTypes[leaveType]) {
      Object.assign(leaveSystem.leaveTypes[leaveType], config);

      res.json({
        success: true,
        message: 'تم تحديث الإعدادات',
        data: leaveSystem.leaveTypes[leaveType],
      });
    } else {
      res.status(400).json({
        success: false,
        message: 'نوع الإجازة غير موجود',
      });
    }
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'فشل تحديث الإعدادات',
      error: error.message,
    });
  }
});

/**
 * GET /api/leave/config
 * الحصول على إعدادات الإجازات
 */
router.get('/config', authenticate, authorize(['admin', 'hr']), async (req, res) => {
  try {
    res.json({
      success: true,
      data: leaveSystem.leaveTypes,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'فشل الحصول على الإعدادات',
      error: error.message,
    });
  }
});

// ============================================
// 🔄 صحة النظام والمراقبة
// ============================================

/**
 * GET /api/leave/health
 * فحص صحة نظام الإجازات
 */
router.get('/health', async (req, res) => {
  try {
    const health = {
      status: 'healthy',
      timestamp: new Date(),
      uptime: process.uptime(),
      requests: leaveSystem.requests.size,
      alertsActive: 0,
    };

    res.json({
      success: true,
      data: health,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'فشل فحص الصحة',
      error: error.message,
    });
  }
});

module.exports = router;
