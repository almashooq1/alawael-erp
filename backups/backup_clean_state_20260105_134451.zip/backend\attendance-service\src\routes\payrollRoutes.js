/**
 * payrollRoutes.js
 * مسارات API لتكامل الرواتب
 */

const express = require('express');
const router = express.Router();
const unifiedAuth = require('../../../../shared/auth/unified-auth');
const validateJWT = unifiedAuth.authenticate();
const validateRole = (...roles) => unifiedAuth.authorize(...roles);
const Logger = require('../utils/Logger');
const AttendancePayrollIntegration = require('../AttendancePayrollIntegration');

const logger = new Logger('payrollRoutes');
const payrollIntegration = new AttendancePayrollIntegration();

/**
 * POST /api/payroll/calculate-deductions
 * حساب الخصومات للموظف بناءً على بيانات الحضور
 */
router.post(
  '/calculate-deductions',
  validateJWT,
  validateRole(['admin', 'hr', 'finance']),
  async (req, res) => {
    try {
      const { employeeId, absenceRecords, lateRecords, salary, month } = req.body;

      if (!employeeId || !salary) {
        return res.status(400).json({
          success: false,
          message: 'معرف الموظف والراتب مطلوبان',
          errors: ['employeeId', 'salary'],
        });
      }

      // حساب الخصومات
      const monthlyImpact = payrollIntegration.calculateMonthlyImpact(employeeId, {
        absenceRecords: absenceRecords || [],
        lateRecords: lateRecords || [],
        salary,
        bonus: req.body.bonus || 0,
        attendanceAnalysis: req.body.attendanceAnalysis || {},
        month: month || new Date().toLocaleDateString('ar-SA'),
      });

      // إنشاء تنبيه إن لزم الأمر
      const alert = payrollIntegration.createDeductionAlert(employeeId, monthlyImpact);

      res.status(200).json({
        success: true,
        message: 'تم حساب الخصومات بنجاح',
        data: {
          ...monthlyImpact,
          alert: alert || null,
        },
      });

      logger.info(`حساب الخصومات للموظف ${employeeId} بواسطة ${req.user.id}`);
    } catch (error) {
      logger.error('خطأ في حساب الخصومات:', error.message);
      res.status(500).json({
        success: false,
        message: 'خطأ في حساب الخصومات',
        error: error.message,
      });
    }
  }
);

/**
 * GET /api/payroll/payslip/:employeeId/:month
 * الحصول على قسيمة الراتب
 */
router.get(
  '/payslip/:employeeId/:month',
  validateJWT,
  validateRole(['admin', 'hr', 'finance', 'employee']),
  async (req, res) => {
    try {
      const { employeeId, month } = req.params;

      // التحقق من الصلاحيات
      if (req.user.role === 'employee' && req.user.id !== employeeId) {
        return res.status(403).json({
          success: false,
          message: 'لا يمكنك الوصول لقسيمة راتب موظف آخر',
        });
      }

      const payslipRecord = payrollIntegration.getMonthlyPayrollRecord(employeeId, month);

      if (!payslipRecord) {
        return res.status(404).json({
          success: false,
          message: 'لم يتم العثور على قسيمة الراتب',
        });
      }

      res.status(200).json({
        success: true,
        message: 'تم استرجاع قسيمة الراتب',
        data: payslipRecord,
      });

      logger.info(`استرجاع قسيمة الراتب للموظف ${employeeId} بواسطة ${req.user.id}`);
    } catch (error) {
      logger.error('خطأ في استرجاع قسيمة الراتب:', error.message);
      res.status(500).json({
        success: false,
        message: 'خطأ في استرجاع قسيمة الراتب',
        error: error.message,
      });
    }
  }
);

/**
 * POST /api/payroll/generate-payslip
 * توليد قسيمة الراتب الشاملة
 */
router.post(
  '/generate-payslip',
  validateJWT,
  validateRole(['admin', 'hr', 'finance']),
  async (req, res) => {
    try {
      const { employeeData, monthlyImpact } = req.body;

      if (!employeeData || !monthlyImpact) {
        return res.status(400).json({
          success: false,
          message: 'بيانات الموظف والتأثير الشهري مطلوبة',
        });
      }

      const payslipReport = payrollIntegration.generatePayslipReport(employeeData, monthlyImpact);

      res.status(201).json({
        success: true,
        message: 'تم توليد قسيمة الراتب بنجاح',
        data: payslipReport,
      });

      logger.info(`توليد قسيمة راتب للموظف ${employeeData.employeeId} بواسطة ${req.user.id}`);
    } catch (error) {
      logger.error('خطأ في توليد قسيمة الراتب:', error.message);
      res.status(500).json({
        success: false,
        message: 'خطأ في توليد قسيمة الراتب',
        error: error.message,
      });
    }
  }
);

/**
 * GET /api/payroll/history/:employeeId
 * الحصول على السجل الخصومات للموظف
 */
router.get(
  '/history/:employeeId',
  validateJWT,
  validateRole(['admin', 'hr', 'finance', 'employee']),
  async (req, res) => {
    try {
      const { employeeId } = req.params;
      const months = parseInt(req.query.months) || 12;

      // التحقق من الصلاحيات
      if (req.user.role === 'employee' && req.user.id !== employeeId) {
        return res.status(403).json({
          success: false,
          message: 'لا يمكنك الوصول لسجل خصومات موظف آخر',
        });
      }

      const history = payrollIntegration.getDeductionHistory(employeeId, months);

      res.status(200).json({
        success: true,
        message: 'تم استرجاع السجل',
        data: {
          employeeId,
          months,
          records: history,
          totalRecords: history.length,
        },
      });

      logger.info(`استرجاع سجل الخصومات للموظف ${employeeId} بواسطة ${req.user.id}`);
    } catch (error) {
      logger.error('خطأ في استرجاع السجل:', error.message);
      res.status(500).json({
        success: false,
        message: 'خطأ في استرجاع السجل',
        error: error.message,
      });
    }
  }
);

/**
 * GET /api/payroll/trends/:employeeId
 * تحليل الاتجاهات المالية
 */
router.get(
  '/trends/:employeeId',
  validateJWT,
  validateRole(['admin', 'hr', 'finance', 'employee']),
  async (req, res) => {
    try {
      const { employeeId } = req.params;
      const months = parseInt(req.query.months) || 6;

      // التحقق من الصلاحيات
      if (req.user.role === 'employee' && req.user.id !== employeeId) {
        return res.status(403).json({
          success: false,
          message: 'لا يمكنك الوصول لتحليل موظف آخر',
        });
      }

      const trends = payrollIntegration.analyzePaidTrends(employeeId, months);

      if (!trends) {
        return res.status(404).json({
          success: false,
          message: 'لا توجد بيانات كافية للتحليل',
        });
      }

      res.status(200).json({
        success: true,
        message: 'تم استرجاع التحليل',
        data: trends,
      });

      logger.info(`استرجاع اتجاهات الرواتب للموظف ${employeeId} بواسطة ${req.user.id}`);
    } catch (error) {
      logger.error('خطأ في تحليل الاتجاهات:', error.message);
      res.status(500).json({
        success: false,
        message: 'خطأ في تحليل الاتجاهات',
        error: error.message,
      });
    }
  }
);

/**
 * GET /api/payroll/health
 * فحص صحة الخدمة
 */
router.get('/health', (req, res) => {
  res.status(200).json({
    success: true,
    message: 'خدمة الرواتب تعمل بشكل سليم',
    timestamp: new Date().toISOString(),
  });
});

module.exports = router;
