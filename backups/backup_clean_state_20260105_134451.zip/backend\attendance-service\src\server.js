/**
 * @file Attendance Service Server
 * Main entry for the attendance microservice using Fastify.
 * ---------------------------------------------------------
 * Handles attendance tracking, sessions, metrics, and event publishing for attendance events.
 * All endpoints are documented inline. Strict mode is enforced for reliability.
 *
 * @example
 * // Start the server (from CLI)
 * $ node backend/attendance-service/src/server.js
 *
 * @example
 * // Import and use in another module
 * const { createServer } = require('./server');
 * const fastify = createServer();
 * if (process.env.NODE_ENV !== 'test') {
  fastify.listen({ port: 3001 });
   *
   * @see {@link https://www.fastify.io/docs/latest/ Fastify Documentation}
   * @see {@link https://github.com/almashooq1/66666 Project Repository}
   *
   * @section Main Variables
   * @property {Logger} logger - Main logger instance for service logging.
   * @property {EventBus} bus - Event bus for publishing and subscribing to attendance events.
   * @property {AttendanceRepo} repo - Repository for attendance data operations.
   * @property {Outbox} outbox - Outbox pattern for reliable event publishing.
   *
   * @section Service Endpoints
   * - /metrics: Expose Prometheus metrics for attendance events.
   * - /health, /ready: Service health and readiness checks.
   * - /event-bus/health: Event bus health check.
   * // ... باقي نقاط النهاية موثقة ضمن الكود الداخلي
   *
   * @section Security
   * - Security headers and rate limiting applied to sensitive endpoints.
   * - Error handler attached for robust error reporting.
   *
   * @section Notes
   * - All endpoints are documented inline with JSDoc.
   * - Strict mode is enforced for reliability and best practices.
   * - For more details, see inline documentation for each function and endpoint.
   */
}
const Fastify = require('fastify');
// Security Middleware
const helmetConfig = require('../../shared/middleware/security/helmet-config');
const corsConfig = require('../../shared/middleware/security/cors-config');
const { apiLimiter } = require('../../shared/middleware/security/rate-limiter');
const securityHeaders = require('../../shared/middleware/security/security-headers');


const { sanitizeInputs, trackRequest, errorHandler } = require('../../shared/middleware/security-middleware-fastify');
const { initObservability } = require('../../shared/observability.js');
const { initEnv } = require('../../shared/env.js');
const { createLogger } = require('../../shared/logging/index.js');
const { v4: uuidv4 } = require('uuid');
// const { fileURLToPath } = require('url');
const { EventBus } = require('../../shared/event-bus/index.js');
const { createEnvelope, withMeta } = require('../../shared/events/index.js');
const { initTracing, withSpan } = require('../../shared/otel/index.js');
const { Outbox, startPeriodicFlush } = require('../../shared/outbox/index.js');
const { auditLog } = require('../../shared/security/audit.js');
const { createAttendanceRepo } = require('./repo.js');
const { getCounter } = require('../../shared/metrics/index.js');
const { createRequire } = require('module');
const { applySecurityHeaders, makeRouteRateLimiter } = require('../../shared/http/security.js');
const { attachErrorHandler } = require('../../shared/http/errors.js');
const { buildHealthHandler } = require('../../shared/http/health.js');
const { buildReadyHandler } = require('../../shared/http/ready.js');

function cryptoRandomId() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

// Initialize environment and observability once at startup
initEnv();
initObservability();
const logger = createLogger();
initTracing({ serviceName: 'attendance-service' });
export function createServer() {
  const fastify = Fastify({ logger });
  // Request context enrichment (requestId + userId)
  fastify.addHook('onRequest', async (req) => {
    req.requestId = req.headers['x-request-id'] || cryptoRandomId();
    req.userId = req.headers['x-user-id'] || 'anonymous';
  });

  const bus = new EventBus({ logger });
  const repo = createAttendanceRepo({ logger });
  const outbox = new Outbox({ logger, bus, serviceName: 'attendance-service' });
  startPeriodicFlush(outbox, process.env.OUTBOX_INTERVAL_MS || 0);
  // Inline metrics registration with duplicate guard (avoid double registration in tests / hot-reload)
  if (process.env.METRICS_ENABLED === 'true') {
    try {
      const requireCJS =
        typeof __filename !== 'undefined' ? createRequire(__filename) : createRequire(process.cwd() + '/dummy.js');

      const prom = (globalThis.__promClient ||= requireCJS('prom-client'));
      if (process.env.METRICS_DEFAULTS === 'true') {
        prom.collectDefaultMetrics({ prefix: process.env.METRICS_PREFIX || '' });
      }
      const httpReqCounter =
        prom.register.getSingleMetric?.('service_http_requests_total') ||
        new prom.Counter({
          name: 'service_http_requests_total',
          help: 'Total HTTP requests',
          labelNames: ['service', 'method', 'route', 'status']
        });
      fastify.addHook('onResponse', (req, reply, done) => {
        try {
          const route = (req.routeOptions && req.routeOptions.url) || req.url || 'unknown';
          httpReqCounter.inc({
            service: 'attendance-service',
            method: req.method,
            route,
            status: String(reply.statusCode)
          });
        } catch {}
        done();
      });
      fastify.get('/metrics', async (_req, reply) => {
        try {
          reply.header('Content-Type', prom.register.contentType);
          reply.send(await prom.register.metrics());
        } catch (err) {
          reply.code(500).send({ error: 'metrics_error', details: String(err) });
        }
      });
    } catch (err) {
      fastify.log.warn({ err: String(err) }, 'metrics-registration-failed');
    }
  }
  fastify.get('/event-bus/health', async () => bus.getHealth());

  async function stageEvent(event) {
    await outbox.enqueue({ topic: 'attendance.events', event });
  }

  // Standardized health endpoint
  fastify.get('/health', buildHealthHandler({ serviceName: 'attendance-service' }));
  // Readiness endpoint with basic component checks
  fastify.get(
    '/ready',
    buildReadyHandler({
      serviceName: 'attendance-service',
      checks: [
        { name: 'env.NODE_ENV', check: () => !!process.env.NODE_ENV },
        { name: 'env.METRICS_ENABLED', check: () => process.env.METRICS_ENABLED === 'true' },
        {
          name: 'outbox.memQueue',
          check: () => ({
            ok: outbox._mem.length < 10000,
            details: { pending: outbox._mem.length }
          })
        },
        {
          name: 'attendance.backlog.simulated',
          check: () => {
            const backlog = Number.parseInt(process.env.ATTENDANCE_BACKLOG_SIZE || '0', 10);
            const ok = Number.isFinite(backlog) ? backlog < 5000 : true;
            return { ok, details: { backlog: Number.isFinite(backlog) ? backlog : 0 } };
          }
        },
        {
          name: 'forcedFail',
          check: () => ({
            ok: process.env.ATTENDANCE_FORCE_FAIL === 'true' ? false : true,
            details: { flag: process.env.ATTENDANCE_FORCE_FAIL === 'true' }
          })
        }
      ]
    })
  );

  // Security headers & basic rate limit for debug endpoint
  applySecurityHeaders(fastify);
  const debugRateLimit = makeRouteRateLimiter({ windowMs: 60000, max: 20 });
  attachErrorHandler(fastify);

  // Metrics counters
  const attendanceCreatedCounter = getCounter('attendance_created_total', {
    description: 'Total attendance records created'
  });

  fastify.get('/attendance', async (request) =>
    withSpan('list_attendance', async () => {
      const { patientId, status } = request.query;
      const items = await repo.list({ patientId, status });
      return items;
    })
  );

  fastify.post(
    '/attendance',
    {
      preHandler: debugRateLimit,
      schema: {
        body: {
          type: 'object',
          required: ['patientId', 'therapistId'],
          properties: {
            id: { type: 'string' },
            patientId: { type: 'string', minLength: 1 },
            therapistId: { type: 'string', minLength: 1 },
            scheduledSessionId: { type: ['string', 'null'] },
            status: { type: 'string', enum: ['PRESENT', 'ABSENT', 'LATE'] },
            checkInAt: { type: 'string' },
            checkOutAt: { type: ['string', 'null'] },
            branchId: { type: ['string', 'null'] },
            tags: { type: 'array', items: { type: 'string' } }
          },
          additionalProperties: false
        },
        response: {
          201: {
            type: 'object',
            properties: { id: { type: 'string' } },
            required: ['id']
          }
        }
      }
    },
    async (request, _reply) =>
      withSpan('create_attendance', async () => {
        const body = request.body || {};
        const id = body.id || uuidv4();
        const record = {
          id,
          patientId: body.patientId,
          therapistId: body.therapistId,
          scheduledSessionId: body.scheduledSessionId || null,
          status: body.status || 'PRESENT',
          checkInAt: body.checkInAt || new Date().toISOString(),
          checkOutAt: body.checkOutAt || null,
          branchId: body.branchId || null,
          tags: body.tags || []
        };
        await repo.create(record);
        attendanceCreatedCounter.add(1, { service: 'attendance-service' });

        stageEvent(
          createEnvelope({
            type: 'ATTENDANCE_RECORDED',
            source: 'attendance-service',
            payload: withMeta(record, {
              requestId: request.requestId,
              userId: request.userId
            })
          })
        );
        auditLog(logger, {
          action: 'create_attendance',
          route: '/attendance',
          resourceId: id,
          userId: request.userId,
          details: { requestId: request.requestId }
        });
        _reply.code(201);
        return { id };
      })
  );

  fastify.get('/attendance/:id', async (request, reply) => {
    const { id } = request.params;
    const rec = await repo.getById(id);
    if (!rec) {
      return reply.code(404).send({ error: 'Not Found' });
    }
    return rec;
  });

  // Test-only flush helper (excluded in production)
  if (process.env.NODE_ENV !== 'production') {
    fastify.post(
      '/debug/outbox/flush',
      {
        preHandler: debugRateLimit,
        schema: {
          querystring: {
            type: 'object',
            properties: { limit: { type: 'integer', minimum: 1, maximum: 1000 } },
            additionalProperties: false
          }
        }
      },
      async (request, reply) => {
        let limit = Number.parseInt(request.query?.limit ?? '100', 10);
        if (!Number.isInteger(limit)) {
          limit = 100;
        }
        if (limit < 1 || limit > 1000) {
          return reply.code(400).send({ error: 'limit must be an integer between 1 and 1000' });
        }
        const flushed = await outbox.flushBatch(limit);
        return { flushed };
      }
    );
  }

  // Test-only debug helpers; disabled in production builds
  if (process.env.NODE_ENV !== 'production') {
    // Debug helper to enqueue synthetic outbox events without touching the database
    fastify.post(
      '/debug/outbox/enqueue',
      {
        preHandler: debugRateLimit,
        schema: {
          body: {
            type: 'object',
            properties: { count: { type: 'integer', minimum: 1, maximum: 1000 } },
            additionalProperties: false
          }
        }
      },
      async (request, reply) => {
        const count = Math.min(Math.max(Number(request.body?.count ?? 1), 1), 1000);
        const now = new Date().toISOString();
        for (let i = 0; i < count; i++) {
          await stageEvent(
            createEnvelope({
              type: 'ATTENDANCE_RECORDED',
              source: 'attendance-service',
              payload: withMeta(
                {
                  id: cryptoRandomId(),
                  at: now
                },
                { userId: 'debug' }
              )
            })
          );
        }
        return reply.code(202).send({ enqueued: count });
      }
    );

    // Debug helper to directly simulate publish latency histogram observations
    fastify.post(
      '/debug/metrics/simulate-publish',
      {
        preHandler: debugRateLimit,
        schema: {
          body: {
            type: 'object',
            properties: {
              count: { type: 'integer', minimum: 1, maximum: 10000 },
              valueSeconds: { type: 'number', minimum: 0 }
            },
            additionalProperties: false
          }
        }
      },
      async (request, reply) => {
        try {
          const requireCJS = createRequire(__filename);

          const prom = (globalThis.__promClient ||= requireCJS('prom-client'));
          const hist = prom.register.getSingleMetric('outbox_publish_latency_seconds');
          if (!hist) {
            return reply.code(500).send({ error: 'histogram_not_found' });
          }
          const count = Math.min(Math.max(Number(request.body?.count ?? 5), 1), 10000);
          const val = Number.isFinite(request.body?.valueSeconds) ? Number(request.body.valueSeconds) : 0.02; // 20ms fits mid-bucket
          for (let i = 0; i < count; i++) {
            hist.observe({ service: 'attendance-service', topic: 'debug', outcome: 'success' }, val);
          }
          return reply.code(202).send({ observed: count, valueSeconds: val });
        } catch (err) {
          return reply.code(500).send({ error: 'simulate_failed', details: String(err) });
        }
      }
    );
  }

  return fastify;
}

const isMain = process.argv[1] === __filename;
if (isMain) {
  const fastify = createServer();
  const port = Number(process.env.PORT || 3001);
  fastify
    .listen({ port, host: '0.0.0.0' })
    .then(() => logger.info(`attendance-service listening on ${port}`))
    .catch((err) => {
      logger.error(err, 'server failed to start');
      process.exit(1);
    });
}

// Error Handling
const { errorHandler, notFoundHandler } = require('../../shared/middleware/error-handler');


// 404 handler (must be after all routes)

// API Documentation
const { swaggerSetup } = require('../../shared/docs/swagger-config');
swaggerSetup(app);

app.use(notFoundHandler);

// Error handler (must be last)
app.use(errorHandler);
