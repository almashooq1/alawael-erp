import { expect } from 'chai';
import { toDb, fromDb } from '../src/repo.js';

describe('Attendance Service - repo', function () {
  it('should convert a record to DB format', function () {
    const record = {
      id: 1,
      patientId: 'p1',
      therapistId: 't1',
      scheduledSessionId: 's1',
      status: 'checked-in',
      checkInAt: '2025-11-27T10:00:00Z',
      checkOutAt: '2025-11-27T11:00:00Z',
      branchId: 'b1',
      tags: ['urgent', 'morning'],
    };
    const db = toDb(record);
    expect(db.patient_id).to.equal('p1');
    expect(db.therapist_id).to.equal('t1');
    expect(db.tags).to.equal(JSON.stringify(['urgent', 'morning']));
    expect(db.status).to.equal('checked-in');
  });

  it('should convert DB row to record format', function () {
    const row = {
      id: 1,
      patient_id: 'p1',
      therapist_id: 't1',
      scheduled_session_id: 's1',
      status: 'checked-in',
      check_in_at: '2025-11-27T10:00:00Z',
      check_out_at: '2025-11-27T11:00:00Z',
      branch_id: 'b1',
      tags: JSON.stringify(['urgent', 'morning']),
    };
    const rec = fromDb(row);
    expect(rec.patientId).to.equal('p1');
    expect(rec.therapistId).to.equal('t1');
    expect(rec.tags).to.deep.equal(['urgent', 'morning']);
    expect(rec.status).to.equal('checked-in');
  });

  it('should handle invalid tags gracefully', function () {
    const row = { tags: 'not-a-json' };
    const rec = fromDb(row);
    expect(rec.tags).to.deep.equal([]);
  });
});
