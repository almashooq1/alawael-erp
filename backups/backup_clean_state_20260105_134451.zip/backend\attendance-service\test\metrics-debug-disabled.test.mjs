import { createServer } from '../src/server.js';
import { withMetricsServer } from '../../test-utils/withMetricsServer.js';

let helper;
let origNodeEnv;
beforeAll(async () => {
  process.env.METRICS_ENABLED = 'true';
  process.env.OTEL_ENABLED = 'false';
  // Ensure production so debug routes are not registered
  origNodeEnv = process.env.NODE_ENV;
  process.env.NODE_ENV = 'production';
  helper = withMetricsServer(createServer);
  await helper.waitForMetrics();
});
afterAll(async () => {
  await helper?.close();
  if (origNodeEnv !== undefined) {
    process.env.NODE_ENV = origNodeEnv;
  } else {
    delete process.env.NODE_ENV;
  }
});

describe('attendance debug endpoints disabled in production', () => {
  test('metrics still exposed but debug routes are 404', async () => {
    const m = await helper.get('/metrics');
    expect(m.statusCode).toBe(200);

    const sim = await helper.post('/debug/metrics/simulate-publish', {
      count: 1,
      valueSeconds: 0.01,
    });
    expect(sim.statusCode).toBe(404);

    const enq = await helper.post('/debug/outbox/enqueue', { count: 1 });
    expect(enq.statusCode).toBe(404);

    const flush = await helper.post('/debug/outbox/flush?limit=1');
    expect(flush.statusCode).toBe(404);
  });
});
