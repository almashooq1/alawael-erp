import { createServer } from '../src/server.js';
import { withMetricsServer } from '../../test-utils/withMetricsServer.js';
import { jest } from '@jest/globals';

jest.setTimeout(10000);

let helper;
beforeAll(async () => {
  // Explicitly disable metrics
  process.env.METRICS_ENABLED = 'false';
  process.env.OTEL_ENABLED = 'false';
  helper = withMetricsServer(createServer);
  // Fastify readiness only; metrics route should never appear
  await new Promise((resolve, reject) => helper.app.ready(err => (err ? reject(err) : resolve())));
});
afterAll(async () => {
  await helper?.close();
});

describe('metrics disabled', () => {
  test('GET /metrics returns 404 when METRICS_ENABLED != true', async () => {
    const res = await helper.get('/metrics');
    expect([404, 500]).toContain(res.statusCode); // 404 normally; 500 if unexpected error wrapper
    const body = res.body || '';
    expect(body).not.toContain('outbox_publish_latency_seconds_bucket');
    expect(body).not.toContain('outbox_pending_rows');
  });
});
