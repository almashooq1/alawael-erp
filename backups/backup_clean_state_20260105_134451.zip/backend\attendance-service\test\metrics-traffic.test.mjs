import { createServer } from '../src/server.js';
import { withMetricsServer } from '../../test-utils/withMetricsServer.js';

let helper;
beforeAll(async () => {
  process.env.METRICS_ENABLED = 'true';
  process.env.OTEL_ENABLED = 'false';
  // Disable DB to use in-memory outbox fallback
  process.env.DATABASE_URL = '';
  process.env.ATTENDANCE_DATABASE_URL = '';
  helper = withMetricsServer(createServer);
  await helper.waitForMetrics();
});
afterAll(async () => {
  await helper?.close();
});

function extractMetricLines(text, name) {
  return (text || '')
    .split(/\n/)
    .map(l => l.trim())
    .filter(l => l.startsWith(name + '{') || l.startsWith(name + ' '));
}
function parsePromLine(line) {
  // metric{a="b",c="d"} 123 or metric 123
  const m = line.match(/^(\w+)(?:\{([^}]*)\})?\s+([0-9.eE+-]+)$/);
  if (!m) {
    return null;
  }
  const labels = {};
  if (m[2]) {
    m[2].split(/,(?=(?:[^"\\]|\\.|"[^"]*")*$)/).forEach(kv => {
      const [k, v] = kv.split('=');
      if (k && v) {
        labels[k.trim()] = v.replace(/^"|"$/g, '').trim();
      }
    });
  }
  return { name: m[1], value: Number(m[3]), labels };
}
function findCount(body, service) {
  const lines = extractMetricLines(body, 'outbox_publish_latency_seconds_count');
  for (const l of lines) {
    const parsed = parsePromLine(l);
    if (!parsed) {
      continue;
    }
    const { labels, value } = parsed;
    if (labels.service === service && labels.topic === 'debug' && labels.outcome === 'success') {
      return value;
    }
  }
  return 0;
}
function hasNonZero(lines) {
  // Parse numeric values and ensure any value is strictly > 0, including decimals like 0.25
  return lines.some(l => {
    const parsed = parsePromLine(l);
    return parsed && Number.isFinite(parsed.value) && parsed.value > 0;
  });
}

describe('metrics traffic attendance', () => {
  test('publish latency histogram count increases after simulated events', async () => {
    // Directly simulate publish latency observations to avoid DB dependency
    const sim = await helper.post('/debug/metrics/simulate-publish', {
      count: 5,
      valueSeconds: 0.05,
    });
    expect(sim.statusCode).toBe(202);
    const m = await helper.get('/metrics');
    expect(m.statusCode).toBe(200);
    const body = m.body || '';
    const bucketLines = extractMetricLines(body, 'outbox_publish_latency_seconds_bucket');
    const countLines = extractMetricLines(body, 'outbox_publish_latency_seconds_count');
    const sumLines = extractMetricLines(body, 'outbox_publish_latency_seconds_sum');
    expect(bucketLines.length + countLines.length).toBeGreaterThan(0);
    expect(hasNonZero([...bucketLines, ...countLines])).toBe(true);
    const countVal = findCount(body, 'attendance-service');
    expect(countVal).toBeGreaterThanOrEqual(5);
    // Sum should be > 0 for observed latency values
    const anySumNonZero = hasNonZero(sumLines);
    expect(anySumNonZero).toBe(true);
  });
});
