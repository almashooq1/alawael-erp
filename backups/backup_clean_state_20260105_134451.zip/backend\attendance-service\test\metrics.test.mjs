import { createServer } from '../src/server.js';
import { withMetricsServer } from '../../test-utils/withMetricsServer.js';
import { jest } from '@jest/globals';

// Extend Jest timeout for slower startup (tracing, plugin registration)
jest.setTimeout(15000);

let helper;
beforeAll(async () => {
  process.env.METRICS_ENABLED = 'true';
  // Disable tracing auto instrumentation for test speed/stability
  process.env.OTEL_ENABLED = 'false';
  delete process.env.OTEL_EXPORTER_OTLP_ENDPOINT;
  helper = withMetricsServer(createServer);
  // Increase wait timeout because Fastify + tracing init may take >1s in CI
  await helper.waitForMetrics({ timeoutMs: 10000, intervalMs: 100 });
});
afterAll(async () => {
  await helper?.close();
});

describe('metrics exposure', () => {
  test('exposes histogram & gauge after activity', async () => {
    // Trigger a tiny bit of activity (health + metrics fetch)
    await helper.get('/health');
    const first = await helper.get('/metrics');
    expect(first.statusCode).toBe(200);
    let body = first.body || '';
    // If histogram not yet registered (rare race), wait & retry
    if (!body.includes('outbox_publish_latency_seconds_bucket')) {
      await new Promise(r => setTimeout(r, 100));
      body = (await helper.get('/metrics')).body || '';
    }
    expect(body).toContain('outbox_publish_latency_seconds_bucket');
    expect(body).toContain('outbox_pending_rows');
  });

  test('increments HTTP counter with route label', async () => {
    await helper.get('/health');
    const m = await helper.get('/metrics');
    expect(m.statusCode).toBe(200);
    const text = m.body || '';
    // Look for a sample metric line with route label
    expect(text).toMatch(/service_http_requests_total\{[^}]*route="\/health"[^}]*\}\s+\d+/);
  });
});
