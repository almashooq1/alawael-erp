const { Outbox } = require('../../../shared/outbox/index.js');
import { runMigrations } from '../../scripts/run-migrations.mjs';

// This test requires a real Postgres database. It will be skipped if no DB URL is provided.
describe('outbox dead-letter integration (requires Postgres)', () => {
  const svcUrl = process.env.ATTENDANCE_DATABASE_URL || process.env.DATABASE_URL;
  if (!svcUrl) {
    test('skipped: DATABASE_URL or ATTENDANCE_DATABASE_URL not set', () => {});
    return;
  }

  const databaseUrl = svcUrl;

  test('moves message to dead-letter when publish fails and max attempts reached', async () => {
    // Ensure migrations are applied on the target DB
    await runMigrations({ databaseUrl, logger: { info() {} } });

    // Force single attempt to trigger DLQ on first failure
    process.env.OUTBOX_MAX_ATTEMPTS = '1';
    process.env.OUTBOX_USE_NEXT_ATTEMPT_AT = 'false';

    // Stub bus that always fails
    const failingBus = {
      publish: async () => {
        throw new Error('synthetic publish failure');
      },
    };
    const outbox = new Outbox({
      logger: console,
      bus: failingBus,
      serviceName: 'attendance-service',
    });

    // Stage one event
    const payload = { hello: 'world' };
    await outbox.enqueue({ topic: 'test.events', event: payload });

    // Flush once; with max=1 the failed publish should move the record to dead-letter
    const flushed = await outbox.flushBatch(5);
    expect(flushed).toBe(0);

    // Verify in DB: outbox has no unpublished rows with this payload; dead-letter has one
    const { Pool } = await import('pg');
    const pool = new Pool({ connectionString: databaseUrl });
    const client = await pool.connect();
    try {
      const ob = await client.query(
        'SELECT count(*)::int AS c FROM outbox WHERE published_at IS NULL'
      );
      const dlq = await client.query('SELECT count(*)::int AS c FROM outbox_deadletter');
      expect(ob.rows[0].c).toBeGreaterThanOrEqual(0);
      expect(dlq.rows[0].c).toBeGreaterThanOrEqual(1);
    } finally {
      client.release();
      await pool.end();
    }
  }, 20000);
});
