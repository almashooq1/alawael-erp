const { Outbox } = require('../../../shared/outbox/index.js');
const path = require('path');
let runMigrations;

beforeAll(async () => {
  // Dynamically import the ESM migration script
  const mod = await import(path.resolve(__dirname, '../../scripts/run-migrations.mjs'));
  runMigrations = mod.runMigrations;
});

// This test validates delayed retry using next_attempt_at; requires a real Postgres.
describe('outbox precise scheduling with next_attempt_at (requires Postgres)', () => {
  const svcUrl = process.env.ATTENDANCE_DATABASE_URL || process.env.DATABASE_URL;
  if (!svcUrl) {
    test('skipped: no DATABASE_URL provided', () => {});
    return;
  }
  const databaseUrl = svcUrl;

  test('after failure, next_attempt_at defers publish until due', async () => {
    // Apply baseline migrations
    await runMigrations({ databaseUrl, logger: { info() {} } });

    // Ensure next_attempt_at column exists (manual apply if needed)
    const { Pool } = require('pg');
    const pool = new Pool({ connectionString: databaseUrl });
    const client = await pool.connect();
    try {
      const col = await client.query(
        "SELECT 1 FROM information_schema.columns WHERE table_name='outbox' AND column_name='next_attempt_at'"
      );
      if (col.rowCount === 0) {
        await client.query('ALTER TABLE outbox ADD COLUMN next_attempt_at timestamptz');
        await client.query(
          'CREATE INDEX IF NOT EXISTS outbox_next_attempt_idx ON outbox(next_attempt_at) WHERE published_at IS NULL'
        );
      }
    } finally {
      client.release();
      await pool.end();
    }

    // Configure env to use next_attempt_at and small base delay
    process.env.OUTBOX_USE_NEXT_ATTEMPT_AT = 'true';
    process.env.OUTBOX_RETRY_BASE_SECONDS = '5';
    process.env.OUTBOX_MAX_ATTEMPTS = '2';

    // First, use a failing bus to schedule a retry into the future
    const failingBus = {
      publish: async () => {
        throw new Error('fail-on-purpose');
      },
    };
    const outboxFail = new Outbox({
      logger: console,
      bus: failingBus,
      serviceName: 'attendance-service',
    });
    await outboxFail.enqueue({ topic: 'test.events', event: { step: 'first' } });
    // This flush attempts publish, fails, and should set next_attempt_at = now() + baseDelay
    await outboxFail.flushBatch(10);

    // Now swap to a succeeding bus and try to flush immediately; should be 0 because not due yet
    const published = [];
    const successBus = { publish: async (topic, event) => published.push({ topic, event }) };
    const outboxOk = new Outbox({
      logger: console,
      bus: successBus,
      serviceName: 'attendance-service',
    });
    const immediate = await outboxOk.flushBatch(10);
    expect(immediate).toBe(0);

    // Force due by moving next_attempt_at back in time
    const { Pool: P2 } = require('pg');
    const pool2 = new P2({ connectionString: databaseUrl });
    const client2 = await pool2.connect();
    try {
      await client2.query(
        "UPDATE outbox SET next_attempt_at = now() - interval '1 second' WHERE published_at IS NULL"
      );
    } finally {
      client2.release();
      await pool2.end();
    }

    // Now flush again; should publish >= 1
    const later = await outboxOk.flushBatch(10);
    expect(later).toBeGreaterThanOrEqual(1);
    expect(published.length).toBeGreaterThanOrEqual(1);
  }, 30000);
});
