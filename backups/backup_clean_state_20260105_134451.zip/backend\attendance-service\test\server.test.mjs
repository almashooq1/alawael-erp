import { createServer } from '../src/server.js';

describe('attendance-service', () => {
  let app;
  beforeAll(async () => {
    app = createServer();
    await app.ready();
  });
  afterAll(async () => {
    await app.close();
  });

  test('GET /health', async () => {
    const res = await app.inject({ method: 'GET', url: '/health' });
    expect(res.statusCode).toBe(200);
  });

  test('POST /attendance validation failure (missing therapistId)', async () => {
    const res = await app.inject({
      method: 'POST',
      url: '/attendance',
      payload: { patientId: 'p1' },
    });
    expect(res.statusCode).toBe(400);
  });

  test('POST /attendance success and manual flush', async () => {
    const res = await app.inject({
      method: 'POST',
      url: '/attendance',
      payload: {
        patientId: 'p1',
        therapistId: 't1',
        status: 'PRESENT',
        checkInAt: new Date().toISOString(),
      },
    });
    expect(res.statusCode).toBe(201);
    const flush = await app.inject({ method: 'POST', url: '/debug/outbox/flush?limit=5' });
    expect(flush.statusCode).toBe(200);
    const body = JSON.parse(flush.body);
    expect(body.flushed).toBeGreaterThanOrEqual(0);
  });

  test('POST then list attendance records', async () => {
    const patientId = 'list-patient';
    const therapistId = 'list-therapist';
    const createRes = await app.inject({
      method: 'POST',
      url: '/attendance',
      payload: { patientId, therapistId },
    });
    expect(createRes.statusCode).toBe(201);
    const listRes = await app.inject({ method: 'GET', url: `/attendance?patientId=${patientId}` });
    expect(listRes.statusCode).toBe(200);
    const items = JSON.parse(listRes.body);
    expect(Array.isArray(items)).toBe(true);
    expect(items.find(r => r.patientId === patientId)).toBeTruthy();
  });

  test('Outbox flush publishes staged events (>=1 flushed)', async () => {
    const createRes = await app.inject({
      method: 'POST',
      url: '/attendance',
      payload: { patientId: 'p2', therapistId: 't2' },
    });
    expect(createRes.statusCode).toBe(201);
    const flush = await app.inject({ method: 'POST', url: '/debug/outbox/flush?limit=10' });
    expect(flush.statusCode).toBe(200);
    const body = JSON.parse(flush.body);
    expect(body.flushed).toBeGreaterThan(0);
  });
});
