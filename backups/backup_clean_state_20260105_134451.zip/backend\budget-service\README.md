# 💰 نظام إدارة الميزانية - Budget Service

نظام شامل لتخطيط وتتبع وإدارة الميزانيات.

## المميزات

- ✅ إدارة الميزانيات (إنشاء، تعديل، حذف)
- ✅ تتبع المصروفات
- ✅ تصنيف المصروفات
- ✅ تنبيهات الميزانية (80%, 90%, 100%)
- ✅ تقارير شاملة
- ✅ تحليل الاستخدام

## API Endpoints

### Health Check

```
GET /health
```

### Budgets

```
GET /budgets - Get all budgets
GET /budgets/:budgetId - Get budget by ID
POST /budgets - Create new budget
PUT /budgets/:budgetId - Update budget
DELETE /budgets/:budgetId - Delete budget
```

### Expenses

```
GET /expenses - Get all expenses
GET /expenses/:expenseId - Get expense by ID
POST /expenses - Create new expense
PUT /expenses/:expenseId - Update expense
DELETE /expenses/:expenseId - Delete expense
```

### Categories

```
GET /categories - Get all categories
POST /categories - Create new category
```

### Reports

```
GET /reports/summary - Get budget summary
GET /reports/department/:department - Get department report
```

### Alerts

```
GET /alerts - Get all alerts
```

## التشغيل

```bash
npm install
npm start
```

الخدمة ستعمل على المنفذ `3033` افتراضياً.
