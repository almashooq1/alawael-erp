#!/usr/bin/env node
/**
 * 💰 نظام إدارة الميزانية - Budget Management System
 * نظام شامل لتخطيط وتتبع وإدارة الميزانيات
 */

const express = require('express');
const compression = require('compression');
const morgan = require('morgan');
const {
  sanitizeInputs,
  trackRequest,
  errorHandler: securityErrorHandler,
} = require('../../shared/middleware/security-middleware');
const { v4: uuidv4 } = require('uuid');
const moment = (() => {
  try {
    return require('moment');
  } catch (e) {
    return {
      isMoment: () => false,
      utc: () => ({ format: () => new Date().toISOString() }),
      format: () => new Date().toISOString(),
      duration: () => ({ humanize: () => '0s' }),
    };
  }
})();
const BudgetCalculator = require('./services/budget-calculator');
const Logger = require('./utils/logger');

const app = express();
// Security Middleware
const helmetConfig = require('../../shared/middleware/security/helmet-config');
const corsConfig = require('../../shared/middleware/security/cors-config');
const { apiLimiter } = require('../../shared/middleware/security/rate-limiter');
const securityHeaders = require('../../shared/middleware/security/security-headers');

const PORT = process.env.PORT || 3033;
const logger = new Logger('budget-service');

// ============================================
// Performance Middleware
// ============================================
app.use(
  compression({
    level: 6,
    threshold: 1024,
    filter: (req, res) => {
      if (req.headers['x-no-compression']) {
        return false;
      }
      return compression.filter(req, res);
    },
  })
);

// ============================================
// Logging Middleware
// ============================================
if (process.env.NODE_ENV === 'development') {
  app.use(morgan('dev'));
} else {
  app.use(morgan('combined'));
}

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Monitoring Middleware
const { requestLogger, errorLogger } = require('../../shared/utils/logger/logger-middleware');
const { metricsMiddleware } = require('../../shared/utils/metrics/prometheus');
const tracingMiddleware = require('../../shared/utils/tracing/tracing-middleware');

app.use(requestLogger);
app.use(metricsMiddleware);
app.use(tracingMiddleware);

app.use(helmetConfig);
app.use(corsConfig);
app.use(securityHeaders);
app.use('/api/', apiLimiter);

app.use(sanitizeInputs);
app.use(trackRequest);

// Initialize services
const budgetCalculator = new BudgetCalculator();

// In-memory storage
const storage = {
  budgets: new Map(), // { budgetId: { id, name, department, totalAmount, spent, remaining, period, status } }
  expenses: new Map(), // { expenseId: { id, budgetId, amount, category, description, date, status } }
  categories: new Map(), // { categoryId: { id, name, budget, spent } }
  alerts: [], // { budgetId, type, message, timestamp }
};

// Helper functions
function checkBudgetAlerts(budgetId) {
  const budget = storage.budgets.get(budgetId);
  if (!budget) return;

  const alerts = budgetCalculator.generateAlerts(budget);
  alerts.forEach(alert => {
    storage.alerts.push({
      ...alert,
      timestamp: new Date().toISOString(),
    });
  });
}

// Routes

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'budget-service', timestamp: new Date().toISOString() });
});

// Budgets
app.get('/budgets', (req, res) => {
  const { department, status, period } = req.query;
  let budgets = Array.from(storage.budgets.values());

  if (department) budgets = budgets.filter(b => b.department === department);
  if (status) budgets = budgets.filter(b => b.status === status);
  if (period) budgets = budgets.filter(b => b.period === period);

  res.json({ success: true, data: budgets });
});

app.get('/budgets/:budgetId', (req, res) => {
  const { budgetId } = req.params;
  const budget = storage.budgets.get(budgetId);

  if (!budget) {
    return res.status(404).json({ success: false, message: 'الميزانية غير موجودة' });
  }

  res.json({ success: true, data: budget });
});

app.post('/budgets', (req, res) => {
  const { name, department, totalAmount, period, description } = req.body;

  if (!name || !department || !totalAmount || !period) {
    return res.status(400).json({ success: false, message: 'جميع الحقول مطلوبة' });
  }

  const budgetId = uuidv4();
  const budget = {
    id: budgetId,
    name,
    department,
    totalAmount: parseFloat(totalAmount),
    spent: 0,
    remaining: parseFloat(totalAmount),
    period, // monthly, quarterly, yearly
    status: 'active',
    description: description || '',
    utilizationRate: 0,
    statusLevel: 'healthy',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  budget.utilizationRate = budgetCalculator.calculateUtilizationRate(budget);
  budget.statusLevel = budgetCalculator.getBudgetStatus(budget);

  storage.budgets.set(budgetId, budget);

  res.status(201).json({ success: true, data: budget });
});

app.put('/budgets/:budgetId', (req, res) => {
  const { budgetId } = req.params;
  const { name, totalAmount, status, description } = req.body;

  const budget = storage.budgets.get(budgetId);
  if (!budget) {
    return res.status(404).json({ success: false, message: 'الميزانية غير موجودة' });
  }

  if (name) budget.name = name;
  if (totalAmount !== undefined) {
    budget.totalAmount = parseFloat(totalAmount);
    budget.remaining = budgetCalculator.calculateRemaining(budget);
    budget.utilizationRate = budgetCalculator.calculateUtilizationRate(budget);
    budget.statusLevel = budgetCalculator.getBudgetStatus(budget);
  }
  if (status) budget.status = status;
  if (description !== undefined) budget.description = description;
  budget.updatedAt = new Date().toISOString();

  storage.budgets.set(budgetId, budget);

  res.json({ success: true, data: budget });
});

app.delete('/budgets/:budgetId', (req, res) => {
  const { budgetId } = req.params;

  if (!storage.budgets.has(budgetId)) {
    return res.status(404).json({ success: false, message: 'الميزانية غير موجودة' });
  }

  storage.budgets.delete(budgetId);

  // Delete related expenses
  Array.from(storage.expenses.values())
    .filter(e => e.budgetId === budgetId)
    .forEach(e => storage.expenses.delete(e.id));

  res.json({ success: true, message: 'تم حذف الميزانية بنجاح' });
});

// Expenses
app.get('/expenses', (req, res) => {
  const { budgetId, category, startDate, endDate } = req.query;
  let expenses = Array.from(storage.expenses.values());

  if (budgetId) expenses = expenses.filter(e => e.budgetId === budgetId);
  if (category) expenses = expenses.filter(e => e.category === category);
  if (startDate) expenses = expenses.filter(e => moment(e.date).isAfter(moment(startDate)));
  if (endDate) expenses = expenses.filter(e => moment(e.date).isBefore(moment(endDate)));

  res.json({ success: true, data: expenses });
});

app.get('/expenses/:expenseId', (req, res) => {
  const { expenseId } = req.params;
  const expense = storage.expenses.get(expenseId);

  if (!expense) {
    return res.status(404).json({ success: false, message: 'المصروف غير موجود' });
  }

  res.json({ success: true, data: expense });
});

app.post('/expenses', (req, res) => {
  const { budgetId, amount, category, description, date } = req.body;

  if (!budgetId || !amount || !category) {
    return res.status(400).json({ success: false, message: 'جميع الحقول مطلوبة' });
  }

  const budget = storage.budgets.get(budgetId);
  if (!budget) {
    return res.status(404).json({ success: false, message: 'الميزانية غير موجودة' });
  }

  const expenseAmount = parseFloat(amount);

  if (!budgetCalculator.canAffordExpense(budget, expenseAmount)) {
    return res.status(400).json({ success: false, message: 'الميزانية غير كافية' });
  }

  const expenseId = uuidv4();
  const expense = {
    id: expenseId,
    budgetId,
    amount: expenseAmount,
    category,
    description: description || '',
    date: date || new Date().toISOString(),
    status: 'pending',
    createdAt: new Date().toISOString(),
  };

  storage.expenses.set(expenseId, expense);

  // Update budget
  budget.spent += expenseAmount;
  budget.remaining = budgetCalculator.calculateRemaining(budget);
  budget.utilizationRate = budgetCalculator.calculateUtilizationRate(budget);
  budget.statusLevel = budgetCalculator.getBudgetStatus(budget);
  budget.updatedAt = new Date().toISOString();

  checkBudgetAlerts(budgetId);

  res.status(201).json({ success: true, data: expense });
});

app.put('/expenses/:expenseId', (req, res) => {
  const { expenseId } = req.params;
  const { amount, category, description, status } = req.body;

  const expense = storage.expenses.get(expenseId);
  if (!expense) {
    return res.status(404).json({ success: false, message: 'المصروف غير موجود' });
  }

  const budget = storage.budgets.get(expense.budgetId);
  if (!budget) {
    return res.status(404).json({ success: false, message: 'الميزانية غير موجودة' });
  }

  // If amount changed, update budget
  if (amount !== undefined && parseFloat(amount) !== expense.amount) {
    const oldAmount = expense.amount;
    const newAmount = parseFloat(amount);
    const difference = newAmount - oldAmount;

    if (budget.remaining < difference) {
      return res.status(400).json({ success: false, message: 'الميزانية غير كافية' });
    }

    budget.spent += difference;
    budget.remaining -= difference;
    budget.updatedAt = new Date().toISOString();
    expense.amount = newAmount;

    checkBudgetAlerts(expense.budgetId);
  }

  if (category) expense.category = category;
  if (description !== undefined) expense.description = description;
  if (status) expense.status = status;

  storage.expenses.set(expenseId, expense);

  res.json({ success: true, data: expense });
});

app.delete('/expenses/:expenseId', (req, res) => {
  const { expenseId } = req.params;

  const expense = storage.expenses.get(expenseId);
  if (!expense) {
    return res.status(404).json({ success: false, message: 'المصروف غير موجود' });
  }

  const budget = storage.budgets.get(expense.budgetId);
  if (budget) {
    budget.spent -= expense.amount;
    budget.remaining += expense.amount;
    budget.updatedAt = new Date().toISOString();
  }

  storage.expenses.delete(expenseId);

  res.json({ success: true, message: 'تم حذف المصروف بنجاح' });
});

// Categories
app.get('/categories', (req, res) => {
  const categories = Array.from(storage.categories.values());
  res.json({ success: true, data: categories });
});

app.post('/categories', (req, res) => {
  const { name, budget } = req.body;

  if (!name || !budget) {
    return res.status(400).json({ success: false, message: 'جميع الحقول مطلوبة' });
  }

  const categoryId = uuidv4();
  const category = {
    id: categoryId,
    name,
    budget: parseFloat(budget),
    spent: 0,
    createdAt: new Date().toISOString(),
  };

  storage.categories.set(categoryId, category);

  res.status(201).json({ success: true, data: category });
});

// Reports
app.get('/reports/summary', (req, res) => {
  const { period, department } = req.query;

  let budgets = Array.from(storage.budgets.values());
  if (period) budgets = budgets.filter(b => b.period === period);
  if (department) budgets = budgets.filter(b => b.department === department);

  const totalBudget = budgets.reduce((sum, b) => sum + b.totalAmount, 0);
  const totalSpent = budgets.reduce((sum, b) => sum + b.spent, 0);
  const totalRemaining = budgets.reduce((sum, b) => sum + b.remaining, 0);

  res.json({
    success: true,
    data: {
      totalBudgets: budgets.length,
      totalBudget,
      totalSpent,
      totalRemaining,
      utilizationRate: totalBudget > 0 ? ((totalSpent / totalBudget) * 100).toFixed(2) : 0,
    },
  });
});

app.get('/reports/department/:department', (req, res) => {
  const { department } = req.params;
  const budgets = Array.from(storage.budgets.values()).filter(b => b.department === department);

  const expenses = Array.from(storage.expenses.values()).filter(e => {
    const budget = storage.budgets.get(e.budgetId);
    return budget && budget.department === department;
  });

  res.json({
    success: true,
    data: {
      department,
      budgets: budgets.length,
      totalBudget: budgets.reduce((sum, b) => sum + b.totalAmount, 0),
      totalSpent: budgets.reduce((sum, b) => sum + b.spent, 0),
      expenses: expenses.length,
    },
  });
});

// Alerts
app.get('/alerts', (req, res) => {
  const { budgetId, type } = req.query;
  let alerts = storage.alerts;

  if (budgetId) alerts = alerts.filter(a => a.budgetId === budgetId);
  if (type) alerts = alerts.filter(a => a.type === type);

  res.json({ success: true, data: alerts });
});

// Error handler (security middleware)
app.use(securityErrorHandler);

// Start server
// Error Handling
const { errorHandler, notFoundHandler } = require('../../shared/middleware/error-handler');

// 404 handler (must be after all routes)

// API Documentation
const { swaggerSetup } = require('../../shared/docs/swagger-config');
swaggerSetup(app);

app.use(notFoundHandler);

// Error handler (must be last)
app.use(errorHandler);

if (require.main === module && process.env.NODE_ENV !== 'test') {
  app
    .listen(PORT, () => {
      logger.info(`Budget Service running on port ${PORT}`);
      logger.info(`Health: http://localhost:${PORT}/health`);
    })
    .on('error', error => {
      if (error.code === 'EADDRINUSE') {
        logger.error(`❌ Port ${PORT} is already in use`);
        logger.error(
          'Please change the PORT in your .env file or stop the process using this port'
        );
        process.exit(1);
      } else {
        logger.error('❌ Server error:', error);
        process.exit(1);
      }
    });
} else {
  // Exported for tests to `require()` without starting the server
}

module.exports = app;
