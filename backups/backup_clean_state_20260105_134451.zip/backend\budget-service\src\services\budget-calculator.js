/**
 * 💰 Budget Calculator Service
 * Business logic for budget calculations
 */

class BudgetCalculator {
  calculateUtilizationRate(budget) {
    if (budget.totalAmount === 0) return '0';
    return ((budget.spent / budget.totalAmount) * 100).toFixed(2);
  }

  calculateRemaining(budget) {
    return budget.totalAmount - budget.spent;
  }

  canAffordExpense(budget, expenseAmount) {
    return budget.remaining >= expenseAmount;
  }

  getBudgetStatus(budget) {
    const utilizationRate = parseFloat(this.calculateUtilizationRate(budget));

    if (utilizationRate >= 100) return 'exceeded';
    if (utilizationRate >= 90) return 'critical';
    if (utilizationRate >= 80) return 'warning';
    if (utilizationRate >= 50) return 'moderate';
    return 'healthy';
  }

  generateAlerts(budget) {
    const alerts = [];
    const utilizationRate = parseFloat(this.calculateUtilizationRate(budget));

    if (utilizationRate >= 80 && utilizationRate < 90) {
      alerts.push({
        type: 'warning',
        message: `الميزانية وصلت إلى ${utilizationRate.toFixed(1)}%`,
        budgetId: budget.id,
      });
    }

    if (utilizationRate >= 90 && utilizationRate < 100) {
      alerts.push({
        type: 'critical',
        message: `الميزانية وصلت إلى ${utilizationRate.toFixed(1)}% - تحذير عالي`,
        budgetId: budget.id,
      });
    }

    if (utilizationRate >= 100) {
      alerts.push({
        type: 'exceeded',
        message: 'الميزانية تجاوزت الحد المخصص',
        budgetId: budget.id,
      });
    }

    return alerts;
  }
}

module.exports = BudgetCalculator;
