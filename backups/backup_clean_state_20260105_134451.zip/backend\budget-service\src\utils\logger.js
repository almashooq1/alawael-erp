/**
 * 💰 Logger Utility
 * Enhanced logging for Budget Service
 */

class Logger {
  constructor(serviceName = 'budget-service') {
    this.serviceName = serviceName;
  }

  info(message, data = {}) {
    console.log(`[${this.serviceName}] [INFO] ${message}`, data);
  }

  error(message, error = null, data = {}) {
    console.error(`[${this.serviceName}] [ERROR] ${message}`, {
      error: error?.message || error,
      stack: error?.stack,
      ...data,
    });
  }

  warn(message, data = {}) {
    console.warn(`[${this.serviceName}] [WARN] ${message}`, data);
  }

  debug(message, data = {}) {
    if (process.env.DEBUG === 'true') {
      console.log(`[${this.serviceName}] [DEBUG] ${message}`, data);
    }
  }
}

module.exports = Logger;
