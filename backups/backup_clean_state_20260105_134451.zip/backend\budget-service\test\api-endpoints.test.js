/**
 * 💰 Tests for Budget Service API Endpoints
 */

const request = require('supertest');
const app = require('../src/server');

describe('Budget API Endpoints', () => {
  describe('Budget CRUD', () => {
    test('should create, read, update, and delete budget', async () => {
      // Create
      const createResponse = await request(app)
        .post('/budgets')
        .send({
          name: 'API Test Budget',
          department: 'IT',
          totalAmount: 50000,
          period: 'quarterly',
        })
        .expect(201);

      const budgetId = createResponse.body.data.id;
      expect(createResponse.body.success).toBe(true);

      // Read
      const getResponse = await request(app).get(`/budgets/${budgetId}`).expect(200);

      expect(getResponse.body.data.id).toBe(budgetId);

      // Update
      const updateResponse = await request(app)
        .put(`/budgets/${budgetId}`)
        .send({ totalAmount: 60000 })
        .expect(200);

      expect(updateResponse.body.data.totalAmount).toBe(60000);

      // Delete (if endpoint exists)
      // const deleteResponse = await request(app)
      //   .delete(`/budgets/${budgetId}`)
      //   .expect(200);
    });
  });

  describe('Expense Management', () => {
    test('should create and list expenses', async () => {
      // Create budget
      const budgetResponse = await request(app).post('/budgets').send({
        name: 'Expense Test Budget',
        department: 'IT',
        totalAmount: 10000,
        period: 'monthly',
      });

      const budgetId = budgetResponse.body.data.id;

      // Create expense
      const expenseResponse = await request(app)
        .post('/expenses')
        .send({
          budgetId,
          amount: 2000,
          category: 'Equipment',
        })
        .expect(201);

      expect(expenseResponse.body.success).toBe(true);

      // List expenses
      const listResponse = await request(app).get('/expenses').query({ budgetId }).expect(200);

      expect(Array.isArray(listResponse.body.data)).toBe(true);
    });
  });

  describe('Budget Status', () => {
    test('should track budget utilization correctly', async () => {
      const budgetResponse = await request(app).post('/budgets').send({
        name: 'Status Test Budget',
        department: 'IT',
        totalAmount: 10000,
        period: 'monthly',
      });

      const budgetId = budgetResponse.body.data.id;

      // Add expenses
      await request(app).post('/expenses').send({ budgetId, amount: 8000, category: 'Test' });

      // Check status
      const statusResponse = await request(app).get(`/budgets/${budgetId}`).expect(200);

      expect(parseFloat(statusResponse.body.data.utilizationRate)).toBeGreaterThanOrEqual(80);
      expect(['warning', 'critical', 'exceeded']).toContain(statusResponse.body.data.statusLevel);
    });
  });
});
