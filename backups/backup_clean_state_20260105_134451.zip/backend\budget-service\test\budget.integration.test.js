/**
 * 💰 Integration Tests for Budget Service
 */

const request = require('supertest');
const app = require('../src/server');

describe('Budget Service Integration', () => {
  let testBudgetId;

  beforeAll(async () => {
    // Create test budget
    const response = await request(app).post('/budgets').send({
      name: 'Integration Test Budget',
      department: 'IT',
      totalAmount: 50000,
      period: 'quarterly',
    });
    testBudgetId = response.body.data.id;
  });

  describe('Budget Lifecycle', () => {
    test('should handle complete budget lifecycle: create -> expenses -> alerts -> reports', async () => {
      // Step 1: Create budget
      expect(testBudgetId).toBeDefined();

      // Step 2: Add multiple expenses
      const expense1 = await request(app)
        .post('/expenses')
        .send({
          budgetId: testBudgetId,
          amount: 10000,
          category: 'Equipment',
        })
        .expect(201);

      const expense2 = await request(app)
        .post('/expenses')
        .send({
          budgetId: testBudgetId,
          amount: 15000,
          category: 'Software',
        })
        .expect(201);

      // Step 3: Check budget status
      const budgetResponse = await request(app).get(`/budgets/${testBudgetId}`).expect(200);

      expect(budgetResponse.body.data.spent).toBe(25000);
      expect(budgetResponse.body.data.remaining).toBe(25000);
      expect(parseFloat(budgetResponse.body.data.utilizationRate)).toBe(50);

      // Step 4: Add expense to trigger warning
      await request(app)
        .post('/expenses')
        .send({
          budgetId: testBudgetId,
          amount: 20000,
          category: 'Services',
        })
        .expect(201);

      // Step 5: Check alerts
      const alertsResponse = await request(app).get('/alerts').expect(200);

      const budgetAlerts = alertsResponse.body.data.filter(a => a.budgetId === testBudgetId);

      expect(budgetAlerts.length).toBeGreaterThan(0);

      // Step 6: Get reports
      const reportsResponse = await request(app).get('/reports/summary').expect(200);

      expect(reportsResponse.body.data.totalBudgets).toBeGreaterThan(0);
    });
  });

  describe('Budget Constraints', () => {
    test('should prevent exceeding budget limit', async () => {
      const smallBudget = await request(app).post('/budgets').send({
        name: 'Small Budget',
        department: 'Test',
        totalAmount: 1000,
        period: 'monthly',
      });

      const smallBudgetId = smallBudget.body.data.id;

      // Try to exceed budget
      const response = await request(app)
        .post('/expenses')
        .send({
          budgetId: smallBudgetId,
          amount: 2000,
          category: 'Test',
        })
        .expect(400);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toContain('غير كافية');
    });
  });
});
