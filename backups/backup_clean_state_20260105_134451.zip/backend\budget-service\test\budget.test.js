/**
 * 🧪 Tests for Budget Service
 */

const request = require('supertest');
const app = require('../src/server');

describe('Budget Service', () => {
  describe('Health Check', () => {
    test('should return health status', async () => {
      const response = await request(app).get('/health').expect(200);

      expect(response.body.status).toBe('ok');
      expect(response.body.service).toBe('budget-service');
    });
  });

  describe('Budgets', () => {
    test('should create budget', async () => {
      const response = await request(app)
        .post('/budgets')
        .send({
          name: 'Test Budget',
          department: 'IT',
          totalAmount: 10000,
          period: 'monthly',
        })
        .expect(201);

      expect(response.body.success).toBe(true);
      expect(response.body.data.totalAmount).toBe(10000);
      expect(response.body.data.utilizationRate).toBeDefined();
      expect(response.body.data.statusLevel).toBeDefined();
    });

    test('should get all budgets', async () => {
      const response = await request(app).get('/budgets').expect(200);

      expect(response.body.success).toBe(true);
      expect(Array.isArray(response.body.data)).toBe(true);
    });
  });

  describe('Expenses', () => {
    let budgetId;

    beforeAll(async () => {
      const response = await request(app).post('/budgets').send({
        name: 'Test Budget',
        department: 'IT',
        totalAmount: 10000,
        period: 'monthly',
      });
      budgetId = response.body.data.id;
    });

    test('should create expense', async () => {
      const response = await request(app)
        .post('/expenses')
        .send({
          budgetId,
          amount: 1000,
          category: 'Equipment',
        })
        .expect(201);

      expect(response.body.success).toBe(true);
      expect(response.body.data.amount).toBe(1000);
    });

    test('should reject expense exceeding budget', async () => {
      const response = await request(app)
        .post('/expenses')
        .send({
          budgetId,
          amount: 50000,
          category: 'Equipment',
        })
        .expect(400);

      expect(response.body.success).toBe(false);
    });
  });

  describe('Reports', () => {
    test('should get budget summary', async () => {
      const response = await request(app).get('/reports/summary').expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.data.totalBudgets).toBeDefined();
      expect(response.body.data.utilizationRate).toBeDefined();
    });

    test('should get budget alerts', async () => {
      const response = await request(app).get('/alerts').expect(200);

      expect(response.body.success).toBe(true);
      expect(Array.isArray(response.body.data)).toBe(true);
    });
  });

  describe('Budget Status', () => {
    test('should calculate utilization rate correctly', async () => {
      const response = await request(app).post('/budgets').send({
        name: 'Status Test Budget',
        department: 'IT',
        totalAmount: 10000,
        period: 'monthly',
      });

      const budgetId = response.body.data.id;

      // Add expense
      await request(app).post('/expenses').send({
        budgetId,
        amount: 8000,
        category: 'Equipment',
      });

      // Get budget
      const getResponse = await request(app).get(`/budgets/${budgetId}`).expect(200);

      expect(getResponse.body.data.utilizationRate).toBe('80.00');
      expect(getResponse.body.data.statusLevel).toBe('warning');
    });
  });

  describe('Error Handling', () => {
    test('should reject expense exceeding budget', async () => {
      const budgetResponse = await request(app).post('/budgets').send({
        name: 'Small Budget',
        department: 'IT',
        totalAmount: 1000,
        period: 'monthly',
      });

      const budgetId = budgetResponse.body.data.id;

      const response = await request(app)
        .post('/expenses')
        .send({
          budgetId,
          amount: 2000,
          category: 'Equipment',
        })
        .expect(400);

      expect(response.body.success).toBe(false);
    });
  });
});
