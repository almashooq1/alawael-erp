/**
 * 💰 Tests for Budget Service Services
 */

const BudgetCalculator = require('../src/services/budget-calculator');

describe('Budget Calculator Service', () => {
  let calculator;

  beforeEach(() => {
    calculator = new BudgetCalculator();
  });

  describe('calculateUtilizationRate', () => {
    test('should calculate utilization rate correctly', () => {
      const budget = {
        totalAmount: 10000,
        spent: 5000,
      };

      const rate = calculator.calculateUtilizationRate(budget);

      expect(rate).toBe('50.00');
    });

    test('should return 0 for zero total amount', () => {
      const budget = {
        totalAmount: 0,
        spent: 1000,
      };

      const rate = calculator.calculateUtilizationRate(budget);

      expect(rate).toBe('0');
    });
  });

  describe('calculateRemaining', () => {
    test('should calculate remaining amount correctly', () => {
      const budget = {
        totalAmount: 10000,
        spent: 3000,
      };

      const remaining = calculator.calculateRemaining(budget);

      expect(remaining).toBe(7000);
    });
  });

  describe('canAffordExpense', () => {
    test('should return true when budget can afford expense', () => {
      const budget = {
        totalAmount: 10000,
        spent: 5000,
        remaining: 5000,
      };

      expect(calculator.canAffordExpense(budget, 3000)).toBe(true);
    });

    test('should return false when budget cannot afford expense', () => {
      const budget = {
        totalAmount: 10000,
        spent: 5000,
        remaining: 5000,
      };

      expect(calculator.canAffordExpense(budget, 6000)).toBe(false);
    });
  });

  describe('getBudgetStatus', () => {
    test('should return healthy for low utilization', () => {
      const budget = {
        totalAmount: 10000,
        spent: 3000,
      };

      const status = calculator.getBudgetStatus(budget);

      expect(status).toBe('healthy');
    });

    test('should return warning for high utilization', () => {
      const budget = {
        totalAmount: 10000,
        spent: 8500,
      };

      const status = calculator.getBudgetStatus(budget);

      expect(status).toBe('warning');
    });

    test('should return critical for very high utilization', () => {
      const budget = {
        totalAmount: 10000,
        spent: 9500,
      };

      const status = calculator.getBudgetStatus(budget);

      expect(status).toBe('critical');
    });

    test('should return exceeded for 100% utilization', () => {
      const budget = {
        totalAmount: 10000,
        spent: 10000,
      };

      const status = calculator.getBudgetStatus(budget);

      expect(status).toBe('exceeded');
    });
  });

  describe('generateAlerts', () => {
    test('should generate warning alert at 80%', () => {
      const budget = {
        id: 'budget-1',
        totalAmount: 10000,
        spent: 8500,
      };

      const alerts = calculator.generateAlerts(budget);

      expect(alerts.length).toBeGreaterThan(0);
      expect(alerts[0].type).toBe('warning');
    });

    test('should generate critical alert at 90%', () => {
      const budget = {
        id: 'budget-1',
        totalAmount: 10000,
        spent: 9500,
      };

      const alerts = calculator.generateAlerts(budget);

      expect(alerts.length).toBeGreaterThan(0);
      expect(alerts[0].type).toBe('critical');
    });

    test('should generate exceeded alert at 100%', () => {
      const budget = {
        id: 'budget-1',
        totalAmount: 10000,
        spent: 10000,
      };

      const alerts = calculator.generateAlerts(budget);

      expect(alerts.length).toBeGreaterThan(0);
      expect(alerts[0].type).toBe('exceeded');
    });
  });
});
