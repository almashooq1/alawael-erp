# 💾 Cache Service

Advanced caching with multi-level, invalidation, and warming.

## Features

- Distributed Caching
- Multi-level Cache (L1/L2)
- Cache Invalidation
- Cache Warming
- Cache Analytics
- Cache Statistics

## Usage

```bash
npm install
npm start
```

## Endpoints

- `GET /health` - Health check
- `GET /api/cache/:key` - Get cached value
- `POST /api/cache` - Set cached value
- `DELETE /api/cache/:key` - Invalidate cache
- `POST /api/cache/invalidate-pattern` - Invalidate by pattern
- `POST /api/cache/warm` - Add warming task
- `GET /api/cache/warming-tasks` - Get warming tasks
- `GET /api/cache/analytics` - Get cache analytics
- `GET /api/cache/stats` - Get cache statistics

## Environment Variables

- `PORT` - Service port (default: 3105)
