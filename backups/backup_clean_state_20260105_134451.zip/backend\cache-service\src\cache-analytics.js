/**
 * 📊 Cache Analytics
 * Track cache performance and usage
 */

class CacheAnalytics {
  constructor() {
    this.analytics = {
      requests: [],
      performance: {
        avgResponseTime: 0,
        totalRequests: 0,
      },
    };
  }

  trackRequest(key, hit, responseTime) {
    const request = {
      key,
      hit,
      responseTime,
      timestamp: new Date(),
    };

    this.analytics.requests.push(request);

    this.analytics.performance.totalRequests++;
    this.analytics.performance.avgResponseTime =
      (this.analytics.performance.avgResponseTime * (this.analytics.performance.totalRequests - 1) +
        responseTime) /
      this.analytics.performance.totalRequests;

    if (this.analytics.requests.length > 1000) {
      this.analytics.requests.shift();
    }
  }

  getAnalytics() {
    return this.analytics;
  }
}

module.exports = CacheAnalytics;
