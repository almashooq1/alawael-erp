/**
 * 🔄 Cache Invalidation
 * Smart cache invalidation strategies
 */

class CacheInvalidationStrategy {
  constructor(cache) {
    this.cache = cache;
    this.invalidationRules = [];
  }

  addRule(pattern, strategy) {
    this.invalidationRules.push({ pattern, strategy });
  }

  invalidate(key, operation) {
    this.invalidationRules.forEach(rule => {
      if (new RegExp(rule.pattern).test(key)) {
        switch (rule.strategy) {
          case 'exact':
            this.cache.invalidate(key);
            break;
          case 'pattern':
            this.cache.invalidatePattern(rule.pattern);
            break;
          case 'all':
            this.cache.invalidatePattern('.*');
            break;
        }
      }
    });
  }

  getRules() {
    return this.invalidationRules;
  }
}

module.exports = CacheInvalidationStrategy;
