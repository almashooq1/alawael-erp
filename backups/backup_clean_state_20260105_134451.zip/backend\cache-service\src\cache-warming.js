/**
 * 🔥 Cache Warming
 * Pre-populate cache with frequently accessed data
 */

class CacheWarmer {
  constructor(cache) {
    this.cache = cache;
    this.warmingTasks = [];
  }

  addWarmingTask(key, fetchFn, interval = 300000) {
    this.warmingTasks.push({
      key,
      fetchFn,
      interval,
      lastWarmed: null,
    });

    this.warm(key, fetchFn);

    setInterval(() => {
      this.warm(key, fetchFn);
    }, interval);
  }

  async warm(key, fetchFn) {
    try {
      const value = await fetchFn();
      this.cache.set(key, value);
      const task = this.warmingTasks.find(t => t.key === key);
      if (task) {
        task.lastWarmed = new Date();
      }
    } catch (error) {
      console.error(`Cache warming failed for ${key}:`, error);
    }
  }

  getTasks() {
    return this.warmingTasks;
  }
}

module.exports = CacheWarmer;
