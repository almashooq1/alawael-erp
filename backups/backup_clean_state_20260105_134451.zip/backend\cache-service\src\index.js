#!/usr/bin/env node
/**
 * 💾 Cache Service
 * Distributed caching with invalidation and warming
 */

const express = require('express');
const helmet = require('helmet');
const compression = require('compression');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');
const cors = require('cors');
const NodeCache = require('node-cache');

const app = express();

const PORT = process.env.PORT || 3105;

// ============================================
// Security Middleware
// ============================================
app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'"],
        scriptSrc: ["'self'", "'unsafe-inline'"],
        imgSrc: ["'self'", 'data:', 'https:'],
      },
    },
    crossOriginEmbedderPolicy: false,
  })
);

// ============================================
// Performance Middleware
// ============================================
app.use(
  compression({
    level: 6,
    threshold: 1024,
    filter: (req, res) => {
      if (req.headers['x-no-compression']) {
        return false;
      }
      return compression.filter(req, res);
    },
  })
);

// ============================================
// Logging Middleware
// ============================================
if (process.env.NODE_ENV === 'development') {
  app.use(morgan('dev'));
} else {
  app.use(morgan('combined'));
}

// ============================================
// Rate Limiting
// ============================================
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 200, // limit each IP to 200 requests per windowMs (higher for cache service)
  message: 'Too many requests from this IP, please try again later.',
  standardHeaders: true,
  legacyHeaders: false,
});

app.use('/api/', limiter);

// ============================================
// CORS
// ============================================
const allowedOrigins = process.env.ALLOWED_ORIGINS
  ? process.env.ALLOWED_ORIGINS.split(',').map(o => o.trim())
  : process.env.NODE_ENV === 'production'
    ? []
    : ['http://localhost:3000', 'http://localhost:5173'];

app.use(
  cors({
    origin: function (origin, callback) {
      if (!origin || process.env.NODE_ENV === 'development') {
        return callback(null, true);
      }
      if (allowedOrigins.includes(origin)) {
        callback(null, true);
      } else {
        callback(new Error('CORS: Origin not allowed'));
      }
    },
    credentials: true,
  })
);

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// ============================================
// Error Handling Middleware
// ============================================
app.use((err, req, res, next) => {
  console.error('Error:', err);
  res.status(err.status || 500).json({
    success: false,
    error: process.env.NODE_ENV === 'production' ? 'Internal server error' : err.message,
    timestamp: new Date().toISOString(),
  });
});

// Multi-level Cache
class MultiLevelCache {
  constructor() {
    // L1: In-memory cache (fastest)
    this.l1Cache = new NodeCache({ stdTTL: 300, checkperiod: 60 });

    // L2: Distributed cache (Redis would be used in production)
    this.l2Cache = new Map();

    // Cache statistics
    this.stats = {
      hits: { l1: 0, l2: 0, miss: 0 },
      sets: { l1: 0, l2: 0 },
      invalidations: 0,
    };
  }

  get(key) {
    // Try L1 first
    const l1Value = this.l1Cache.get(key);
    if (l1Value !== undefined) {
      this.stats.hits.l1++;
      return l1Value;
    }

    // Try L2
    const l2Value = this.l2Cache.get(key);
    if (l2Value !== undefined) {
      this.stats.hits.l2++;
      // Promote to L1
      this.l1Cache.set(key, l2Value);
      return l2Value;
    }

    this.stats.hits.miss++;
    return undefined;
  }

  set(key, value, ttl = 300) {
    // Set in both levels
    this.l1Cache.set(key, value, ttl);
    this.l2Cache.set(key, { value, expiresAt: Date.now() + ttl * 1000 });
    this.stats.sets.l1++;
    this.stats.sets.l2++;
  }

  invalidate(key) {
    this.l1Cache.del(key);
    this.l2Cache.delete(key);
    this.stats.invalidations++;
  }

  invalidatePattern(pattern) {
    const regex = new RegExp(pattern);

    // Invalidate L1
    const l1Keys = this.l1Cache.keys();
    l1Keys.forEach(key => {
      if (regex.test(key)) {
        this.l1Cache.del(key);
      }
    });

    // Invalidate L2
    const l2Keys = Array.from(this.l2Cache.keys());
    l2Keys.forEach(key => {
      if (regex.test(key)) {
        this.l2Cache.delete(key);
      }
    });

    this.stats.invalidations++;
  }

  getStats() {
    return {
      ...this.stats,
      l1Size: this.l1Cache.keys().length,
      l2Size: this.l2Cache.size,
      hitRate:
        (this.stats.hits.l1 + this.stats.hits.l2) /
          (this.stats.hits.l1 + this.stats.hits.l2 + this.stats.hits.miss) || 0,
    };
  }
}

const cache = new MultiLevelCache();

// Cache Warming
class CacheWarmer {
  constructor() {
    this.warmingTasks = [];
  }

  addWarmingTask(key, fetchFn, interval = 300000) {
    this.warmingTasks.push({
      key,
      fetchFn,
      interval,
      lastWarmed: null,
    });

    // Start warming
    this.warm(key, fetchFn);

    // Schedule periodic warming
    setInterval(() => {
      this.warm(key, fetchFn);
    }, interval);
  }

  async warm(key, fetchFn) {
    try {
      const value = await fetchFn();
      cache.set(key, value);
      const task = this.warmingTasks.find(t => t.key === key);
      if (task) {
        task.lastWarmed = new Date();
      }
      console.log(`🔥 Cache warmed: ${key}`);
    } catch (error) {
      console.error(`❌ Cache warming failed for ${key}:`, error);
    }
  }

  getTasks() {
    return this.warmingTasks;
  }
}

const cacheWarmer = new CacheWarmer();

// Cache Invalidation Strategy
class CacheInvalidationStrategy {
  constructor() {
    this.invalidationRules = [];
  }

  addRule(pattern, strategy) {
    this.invalidationRules.push({ pattern, strategy });
  }

  invalidate(key, operation) {
    this.invalidationRules.forEach(rule => {
      if (new RegExp(rule.pattern).test(key)) {
        switch (rule.strategy) {
          case 'exact':
            cache.invalidate(key);
            break;
          case 'pattern':
            cache.invalidatePattern(rule.pattern);
            break;
          case 'all':
            cache.invalidatePattern('.*');
            break;
        }
      }
    });
  }
}

const invalidationStrategy = new CacheInvalidationStrategy();

// Cache Analytics
class CacheAnalytics {
  constructor() {
    this.analytics = {
      requests: [],
      performance: {
        avgResponseTime: 0,
        totalRequests: 0,
      },
    };
  }

  trackRequest(key, hit, responseTime) {
    const request = {
      key,
      hit,
      responseTime,
      timestamp: new Date(),
    };

    this.analytics.requests.push(request);

    // Update performance metrics
    this.analytics.performance.totalRequests++;
    this.analytics.performance.avgResponseTime =
      (this.analytics.performance.avgResponseTime * (this.analytics.performance.totalRequests - 1) +
        responseTime) /
      this.analytics.performance.totalRequests;

    // Keep only last 1000 requests
    if (this.analytics.requests.length > 1000) {
      this.analytics.requests.shift();
    }
  }

  getAnalytics() {
    return {
      ...this.analytics,
      cacheStats: cache.getStats(),
    };
  }
}

const cacheAnalytics = new CacheAnalytics();

// Health check
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'cache-service',
    timestamp: new Date(),
    cache: cache.getStats(),
  });
});

// Cache operations
app.get('/api/cache/:key', (req, res) => {
  const startTime = Date.now();
  const value = cache.get(req.params.key);
  const responseTime = Date.now() - startTime;

  cacheAnalytics.trackRequest(req.params.key, value !== undefined, responseTime);

  if (value === undefined) {
    return res.status(404).json({ error: 'Key not found' });
  }

  res.json({ key: req.params.key, value });
});

app.post('/api/cache', (req, res) => {
  const { key, value, ttl } = req.body;
  if (!key || value === undefined) {
    return res.status(400).json({ error: 'key and value are required' });
  }

  cache.set(key, value, ttl || 300);
  res.json({ success: true, key });
});

app.delete('/api/cache/:key', (req, res) => {
  cache.invalidate(req.params.key);
  res.json({ success: true, key: req.params.key });
});

app.post('/api/cache/invalidate-pattern', (req, res) => {
  const { pattern } = req.body;
  if (!pattern) {
    return res.status(400).json({ error: 'pattern is required' });
  }

  cache.invalidatePattern(pattern);
  res.json({ success: true, pattern });
});

// Cache warming
app.post('/api/cache/warm', (req, res) => {
  const { key, fetchFn, interval } = req.body;
  if (!key || !fetchFn) {
    return res.status(400).json({ error: 'key and fetchFn are required' });
  }

  // In production, fetchFn would be a function reference
  // For now, we'll just add the task
  cacheWarmer.addWarmingTask(
    key,
    async () => {
      // This would call the actual fetch function
      return { data: 'warmed' };
    },
    interval || 300000
  );

  res.json({ success: true, key });
});

app.get('/api/cache/warming-tasks', (req, res) => {
  res.json(cacheWarmer.getTasks());
});

// Cache analytics
app.get('/api/cache/analytics', (req, res) => {
  res.json(cacheAnalytics.getAnalytics());
});

// Cache stats
app.get('/api/cache/stats', (req, res) => {
  res.json(cache.getStats());
});

// Root endpoint
app.get('/', (req, res) => {
  res.json({
    name: 'Cache Service',
    version: '1.0.0',
    description: 'Advanced caching with multi-level, invalidation, and warming',
    features: [
      'Distributed Caching',
      'Multi-level Cache',
      'Cache Invalidation',
      'Cache Warming',
      'Cache Analytics',
      'Cache Statistics',
    ],
    endpoints: {
      health: '/health',
      cache: '/api/cache',
      warming: '/api/cache/warm',
      analytics: '/api/cache/analytics',
      stats: '/api/cache/stats',
    },
  });
});

app.listen(PORT, () => {
  console.log(`💾 Cache Service running on port ${PORT}`);
  console.log(`💚 Health: http://localhost:${PORT}/health`);
  console.log(`📊 Stats: http://localhost:${PORT}/api/cache/stats`);
});
