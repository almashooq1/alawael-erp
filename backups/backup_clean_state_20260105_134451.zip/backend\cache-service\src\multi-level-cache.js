/**
 * 💾 Multi-level Cache
 * L1 (in-memory) and L2 (distributed) cache
 */

const NodeCache = require('node-cache');

class MultiLevelCache {
  constructor() {
    this.l1Cache = new NodeCache({ stdTTL: 300, checkperiod: 60 });
    this.l2Cache = new Map();
    this.stats = {
      hits: { l1: 0, l2: 0, miss: 0 },
      sets: { l1: 0, l2: 0 },
      invalidations: 0,
    };
  }

  get(key) {
    const l1Value = this.l1Cache.get(key);
    if (l1Value !== undefined) {
      this.stats.hits.l1++;
      return l1Value;
    }

    const l2Value = this.l2Cache.get(key);
    if (l2Value !== undefined) {
      this.stats.hits.l2++;
      this.l1Cache.set(key, l2Value.value);
      return l2Value.value;
    }

    this.stats.hits.miss++;
    return undefined;
  }

  set(key, value, ttl = 300) {
    this.l1Cache.set(key, value, ttl);
    this.l2Cache.set(key, { value, expiresAt: Date.now() + ttl * 1000 });
    this.stats.sets.l1++;
    this.stats.sets.l2++;
  }

  invalidate(key) {
    this.l1Cache.del(key);
    this.l2Cache.delete(key);
    this.stats.invalidations++;
  }

  invalidatePattern(pattern) {
    const regex = new RegExp(pattern);

    this.l1Cache.keys().forEach(key => {
      if (regex.test(key)) {
        this.l1Cache.del(key);
      }
    });

    Array.from(this.l2Cache.keys()).forEach(key => {
      if (regex.test(key)) {
        this.l2Cache.delete(key);
      }
    });

    this.stats.invalidations++;
  }

  getStats() {
    return {
      ...this.stats,
      l1Size: this.l1Cache.keys().length,
      l2Size: this.l2Cache.size,
      hitRate:
        (this.stats.hits.l1 + this.stats.hits.l2) /
          (this.stats.hits.l1 + this.stats.hits.l2 + this.stats.hits.miss) || 0,
    };
  }
}

module.exports = MultiLevelCache;
