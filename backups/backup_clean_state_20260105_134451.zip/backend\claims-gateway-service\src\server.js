import Fastify from 'fastify';
import { createRequire } from 'module';
import { randomUUID } from 'crypto';
import { attachErrorHandler, notFound } from '../../shared/http/errors.js';
import { applySecurityHeaders, makeRouteRateLimiter } from '../../shared/http/security.js';
import { EventBus } from '../../shared/event-bus/index.js';
import {
  sanitizeInputs,
  trackRequest,
  errorHandler,
} from '../../shared/middleware/security-middleware-fastify-es6.js';
import { ClaimsEvents, HealthcareEvents } from '../../shared/event-schemas/types.js';
import { validate as validateEvent } from '../../shared/event-schemas/registry.js';
import events from '../../shared/events/index.js';
import { requireAuth } from '../../shared/http/auth.js';
import { buildReadyHandler } from '../../shared/http/ready.js';

const { createCloudEvent } = events;

const bus = new EventBus({});
const claims = new Map(); // id -> { id, status, payer, amount, ... }

function registerMetrics(fastify) {
  try {
    const requireCJS = createRequire(import.meta.url);

    const prom = (globalThis.__promClient ||= requireCJS('prom-client'));
    if (process.env.METRICS_DEFAULTS === 'true' && !globalThis.__metricsDefaultsRegistered) {
      try {
        prom.collectDefaultMetrics({ prefix: process.env.METRICS_PREFIX || '' });
        globalThis.__metricsDefaultsRegistered = true;
      } catch {}
    }
    const statusGauge = new prom.Gauge({
      name: 'claims_total',
      help: 'Total claims',
      labelNames: ['status'],
    });
    const refresh = () => {
      const counts = { submitted: 0, acknowledged: 0, denied: 0, paid: 0 };
      for (const c of claims.values()) {
        counts[c.status] = (counts[c.status] || 0) + 1;
      }
      for (const [k, v] of Object.entries(counts)) {
        statusGauge.set({ status: k }, v);
      }
    };
    setInterval(refresh, 5000).unref?.();
    fastify.get('/metrics', async (_req, reply) => {
      refresh();
      reply.header('Content-Type', prom.register.contentType);
      reply.send(await prom.register.metrics());
    });
  } catch {}
}

export function createServer() {
  const fastify = Fastify({ logger: true, ignoreTrailingSlash: true });

  // Security Middleware
  fastify.addHook('onRequest', sanitizeInputs);
  fastify.addHook('onRequest', trackRequest);
  fastify.setErrorHandler(errorHandler);

  if (process.env.METRICS_ENABLED === 'true') {
    registerMetrics(fastify);
  }
  applySecurityHeaders(fastify);
  attachErrorHandler(fastify);
  const rateLimit = makeRouteRateLimiter({ windowMs: 60000, max: 50 });
  const auth = requireAuth();

  fastify.get('/health', async () => ({ status: 'ok', integrations: ['payer-stub'] }));
  // Readiness: env, metrics, claims counts by status, simulated backlog & forced fail
  fastify.get(
    '/ready',
    buildReadyHandler({
      serviceName: 'claims-gateway-service',
      checks: [
        { name: 'env.NODE_ENV', check: () => !!process.env.NODE_ENV },
        { name: 'env.METRICS_ENABLED', check: () => process.env.METRICS_ENABLED === 'true' },
        {
          name: 'claims.counts',
          check: () => {
            const counts = { submitted: 0, acknowledged: 0, denied: 0, paid: 0 };
            for (const c of claims.values()) {
              counts[c.status] = (counts[c.status] || 0) + 1;
            }
            return { ok: claims.size >= 0, details: counts };
          },
        },
        {
          name: 'claims.backlog.simulated',
          check: () => {
            const backlog = Number.parseInt(process.env.CLAIMS_GATEWAY_BACKLOG_SIZE || '0', 10);
            const ok = Number.isFinite(backlog) ? backlog < 75000 : true;
            return { ok, details: { backlog: Number.isFinite(backlog) ? backlog : 0 } };
          },
        },
        {
          name: 'forcedFail',
          check: () => {
            const flag = process.env.CLAIMS_GATEWAY_FORCE_FAIL === 'true';
            return { ok: flag ? false : true, details: { flag } };
          },
        },
      ],
    })
  );

  // Submit claim
  fastify.post('/claims/submit', { preHandler: [auth, rateLimit] }, async (req, reply) => {
    const body = req.body || {};
    const id = randomUUID();
    const claim = {
      id,
      status: 'submitted',
      amount: body.amount || 0,
      payer: body.payer || 'default',
      patient: body.patient || null,
    };
    claims.set(id, claim);
    await bus.publish({
      topic: 'claims',
      event: { type: ClaimsEvents.CLAIM_SUBMITTED, id, amount: claim.amount },
    });
    reply.code(202).send({ id, status: claim.status });
  });

  fastify.get('/claims/:id/status', async (req, reply) => {
    const c = claims.get(req.params.id);
    if (!c) {
      return notFound(reply, 'Claim not found');
    }
    return { id: c.id, status: c.status };
  });

  // Simulate status transitions for demo/testing
  fastify.post('/claims/:id/_simulate', { preHandler: [auth, rateLimit] }, async (req, reply) => {
    const c = claims.get(req.params.id);
    if (!c) {
      return notFound(reply, 'Claim not found');
    }
    const { status } = req.body || {};
    c.status = status;
    if (status === 'acknowledged') {
      await bus.publish({
        topic: 'claims',
        event: { type: ClaimsEvents.CLAIM_ACKNOWLEDGED, id: c.id },
      });
    }
    if (status === 'paid') {
      await bus.publish({ topic: 'claims', event: { type: ClaimsEvents.CLAIM_PAID, id: c.id } });
      const pevt = createCloudEvent({
        type: HealthcareEvents.PAYMENT_RECEIVED,
        source: 'claims-gateway-service',
        subject: `Claim/${c.id}`,
        data: { claimId: c.id, amount: c.amount || 0, payer: c.payer || 'default' },
      });
      try {
        const res = await validateEvent('payment.received.v1', pevt);
        if (!res.ok) {
          fastify.log?.warn?.({ errors: res.errors }, 'event.validation.failed');
        } else {
          await bus.publish('fhir.events', pevt);
        }
      } catch (e) {
        fastify.log?.warn?.({ err: String(e) }, 'event.validation.error');
        await bus.publish('fhir.events', pevt);
      }
    }
    if (status === 'denied') {
      await bus.publish({ topic: 'claims', event: { type: ClaimsEvents.CLAIM_DENIED, id: c.id } });
    }
    return { id: c.id, status: c.status };
  });

  return fastify;
}

if (process.argv[1] && process.argv[1].endsWith('server.js')) {
  const port = Number(process.env.PORT || 3075);
  createServer().listen({ port, host: '0.0.0.0' }, (err, address) => {
    if (err) {
      console.error('claims-gateway-service failed', err);
      return;
    }
    console.log('claims-gateway-service listening at', address);
  });
}

// Error Handling
const { errorHandler, notFoundHandler } = require('../../shared/middleware/error-handler');

// 404 handler (must be after all routes)

// API Documentation
const { swaggerSetup } = require('../../shared/docs/swagger-config');
swaggerSetup(app);

app.use(notFoundHandler);

// Error handler (must be last)
app.use(errorHandler);
