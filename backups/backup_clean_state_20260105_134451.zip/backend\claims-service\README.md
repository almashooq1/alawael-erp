# claims-service

Fastify-based microservice for claims endpoints with idempotent status updates.

## Endpoints

- GET /health
- GET /claims
- POST /claims
- PATCH /claims/:id/status (requires Idempotency-Key header)

## Run

1. Install deps:
   npm install
2. Start:
   npm start

Notes: In-memory store and stub publisher; replace with DB + outbox.

## Environment & Observability

- In development, the service auto-loads `.env` via `shared/env.js`.
- Observability (Sentry + Application Insights) initializes at startup; set `SENTRY_DSN` and `APPINSIGHTS_INSTRUMENTATIONKEY` in `.env`.
- Optional: enable NATS by setting `EVENT_BUS_IMPL=nats` and `NATS_SERVERS`.
