// Claims repository with Postgres or in-memory fallback
import { Pool } from 'pg';
import { SafeDBHelper } from '../../shared/database/safe-db-helper-es6.js';

function toDb(claim) {
  return {
    id: claim.id,
    patient_id: claim.patientId,
    session_id: claim.sessionId,
    lines: JSON.stringify(claim.lines || []),
    status: claim.status,
    submitted_at: claim.submittedAt,
    updated_at: claim.updatedAt,
    notes_encrypted: claim.notesEncrypted,
  };
}

function fromDb(row) {
  let lines = [];
  try {
    lines = typeof row.lines === 'string' ? JSON.parse(row.lines) : row.lines || [];
  } catch {}
  return {
    id: row.id,
    patientId: row.patient_id,
    sessionId: row.session_id,
    lines,
    status: row.status,
    submittedAt: row.submitted_at,
    updatedAt: row.updated_at,
    notesEncrypted: row.notes_encrypted,
  };
}

// Table creation removed; rely on SQL migrations.

function createPgRepo({ logger }) {
  const pool = new Pool({ connectionString: process.env.DATABASE_URL });
  const dbHelper = new SafeDBHelper(pool);
  let ready = false;
  async function init() {
    if (!ready) {
      // Assume schema exists via migrations
      ready = true;
      logger.info?.('claims repo: connected to Postgres');
    }
  }
  return {
    async create(claim) {
      await init();
      const db = toDb(claim);
      const fields = Object.keys(db);
      const vals = Object.values(db);
      const placeholders = fields.map((_, i) => `$${i + 1}`).join(',');
      await pool.query(`INSERT INTO claims(${fields.join(',')}) VALUES (${placeholders})`, vals);
      return claim.id;
    },
    async list() {
      await init();
      const res = await pool.query('SELECT * FROM claims ORDER BY submitted_at DESC LIMIT 200');
      return res.rows.map(fromDb);
    },
    async getById(id) {
      await init();
      const rows = await dbHelper.safeSelect('claims', {
        where: { id },
        limit: 1,
      });
      return rows[0] ? fromDb(rows[0]) : null;
    },
    async updateStatus(id, newStatus) {
      await init();
      const res = await pool.query(
        'UPDATE claims SET status=$2, updated_at=now() WHERE id=$1 RETURNING status as new_status',
        [id, newStatus]
      );
      return res.rowCount > 0;
    },
  };
}

function createMemoryRepo() {
  const store = new Map();
  return {
    async create(claim) {
      store.set(claim.id, claim);
      return claim.id;
    },
    async list() {
      return Array.from(store.values());
    },
    async getById(id) {
      return store.get(id) || null;
    },
    async updateStatus(id, newStatus) {
      const c = store.get(id);
      if (!c) {
        return false;
      }
      c.status = newStatus;
      c.updatedAt = new Date().toISOString();
      store.set(id, c);
      return true;
    },
  };
}

export function createClaimsRepo({ logger = console } = {}) {
  if (process.env.DATABASE_URL) {
    return createPgRepo({ logger });
  }
  return createMemoryRepo();
}
