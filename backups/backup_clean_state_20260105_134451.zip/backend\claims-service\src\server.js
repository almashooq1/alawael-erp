/**
 * @file Claims Service Server
 * Main entry for the claims microservice using Fastify.
 * -----------------------------------------------------
 * Handles insurance claims registration, listing, and event publishing.
 * Integrates metrics, tracing, outbox pattern, and event bus for reliability.
 * All endpoints are documented inline. Security and best practices enforced.
 *
 * @example
 * // Start the server (from CLI)
 * $ node backend/claims-service/src/server.js
 *
 * @example
 * // Import and use in another module
 * const { createServer } = require('./server');
 * const fastify = createServer();
 * if (process.env.NODE_ENV !== 'test') {
  fastify.listen({ port: 3003 });
   *
   * @see {@link https://www.fastify.io/docs/latest/ Fastify Documentation}
   * @see {@link https://github.com/almashooq1/66666 Project Repository}
   *
   * @section Main Variables
   * @property {Logger} logger - Main logger instance for service logging.
   * @property {EventBus} bus - Event bus for publishing and subscribing to events.
   * @property {ClaimsRepo} repo - Repository for claims data operations.
   * @property {Outbox} outbox - Outbox pattern for reliable event publishing.
   * @property {Map} idempotency - In-memory idempotency cache for requests.
   *
   * @section Service Endpoints
   * - /claims: List all claims (GET).
   * - /metrics: Expose Prometheus metrics.
   * - /health, /ready: Service health and readiness checks.
   *
   * @section Security
   * - Authentication enforced via requireAuth middleware.
   * - Security headers and rate limiting applied to sensitive endpoints.
   *
   * @section Notes
   * - All endpoints are documented inline with JSDoc.
   * - For more details, see inline documentation for each function and endpoint.
   */
}
const Fastify = require('fastify');
// Security Middleware
const helmetConfig = require('../../shared/middleware/security/helmet-config');
const corsConfig = require('../../shared/middleware/security/cors-config');
const { apiLimiter } = require('../../shared/middleware/security/rate-limiter');
const securityHeaders = require('../../shared/middleware/security/security-headers');


const { initObservability } = require('../../shared/observability.js');
const { initEnv } = require('../../shared/env.js');
const { createLogger } = require('../../shared/logging/index.js');
const { v4: uuidv4 } = require('uuid');
const hash = require('object-hash');
const { sanitizeInputs, trackRequest, errorHandler } = require('../../shared/middleware/security-middleware-fastify');
// const { fileURLToPath } = require('url'); // Only if needed
const { EventBus } = require('../../shared/event-bus/index.js');
const { createEnvelope, withMeta } = require('../../shared/events/index.js');
const { initTracing, withSpan } = require('../../shared/otel/index.js');
const { Outbox, startPeriodicFlush } = require('../../shared/outbox/index.js');
const { encrypt } = require('../../shared/crypto/encryption.js');
const { auditLog } = require('../../shared/security/audit.js');
const { createClaimsRepo } = require('./repo.js');
const { getCounter } = require('../../shared/metrics/index.js');
const { createRequire } = require('module');
const { applySecurityHeaders, makeRouteRateLimiter } = require('../../shared/http/security.js');
const { attachErrorHandler, badRequest, notFound } = require('../../shared/http/errors.js');
const { requireAuth } = require('../../shared/http/auth.js');
const { buildReadyHandler } = require('../../shared/http/ready.js');

function cryptoRandomId() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

// Initialize environment and observability once at startup
initEnv();
initObservability();
const logger = createLogger();
initTracing({ serviceName: 'claims-service' });
function createServer() {
  const fastify = Fastify({ logger });
  fastify.addHook('onRequest', async (req, _reply) => {
    req.requestId = req.headers['x-request-id'] || cryptoRandomId();
    req.userId = req.headers['x-user-id'] || 'anonymous';
  });
  const bus = new EventBus({ logger });
  const repo = createClaimsRepo({ logger });
  const idempotency = new Map();
  const outbox = new Outbox({ logger, bus, serviceName: 'claims-service' });
  startPeriodicFlush(outbox, process.env.OUTBOX_INTERVAL_MS || 0);
  // Inline metrics registration (global prom-client)
  if (process.env.METRICS_ENABLED === 'true') {
    try {
      const requireCJS = createRequire(__filename);

      const prom = (globalThis.__promClient ||= requireCJS('prom-client'));
      if (process.env.METRICS_DEFAULTS === 'true') {
        prom.collectDefaultMetrics({ prefix: process.env.METRICS_PREFIX || '' });
      }
      const httpReqCounter = new prom.Counter({
        name: 'service_http_requests_total',
        help: 'Total HTTP requests',
        labelNames: ['service', 'method', 'route', 'status']
      });
      fastify.addHook('onResponse', (req, reply, done) => {
        try {
          const route = (req.routeOptions && req.routeOptions.url) || req.url || 'unknown';
          httpReqCounter.inc({
            service: 'claims-service',
            method: req.method,
            route,
            status: String(reply.statusCode)
          });
        } catch {}
        done();
      });
      fastify.get('/metrics', async (_req, reply) => {
        try {
          reply.header('Content-Type', prom.register.contentType);
          reply.send(await prom.register.metrics());
        } catch (err) {
          reply.code(500).send({ error: 'metrics_error', details: String(err) });
        }
      });
    } catch (err) {
      fastify.log.warn({ err: String(err) }, 'metrics-registration-failed');
    }
  }
  fastify.get('/event-bus/health', async () => bus.getHealth());

  async function stageEvent(event) {
    await outbox.enqueue({ topic: 'claims.events', event });
  }

  fastify.get('/health', async () => ({ status: 'ok' }));
  // Readiness endpoint with env + queue backlog + forced fail simulation
  fastify.get(
    '/ready',
    buildReadyHandler({
      serviceName: 'claims-service',
      checks: [
        { name: 'env.NODE_ENV', check: () => !!process.env.NODE_ENV },
        { name: 'env.METRICS_ENABLED', check: () => process.env.METRICS_ENABLED === 'true' },
        {
          name: 'outbox.memQueue',
          check: () => ({
            ok: Array.isArray(outbox._mem) ? outbox._mem.length < 20000 : true,
            details: { pending: Array.isArray(outbox._mem) ? outbox._mem.length : 0 }
          })
        },
        {
          name: 'claims.backlog.simulated',
          check: () => {
            const backlog = Number.parseInt(process.env.CLAIMS_BACKLOG_SIZE || '0', 10);
            const ok = Number.isFinite(backlog) ? backlog < 5000 : true;
            return { ok, details: { backlog: Number.isFinite(backlog) ? backlog : 0 } };
          }
        },
        {
          name: 'forcedFail',
          check: () => ({
            ok: process.env.CLAIMS_FORCE_FAIL === 'true' ? false : true,
            details: { flag: process.env.CLAIMS_FORCE_FAIL === 'true' }
          })
        }
      ]
    })
  );
  fastify.get('/claims', async () => repo.list());

  // Security headers & rate limiting (debug route)
  applySecurityHeaders(fastify);
  const debugRateLimit = makeRouteRateLimiter({ windowMs: 60000, max: 20 });
  attachErrorHandler(fastify);
  const auth = requireAuth();

  // Metrics counters
  const claimsSubmittedCounter = getCounter('claims_submitted_total', {
    description: 'Total claims submitted'
  });
  const claimStatusChangedCounter = getCounter('claim_status_changed_total', {
    description: 'Total claim status changes'
  });

  fastify.post(
    '/claims',
    {
      preHandler: auth,
      schema: {
        body: {
          type: 'object',
          required: ['patientId', 'sessionId'],
          properties: {
            id: { type: 'string' },
            patientId: { type: 'string', minLength: 1 },
            sessionId: { type: 'string', minLength: 1 },
            lines: {
              type: 'array',
              items: {
                type: 'object',
                additionalProperties: true
              }
            },
            notes: { type: 'string' }
          },
          additionalProperties: false
        },
        response: {
          201: { type: 'object', required: ['id'], properties: { id: { type: 'string' } } }
        }
      }
    },
    async (request, reply) =>
      withSpan('submit_claim', async () => {
        const body = request.body || {};
        const id = body.id || uuidv4();
        const claim = {
          id,
          patientId: body.patientId,
          sessionId: body.sessionId,
          lines: Array.isArray(body.lines) ? body.lines : [],
          status: 'SUBMITTED',
          submittedAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          notesEncrypted: body.notes ? encrypt(body.notes) : null
        };
        await repo.create(claim);
        claimsSubmittedCounter.add(1, { service: 'claims-service' });
        stageEvent(
          createEnvelope({
            type: 'CLAIM_SUBMITTED',
            source: 'claims-service',
            payload: withMeta(
              { claimId: id },
              {
                requestId: request.requestId,
                userId: request.userId
              }
            )
          })
        );
        auditLog(logger, {
          action: 'submit_claim',
          route: '/claims',
          resourceId: id,
          userId: request.userId,
          details: { requestId: request.requestId }
        });
        reply.code(201);
        return { id };
      })
  );

  fastify.patch(
    '/claims/:id/status',
    {
      preHandler: auth,
      schema: {
        params: {
          type: 'object',
          required: ['id'],
          properties: { id: { type: 'string' } },
          additionalProperties: false
        },
        body: {
          type: 'object',
          required: ['newStatus'],
          properties: {
            newStatus: {
              type: 'string',
              enum: ['SUBMITTED', 'PROCESSING', 'APPROVED', 'REJECTED']
            }
          },
          additionalProperties: false
        },
        headers: {
          type: 'object',
          properties: { 'idempotency-key': { type: 'string' } },
          required: ['idempotency-key']
        }
      }
    },
    async (request, reply) =>
      withSpan('update_claim_status', async () => {
        const { id } = request.params;
        const { newStatus } = request.body || {};
        const idemKey = request.headers['idempotency-key'];
        if (!idemKey) {
          return badRequest(reply, 'Idempotency-Key required');
        }

        const bodyHash = hash({ id, newStatus });
        const existing = idempotency.get(idemKey);
        if (existing) {
          if (existing.hash === bodyHash) {
            return reply.code(existing.code).send(existing.response);
          }
          return reply.code(409).send({ error: 409, message: 'Idempotency-Key conflict' });
        }

        const claim = await repo.getById(id);
        if (!claim) {
          return notFound(reply, 'Claim not found');
        }

        const oldStatus = claim.status;
        await repo.updateStatus(id, newStatus);
        claim.status = newStatus; // local object mutation for event/audit
        claim.updatedAt = new Date().toISOString();
        stageEvent(
          createEnvelope({
            type: 'CLAIM_STATUS_CHANGED',
            source: 'claims-service',
            payload: withMeta(
              {
                claimId: id,
                oldStatus,
                newStatus,
                changedAt: new Date().toISOString()
              },
              { requestId: request.requestId, userId: request.userId }
            )
          })
        );
        claimStatusChangedCounter.add(1, { service: 'claims-service', oldStatus, newStatus });

        const response = { id, status: newStatus };
        idempotency.set(idemKey, { hash: bodyHash, code: 200, response });
        auditLog(logger, {
          action: 'update_claim_status',
          route: `/claims/${id}/status`,
          resourceId: id,
          userId: request.userId,
          details: { oldStatus, newStatus, requestId: request.requestId }
        });
        return response;
      })
  );

  // Test-only flush helper (excluded in production)
  if (process.env.NODE_ENV !== 'production') {
    fastify.post(
      '/debug/outbox/flush',
      {
        preHandler: debugRateLimit,
        schema: {
          querystring: {
            type: 'object',
            properties: { limit: { type: 'integer', minimum: 1, maximum: 1000 } },
            additionalProperties: false
          }
        }
      },
      async (request, reply) => {
        let limit = Number.parseInt(request.query?.limit ?? '100', 10);
        if (!Number.isInteger(limit)) {
          limit = 100;
        }
        if (limit < 1 || limit > 1000) {
          return reply.code(400).send({ error: 'limit must be an integer between 1 and 1000' });
        }
        const flushed = await outbox.flushBatch(limit);
        return { flushed };
      }
    );
  }

  // Test-only debug helpers disabled in production
  if (process.env.NODE_ENV !== 'production') {
    // Debug helper to enqueue synthetic outbox events for testing without DB
    fastify.post(
      '/debug/outbox/enqueue',
      {
        preHandler: debugRateLimit,
        schema: {
          body: {
            type: 'object',
            properties: { count: { type: 'integer', minimum: 1, maximum: 1000 } },
            additionalProperties: false
          }
        }
      },
      async (request, reply) => {
        const count = Math.min(Math.max(Number(request.body?.count ?? 1), 1), 1000);
        const now = new Date().toISOString();
        for (let i = 0; i < count; i++) {
          await stageEvent(
            createEnvelope({
              type: 'CLAIM_SUBMITTED',
              source: 'claims-service',
              payload: withMeta(
                {
                  id: cryptoRandomId(),
                  at: now
                },
                { userId: 'debug' }
              )
            })
          );
        }
        return reply.code(202).send({ enqueued: count });
      }
    );

    // Debug helper to directly simulate publish latency histogram observations
    fastify.post(
      '/debug/metrics/simulate-publish',
      {
        preHandler: debugRateLimit,
        schema: {
          body: {
            type: 'object',
            properties: {
              count: { type: 'integer', minimum: 1, maximum: 10000 },
              valueSeconds: { type: 'number', minimum: 0 }
            },
            additionalProperties: false
          }
        }
      },
      async (request, reply) => {
        try {
          const requireCJS = createRequire(import.meta.url);

          const prom = (globalThis.__promClient ||= requireCJS('prom-client'));
          const hist = prom.register.getSingleMetric('outbox_publish_latency_seconds');
          if (!hist) {
            return reply.code(500).send({ error: 'histogram_not_found' });
          }
          const count = Math.min(Math.max(Number(request.body?.count ?? 5), 1), 10000);
          const val = Number.isFinite(request.body?.valueSeconds) ? Number(request.body.valueSeconds) : 0.02;
          for (let i = 0; i < count; i++) {
            hist.observe({ service: 'claims-service', topic: 'debug', outcome: 'success' }, val);
          }
          return reply.code(202).send({ observed: count, valueSeconds: val });
        } catch (err) {
          return reply.code(500).send({ error: 'simulate_failed', details: String(err) });
        }
      }
    );
  }

  return fastify;
}

if (require.main === module) {
  const fastify = createServer();
  const port = Number(process.env.PORT || 3003);
  fastify.listen({ port, host: '0.0.0.0' }, (err, address) => {
    if (err) {
      logger.error(err, 'server failed to start');
      process.exit(1);
    }
    logger.info(`claims-service listening on ${port}`);
  });
}

module.exports = { createServer };

// Error Handling
const { errorHandler, notFoundHandler } = require('../../shared/middleware/error-handler');


// 404 handler (must be after all routes)

// API Documentation
const { swaggerSetup } = require('../../shared/docs/swagger-config');
swaggerSetup(app);

app.use(notFoundHandler);

// Error handler (must be last)
app.use(errorHandler);
