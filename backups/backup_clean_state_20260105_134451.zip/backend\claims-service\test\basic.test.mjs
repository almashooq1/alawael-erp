import { expect } from 'chai';
import { toDb, fromDb } from '../src/repo.js';

describe('Claims Service - repo', function () {
  it('should convert a claim to DB format', function () {
    const claim = {
      id: 1,
      patientId: 'p1',
      sessionId: 's1',
      lines: [{ code: 'A', amount: 100 }],
      status: 'submitted',
      submittedAt: '2025-11-27T10:00:00Z',
      updatedAt: '2025-11-27T11:00:00Z',
      notesEncrypted: 'secret',
    };
    const db = toDb(claim);
    expect(db.patient_id).toBe('p1');
    expect(db.session_id).toBe('s1');
    expect(db.lines).toBe(JSON.stringify([{ code: 'A', amount: 100 }]));
    expect(db.status).toBe('submitted');
    expect(db.notes_encrypted).toBe('secret');
  });

  it('should convert DB row to claim format', function () {
    const row = {
      id: 1,
      patient_id: 'p1',
      session_id: 's1',
      lines: JSON.stringify([{ code: 'A', amount: 100 }]),
      status: 'submitted',
      submitted_at: '2025-11-27T10:00:00Z',
      updated_at: '2025-11-27T11:00:00Z',
      notes_encrypted: 'secret',
    };
    const claim = fromDb(row);
    expect(claim.patientId).toBe('p1');
    expect(claim.sessionId).toBe('s1');
    expect(claim.lines).toEqual([{ code: 'A', amount: 100 }]);
    expect(claim.status).toBe('submitted');
    expect(claim.notesEncrypted).toBe('secret');
  });

  it('should handle invalid lines gracefully', function () {
    const row = { lines: 'not-a-json' };
    const claim = fromDb(row);
    expect(claim.lines).toEqual([]);
  });
});
