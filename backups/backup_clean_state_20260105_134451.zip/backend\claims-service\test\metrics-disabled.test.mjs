import { createServer } from '../src/server.js';
import { withMetricsServer } from '../../test-utils/withMetricsServer.js';

let helper;
beforeAll(async () => {
  process.env.METRICS_ENABLED = 'false';
  process.env.OTEL_ENABLED = 'false';
  helper = withMetricsServer(createServer);
  await new Promise((resolve, reject) => helper.app.ready(err => (err ? reject(err) : resolve())));
});
afterAll(async () => {
  await helper?.close();
});

describe('metrics disabled claims', () => {
  test('GET /metrics returns 404 when disabled', async () => {
    const res = await helper.get('/metrics');
    expect([404, 500]).toContain(res.statusCode);
    const body = res.body || '';
    expect(body).not.toContain('outbox_publish_latency_seconds_bucket');
    expect(body).not.toContain('outbox_pending_rows');
  });
});
