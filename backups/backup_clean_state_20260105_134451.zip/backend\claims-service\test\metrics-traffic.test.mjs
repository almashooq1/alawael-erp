import { createServer } from '../src/server.js';
import { withMetricsServer } from '../../test-utils/withMetricsServer.js';

let helper;
beforeAll(async () => {
  process.env.METRICS_ENABLED = 'true';
  process.env.OTEL_ENABLED = 'false';
  process.env.DATABASE_URL = '';
  process.env.CLAIMS_DATABASE_URL = '';
  helper = withMetricsServer(createServer);
  await helper.waitForMetrics();
});
afterAll(async () => {
  await helper?.close();
});

function extractMetricLines(text, name) {
  return (text || '')
    .split(/\n/)
    .map(l => l.trim())
    .filter(l => l.startsWith(name + '{') || l.startsWith(name + ' '));
}
function parsePromLine(line) {
  const m = line.match(/^(\w+)(?:\{([^}]*)\})?\s+([0-9.eE+-]+)$/);
  if (!m) {
    return null;
  }
  const labels = {};
  if (m[2]) {
    m[2].split(/,(?=(?:[^"\\]|\\.|"[^"]*")*$)/).forEach(kv => {
      const [k, v] = kv.split('=');
      if (k && v) {
        labels[k.trim()] = v.replace(/^"|"$/g, '').trim();
      }
    });
  }
  return { name: m[1], value: Number(m[3]), labels };
}
function findCount(body, service) {
  const lines = extractMetricLines(body, 'outbox_publish_latency_seconds_count');
  for (const l of lines) {
    const parsed = parsePromLine(l);
    if (!parsed) {
      continue;
    }
    const { labels, value } = parsed;
    if (labels.service === service && labels.topic === 'debug' && labels.outcome === 'success') {
      return value;
    }
  }
  return 0;
}
function hasNonZero(lines) {
  return lines.some(l => /\s([0-9]*[1-9][0-9]*(?:\.[0-9]+)?)$/.test(l));
}

describe('metrics traffic claims', () => {
  test('publish latency histogram count increases after simulated events', async () => {
    const sim = await helper.post('/debug/metrics/simulate-publish', {
      count: 5,
      valueSeconds: 0.05,
    });
    expect(sim.statusCode).toBe(202);
    const m = await helper.get('/metrics');
    expect(m.statusCode).toBe(200);
    const body = m.body || '';
    const bucketLines = extractMetricLines(body, 'outbox_publish_latency_seconds_bucket');
    const countLines = extractMetricLines(body, 'outbox_publish_latency_seconds_count');
    const sumLines = extractMetricLines(body, 'outbox_publish_latency_seconds_sum');
    expect(bucketLines.length + countLines.length).toBeGreaterThan(0);
    expect(hasNonZero([...bucketLines, ...countLines])).toBe(true);
    const countVal = findCount(body, 'claims-service');
    expect(countVal).toBeGreaterThanOrEqual(5);
    expect(hasNonZero(sumLines)).toBe(true);
  });
});
