import { createServer } from '../src/server.js';
import { withMetricsServer } from '../../test-utils/withMetricsServer.js';

let helper;
beforeAll(async () => {
  process.env.METRICS_ENABLED = 'true';
  helper = withMetricsServer(createServer);
  await helper.waitForMetrics();
});
afterAll(async () => {
  await helper?.close();
});

describe('metrics exposure claims', () => {
  test('GET /metrics exposes histogram & gauge', async () => {
    const res = await helper.get('/metrics');
    expect(res.statusCode).toBe(200);
    let body = res.body || '';
    if (!body.includes('outbox_publish_latency_seconds_bucket')) {
      await new Promise(r => setTimeout(r, 100));
      body = (await helper.get('/metrics')).body || '';
    }
    expect(body).toContain('outbox_publish_latency_seconds_bucket');
    expect(body).toContain('outbox_pending_rows');
  });
  test('increments HTTP counter with route label', async () => {
    await helper.get('/health');
    const m = await helper.get('/metrics');
    expect(m.statusCode).toBe(200);
    const text = m.body || '';
    expect(text).toMatch(/service_http_requests_total\{[^}]*route="\/health"[^}]*\}\s+\d+/);
  });
});
