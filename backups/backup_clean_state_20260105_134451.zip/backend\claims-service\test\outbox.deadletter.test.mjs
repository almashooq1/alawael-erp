const { Outbox } = require('../../../shared/outbox/index.js');
import { runMigrations } from '../../scripts/run-migrations.mjs';

describe('claims outbox dead-letter (requires Postgres)', () => {
  const svcUrl = process.env.CLAIMS_DATABASE_URL || process.env.DATABASE_URL;
  if (!svcUrl) {
    test('skipped: DATABASE_URL or CLAIMS_DATABASE_URL not set', () => {});
    return;
  }

  const databaseUrl = svcUrl;

  test('moves to dead-letter when publish fails and attempts exhausted', async () => {
    await runMigrations({ databaseUrl, logger: { info() {} } });
    process.env.OUTBOX_MAX_ATTEMPTS = '1';
    process.env.OUTBOX_USE_NEXT_ATTEMPT_AT = 'false';

    const failingBus = {
      publish: async () => {
        throw new Error('synthetic failure');
      },
    };
    const outbox = new Outbox({ logger: console, bus: failingBus, serviceName: 'claims-service' });
    await outbox.enqueue({ topic: 'test.events', event: { svc: 'claims' } });

    const flushed = await outbox.flushBatch(10);
    expect(flushed).toBe(0);

    const { Pool } = await import('pg');
    const pool = new Pool({ connectionString: databaseUrl });
    const client = await pool.connect();
    try {
      const dlq = await client.query('SELECT count(*)::int AS c FROM outbox_deadletter');
      expect(dlq.rows[0].c).toBeGreaterThanOrEqual(1);
    } finally {
      client.release();
      await pool.end();
    }
  }, 20000);
});
