module.exports = {
  process() {
    return 'module.exports = {}';
  },
};
